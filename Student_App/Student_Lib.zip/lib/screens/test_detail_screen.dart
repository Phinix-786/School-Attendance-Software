// lib/screens/test_detail_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/student_firebase_service.dart';
import '../backend_image.dart';

class StudentTestDetailScreen extends StatefulWidget {
  final SchoolTest test;
  final String schoolId, sectionId, classId, studentId;

  const StudentTestDetailScreen({
    super.key,
    required this.test,
    required this.schoolId,
    required this.sectionId,
    required this.classId,
    required this.studentId,
  });

  @override
  State<StudentTestDetailScreen> createState() =>
      _StudentTestDetailScreenState();
}

class _StudentTestDetailScreenState extends State<StudentTestDetailScreen> {
  TestResult? _result;
  bool        _loadingResult = true;
  int         _imgIndex      = 0;

  @override
  void initState() {
    super.initState();
    _loadResult();
  }

  Future<void> _loadResult() async {
    final r = await StudentFirebaseService.getMyResult(
        widget.schoolId, widget.sectionId, widget.classId,
        widget.test.id, widget.studentId);
    if (mounted) setState(() { _result = r; _loadingResult = false; });
  }

  @override
  Widget build(BuildContext context) {
    final test      = widget.test;
    final testDate  = '${test.testDate.day}/${test.testDate.month}/${test.testDate.year}';
    final isUpcoming = test.testDate.isAfter(DateTime.now());

    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Text('Test Details',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   19,
                            fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color:        kTeal.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(test.subject,
                              style: TextStyle(
                                  color:      cNavy(context),
                                  fontSize:   12,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: isUpcoming
                                ? kPink.withValues(alpha: 0.2)
                                : cBorder(context),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(isUpcoming ? 'Upcoming' : 'Past',
                              style: TextStyle(
                                  color: isUpcoming
                                      ? kNavy
                                      : cMuted(context),
                                  fontSize:   11,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(test.topic,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   20,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Icon(Icons.calendar_today_outlined,
                            size: 16, color: cMuted(context)),
                        const SizedBox(width: 6),
                        Text('Test Date: $testDate',
                            style: TextStyle(
                                color: cNavy(context), fontSize: 13)),
                      ],
                    ),
                    if (test.imageUrls.isNotEmpty) ...[
                      const SizedBox(height: 14),
                      Text('Test Material (${test.imageUrls.length})',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: AspectRatio(
                          aspectRatio: 4 / 3,
                          child: BackendImage(test.imageUrls[_imgIndex],
                              fit: BoxFit.cover),
                        ),
                      ),
                    ],
                    if (test.instructions.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text('Instructions',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Container(
                        width:   double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(14),
                          border:       Border.all(color: cBorder(context)),
                        ),
                        child: Text(test.instructions,
                            style: TextStyle(
                                color:    cBlue(context),
                                fontSize: 14,
                                height:   1.5)),
                      ),
                    ],
                    if (!isUpcoming) ...[
                      const SizedBox(height: 20),
                      Text('Result',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   16,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 10),
                      _loadingResult
                          ? Center(
                              child: CircularProgressIndicator(
                                  color: isDark(context)
                                      ? kDarkTeal
                                      : kTeal))
                          : _result == null
                              ? Container(
                                  padding: const EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                    color:        cCard(context),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                        color: cBorder(context)),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Result not published yet.',
                                      style: TextStyle(
                                          color:    cMuted(context),
                                          fontSize: 14),
                                    ),
                                  ),
                                )
                              : _ResultCard(result: _result!),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final TestResult result;
  const _ResultCard({required this.result});

  @override
  Widget build(BuildContext context) {
    if (result.wasAbsent) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(color: kNavy.withValues(alpha: 0.06),
                blurRadius: 16, offset: const Offset(0, 4)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:  const Color(0xFFF59E0B).withValues(alpha: 0.1),
                border: Border.all(
                    color: const Color(0xFFF59E0B), width: 3),
              ),
              child: const Center(
                child: Text('—',
                    style: TextStyle(
                        color:      Color(0xFFF59E0B),
                        fontSize:   26,
                        fontWeight: FontWeight.w900)),
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Absent on test day',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   16,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF59E0B).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: const Color(0xFFF59E0B).withValues(alpha: 0.4)),
                    ),
                    child: const Text('Absent',
                        style: TextStyle(
                            color:      Color(0xFFF59E0B),
                            fontSize:   12,
                            fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    final pct = result.percentage;
    Color color;
    String grade;
    if (pct >= 90)       { color = const Color(0xFF16A34A); grade = 'A+'; }
    else if (pct >= 80)  { color = const Color(0xFF16A34A); grade = 'A';  }
    else if (pct >= 70)  { color = const Color(0xFF2563EB); grade = 'B';  }
    else if (pct >= 60)  { color = const Color(0xFFF59E0B); grade = 'C';  }
    else if (pct >= 50)  { color = const Color(0xFFF59E0B); grade = 'D';  }
    else                 { color = kError;                  grade = 'F';  }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(color: kNavy.withValues(alpha: 0.06),
              blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color:  color.withValues(alpha: 0.12),
                  border: Border.all(color: color, width: 3),
                ),
                child: Center(
                  child: Text(grade,
                      style: TextStyle(
                          color:      color,
                          fontSize:   22,
                          fontWeight: FontWeight.w900)),
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${result.marksObtained} / ${result.marksTotal}',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   26,
                            fontWeight: FontWeight.w900)),
                    Text('${pct.toStringAsFixed(1)}%',
                        style: TextStyle(
                            color:      color,
                            fontSize:   15,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
          if (result.remarks.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              width:   double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:        cBg(context),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Teacher's Remarks",
                      style: TextStyle(
                          color:         cMuted(context),
                          fontSize:      11,
                          fontWeight:    FontWeight.w700,
                          letterSpacing: 0.5)),
                  const SizedBox(height: 6),
                  Text(result.remarks,
                      style: TextStyle(
                          color:    cNavy(context),
                          fontSize: 14,
                          height:   1.4)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
