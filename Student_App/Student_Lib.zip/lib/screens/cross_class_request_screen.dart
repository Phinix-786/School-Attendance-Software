// lib/screens/cross_class_request_screen.dart
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/student_firebase_service.dart';

class CrossClassRequestScreen extends StatefulWidget {
  final Map<String, String> session;
  const CrossClassRequestScreen({super.key, required this.session});

  @override
  State<CrossClassRequestScreen> createState() =>
      _CrossClassRequestScreenState();
}

class _CrossClassRequestScreenState extends State<CrossClassRequestScreen> {
  final _targetNameCtrl  = TextEditingController();
  final _targetClassCtrl = TextEditingController();

  List<CrossChatRequest> _myRequests = [];
  bool _loadingReqs = true;
  bool _submitting  = false;
  bool _success     = false;
  String? _error;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  @override
  void dispose() {
    _targetNameCtrl.dispose();
    _targetClassCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadRequests() async {
    setState(() => _loadingReqs = true);
    final reqs = await StudentFirebaseService.getMyCrossClassRequests(
        _schoolId, _sectionId, _classId, _studentId);
    if (mounted) setState(() { _myRequests = reqs; _loadingReqs = false; });
  }

  Future<void> _submit() async {
    final targetName  = _targetNameCtrl.text.trim();
    final targetClass = _targetClassCtrl.text.trim();

    if (targetName.isEmpty) {
      setState(() => _error = 'Please enter the target student\'s name.');
      return;
    }
    setState(() { _submitting = true; _error = null; });

    final req = CrossChatRequest(
      id:               const Uuid().v4(),
      requesterId:      _studentId,
      requesterName:    _name,
      requesterClassId: _classId,
      targetStudentId:  '',
      targetStudentName: targetName,
      targetClassId:    targetClass,
      status:           'pending',
      createdAt:        DateTime.now(),
    );

    try {
      await StudentFirebaseService.submitCrossClassRequest(
          _schoolId, _sectionId, _classId, req);
      _targetNameCtrl.clear();
      _targetClassCtrl.clear();
      setState(() { _submitting = false; _success = true; });
      _loadRequests();
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) setState(() => _success = false);
      });
    } catch (e) {
      if (mounted)
        setState(() { _submitting = false; _error = 'Failed. Try again.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Cross-Class Chat Request',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   16,
                fontWeight: FontWeight.w800)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Info banner
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color:        kTeal.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kTeal.withValues(alpha: 0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline_rounded,
                    color: kTeal, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Your class teacher will review and approve this request before you can chat.',
                    style: TextStyle(
                        color:    cNavy(context),
                        fontSize: 12,
                        height:   1.4),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          Text('New Request',
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   15,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),

          TextField(
            controller: _targetNameCtrl,
            style: TextStyle(color: cNavy(context), fontSize: 14),
            decoration: InputDecoration(
              labelText:  'Target Student Name *',
              labelStyle: TextStyle(color: cMuted(context), fontSize: 13),
              filled:     true,
              fillColor:  cCard(context),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: cBorder(context))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: cBorder(context))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: kTeal, width: 2)),
            ),
          ),
          const SizedBox(height: 12),

          TextField(
            controller: _targetClassCtrl,
            style: TextStyle(color: cNavy(context), fontSize: 14),
            decoration: InputDecoration(
              labelText:  'Their Class (e.g. 8-A)',
              labelStyle: TextStyle(color: cMuted(context), fontSize: 13),
              filled:     true,
              fillColor:  cCard(context),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: cBorder(context))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: cBorder(context))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: kTeal, width: 2)),
            ),
          ),

          if (_error != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color:        kError.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(_error!,
                  style: const TextStyle(color: kError, fontSize: 12)),
            ),
          ],
          if (_success) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color:        const Color(0xFF16A34A).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text('Request submitted! Awaiting teacher approval.',
                  style: TextStyle(
                      color: Color(0xFF16A34A), fontSize: 12)),
            ),
          ],
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: _submitting ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: kNavy,
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              child: _submitting
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2.5))
                  : const Text('Submit Request',
                      style: TextStyle(
                          fontSize:   15,
                          fontWeight: FontWeight.w700)),
            ),
          ),

          // My requests
          if (_myRequests.isNotEmpty) ...[
            const SizedBox(height: 24),
            Text('My Requests',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   15,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            ..._myRequests.map((r) => _RequestItem(req: r)),
          ],
        ],
      ),
    );
  }
}

class _RequestItem extends StatelessWidget {
  final CrossChatRequest req;
  const _RequestItem({required this.req});

  Color _statusColor(String s) {
    switch (s) {
      case 'approved': return const Color(0xFF16A34A);
      case 'rejected': return kError;
      default:         return const Color(0xFFF59E0B);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sc = _statusColor(req.status);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(12),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(req.targetStudentName,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   13,
                        fontWeight: FontWeight.w700)),
                if (req.targetClassId.isNotEmpty)
                  Text('Class: ${req.targetClassId}',
                      style: TextStyle(
                          color: cMuted(context), fontSize: 11)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color:        sc.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: sc.withValues(alpha: 0.35)),
            ),
            child: Text(req.status.toUpperCase(),
                style: TextStyle(
                    color:      sc,
                    fontSize:   9,
                    fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}
