// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/student_firebase_service.dart';
import 'login_screen.dart';
import 'homework_detail_screen.dart';
import 'test_detail_screen.dart';
import 'leave_request_screen.dart';
import 'notices_screen.dart';
import 'student_chat_page.dart';
import 'privacy_policy_screen.dart';

class StudentHomeScreen extends StatefulWidget {
  final Map<String, String> session;
  const StudentHomeScreen({super.key, required this.session});

  @override
  State<StudentHomeScreen> createState() => _StudentHomeScreenState();
}

class _StudentHomeScreenState extends State<StudentHomeScreen> {
  int _tab = 0; // 0=Homework 1=Tests 2=Chat 3=Leave

  List<Homework>   _homeworks = [];
  List<SchoolTest> _tests     = [];
  bool             _loading   = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? 'Student';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    switch (_tab) {
      case 0:
        final hw = await StudentFirebaseService.getHomeworks(
            _schoolId, _sectionId, _classId);
        if (mounted) setState(() { _homeworks = hw; _loading = false; });
        break;
      case 1:
        final ts = await StudentFirebaseService.getTests(
            _schoolId, _sectionId, _classId);
        if (mounted) setState(() { _tests = ts; _loading = false; });
        break;
      default:
        if (mounted) setState(() => _loading = false);
        break;
    }
  }

  Future<void> _logout() async {
    await StudentFirebaseService.clearSession();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const StudentLoginScreen()),
        (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 12),
            _buildTabBar(),
            const SizedBox(height: 8),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 20, 12, 0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Hello,',
                    style: TextStyle(color: cMuted(context), fontSize: 13)),
                Text(_name,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   22,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color:        kTeal.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('Student Portal',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   11,
                          fontWeight: FontWeight.w700)),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip:  'Notices',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(
                    builder: (_) =>
                        StudentNoticesScreen(session: widget.session))),
            icon: Icon(Icons.notifications_outlined,
                color: cMuted(context), size: 22),
          ),
          IconButton(
            tooltip:  'Privacy Policy',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(
                    builder: (_) => const PrivacyPolicyScreen())),
            icon: Icon(Icons.privacy_tip_outlined,
                color: cMuted(context), size: 20),
          ),
          IconButton(
            onPressed: _logout,
            icon: Icon(Icons.logout_rounded,
                color: cMuted(context), size: 22),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    const tabs = [
      ('📚', 'Homework'),
      ('📝', 'Tests'),
      ('💬', 'Chat'),
      ('🏖️', 'Leave'),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color:      kNavy.withValues(alpha: 0.06),
                blurRadius: 12,
                offset:     const Offset(0, 3)),
          ],
        ),
        child: Row(
          children: List.generate(tabs.length, (i) {
            final (emoji, label) = tabs[i];
            final active = _tab == i;
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() { _tab = i; _loading = true; });
                  _load();
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color:        active ? kNavy : Colors.transparent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(
                    children: [
                      Text(emoji, style: const TextStyle(fontSize: 14)),
                      const SizedBox(height: 2),
                      Text(label,
                          style: TextStyle(
                              color:      active ? Colors.white : cMuted(context),
                              fontSize:   10,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return Center(
          child: CircularProgressIndicator(
              color: isDark(context) ? kDarkTeal : kTeal));
    }

    switch (_tab) {
      case 0:
        return _HomeworkFeed(homeworks: _homeworks, onRefresh: _load);
      case 1:
        return _TestFeed(
          tests: _tests,
          schoolId: _schoolId, sectionId: _sectionId,
          classId: _classId, studentId: _studentId,
          onRefresh: _load,
        );
      case 2:
        return _ChatEntryTab(session: widget.session);
      case 3:
        return _LeaveFeed(session: widget.session);
      default:
        return const SizedBox.shrink();
    }
  }
}

// ── Homework Feed ─────────────────────────────────────────────
class _HomeworkFeed extends StatelessWidget {
  final List<Homework> homeworks;
  final VoidCallback   onRefresh;
  const _HomeworkFeed({required this.homeworks, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    if (homeworks.isEmpty) {
      return Center(child: Text('No homework assigned yet.',
          style: TextStyle(color: cMuted(context), fontSize: 14)));
    }
    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        itemCount: homeworks.length,
        itemBuilder: (ctx, i) {
          final hw = homeworks[i];
          return GestureDetector(
            onTap: () => Navigator.push(ctx,
                MaterialPageRoute(
                    builder: (_) => StudentHomeworkDetailScreen(hw: hw))),
            child: _HomeworkCard(hw: hw),
          );
        },
      ),
    );
  }
}

class _HomeworkCard extends StatelessWidget {
  final Homework hw;
  const _HomeworkCard({required this.hw});

  @override
  Widget build(BuildContext context) {
    final date = '${hw.createdAt.day}/${hw.createdAt.month}/${hw.createdAt.year}';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: kNavy.withValues(alpha: 0.05),
              blurRadius: 10, offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(hw.subject,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   11,
                        fontWeight: FontWeight.w700)),
              ),
              const Spacer(),
              Text(date, style: TextStyle(color: cMuted(context), fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(hw.topic,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   15,
                  fontWeight: FontWeight.w700)),
          if (hw.instructions.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(hw.instructions,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: cBlue(context), fontSize: 13)),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.chevron_right_rounded, color: cMuted(context), size: 18),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Test Feed ─────────────────────────────────────────────────
class _TestFeed extends StatelessWidget {
  final List<SchoolTest> tests;
  final String schoolId, sectionId, classId, studentId;
  final VoidCallback onRefresh;

  const _TestFeed({
    required this.tests, required this.schoolId, required this.sectionId,
    required this.classId, required this.studentId, required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    if (tests.isEmpty) {
      return Center(child: Text('No tests scheduled.',
          style: TextStyle(color: cMuted(context), fontSize: 14)));
    }
    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        itemCount: tests.length,
        itemBuilder: (ctx, i) {
          final test = tests[i];
          final isUpcoming = test.testDate.isAfter(DateTime.now());
          return GestureDetector(
            onTap: () => Navigator.push(ctx,
                MaterialPageRoute(
                    builder: (_) => StudentTestDetailScreen(
                          test: test, schoolId: schoolId,
                          sectionId: sectionId, classId: classId,
                          studentId: studentId,
                        ))),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: kNavy.withValues(alpha: 0.05),
                      blurRadius: 10, offset: const Offset(0, 3)),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(test.topic,
                            style: TextStyle(
                                color:      cNavy(context),
                                fontSize:   15,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color:        kTeal.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(test.subject,
                                  style: TextStyle(
                                      color:      cNavy(context),
                                      fontSize:   10,
                                      fontWeight: FontWeight.w600)),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '${test.testDate.day}/${test.testDate.month}/${test.testDate.year}',
                              style: TextStyle(
                                  color: cMuted(context), fontSize: 11),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: isUpcoming
                          ? kPink.withValues(alpha: 0.2)
                          : cBorder(context),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(isUpcoming ? 'Upcoming' : 'Past',
                        style: TextStyle(
                            color:      isUpcoming ? kNavy : cMuted(context),
                            fontSize:   11,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Chat Entry Tab — just opens the full Chat Page ────────────
class _ChatEntryTab extends StatelessWidget {
  final Map<String, String> session;
  const _ChatEntryTab({required this.session});

  @override
  Widget build(BuildContext context) {
    // Auto-push on first render so the tab feels native
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => StudentChatPage(session: session)),
      );
    });
    return const Center(child: CircularProgressIndicator(strokeWidth: 2));
  }
}

// ── Leave Feed ────────────────────────────────────────────────
class _LeaveFeed extends StatefulWidget {
  final Map<String, String> session;
  const _LeaveFeed({required this.session});

  @override
  State<_LeaveFeed> createState() => _LeaveFeedState();
}

class _LeaveFeedState extends State<_LeaveFeed> {
  List<LeaveRequest> _leaves  = [];
  bool               _loading = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _studentId => widget.session['studentId']!;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final leaves = await StudentFirebaseService.getMyLeaveRequests(
        _schoolId, _sectionId, _studentId);
    if (mounted) setState(() { _leaves = leaves; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(
          child: CircularProgressIndicator(
              color: isDark(context) ? kDarkTeal : kTeal));
    }

    return Stack(
      children: [
        _leaves.isEmpty
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('🏖️', style: TextStyle(fontSize: 48)),
                    const SizedBox(height: 12),
                    Text('No leave requests.',
                        style: TextStyle(
                            color: cMuted(context), fontSize: 14)),
                    const SizedBox(height: 6),
                    Text('Tap + to submit a leave request.',
                        style: TextStyle(
                            color: cMuted(context), fontSize: 13)),
                  ],
                ),
              )
            : RefreshIndicator(
                onRefresh: _load,
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                  itemCount: _leaves.length,
                  itemBuilder: (_, i) => _LeaveCard(req: _leaves[i]),
                ),
              ),
        Positioned(
          bottom: 16, right: 16,
          child: FloatingActionButton.extended(
            heroTag: 'leave_fab',
            backgroundColor: kNavy,
            foregroundColor: Colors.white,
            icon:  const Icon(Icons.add_rounded),
            label: const Text('Leave Request',
                style: TextStyle(fontWeight: FontWeight.w700)),
            onPressed: () async {
              await Navigator.push(context,
                  MaterialPageRoute(
                      builder: (_) =>
                          StudentLeaveRequestScreen(
                              session: widget.session)));
              _load();
            },
          ),
        ),
      ],
    );
  }
}

class _LeaveCard extends StatelessWidget {
  final LeaveRequest req;
  const _LeaveCard({required this.req});

  Color _statusColor(String s) {
    switch (s) {
      case 'approved': return const Color(0xFF16A34A);
      case 'rejected': return kError;
      default:         return const Color(0xFFF59E0B);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sc   = _statusColor(req.status);
    final date =
        '${req.requestedDate.day}/${req.requestedDate.month}/${req.requestedDate.year}';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(color: kNavy.withValues(alpha: 0.04),
              blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(date,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   14,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(req.reason,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: cBlue(context), fontSize: 13)),
                if (req.remarks.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text('Remark: ${req.remarks}',
                      style: TextStyle(
                          color: cMuted(context), fontSize: 11)),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color:        sc.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: sc.withValues(alpha: 0.35)),
            ),
            child: Text(req.status.toUpperCase(),
                style: TextStyle(
                    color:      sc,
                    fontSize:   10,
                    fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}
