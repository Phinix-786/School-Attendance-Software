// lib/screens/login_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../services/student_firebase_service.dart';
import 'home_screen.dart';
import 'privacy_consent_screen.dart';

class StudentLoginScreen extends StatefulWidget {
  const StudentLoginScreen({super.key});
  @override
  State<StudentLoginScreen> createState() => _StudentLoginScreenState();
}

class _StudentLoginScreenState extends State<StudentLoginScreen> {
  final _schoolCtrl = TextEditingController();
  final _loginCtrl  = TextEditingController();
  final _passCtrl   = TextEditingController();
  bool    _loading = false;
  String? _error;
  bool    _obscure = true;

  @override
  void dispose() {
    _schoolCtrl.dispose();
    _loginCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final schoolId = _schoolCtrl.text.trim();
    final loginId  = _loginCtrl.text.trim();
    final pass     = _passCtrl.text;

    if (schoolId.isEmpty || loginId.isEmpty || pass.isEmpty) {
      setState(() => _error = 'Please fill in all fields.');
      return;
    }
    setState(() { _loading = true; _error = null; });

    try {
      final result = await StudentFirebaseService.login(schoolId, loginId, pass);

      if (!mounted) return;

      if (result == null) {
        setState(() { _loading = false; _error = 'Invalid ID or password.'; });
        return;
      }

      final student   = result['student'] as dynamic;
      final sectionId = result['sectionId'] as String;
      final classId   = result['classId']   as String;

      await StudentFirebaseService.saveSession(
        schoolId:    schoolId,
        sectionId:   sectionId,
        classId:     classId,
        studentId:   student.id,
        studentName: student.name,
        loginId:     loginId,
      );

      if (!mounted) return;
      final session = await StudentFirebaseService.getSavedSession();
      if (!mounted) return;
      final destination = StudentHomeScreen(session: session!);
      final agreed      = await PrivacyConsentScreen.hasAgreed();
      if (!mounted) return;
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (_) => agreed
                  ? destination
                  : PrivacyConsentScreen(nextScreen: destination)));
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Connection error. Try again.'; });
    }
  }

  Widget _field({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboardType,
  }) {
    return Container(
      decoration: BoxDecoration(
        color:        cBg(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: TextField(
        controller:   ctrl,
        obscureText:  obscure,
        keyboardType: keyboardType,
        style: TextStyle(color: cNavy(context), fontSize: 15),
        decoration: InputDecoration(
          labelText:      label,
          labelStyle:     TextStyle(color: cMuted(context), fontSize: 14),
          prefixIcon:     Icon(icon, color: cMuted(context), size: 20),
          suffixIcon:     suffix,
          border:         InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 30),
              Container(
                width: 86, height: 86,
                decoration: BoxDecoration(
                  color:        const Color(0xFFEEDFC8),
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                        color:      kNavy.withValues(alpha: 0.12),
                        blurRadius: 24,
                        offset:     const Offset(0, 8)),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(22),
                  child: Image.asset('assets/icon.png',
                      width: 86, height: 86, fit: BoxFit.cover),
                ),
              ),
              const SizedBox(height: 20),
              Text('Student Portal',
                  style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   26,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.5)),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: kTeal.withValues(alpha: 0.35)),
                ),
                child: Text('✦  View homework, tests & chat',
                    style: TextStyle(
                        color:         isDark(context) ? kDarkTeal : kNavy,
                        fontSize:      12,
                        fontWeight:    FontWeight.w700,
                        letterSpacing: 0.5)),
              ),
              const SizedBox(height: 40),
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color:        cCard(context),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                        color:      kNavy.withValues(alpha: 0.06),
                        blurRadius: 20,
                        offset:     const Offset(0, 6)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _field(ctrl: _schoolCtrl, label: 'School ID',
                        icon: Icons.school_outlined),
                    const SizedBox(height: 14),
                    _field(ctrl: _loginCtrl, label: 'Student ID',
                        icon: Icons.badge_outlined),
                    const SizedBox(height: 14),
                    _field(
                      ctrl:    _passCtrl,
                      label:   'Password',
                      icon:    Icons.lock_outline,
                      obscure: _obscure,
                      suffix: IconButton(
                        icon: Icon(
                            _obscure
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            color: cMuted(context), size: 20),
                        onPressed: () =>
                            setState(() => _obscure = !_obscure),
                      ),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color:        kError.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: kError.withValues(alpha: 0.3)),
                        ),
                        child: Text(_error!,
                            style: const TextStyle(
                                color: kError, fontSize: 13)),
                      ),
                    ],
                    const SizedBox(height: 24),
                    SizedBox(
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _loading ? null : _login,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kNavy,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        child: _loading
                            ? const SizedBox(
                                width: 22, height: 22,
                                child: CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2.5))
                            : const Text('Sign In',
                                style: TextStyle(
                                    fontSize:   16,
                                    fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
