// lib/screens/student_teacher_inbox_screen.dart
// Student's private conversations with teachers.
// Student can start a new DM with any teacher of their class.
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/student_firebase_service.dart';
import 'student_chat_screen.dart';

class StudentTeacherInboxScreen extends StatefulWidget {
  final Map<String, String> session;
  const StudentTeacherInboxScreen({super.key, required this.session});

  @override
  State<StudentTeacherInboxScreen> createState() =>
      _StudentTeacherInboxScreenState();
}

class _StudentTeacherInboxScreenState
    extends State<StudentTeacherInboxScreen> {
  List<Map<String, dynamic>> _chats    = [];
  List<Map<String, dynamic>> _teachers = [];
  bool _loading = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final [chats, teachers] = await Future.wait([
      StudentFirebaseService.getMyTeacherChats(
          _schoolId, _sectionId, _studentId),
      StudentFirebaseService.getTeachersForClass(
          _schoolId, _sectionId, _classId),
    ]);
    if (mounted) {
      setState(() {
        _chats    = chats    as List<Map<String, dynamic>>;
        _teachers = teachers as List<Map<String, dynamic>>;
        _loading  = false;
      });
    }
  }

  Future<void> _openChat(String teacherId, String teacherName) async {
    final chatId = await StudentFirebaseService.getOrCreateTeacherChatId(
      _schoolId, _sectionId, _classId,
      teacherId, teacherName, _studentId, _name,
    );
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StudentChatScreen(
          title:          teacherName,
          subtitle:       'Teacher',
          myId:           _studentId,
          myName:         _name,
          myType:         'student',
          messagesStream: StudentFirebaseService.teacherChatMessagesStream(
              _schoolId, _sectionId, chatId),
          onSend: (msg) => StudentFirebaseService.sendStudentMessage(
              _schoolId, _sectionId, chatId, msg),
        ),
      ),
    );
    _load();
  }

  void _pickTeacher() {
    if (_teachers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No teachers found for your class.')));
      return;
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: cCard(context),
      shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 6),
          Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                  color:        cBorder(ctx),
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text('Message a Teacher',
                style: TextStyle(
                    color:      cNavy(ctx),
                    fontSize:   15,
                    fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _teachers.length,
              itemBuilder: (_, i) {
                final t    = _teachers[i];
                final name = (t['name'] as String?) ?? 'Teacher';
                final subjectsMap = t['classSubjects'] as Map? ?? {};
                final subject =
                    (subjectsMap[_classId] as String?) ?? '';
                final display = subject.isNotEmpty
                    ? '$name ($subject)'
                    : name;
                return ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 20),
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                        color: kTeal.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(9)),
                    child: Center(
                      child: Text(
                          name.isNotEmpty
                              ? name[0].toUpperCase()
                              : 'T',
                          style: TextStyle(
                              color:      cNavy(ctx),
                              fontSize:   15,
                              fontWeight: FontWeight.w800)),
                    ),
                  ),
                  title: Text(display,
                      style: TextStyle(
                          color:      cNavy(ctx),
                          fontSize:   14,
                          fontWeight: FontWeight.w600)),
                  onTap: () {
                    Navigator.pop(ctx);
                    _openChat(t['id'] ?? '', name);
                  },
                );
              },
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Messages with Teachers',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   16,
                fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: Icon(Icons.edit_square,
                color: cNavy(context), size: 20),
            tooltip: 'New Conversation',
            onPressed: _pickTeacher,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _loading
          ? Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal,
                  strokeWidth: 2))
          : _chats.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.chat_bubble_outline_rounded,
                          color: cBorder(context), size: 48),
                      const SizedBox(height: 14),
                      Text('No conversations yet.',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   15,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text(
                          'Tap ✏ to message a teacher directly.',
                          style: TextStyle(
                              color:    cMuted(context),
                              fontSize: 13)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
                    itemCount: _chats.length,
                    itemBuilder: (_, i) {
                      final c    = _chats[i];
                      final name =
                          (c['teacherName'] as String?) ?? 'Teacher';
                      final last =
                          (c['lastMessage'] as String?) ?? '';
                      return GestureDetector(
                        onTap: () => _openChat(
                            c['teacherId'] ?? '', name),
                        child: Container(
                          margin:
                              const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: cCard(context),
                            borderRadius:
                                BorderRadius.circular(14),
                            boxShadow: [
                              BoxShadow(
                                  color: kNavy.withValues(
                                      alpha: 0.04),
                                  blurRadius: 8,
                                  offset:
                                      const Offset(0, 2)),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 44, height: 44,
                                decoration: BoxDecoration(
                                  color: kTeal.withValues(
                                      alpha: 0.18),
                                  borderRadius:
                                      BorderRadius.circular(12),
                                ),
                                child: Center(
                                  child: Text(
                                    name.isNotEmpty
                                        ? name[0].toUpperCase()
                                        : 'T',
                                    style: TextStyle(
                                        color: cNavy(context),
                                        fontSize: 18,
                                        fontWeight:
                                            FontWeight.w800),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(name,
                                        style: TextStyle(
                                            color: cNavy(context),
                                            fontSize: 14,
                                            fontWeight:
                                                FontWeight.w700)),
                                    if (last.isNotEmpty)
                                      Text(last,
                                          maxLines: 1,
                                          overflow:
                                              TextOverflow.ellipsis,
                                          style: TextStyle(
                                              color:
                                                  cMuted(context),
                                              fontSize: 12)),
                                  ],
                                ),
                              ),
                              Icon(Icons.chevron_right_rounded,
                                  color: cMuted(context), size: 18),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
