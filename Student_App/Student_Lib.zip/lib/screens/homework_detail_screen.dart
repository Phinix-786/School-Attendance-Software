// lib/screens/homework_detail_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../backend_image.dart';

class StudentHomeworkDetailScreen extends StatefulWidget {
  final Homework hw;
  const StudentHomeworkDetailScreen({super.key, required this.hw});

  @override
  State<StudentHomeworkDetailScreen> createState() =>
      _StudentHomeworkDetailScreenState();
}

class _StudentHomeworkDetailScreenState
    extends State<StudentHomeworkDetailScreen> {
  int _imgIndex = 0;

  @override
  Widget build(BuildContext context) {
    final hw   = widget.hw;
    final date =
        '${hw.createdAt.day}/${hw.createdAt.month}/${hw.createdAt.year}';

    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Text('Homework Details',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   19,
                            fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color:        kTeal.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(hw.subject,
                              style: TextStyle(
                                  color:      cNavy(context),
                                  fontSize:   12,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const Spacer(),
                        Text(date,
                            style: TextStyle(
                                color: cMuted(context), fontSize: 12)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(hw.topic,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   20,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 16),
                    if (hw.pageNumbers.isNotEmpty) ...[
                      Row(
                        children: [
                          Icon(Icons.menu_book_outlined,
                              size: 16, color: cMuted(context)),
                          const SizedBox(width: 6),
                          Text('Pages: ${hw.pageNumbers}',
                              style: TextStyle(
                                  color: cNavy(context), fontSize: 13)),
                        ],
                      ),
                      const SizedBox(height: 12),
                    ],
                    if (hw.imageUrls.isNotEmpty) ...[
                      Text('Homework Images (${hw.imageUrls.length})',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(14),
                        child: AspectRatio(
                          aspectRatio: 4 / 3,
                          child: BackendImage(hw.imageUrls[_imgIndex],
                              fit: BoxFit.cover),
                        ),
                      ),
                      if (hw.imageUrls.length > 1) ...[
                        const SizedBox(height: 8),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: List.generate(hw.imageUrls.length, (i) {
                              final sel = i == _imgIndex;
                              return GestureDetector(
                                onTap: () =>
                                    setState(() => _imgIndex = i),
                                child: Container(
                                  margin:
                                      const EdgeInsets.only(right: 8),
                                  width:  54, height: 54,
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.circular(10),
                                    border: Border.all(
                                        color: sel
                                            ? kNavy
                                            : Colors.transparent,
                                        width: 2),
                                  ),
                                  child: ClipRRect(
                                    borderRadius:
                                        BorderRadius.circular(8),
                                    child: BackendImage(hw.imageUrls[i],
                                        fit: BoxFit.cover),
                                  ),
                                ),
                              );
                            }),
                          ),
                        ),
                      ],
                      const SizedBox(height: 16),
                    ],
                    if (hw.instructions.isNotEmpty) ...[
                      Text('Instructions',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Container(
                        width:   double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(14),
                          border:       Border.all(color: cBorder(context)),
                        ),
                        child: Text(hw.instructions,
                            style: TextStyle(
                                color:    cBlue(context),
                                fontSize: 14,
                                height:   1.5)),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
