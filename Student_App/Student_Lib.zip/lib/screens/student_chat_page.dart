// lib/screens/student_chat_page.dart
//
// Student Chat — two tabs:
//   Teachers → all teachers of class listed, tap to DM
//   Students → own class on top (highlighted), then other classes;
//              same-class tap → DM immediately,
//              other-class tap → shows cross-class request flow
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/student_firebase_service.dart';
import 'class_chat_screen.dart';
import 'student_chat_screen.dart';
import 'student_teacher_inbox_screen.dart';

class StudentChatPage extends StatefulWidget {
  final Map<String, String> session;
  const StudentChatPage({super.key, required this.session});

  @override
  State<StudentChatPage> createState() => _StudentChatPageState();
}

class _StudentChatPageState extends State<StudentChatPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Chat',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   18,
                fontWeight: FontWeight.w800)),
        bottom: TabBar(
          controller:           _tabs,
          indicatorColor:       kNavy,
          labelColor:           cNavy(context) as Color,
          unselectedLabelColor: cMuted(context),
          labelStyle: const TextStyle(
              fontSize: 13, fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: 'Teachers'),
            Tab(text: 'Students'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _TeachersTab(session: widget.session),
          _StudentsTab(session: widget.session),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// TEACHERS tab — list all class teachers, search, tap to DM
// ══════════════════════════════════════════════════════════════
class _TeachersTab extends StatefulWidget {
  final Map<String, String> session;
  const _TeachersTab({required this.session});

  @override
  State<_TeachersTab> createState() => _TeachersTabState();
}

class _TeachersTabState extends State<_TeachersTab> {
  final _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _all     = [];
  List<Map<String, dynamic>> _results = [];
  bool _loading = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_filter);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final teachers = await StudentFirebaseService.getTeachersForClass(
        _schoolId, _sectionId, _classId);
    if (mounted)
      setState(() { _all = teachers; _results = teachers; _loading = false; });
  }

  void _filter() {
    final q = _searchCtrl.text.toLowerCase().trim();
    setState(() {
      _results = q.isEmpty
          ? _all
          : _all.where((t) =>
              ((t['name'] as String?) ?? '').toLowerCase().contains(q)).toList();
    });
  }

  String _firstName(String full) {
    final parts = full.trim().split(' ');
    return parts.isNotEmpty ? parts.first : full;
  }

  Future<void> _openChat(Map<String, dynamic> t) async {
    final teacherId   = (t['id']   as String?) ?? '';
    final teacherName = (t['name'] as String?) ?? 'Teacher';
    final subjectsMap = t['classSubjects'] as Map? ?? {};
    final subject     = (subjectsMap[_classId] as String?) ?? '';

    final chatId = await StudentFirebaseService.getOrCreateTeacherChatId(
      _schoolId, _sectionId, _classId,
      teacherId, teacherName, _studentId, _name,
    );
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StudentChatScreen(
          title:          '${_firstName(teacherName)}${subject.isNotEmpty ? " ($subject)" : ""}',
          subtitle:       'Teacher',
          myId:           _studentId,
          myName:         _name,
          myType:         'student',
          messagesStream: StudentFirebaseService.teacherChatMessagesStream(
              _schoolId, _sectionId, chatId),
          onSend: (msg) => StudentFirebaseService.sendStudentMessage(
              _schoolId, _sectionId, chatId, msg),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Container(
            decoration: BoxDecoration(
              color:        cCard(context),
              borderRadius: BorderRadius.circular(12),
              border:       Border.all(color: cBorder(context)),
            ),
            child: TextField(
              controller:  _searchCtrl,
              style: TextStyle(color: cNavy(context), fontSize: 14),
              decoration: InputDecoration(
                hintText:       'Search by name…',
                hintStyle:      TextStyle(
                    color: cMuted(context), fontSize: 14),
                prefixIcon:     Icon(Icons.search_rounded,
                    color: cMuted(context), size: 20),
                border:         InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 13),
              ),
            ),
          ),
        ),
        Expanded(
          child: _loading
              ? Center(
                  child: CircularProgressIndicator(
                      color: isDark(context) ? kDarkTeal : kTeal,
                      strokeWidth: 2))
              : _results.isEmpty
                  ? Center(
                      child: Text('No teachers found.',
                          style: TextStyle(
                              color: cMuted(context), fontSize: 14)))
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
                      itemCount: _results.length,
                      separatorBuilder: (_, __) =>
                          Divider(height: 1, color: cBorder(context)),
                      itemBuilder: (_, i) {
                        final t    = _results[i];
                        final name = (t['name'] as String?) ?? 'Teacher';
                        final subMap =
                            t['classSubjects'] as Map? ?? {};
                        final sub =
                            (subMap[_classId] as String?) ?? '';
                        return ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 4, vertical: 4),
                          leading: Container(
                            width: 42, height: 42,
                            decoration: BoxDecoration(
                              color:        kTeal.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: Center(
                              child: Text(
                                name.isNotEmpty
                                    ? name[0].toUpperCase()
                                    : 'T',
                                style: TextStyle(
                                    color:      kNavy,
                                    fontSize:   17,
                                    fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                          title: Text(
                            sub.isNotEmpty
                                ? '${_firstName(name)} ($sub)'
                                : name,
                            style: TextStyle(
                                color:      cNavy(context),
                                fontSize:   14,
                                fontWeight: FontWeight.w700)),
                          subtitle: Text('Teacher',
                              style: TextStyle(
                                  color: cMuted(context), fontSize: 11)),
                          trailing: Icon(Icons.chevron_right_rounded,
                              color: cMuted(context), size: 18),
                          onTap: () => _openChat(t),
                        );
                      },
                    ),
        ),
      ],
    );
  }
}

// ══════════════════════════════════════════════════════════════
// STUDENTS tab — own class first (highlighted), then others
// ══════════════════════════════════════════════════════════════
class _StudentsTab extends StatefulWidget {
  final Map<String, String> session;
  const _StudentsTab({required this.session});

  @override
  State<_StudentsTab> createState() => _StudentsTabState();
}

class _StudentsTabState extends State<_StudentsTab> {
  List<Map<String, dynamic>> _allClasses = [];
  Map<String, List<Map<String, dynamic>>> _classStudents = {};
  bool _loading = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final classes = await StudentFirebaseService.getAllClassesInSection(
        _schoolId, _sectionId);

    // Load students of own class immediately; others lazy
    final myStudents = await StudentFirebaseService.getStudentsOfClass(
        _schoolId, _sectionId, _classId);

    if (!mounted) return;
    setState(() {
      // Put own class first
      _allClasses = [
        ...classes.where((c) => c['id'] == _classId),
        ...classes.where((c) => c['id'] != _classId),
      ];
      _classStudents[_classId] =
          myStudents.where((s) => s['id'] != _studentId).toList();
      _loading = false;
    });
  }

  Future<List<Map<String, dynamic>>> _getStudents(String classId) async {
    if (_classStudents.containsKey(classId)) {
      return _classStudents[classId]!;
    }
    final students = await StudentFirebaseService.getStudentsOfClass(
        _schoolId, _sectionId, classId);
    final filtered =
        students.where((s) => s['id'] != _studentId).toList();
    if (mounted) {
      setState(() => _classStudents[classId] = filtered);
    }
    return filtered;
  }

  // Same-class: open cross_class_chat or DM directly
  Future<void> _openSameClassChat(Map<String, dynamic> s) async {
    final otherId   = (s['id']   as String?) ?? '';
    final otherName = (s['name'] as String?) ?? '';

    // Check if we already have an approved chat
    final chats = await StudentFirebaseService.getApprovedChatsForStudent(
        _schoolId, _sectionId, _classId, _studentId);
    final existing = chats.firstWhere(
        (c) => c.student1Id == otherId || c.student2Id == otherId,
        orElse: () => CrossClassChat(
            id: '', student1Id: '', student1Name: '',
            student2Id: '', student2Name: '', requesterClassId: ''));

    if (!mounted) return;
    if (existing.id.isNotEmpty) {
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => StudentChatScreen(
          title:          otherName,
          subtitle:       'Classmate',
          myId:           _studentId,
          myName:         _name,
          myType:         'student',
          messagesStream: StudentFirebaseService.crossChatMessagesStream(
              _schoolId, _sectionId, _classId, existing.id),
          onSend: (msg) => StudentFirebaseService.sendCrossClassMessage(
              _schoolId, _sectionId, _classId, existing.id, msg),
        ),
      ));
    } else {
      // For same-class, we let them DM directly without a request
      // (class teacher supervises via class chat anyway)
      final chatId = '${[_studentId, otherId]..sort()}'.hashCode.abs().toString();
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => StudentChatScreen(
          title:          otherName,
          subtitle:       'Classmate',
          myId:           _studentId,
          myName:         _name,
          myType:         'student',
          messagesStream: StudentFirebaseService.crossChatMessagesStream(
              _schoolId, _sectionId, _classId, chatId),
          onSend: (msg) => StudentFirebaseService.sendCrossClassMessage(
              _schoolId, _sectionId, _classId, chatId, msg),
        ),
      ));
    }
  }

  // Other class: check for existing approved chat or show request UI
  Future<void> _handleOtherClassStudent(
      Map<String, dynamic> s, String theirClassId) async {
    final otherId   = (s['id']   as String?) ?? '';
    final otherName = (s['name'] as String?) ?? '';

    // Check existing approved cross-class chat
    final chats = await StudentFirebaseService.getApprovedChatsForStudent(
        _schoolId, _sectionId, _classId, _studentId);
    final existing = chats.firstWhere(
        (c) => c.student1Id == otherId || c.student2Id == otherId,
        orElse: () => CrossClassChat(
            id: '', student1Id: '', student1Name: '',
            student2Id: '', student2Name: '', requesterClassId: ''));

    if (!mounted) return;

    if (existing.id.isNotEmpty) {
      // Already approved — open chat
      Navigator.push(context, MaterialPageRoute(
        builder: (_) => StudentChatScreen(
          title:          otherName,
          subtitle:       'Student (other class)',
          myId:           _studentId,
          myName:         _name,
          myType:         'student',
          messagesStream: StudentFirebaseService.crossChatMessagesStream(
              _schoolId, _sectionId,
              existing.requesterClassId, existing.id),
          onSend: (msg) => StudentFirebaseService.sendCrossClassMessage(
              _schoolId, _sectionId,
              existing.requesterClassId, existing.id, msg),
        ),
      ));
    } else {
      // Check if request already pending
      final pending = await StudentFirebaseService.getMyCrossClassRequests(
          _schoolId, _sectionId, _classId, _studentId);
      if (!mounted) return;
      final alreadySent = pending
          .any((r) => r.targetStudentId == otherId && r.status == 'pending');

      showModalBottomSheet(
        context: context,
        backgroundColor: cCard(context),
        shape: const RoundedRectangleBorder(
            borderRadius:
                BorderRadius.vertical(top: Radius.circular(20))),
        builder: (ctx) => Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: kPink.withValues(alpha: 0.18),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(
                        otherName.isNotEmpty
                            ? otherName[0].toUpperCase()
                            : '?',
                        style: TextStyle(
                            color:      cNavy(ctx),
                            fontSize:   18,
                            fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(otherName,
                          style: TextStyle(
                              color:      cNavy(ctx),
                              fontSize:   16,
                              fontWeight: FontWeight.w800)),
                      Text('Different class — approval needed',
                          style: TextStyle(
                              color: cMuted(ctx), fontSize: 12)),
                    ],
                  ),
                ),
              ]),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: kTeal.withValues(alpha: 0.3)),
                ),
                child: Text(
                  'To chat with a student from another class, your class teacher must approve the request first.',
                  style: TextStyle(
                      color:  cNavy(ctx),
                      fontSize: 13,
                      height: 1.5),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: alreadySent
                      ? null
                      : () async {
                          Navigator.pop(ctx);
                          await _sendCrossRequest(
                              otherId, otherName, theirClassId);
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kNavy,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13)),
                    disabledBackgroundColor:
                        cBorder(context),
                  ),
                  child: Text(
                    alreadySent
                        ? 'Request already sent — pending approval'
                        : 'Send Chat Request to Class Teacher',
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
  }

  Future<void> _sendCrossRequest(
      String targetId, String targetName, String targetClassId) async {
    final req = CrossChatRequest(
      id:               DateTime.now().millisecondsSinceEpoch.toString(),
      requesterId:      _studentId,
      requesterName:    _name,
      requesterClassId: _classId,
      targetStudentId:  targetId,
      targetStudentName: targetName,
      targetClassId:    targetClassId,
      status:           'pending',
      createdAt:        DateTime.now(),
    );
    await StudentFirebaseService.submitCrossClassRequest(
        _schoolId, _sectionId, _classId, req);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Request sent! Waiting for teacher approval.'),
          backgroundColor: Color(0xFF16A34A)));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(
          child: CircularProgressIndicator(
              color: isDark(context) ? kDarkTeal : kTeal, strokeWidth: 2));
    }

    return Column(
      children: [
        // Class Chat button
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) =>
                    ClassChatScreen(session: widget.session))),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:        kNavy,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  const Icon(Icons.group_rounded,
                      color: Colors.white, size: 22),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Class Chat',
                            style: TextStyle(
                                color:      Colors.white,
                                fontSize:   14,
                                fontWeight: FontWeight.w700)),
                        Text('Group chat with all classmates & teacher',
                            style: TextStyle(
                                color:    Colors.white70,
                                fontSize: 11)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      color: Colors.white70, size: 20),
                ],
              ),
            ),
          ),
        ),

        Expanded(
          child: RefreshIndicator(
            onRefresh: _load,
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
              itemCount: _allClasses.length,
              itemBuilder: (_, ci) {
                final cls        = _allClasses[ci];
                final clsId      = (cls['id']   as String?) ?? '';
                final clsName    = (cls['name'] as String?) ?? clsId;
                final isMyClass  = clsId == _classId;

                return _ClassSection(
                  classId:      clsId,
                  className:    clsName,
                  isMyClass:    isMyClass,
                  getStudents:  () => _getStudents(clsId),
                  onTapStudent: (s) => isMyClass
                      ? _openSameClassChat(s)
                      : _handleOtherClassStudent(s, clsId),
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

// ── Expandable class section ──────────────────────────────────
class _ClassSection extends StatefulWidget {
  final String                                clsId;
  final String                                className;
  final bool                                  isMyClass;
  final Future<List<Map<String, dynamic>>> Function() getStudents;
  final void Function(Map<String, dynamic>)   onTapStudent;

  const _ClassSection({
    required this.clsId,
    required this.className,
    required this.isMyClass,
    required this.getStudents,
    required this.onTapStudent,
  });

  @override
  State<_ClassSection> createState() => _ClassSectionState();
}

class _ClassSectionState extends State<_ClassSection> {
  List<Map<String, dynamic>> _students = [];
  bool _expanded = false;
  bool _loading  = false;
  bool _loaded   = false;

  Future<void> _toggle() async {
    if (_expanded) {
      setState(() => _expanded = false);
      return;
    }
    if (!_loaded) {
      setState(() { _expanded = true; _loading = true; });
      final s = await widget.getStudents();
      if (mounted)
        setState(() { _students = s; _loading = false; _loaded = true; });
    } else {
      setState(() => _expanded = true);
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.isMyClass) {
      _toggle(); // auto-expand own class
    }
  }

  @override
  Widget build(BuildContext context) {
    // My class gets a teal outline; others neutral
    final border = widget.isMyClass
        ? Border.all(color: kTeal.withValues(alpha: 0.5), width: 1.5)
        : Border.all(color: cBorder(context));
    final headerBg = widget.isMyClass
        ? kTeal.withValues(alpha: 0.08)
        : cCard(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       border,
      ),
      child: Column(
        children: [
          // Header row
          GestureDetector(
            onTap: _toggle,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 13),
              decoration: BoxDecoration(
                color:        headerBg,
                borderRadius: BorderRadius.only(
                  topLeft:  const Radius.circular(13),
                  topRight: const Radius.circular(13),
                  bottomLeft:  Radius.circular(_expanded ? 0 : 13),
                  bottomRight: Radius.circular(_expanded ? 0 : 13),
                ),
              ),
              child: Row(
                children: [
                  if (widget.isMyClass)
                    Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color:        kTeal.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Text('My Class',
                          style: TextStyle(
                              color:         kNavy,
                              fontSize:      9,
                              fontWeight:    FontWeight.w800,
                              letterSpacing: 0.4)),
                    ),
                  Expanded(
                    child: Text(widget.className,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   14,
                            fontWeight: FontWeight.w700)),
                  ),
                  if (!widget.isMyClass)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color:        cBorder(context),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text('Requires approval',
                          style: TextStyle(
                              color:    cMuted(context),
                              fontSize: 10)),
                    ),
                  const SizedBox(width: 8),
                  AnimatedRotation(
                    turns:    _expanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 200),
                    child: Icon(Icons.keyboard_arrow_down_rounded,
                        color: cMuted(context), size: 20),
                  ),
                ],
              ),
            ),
          ),

          // Students list
          if (_expanded) ...[
            Divider(height: 1, color: cBorder(context)),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                    child: CircularProgressIndicator(strokeWidth: 2)),
              )
            else if (_students.isEmpty)
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text('No students.',
                    style: TextStyle(
                        color: cMuted(context), fontSize: 13)),
              )
            else
              ...(_students.map((s) {
                final name = (s['name'] as String?) ?? '?';
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 2),
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: widget.isMyClass
                          ? kTeal.withValues(alpha: 0.12)
                          : kPink.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Center(
                      child: Text(
                          name.isNotEmpty ? name[0].toUpperCase() : '?',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   15,
                              fontWeight: FontWeight.w800)),
                    ),
                  ),
                  title: Text(name,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w600)),
                  subtitle: Text(
                      'Roll: ${(s['rollNo'] as String?) ?? ''}',
                      style: TextStyle(
                          color: cMuted(context), fontSize: 11)),
                  trailing: widget.isMyClass
                      ? Icon(Icons.chat_bubble_outline_rounded,
                          color: kTeal, size: 16)
                      : Icon(Icons.lock_outline_rounded,
                          color: cMuted(context), size: 14),
                  onTap: () => widget.onTapStudent(s),
                );
              })),
          ],
        ],
      ),
    );
  }
}
