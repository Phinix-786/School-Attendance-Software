// lib/screens/notices_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/student_firebase_service.dart';

class StudentNoticesScreen extends StatefulWidget {
  final Map<String, String> session;
  const StudentNoticesScreen({super.key, required this.session});

  @override
  State<StudentNoticesScreen> createState() => _StudentNoticesScreenState();
}

class _StudentNoticesScreenState extends State<StudentNoticesScreen> {
  List<SchoolNotice> _notices = [];
  bool               _loading = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final notices = await StudentFirebaseService.getNotices(
        _schoolId, _sectionId);
    if (mounted) setState(() { _notices = notices; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Notices',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   17,
                fontWeight: FontWeight.w800)),
      ),
      body: _loading
          ? Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal))
          : _notices.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('📣', style: TextStyle(fontSize: 48)),
                      const SizedBox(height: 12),
                      Text('No notices yet.',
                          style: TextStyle(
                              color: cMuted(context), fontSize: 15)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                    itemCount: _notices.length,
                    itemBuilder: (_, i) => _NoticeCard(notice: _notices[i]),
                  ),
                ),
    );
  }
}

class _NoticeCard extends StatelessWidget {
  final SchoolNotice notice;
  const _NoticeCard({required this.notice});

  @override
  Widget build(BuildContext context) {
    final date =
        '${notice.createdAt.day}/${notice.createdAt.month}/${notice.createdAt.year}';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 10,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text('NOTICE',
                    style: TextStyle(
                        color:         kNavy,
                        fontSize:      9,
                        fontWeight:    FontWeight.w800,
                        letterSpacing: 0.5)),
              ),
              const Spacer(),
              Text(date,
                  style: TextStyle(color: cMuted(context), fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(notice.title,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   15,
                  fontWeight: FontWeight.w700)),
          if (notice.body.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(notice.body,
                style: TextStyle(
                    color:    cBlue(context),
                    fontSize: 13,
                    height:   1.5)),
          ],
          if (notice.createdBy.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('By: ${notice.createdBy}',
                style: TextStyle(color: cMuted(context), fontSize: 11)),
          ],
        ],
      ),
    );
  }
}
