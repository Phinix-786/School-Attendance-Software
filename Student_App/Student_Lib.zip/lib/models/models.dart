// lib/models/models.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class Student {
  final String id;
  final String schoolId;
  final String classId;
  final String sectionId;
  final String name;
  final String rollNo;
  final String studentLoginId;
  final String studentPassword;

  Student({
    required this.id, required this.schoolId, required this.classId,
    required this.sectionId, required this.name, required this.rollNo,
    required this.studentLoginId, required this.studentPassword,
  });

  factory Student.fromMap(Map<String, dynamic> m) => Student(
        id:              m['id']              ?? '',
        schoolId:        m['schoolId']        ?? '',
        classId:         m['classId']         ?? '',
        sectionId:       m['sectionId']       ?? '',
        name:            m['name']            ?? '',
        rollNo:          m['rollNo']          ?? '',
        studentLoginId:  m['studentLoginId']  ?? '',
        studentPassword: m['studentPassword'] ?? '',
      );
}

class Homework {
  final String       id;
  final String       schoolId;
  final String       classId;
  final String       subject;
  final String       topic;
  final String       instructions;
  final String       pageNumbers;
  final List<String> imageUrls;
  final DateTime     createdAt;

  Homework({
    required this.id, required this.schoolId, required this.classId,
    required this.subject, required this.topic, required this.instructions,
    required this.pageNumbers, required this.imageUrls, required this.createdAt,
  });

  factory Homework.fromMap(Map<String, dynamic> m) => Homework(
        id:           m['id']           ?? '',
        schoolId:     m['schoolId']     ?? '',
        classId:      m['classId']      ?? '',
        subject:      m['subject']      ?? '',
        topic:        m['topic']        ?? '',
        instructions: m['instructions'] ?? '',
        pageNumbers:  m['pageNumbers']  ?? '',
        imageUrls:    List<String>.from(m['imageUrls'] ?? []),
        createdAt:    (m['createdAt'] as Timestamp).toDate(),
      );
}

class SchoolTest {
  final String       id;
  final String       schoolId;
  final String       classId;
  final String       subject;
  final String       topic;
  final String       instructions;
  final String       pageNumbers;
  final List<String> imageUrls;
  final DateTime     createdAt;
  final DateTime     testDate;

  SchoolTest({
    required this.id, required this.schoolId, required this.classId,
    required this.subject, required this.topic, required this.instructions,
    required this.pageNumbers, required this.imageUrls,
    required this.createdAt, required this.testDate,
  });

  factory SchoolTest.fromMap(Map<String, dynamic> m) => SchoolTest(
        id:           m['id']           ?? '',
        schoolId:     m['schoolId']     ?? '',
        classId:      m['classId']      ?? '',
        subject:      m['subject']      ?? '',
        topic:        m['topic']        ?? '',
        instructions: m['instructions'] ?? '',
        pageNumbers:  m['pageNumbers']  ?? '',
        imageUrls:    List<String>.from(m['imageUrls'] ?? []),
        createdAt:    (m['createdAt'] as Timestamp).toDate(),
        testDate:     (m['testDate']  as Timestamp).toDate(),
      );
}

class TestResult {
  final String   id;
  final String   testId;
  final String   studentId;
  final String   studentName;
  final int      marksObtained;
  final int      marksTotal;
  final String   remarks;
  final DateTime submittedAt;
  final bool     wasAbsent;

  TestResult({
    required this.id, required this.testId, required this.studentId,
    required this.studentName, required this.marksObtained,
    required this.marksTotal, required this.remarks,
    required this.submittedAt, this.wasAbsent = false,
  });

  double get percentage =>
      marksTotal > 0 ? (marksObtained / marksTotal) * 100 : 0;

  factory TestResult.fromMap(Map<String, dynamic> m) => TestResult(
        id:            m['id']            ?? '',
        testId:        m['testId']        ?? '',
        studentId:     m['studentId']     ?? '',
        studentName:   m['studentName']   ?? '',
        marksObtained: m['marksObtained'] ?? 0,
        marksTotal:    m['marksTotal']    ?? 0,
        remarks:       m['remarks']       ?? '',
        submittedAt:   (m['submittedAt'] as Timestamp).toDate(),
        wasAbsent:     m['wasAbsent']     ?? false,
      );
}

class SchoolNotice {
  final String   id;
  final String   title;
  final String   body;
  final String   targetAudience;
  final String   createdBy;
  final DateTime createdAt;

  SchoolNotice({
    required this.id, required this.title, required this.body,
    required this.targetAudience, required this.createdBy,
    required this.createdAt,
  });

  factory SchoolNotice.fromMap(Map<String, dynamic> m) => SchoolNotice(
        id:             m['id']             ?? '',
        title:          m['title']          ?? '',
        body:           m['body']           ?? '',
        targetAudience: m['targetAudience'] ?? 'all',
        createdBy:      m['createdBy']      ?? '',
        createdAt: m['createdAt'] != null
            ? (m['createdAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class ClassMessage {
  final String   id;
  final String   senderId;
  final String   senderName;
  final String   senderType; // 'student' | 'teacher'
  final String   text;
  final DateTime timestamp;

  ClassMessage({
    required this.id, required this.senderId, required this.senderName,
    required this.senderType, required this.text, required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'senderId': senderId, 'senderName': senderName,
        'senderType': senderType, 'text': text,
        'timestamp': Timestamp.fromDate(timestamp),
      };

  factory ClassMessage.fromMap(Map<String, dynamic> m) => ClassMessage(
        id:         m['id']         ?? '',
        senderId:   m['senderId']   ?? '',
        senderName: m['senderName'] ?? '',
        senderType: m['senderType'] ?? 'student',
        text:       m['text']       ?? '',
        timestamp: m['timestamp'] != null
            ? (m['timestamp'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class CrossChatRequest {
  final String   id;
  final String   requesterId;
  final String   requesterName;
  final String   requesterClassId;
  final String   targetStudentId;
  final String   targetStudentName;
  final String   targetClassId;
  final String   status;
  final DateTime createdAt;

  CrossChatRequest({
    required this.id, required this.requesterId, required this.requesterName,
    required this.requesterClassId, required this.targetStudentId,
    required this.targetStudentName, required this.targetClassId,
    required this.status, required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'requesterId': requesterId, 'requesterName': requesterName,
        'requesterClassId': requesterClassId,
        'targetStudentId': targetStudentId,
        'targetStudentName': targetStudentName,
        'targetClassId': targetClassId,
        'status': status, 'createdAt': Timestamp.fromDate(createdAt),
      };

  factory CrossChatRequest.fromMap(Map<String, dynamic> m) => CrossChatRequest(
        id:               m['id']               ?? '',
        requesterId:      m['requesterId']       ?? '',
        requesterName:    m['requesterName']     ?? '',
        requesterClassId: m['requesterClassId']  ?? '',
        targetStudentId:  m['targetStudentId']   ?? '',
        targetStudentName: m['targetStudentName'] ?? '',
        targetClassId:    m['targetClassId']     ?? '',
        status:           m['status']            ?? 'pending',
        createdAt: m['createdAt'] != null
            ? (m['createdAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class CrossClassChat {
  final String   id;
  final String   student1Id;
  final String   student1Name;
  final String   student2Id;
  final String   student2Name;
  final String   requesterClassId;

  CrossClassChat({
    required this.id, required this.student1Id, required this.student1Name,
    required this.student2Id, required this.student2Name,
    required this.requesterClassId,
  });

  factory CrossClassChat.fromMap(Map<String, dynamic> m) => CrossClassChat(
        id:               m['id']               ?? '',
        student1Id:       m['student1Id']        ?? '',
        student1Name:     m['student1Name']      ?? '',
        student2Id:       m['student2Id']        ?? '',
        student2Name:     m['student2Name']      ?? '',
        requesterClassId: m['requesterClassId']  ?? '',
      );
}

class ChatMessage {
  final String   id;
  final String   senderId;
  final String   senderName;
  final String   text;
  final DateTime timestamp;

  ChatMessage({
    required this.id, required this.senderId, required this.senderName,
    required this.text, required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'senderId': senderId, 'senderName': senderName,
        'text': text, 'timestamp': Timestamp.fromDate(timestamp),
      };

  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
        id:         m['id']         ?? '',
        senderId:   m['senderId']   ?? '',
        senderName: m['senderName'] ?? '',
        text:       m['text']       ?? '',
        timestamp: m['timestamp'] != null
            ? (m['timestamp'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class LeaveRequest {
  final String   id;
  final String   studentId;
  final String   studentName;
  final String   classId;
  final String   sectionId;
  final DateTime requestedDate;
  final String   reason;
  final String   status;
  final String   submittedBy;
  final DateTime submittedAt;
  final String   remarks;

  LeaveRequest({
    required this.id, required this.studentId, required this.studentName,
    required this.classId, required this.sectionId,
    required this.requestedDate, required this.reason,
    required this.status, required this.submittedBy,
    required this.submittedAt, this.remarks = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'studentId': studentId, 'studentName': studentName,
        'classId': classId, 'sectionId': sectionId,
        'requestedDate': Timestamp.fromDate(requestedDate),
        'reason': reason, 'status': status, 'submittedBy': submittedBy,
        'submittedAt': Timestamp.fromDate(submittedAt), 'remarks': remarks,
      };

  factory LeaveRequest.fromMap(Map<String, dynamic> m) => LeaveRequest(
        id:            m['id']          ?? '',
        studentId:     m['studentId']   ?? '',
        studentName:   m['studentName'] ?? '',
        classId:       m['classId']     ?? '',
        sectionId:     m['sectionId']   ?? '',
        requestedDate: m['requestedDate'] != null
            ? (m['requestedDate'] as Timestamp).toDate()
            : DateTime.now(),
        reason:        m['reason']      ?? '',
        status:        m['status']      ?? 'pending',
        submittedBy:   m['submittedBy'] ?? 'student',
        submittedAt:   m['submittedAt'] != null
            ? (m['submittedAt'] as Timestamp).toDate()
            : DateTime.now(),
        remarks:       m['remarks']     ?? '',
      );
}
