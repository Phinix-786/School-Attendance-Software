// lib/services/student_firebase_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

class StudentFirebaseService {
  static final _db = FirebaseFirestore.instance;

  // ── Auth ──────────────────────────────────────────────────────
  static Future<Map<String, dynamic>?> login(
      String schoolId, String loginId, String password) async {
    final sectionsSnap =
        await _db.collection('schools/$schoolId/sections').get();

    for (final section in sectionsSnap.docs) {
      final classesSnap = await _db
          .collection('schools/$schoolId/sections/${section.id}/classes')
          .get();

      for (final cls in classesSnap.docs) {
        final stuSnap = await _db
            .collection(
                'schools/$schoolId/sections/${section.id}/classes/${cls.id}/students')
            .where('studentLoginId', isEqualTo: loginId)
            .limit(1)
            .get();

        if (stuSnap.docs.isNotEmpty) {
          final data = stuSnap.docs.first.data();
          final stu  = Student.fromMap({...data, 'sectionId': section.id});
          if (stu.studentPassword != password) return null;
          return {'student': stu, 'sectionId': section.id, 'classId': cls.id};
        }
      }
    }
    return null;
  }

  // ── Session ───────────────────────────────────────────────────
  static Future<void> saveSession({
    required String schoolId,
    required String sectionId,
    required String classId,
    required String studentId,
    required String studentName,
    required String loginId,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('s_schoolId',    schoolId);
    await prefs.setString('s_sectionId',   sectionId);
    await prefs.setString('s_classId',     classId);
    await prefs.setString('s_studentId',   studentId);
    await prefs.setString('s_studentName', studentName);
    await prefs.setString('s_loginId',     loginId);
  }

  static Future<Map<String, String>?> getSavedSession() async {
    final prefs = await SharedPreferences.getInstance();
    final schoolId  = prefs.getString('s_schoolId');
    final sectionId = prefs.getString('s_sectionId');
    final classId   = prefs.getString('s_classId');
    final studentId = prefs.getString('s_studentId');
    if (schoolId == null || classId == null || studentId == null) return null;
    return {
      'schoolId':    schoolId,
      'sectionId':   sectionId   ?? '',
      'classId':     classId,
      'studentId':   studentId,
      'studentName': prefs.getString('s_studentName') ?? '',
      'loginId':     prefs.getString('s_loginId')     ?? '',
    };
  }

  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    for (final key in ['s_schoolId', 's_sectionId', 's_classId',
                       's_studentId', 's_studentName', 's_loginId']) {
      await prefs.remove(key);
    }
  }

  // ── Homework ──────────────────────────────────────────────────
  static Future<List<Homework>> getHomeworks(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/homeworks')
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => Homework.fromMap(d.data())).toList();
  }

  // ── Tests ─────────────────────────────────────────────────────
  static Future<List<SchoolTest>> getTests(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/tests')
        .orderBy('testDate', descending: false)
        .get();
    return snap.docs.map((d) => SchoolTest.fromMap(d.data())).toList();
  }

  // ── Test result ───────────────────────────────────────────────
  static Future<TestResult?> getMyResult(
      String schoolId, String sectionId, String classId,
      String testId, String studentId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/tests/$testId/results')
        .where('studentId', isEqualTo: studentId)
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return null;
    return TestResult.fromMap(snap.docs.first.data());
  }

  // ── Notices ───────────────────────────────────────────────────
  static Future<List<SchoolNotice>> getNotices(
      String schoolId, String sectionId) async {
    final snap = await _db
        .collection('schools/$schoolId/sections/$sectionId/notices')
        .where('targetAudience', whereIn: ['students', 'all'])
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => SchoolNotice.fromMap(d.data())).toList();
  }

  // ── Class chat ────────────────────────────────────────────────
  static Stream<List<ClassMessage>> classChatStream(
      String schoolId, String sectionId, String classId) {
    return _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/class_messages')
        .orderBy('timestamp')
        .snapshots()
        .map((s) => s.docs.map((d) => ClassMessage.fromMap(d.data())).toList());
  }

  static Future<void> sendClassMessage(
      String schoolId, String sectionId, String classId,
      ClassMessage msg) async {
    await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/class_messages')
        .doc(msg.id)
        .set(msg.toMap());
  }

  // ── Cross-class chat requests ─────────────────────────────────
  static Future<void> submitCrossClassRequest(
      String schoolId, String sectionId, String classId,
      CrossChatRequest req) async {
    await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/cross_chat_requests')
        .doc(req.id)
        .set(req.toMap());
  }

  static Future<List<CrossChatRequest>> getMyCrossClassRequests(
      String schoolId, String sectionId, String classId,
      String studentId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/cross_chat_requests')
        .where('requesterId', isEqualTo: studentId)
        .get();
    return snap.docs.map((d) => CrossChatRequest.fromMap(d.data())).toList();
  }

  static Future<List<CrossClassChat>> getApprovedChatsForStudent(
      String schoolId, String sectionId, String classId,
      String studentId) async {
    final [snap1, snap2] = await Future.wait([
      _db
          .collection(
              'schools/$schoolId/sections/$sectionId/classes/$classId/cross_class_chats')
          .where('student1Id', isEqualTo: studentId)
          .get(),
      _db
          .collection(
              'schools/$schoolId/sections/$sectionId/classes/$classId/cross_class_chats')
          .where('student2Id', isEqualTo: studentId)
          .get(),
    ]);
    final all = <CrossClassChat>{};
    for (final doc in [...snap1.docs, ...snap2.docs]) {
      all.add(CrossClassChat.fromMap(doc.data()));
    }
    return all.toList();
  }

  static Stream<List<ChatMessage>> crossChatMessagesStream(
      String schoolId, String sectionId, String classId, String chatId) {
    return _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/cross_class_chats/$chatId/messages')
        .orderBy('timestamp')
        .snapshots()
        .map((s) => s.docs.map((d) => ChatMessage.fromMap(d.data())).toList());
  }

  static Future<void> sendCrossClassMessage(
      String schoolId, String sectionId, String classId,
      String chatId, ChatMessage msg) async {
    await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/cross_class_chats/$chatId/messages')
        .doc(msg.id)
        .set(msg.toMap());
  }

  // ── Teacher ↔ Student chat ────────────────────────────────────
  // Mirrors path used by teacher: sections/{secId}/teacher_student_chats/{teacherId}_{studentId}

  static String _tsChatPath(String schoolId, String sectionId) =>
      'schools/$schoolId/sections/$sectionId/teacher_student_chats';

  /// Get or create the chat doc. chatId = '{teacherId}_{studentId}'.
  static Future<String> getOrCreateTeacherChatId(
      String schoolId, String sectionId, String classId,
      String teacherId, String teacherName,
      String studentId, String studentName) async {
    final chatId = '${teacherId}_$studentId';
    final ref = _db
        .collection(_tsChatPath(schoolId, sectionId))
        .doc(chatId);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'id':          chatId,
        'teacherId':   teacherId,
        'teacherName': teacherName,
        'studentId':   studentId,
        'studentName': studentName,
        'classId':     classId,
        'lastMessage': '',
        'updatedAt':   FieldValue.serverTimestamp(),
      });
    }
    return chatId;
  }

  static Stream<List<ChatMessage>> teacherChatMessagesStream(
      String schoolId, String sectionId, String chatId) {
    return _db
        .collection('${_tsChatPath(schoolId, sectionId)}/$chatId/messages')
        .orderBy('timestamp')
        .snapshots()
        .map((s) =>
            s.docs.map((d) => ChatMessage.fromMap(d.data())).toList());
  }

  static Future<void> sendStudentMessage(
      String schoolId, String sectionId,
      String chatId, ChatMessage msg) async {
    final chatRef = _db
        .collection(_tsChatPath(schoolId, sectionId))
        .doc(chatId);
    await chatRef.collection('messages').doc(msg.id).set(msg.toMap());
    await chatRef.update({
      'lastMessage': msg.text,
      'updatedAt':   FieldValue.serverTimestamp(),
    });
  }

  // Get all teacher→student chats for this student
  static Future<List<Map<String, dynamic>>> getMyTeacherChats(
      String schoolId, String sectionId, String studentId) async {
    final snap = await _db
        .collection(_tsChatPath(schoolId, sectionId))
        .where('studentId', isEqualTo: studentId)
        .orderBy('updatedAt', descending: true)
        .get();
    return snap.docs.map((d) => d.data()).toList();
  }

  // Get teachers for a class (to let student start a new conversation)
  static Future<List<Map<String, dynamic>>> getTeachersForClass(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/teachers')
        .get();
    return snap.docs.map((d) => d.data()).toList();
  }

  // Get ALL classes in section (so student can browse other classes)
  static Future<List<Map<String, dynamic>>> getAllClassesInSection(
      String schoolId, String sectionId) async {
    final snap = await _db
        .collection('schools/$schoolId/sections/$sectionId/classes')
        .get();
    return snap.docs.map((d) => d.data()).toList();
  }

  // Get students of any class (for browsing other classes)
  static Future<List<Map<String, dynamic>>> getStudentsOfClass(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/students')
        .get();
    return snap.docs.map((d) => d.data()).toList();
  }

  // ── Leave request ─────────────────────────────────────────────
  static Future<void> submitLeaveRequest(
      String schoolId, String sectionId, LeaveRequest req) async {
    await _db
        .collection('schools/$schoolId/sections/$sectionId/leaves')
        .doc(req.id)
        .set(req.toMap());
  }

  static Future<List<LeaveRequest>> getMyLeaveRequests(
      String schoolId, String sectionId, String studentId) async {
    final snap = await _db
        .collection('schools/$schoolId/sections/$sectionId/leaves')
        .where('studentId', isEqualTo: studentId)
        .orderBy('submittedAt', descending: true)
        .get();
    return snap.docs.map((d) => LeaveRequest.fromMap(d.data())).toList();
  }
}
