// lib/models/models.dart
import 'package:cloud_firestore/cloud_firestore.dart';

// ─────────────────────────────────────────────────────────────
// Core domain objects
// ─────────────────────────────────────────────────────────────

class SchoolClass {
  final String id;
  final String schoolId;
  final String name;
  final String grade;
  final String section;

  SchoolClass({
    required this.id,
    required this.schoolId,
    required this.name,
    required this.grade,
    required this.section,
  });

  factory SchoolClass.fromMap(Map<String, dynamic> m) => SchoolClass(
        id:       m['id']       ?? '',
        schoolId: m['schoolId'] ?? '',
        name:     m['name']     ?? '',
        grade:    m['grade']    ?? '',
        section:  m['section']  ?? '',
      );

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId,
        'name': name, 'grade': grade, 'section': section,
      };
}

class Student {
  final String id;
  final String schoolId;
  final String classId;
  final String name;
  final String rollNo;
  final String parentPhone;
  final String studentLoginId;
  final String studentPassword;
  final String parentLoginId;
  final String parentPassword;

  Student({
    required this.id,
    required this.schoolId,
    required this.classId,
    required this.name,
    required this.rollNo,
    required this.parentPhone,
    this.studentLoginId  = '',
    this.studentPassword = '',
    this.parentLoginId   = '',
    this.parentPassword  = '',
  });

  factory Student.fromMap(Map<String, dynamic> m) => Student(
        id:              m['id']              ?? '',
        schoolId:        m['schoolId']        ?? '',
        classId:         m['classId']         ?? '',
        name:            m['name']            ?? '',
        rollNo:          m['rollNo']          ?? '',
        parentPhone:     m['parentPhone']     ?? '',
        studentLoginId:  m['studentLoginId']  ?? '',
        studentPassword: m['studentPassword'] ?? '',
        parentLoginId:   m['parentLoginId']   ?? '',
        parentPassword:  m['parentPassword']  ?? '',
      );

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'name': name, 'rollNo': rollNo, 'parentPhone': parentPhone,
        'studentLoginId':  studentLoginId, 'studentPassword': studentPassword,
        'parentLoginId':   parentLoginId,  'parentPassword':  parentPassword,
      };
}

// ── Timetable models ──────────────────────────────────────────
class TimetableEntry {
  final String day;
  final String period;
  final String subject;
  final String classId;
  final String className;

  TimetableEntry({
    required this.day, required this.period,
    required this.subject, required this.classId, required this.className,
  });

  factory TimetableEntry.fromMap(Map<String, dynamic> m) => TimetableEntry(
        day:       m['day']       ?? '',
        period:    m['period']    ?? '',
        subject:   m['subject']   ?? '',
        classId:   m['classId']   ?? '',
        className: m['className'] ?? '',
      );
}

class TeacherTimetable {
  final String             teacherId;
  final DateTime           updatedAt;
  final List<TimetableEntry> entries;

  TeacherTimetable({
    required this.teacherId,
    required this.updatedAt,
    required this.entries,
  });

  factory TeacherTimetable.fromMap(Map<String, dynamic> m) => TeacherTimetable(
        teacherId: m['teacherId'] ?? '',
        updatedAt: m['updatedAt'] != null
            ? (m['updatedAt'] as Timestamp).toDate()
            : DateTime.now(),
        entries: (m['entries'] as List<dynamic>? ?? [])
            .map((e) => TimetableEntry.fromMap(e as Map<String, dynamic>))
            .toList(),
      );
}

class Teacher {
  final String id;
  final String schoolId;
  final String name;
  final String phone;
  final String email;
  final String password;
  final List<String> assignedClassIds;

  /// Classes where this teacher IS the class teacher (can mark attendance).
  final List<String> classTeacherOf;

  /// Subject assigned per class: { classId: 'Subject Name' }
  final Map<String, String> classSubjects;

  Teacher({
    required this.id,
    required this.schoolId,
    required this.name,
    required this.phone,
    required this.email,
    required this.password,
    required this.assignedClassIds,
    this.classTeacherOf = const [],
    this.classSubjects  = const {},
  });

  /// Returns true when this teacher is the class teacher of [classId].
  /// Falls back gracefully: if classTeacherOf was never set (old data),
  /// every assigned class is treated as a class-teacher class.
  bool isClassTeacherOf(String classId) {
    if (classTeacherOf.isEmpty) return assignedClassIds.contains(classId);
    return classTeacherOf.contains(classId);
  }

  /// Subject for a given class, or empty string.
  String subjectFor(String classId) => classSubjects[classId] ?? '';

  factory Teacher.fromMap(Map<String, dynamic> m) => Teacher(
        id:               m['id']       ?? '',
        schoolId:         m['schoolId'] ?? '',
        name:             m['name']     ?? '',
        phone:            m['phone']    ?? '',
        email:            m['email']    ?? '',
        password:         m['password'] ?? '',
        assignedClassIds: List<String>.from(m['assignedClassIds'] ?? []),
        classTeacherOf:   List<String>.from(m['classTeacherOf']   ?? []),
        classSubjects:    Map<String, String>.from(m['classSubjects'] ?? {}),
      );

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'name': name,
        'phone': phone, 'email': email, 'password': password,
        'assignedClassIds': assignedClassIds,
        'classTeacherOf':   classTeacherOf,
        'classSubjects':    classSubjects,
      };
}

// ─────────────────────────────────────────────────────────────
// Attendance
// ─────────────────────────────────────────────────────────────

enum AttendanceStatus { present, absent, late }

class AttendanceRecord {
  final String id;
  final String schoolId;
  final String classId;
  final String studentId;
  final String teacherId;
  AttendanceStatus status;
  final DateTime date;
  final bool messageSent;
  final int? lateMinutes;

  AttendanceRecord({
    required this.id,
    required this.schoolId,
    required this.classId,
    required this.studentId,
    required this.teacherId,
    required this.status,
    required this.date,
    this.messageSent = false,
    this.lateMinutes,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'studentId': studentId, 'teacherId': teacherId,
        'status': status.name,
        'date': Timestamp.fromDate(date),
        'messageSent': messageSent,
        if (lateMinutes != null) 'lateMinutes': lateMinutes,
      };

  factory AttendanceRecord.fromMap(Map<String, dynamic> m) =>
      AttendanceRecord(
        id:          m['id']          ?? '',
        schoolId:    m['schoolId']    ?? '',
        classId:     m['classId']     ?? '',
        studentId:   m['studentId']   ?? '',
        teacherId:   m['teacherId']   ?? '',
        status: AttendanceStatus.values.firstWhere(
            (e) => e.name == m['status'],
            orElse: () => AttendanceStatus.present),
        date: (m['date'] as Timestamp).toDate(),
        messageSent: m['messageSent'] ?? false,
        lateMinutes: m['lateMinutes'] as int?,
      );
}

class AttendanceSession {
  final String   id;
  final String   schoolId;
  final String   classId;
  final String   teacherId;
  final DateTime date;
  final bool     isSubmitted;
  final bool     messagesSent;

  AttendanceSession({
    required this.id,
    required this.schoolId,
    required this.classId,
    required this.teacherId,
    required this.date,
    this.isSubmitted  = false,
    this.messagesSent = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'teacherId': teacherId, 'date': Timestamp.fromDate(date),
        'isSubmitted': isSubmitted, 'messagesSent': messagesSent,
      };

  factory AttendanceSession.fromMap(Map<String, dynamic> m) =>
      AttendanceSession(
        id:           m['id']        ?? '',
        schoolId:     m['schoolId']  ?? '',
        classId:      m['classId']   ?? '',
        teacherId:    m['teacherId'] ?? '',
        date: (m['date'] as Timestamp).toDate(),
        isSubmitted:  m['isSubmitted']  ?? false,
        messagesSent: m['messagesSent'] ?? false,
      );
}

// Offline queue
class OfflineQueueItem {
  final String                     sessionId;
  final String                     classId;
  final List<Map<String, dynamic>> records;
  final DateTime                   timestamp;

  OfflineQueueItem({
    required this.sessionId,
    required this.classId,
    required this.records,
    required this.timestamp,
  });

  Map<String, dynamic> toJson() => {
        'sessionId': sessionId,
        'classId':   classId,
        'records':   records,
        'timestamp': timestamp.toIso8601String(),
      };

  factory OfflineQueueItem.fromJson(Map<String, dynamic> j) =>
      OfflineQueueItem(
        sessionId: j['sessionId'],
        classId:   j['classId'],
        records:   List<Map<String, dynamic>>.from(j['records']),
        timestamp: DateTime.parse(j['timestamp']),
      );
}

// ─────────────────────────────────────────────────────────────
// Homework
// ─────────────────────────────────────────────────────────────

class Homework {
  final String       id;
  final String       schoolId;
  final String       classId;
  final String       teacherId;
  final String       subject;
  final String       topic;
  final String       instructions;
  final String       pageNumbers;
  final List<String> imageUrls;
  final DateTime     createdAt;

  Homework({
    required this.id,
    required this.schoolId,
    required this.classId,
    required this.teacherId,
    required this.subject,
    required this.topic,
    required this.instructions,
    required this.pageNumbers,
    required this.imageUrls,
    required this.createdAt,
  });

  /// Editable only within 3 days of creation.
  bool get isEditable =>
      DateTime.now().difference(createdAt).inDays < 3;

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'teacherId': teacherId, 'subject': subject,
        'topic': topic, 'instructions': instructions,
        'pageNumbers': pageNumbers, 'imageUrls': imageUrls,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  factory Homework.fromMap(Map<String, dynamic> m) => Homework(
        id:           m['id']           ?? '',
        schoolId:     m['schoolId']     ?? '',
        classId:      m['classId']      ?? '',
        teacherId:    m['teacherId']    ?? '',
        subject:      m['subject']      ?? '',
        topic:        m['topic']        ?? '',
        instructions: m['instructions'] ?? '',
        pageNumbers:  m['pageNumbers']  ?? '',
        imageUrls:    List<String>.from(m['imageUrls'] ?? []),
        createdAt:    (m['createdAt'] as Timestamp).toDate(),
      );
}

// ─────────────────────────────────────────────────────────────
// Test
// ─────────────────────────────────────────────────────────────

class SchoolTest {
  final String       id;
  final String       schoolId;
  final String       classId;
  final String       teacherId;
  final String       subject;
  final String       topic;
  final String       instructions;
  final String       pageNumbers;
  final List<String> imageUrls;
  final DateTime     createdAt;
  final DateTime     testDate;

  SchoolTest({
    required this.id,
    required this.schoolId,
    required this.classId,
    required this.teacherId,
    required this.subject,
    required this.topic,
    required this.instructions,
    required this.pageNumbers,
    required this.imageUrls,
    required this.createdAt,
    required this.testDate,
  });

  bool get isEditable =>
      DateTime.now().difference(createdAt).inDays < 3;

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'teacherId': teacherId, 'subject': subject,
        'topic': topic, 'instructions': instructions,
        'pageNumbers': pageNumbers, 'imageUrls': imageUrls,
        'createdAt': Timestamp.fromDate(createdAt),
        'testDate':  Timestamp.fromDate(testDate),
      };

  factory SchoolTest.fromMap(Map<String, dynamic> m) => SchoolTest(
        id:           m['id']           ?? '',
        schoolId:     m['schoolId']     ?? '',
        classId:      m['classId']      ?? '',
        teacherId:    m['teacherId']    ?? '',
        subject:      m['subject']      ?? '',
        topic:        m['topic']        ?? '',
        instructions: m['instructions'] ?? '',
        pageNumbers:  m['pageNumbers']  ?? '',
        imageUrls:    List<String>.from(m['imageUrls'] ?? []),
        createdAt:    (m['createdAt'] as Timestamp).toDate(),
        testDate:     (m['testDate']  as Timestamp).toDate(),
      );
}

// ─────────────────────────────────────────────────────────────
// Test Result
// ─────────────────────────────────────────────────────────────

class TestResult {
  final String   id;
  final String   schoolId;
  final String   classId;
  final String   testId;
  final String   studentId;
  final String   studentName;
  final int      marksObtained;
  final int      marksTotal;
  final String   remarks;
  final DateTime submittedAt;
  final bool     wasAbsent;

  TestResult({
    required this.id,
    required this.schoolId,
    required this.classId,
    required this.testId,
    required this.studentId,
    required this.studentName,
    required this.marksObtained,
    required this.marksTotal,
    required this.remarks,
    required this.submittedAt,
    this.wasAbsent = false,
  });

  double get percentage =>
      marksTotal > 0 ? (marksObtained / marksTotal) * 100 : 0;

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'testId': testId, 'studentId': studentId,
        'studentName': studentName,
        'marksObtained': marksObtained, 'marksTotal': marksTotal,
        'remarks': remarks,
        'submittedAt': Timestamp.fromDate(submittedAt),
        'wasAbsent': wasAbsent,
      };

  factory TestResult.fromMap(Map<String, dynamic> m) => TestResult(
        id:            m['id']            ?? '',
        schoolId:      m['schoolId']      ?? '',
        classId:       m['classId']       ?? '',
        testId:        m['testId']        ?? '',
        studentId:     m['studentId']     ?? '',
        studentName:   m['studentName']   ?? '',
        marksObtained: m['marksObtained'] ?? 0,
        marksTotal:    m['marksTotal']    ?? 0,
        remarks:       m['remarks']       ?? '',
        submittedAt:   (m['submittedAt'] as Timestamp).toDate(),
        wasAbsent:     m['wasAbsent']     ?? false,
      );
}

// ─────────────────────────────────────────────────────────────
// Chat message (teacher ↔ parent  |  teacher ↔ student)
// ─────────────────────────────────────────────────────────────

class ChatMessage {
  final String   id;
  final String   senderId;
  final String   senderType; // 'teacher' | 'parent' | 'student'
  final String   senderName;
  final String   text;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.senderType,
    required this.senderName,
    required this.text,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'senderId': senderId, 'senderType': senderType,
        'senderName': senderName, 'text': text,
        'timestamp': Timestamp.fromDate(timestamp),
      };

  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
        id:         m['id']         ?? '',
        senderId:   m['senderId']   ?? '',
        senderType: m['senderType'] ?? '',
        senderName: m['senderName'] ?? '',
        text:       m['text']       ?? '',
        timestamp:  m['timestamp'] != null
            ? (m['timestamp'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

// ─────────────────────────────────────────────────────────────
// Notice
// ─────────────────────────────────────────────────────────────

class SchoolNotice {
  final String   id;
  final String   schoolId;
  final String   sectionId;
  final String   title;
  final String   body;
  final String   targetAudience; // 'teachers' | 'parents' | 'students' | 'all'
  final String   createdBy;
  final DateTime createdAt;

  SchoolNotice({
    required this.id,
    required this.schoolId,
    required this.sectionId,
    required this.title,
    required this.body,
    required this.targetAudience,
    required this.createdBy,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'sectionId': sectionId,
        'title': title, 'body': body,
        'targetAudience': targetAudience, 'createdBy': createdBy,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  factory SchoolNotice.fromMap(Map<String, dynamic> m) => SchoolNotice(
        id:             m['id']             ?? '',
        schoolId:       m['schoolId']       ?? '',
        sectionId:      m['sectionId']      ?? '',
        title:          m['title']          ?? '',
        body:           m['body']           ?? '',
        targetAudience: m['targetAudience'] ?? 'all',
        createdBy:      m['createdBy']      ?? '',
        createdAt: m['createdAt'] != null
            ? (m['createdAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

// ─────────────────────────────────────────────────────────────
// Cross-class chat request
// ─────────────────────────────────────────────────────────────

class CrossChatRequest {
  final String   id;
  final String   requesterId;
  final String   requesterName;
  final String   requesterClassId;
  final String   targetStudentId;
  final String   targetStudentName;
  final String   targetClassId;
  final String   status; // 'pending' | 'approved' | 'rejected'
  final DateTime createdAt;

  CrossChatRequest({
    required this.id,
    required this.requesterId,
    required this.requesterName,
    required this.requesterClassId,
    required this.targetStudentId,
    required this.targetStudentName,
    required this.targetClassId,
    required this.status,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'requesterId': requesterId, 'requesterName': requesterName,
        'requesterClassId': requesterClassId,
        'targetStudentId': targetStudentId,
        'targetStudentName': targetStudentName,
        'targetClassId': targetClassId,
        'status': status,
        'createdAt': Timestamp.fromDate(createdAt),
      };

  factory CrossChatRequest.fromMap(Map<String, dynamic> m) => CrossChatRequest(
        id:               m['id']               ?? '',
        requesterId:      m['requesterId']       ?? '',
        requesterName:    m['requesterName']     ?? '',
        requesterClassId: m['requesterClassId']  ?? '',
        targetStudentId:  m['targetStudentId']   ?? '',
        targetStudentName: m['targetStudentName'] ?? '',
        targetClassId:    m['targetClassId']     ?? '',
        status:           m['status']            ?? 'pending',
        createdAt: m['createdAt'] != null
            ? (m['createdAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

