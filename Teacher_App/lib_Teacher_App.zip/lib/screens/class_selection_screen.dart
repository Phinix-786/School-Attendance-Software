// lib/screens/class_selection_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_screen.dart';
import 'class_detail_screen.dart';
import 'notice_board_screen.dart';
import 'account_screen.dart';
import 'timetable_screen.dart';
import 'teacher_chat_page.dart';

class ClassSelectionScreen extends StatefulWidget {
  final String  schoolId;
  final Teacher teacher;
  const ClassSelectionScreen(
      {super.key, required this.schoolId, required this.teacher});

  @override
  State<ClassSelectionScreen> createState() => _ClassSelectionScreenState();
}

class _ClassSelectionScreenState extends State<ClassSelectionScreen> {
  List<SchoolClass> _classes        = [];
  bool              _loading        = true;
  int               _queueCount     = 0;
  bool              _syncing        = false;
  bool              _timetableNew   = false;

  static const _prefKey = 'timetable_last_viewed_';

  @override
  void initState() {
    super.initState();
    _load();
    _checkOfflineQueue();
    _checkTimetableUpdate();
  }

  Future<void> _checkTimetableUpdate() async {
    final tt = await TeacherFirebaseService.getMyTimetable(
        widget.schoolId, widget.teacher.id);
    if (tt == null) return;
    final prefs   = await SharedPreferences.getInstance();
    final lastMs  = prefs.getInt('$_prefKey${widget.teacher.id}') ?? 0;
    final isNew   = tt.updatedAt.millisecondsSinceEpoch > lastMs;
    if (mounted && isNew != _timetableNew) {
      setState(() => _timetableNew = isNew);
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final classes = await TeacherFirebaseService.getTeacherClasses(
        widget.schoolId, widget.teacher.assignedClassIds);
    if (!mounted) return;
    setState(() {
      _classes = classes;
      _loading = false;
    });
  }

  Future<void> _checkOfflineQueue() async {
    final queue = await TeacherFirebaseService.getOfflineQueue();
    if (!mounted) return;
    setState(() => _queueCount = queue.length);
    if (queue.isNotEmpty) _syncOfflineQueue();
  }

  Future<void> _syncOfflineQueue() async {
    if (!mounted) return;
    setState(() => _syncing = true);
    try {
      final queue = await TeacherFirebaseService.getOfflineQueue();
      int synced = 0;
      for (final item in queue) {
        final records = item.records.map((r) {
          final raw = Map<String, dynamic>.from(r);
          if (raw['date'] is String) {
            final dt = DateTime.parse(raw['date'] as String);
            raw['date'] = {
              '_seconds':     dt.millisecondsSinceEpoch ~/ 1000,
              '_nanoseconds': 0,
            };
          }
          return AttendanceRecord.fromMap(raw);
        }).toList();

        if (records.isEmpty) continue;

        final session = AttendanceSession(
          id:          item.sessionId,
          schoolId:    widget.schoolId,
          classId:     item.classId,
          teacherId:   widget.teacher.id,
          date:        records.first.date,
          isSubmitted: true,
        );

        await TeacherFirebaseService.submitAttendance(
            session: session, records: records);
        synced++;
      }
      await TeacherFirebaseService.clearOfflineQueue();
      if (!mounted) return;
      setState(() { _queueCount = 0; _syncing = false; });
      if (synced > 0) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('$synced offline session(s) synced!'),
          backgroundColor: const Color(0xFF16A34A),
          duration: const Duration(seconds: 2),
        ));
      }
    } catch (_) {
      if (mounted) setState(() => _syncing = false);
    }
  }

  Future<void> _logout() async {
    await TeacherFirebaseService.clearSession();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const TeacherLoginScreen()),
      (_) => false,
    );
  }

  String _todayLabel() {
    final n = DateTime.now();
    const days   = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    const months = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'];
    return '${days[n.weekday - 1]}, ${n.day} ${months[n.month - 1]} ${n.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(),
            if (_queueCount > 0) _buildSyncBanner(),
            const SizedBox(height: 6),
            _buildDateChip(),
            const SizedBox(height: 12),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  // ── Top bar ──────────────────────────────────────────────
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 12, 0),
      child: Row(
        children: [
          // Avatar + name
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => AccountScreen(
                schoolId: widget.schoolId,
                teacher:  widget.teacher,
              ),
            )),
            child: Row(
              children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color:        kPink.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: kPink.withValues(alpha: 0.5), width: 1.5),
                  ),
                  child: Center(
                    child: Text(
                      widget.teacher.name.isNotEmpty
                          ? widget.teacher.name[0].toUpperCase()
                          : 'T',
                      style: TextStyle(
                        color:      isDark(context) ? kDarkPink : kNavy,
                        fontSize:   18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.teacher.name,
                      style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'ID: ${widget.teacher.id}',
                      style: TextStyle(color: cMuted(context), fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Spacer(),
          // Chat
          _TopBtn(
            icon:    Icons.chat_rounded,
            color:   isDark(context) ? kDarkPink : kNavy,
            tooltip: 'Chat',
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => TeacherChatPage(
                schoolId: widget.schoolId,
                teacher:  widget.teacher,
              ),
            )),
          ),
          const SizedBox(width: 6),
          // Timetable
          Stack(
            clipBehavior: Clip.none,
            children: [
              _TopBtn(
                icon:    Icons.calendar_month_outlined,
                color:   isDark(context) ? kDarkTeal : kNavy,
                tooltip: 'My Timetable',
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(
                    builder: (_) => TimetableScreen(
                      schoolId: widget.schoolId,
                      teacher:  widget.teacher,
                    ),
                  ));
                  _checkTimetableUpdate();
                },
              ),
              if (_timetableNew)
                Positioned(
                  top:   -2,
                  right: -2,
                  child: Container(
                    width: 10, height: 10,
                    decoration: const BoxDecoration(
                        color: kError, shape: BoxShape.circle),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 6),
          // Notices
          _TopBtn(
            icon:    Icons.campaign_outlined,
            color:   isDark(context) ? kDarkTeal : kTeal,
            tooltip: 'Notices',
            onTap: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => NoticesScreen(
                schoolId:   widget.schoolId,
                schoolName: widget.schoolId,
              ),
            )),
          ),
          const SizedBox(width: 6),
          // Theme toggle
          _TopBtn(
            icon: isDark(context)
                ? Icons.light_mode_rounded
                : Icons.dark_mode_rounded,
            color:   isDark(context) ? kDarkTeal : kNavy,
            tooltip: 'Toggle theme',
            onTap: () => themeNotifier.value =
                isDark(context) ? ThemeMode.light : ThemeMode.dark,
          ),
          const SizedBox(width: 6),
          // Logout
          _TopBtn(
            icon:    Icons.logout_rounded,
            color:   cMuted(context),
            tooltip: 'Sign out',
            onTap:   _logout,
          ),
          const SizedBox(width: 4),
        ],
      ),
    );
  }

  // ── Offline sync banner ──────────────────────────────────
  Widget _buildSyncBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color:        const Color(0xFFF59E0B).withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: const Color(0xFFF59E0B).withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          const Icon(Icons.wifi_off_rounded,
              color: Color(0xFFF59E0B), size: 17),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '$_queueCount offline attendance session(s) pending sync',
              style: const TextStyle(
                  color: Color(0xFFF59E0B), fontSize: 12),
            ),
          ),
          _syncing
              ? const SizedBox(
                  width: 15, height: 15,
                  child: CircularProgressIndicator(
                      color: Color(0xFFF59E0B), strokeWidth: 2))
              : GestureDetector(
                  onTap: _syncOfflineQueue,
                  child: const Text('Sync now',
                      style: TextStyle(
                          color:      Color(0xFFF59E0B),
                          fontSize:   12,
                          fontWeight: FontWeight.w700)),
                ),
        ],
      ),
    );
  }

  // ── Date chip ────────────────────────────────────────────
  Widget _buildDateChip() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color:        kTeal.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(20),
            border:       Border.all(color: kTeal.withValues(alpha: 0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.calendar_today_outlined,
                  color: isDark(context) ? kDarkTeal : kTeal, size: 13),
              const SizedBox(width: 6),
              Text(
                _todayLabel(),
                style: TextStyle(
                  color:      isDark(context) ? kDarkTeal : kTeal,
                  fontSize:   12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Body ─────────────────────────────────────────────────
  Widget _buildBody() {
    if (_loading) {
      return Center(
        child: CircularProgressIndicator(
          color:       isDark(context) ? kDarkTeal : kTeal,
          strokeWidth: 2.5,
        ),
      );
    }
    if (_classes.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.class_outlined, color: cBorder(context), size: 56),
            const SizedBox(height: 12),
            Text('No classes assigned.',
                style: TextStyle(color: cMuted(context), fontSize: 15)),
            const SizedBox(height: 4),
            Text('Ask admin to assign classes.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );
    }
    return RefreshIndicator(
      color:     isDark(context) ? kDarkTeal : kTeal,
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
        itemCount: _classes.length,
        itemBuilder: (_, i) => _ClassCard(
          cls:      _classes[i],
          teacher:  widget.teacher,
          schoolId: widget.schoolId,
        ),
      ),
    );
  }
}

// ── Class card ────────────────────────────────────────────────
class _ClassCard extends StatelessWidget {
  final SchoolClass cls;
  final Teacher     teacher;
  final String      schoolId;

  const _ClassCard({
    required this.cls,
    required this.teacher,
    required this.schoolId,
  });

  @override
  Widget build(BuildContext context) {
    final isCT      = teacher.isClassTeacherOf(cls.id);
    final subject   = teacher.subjectFor(cls.id);
    final accentCol = isCT
        ? (isDark(context) ? kDarkTeal : kTeal)
        : kPink;

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ClassDetailScreen(
            schoolId: schoolId,
            teacher:  teacher,
            cls:      cls,
          ),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: accentCol.withValues(alpha: 0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
              color:      kNavy.withValues(alpha: 0.06),
              blurRadius: 16,
              offset:     const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            // Icon box
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                color:        accentCol.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                child: Text(
                  cls.name.isNotEmpty ? cls.name[0].toUpperCase() : '?',
                  style: TextStyle(
                    color:      accentCol,
                    fontSize:   24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),

            // Text
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    cls.name,
                    style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 3),
                  if (subject.isNotEmpty)
                    Text(
                      subject,
                      style: TextStyle(
                          color: cMuted(context), fontSize: 12),
                    ),
                  const SizedBox(height: 6),
                  // Role badges
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: [
                      _Badge(
                        label: isCT ? '★ Class Teacher' : 'Subject Teacher',
                        color: accentCol,
                      ),
                      _Badge(label: 'Homework', color: kNavy),
                      _Badge(label: 'Tests', color: kNavy),
                      if (isCT)
                        _Badge(label: 'Attendance', color: accentCol),
                    ],
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right_rounded,
                color: cMuted(context), size: 22),
          ],
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color  color;
  const _Badge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color:        color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border:       Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color:      color,
          fontSize:   10,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _TopBtn extends StatelessWidget {
  final IconData     icon;
  final Color        color;
  final String       tooltip;
  final VoidCallback onTap;
  const _TopBtn({
    required this.icon,
    required this.color,
    required this.tooltip,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
            color:        color.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withValues(alpha: 0.25)),
          ),
          child: Icon(icon, color: color, size: 19),
        ),
      ),
    );
  }
}