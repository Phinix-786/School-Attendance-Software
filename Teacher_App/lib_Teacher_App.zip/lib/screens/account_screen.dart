// lib/screens/account_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'login_screen.dart';
import 'privacy_policy_screen.dart';

class AccountScreen extends StatelessWidget {
  final String  schoolId;
  final Teacher teacher;

  const AccountScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
  });

  Future<void> _logout(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.45),
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(ctx),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Sign Out?',
          style: TextStyle(
            color:      cNavy(ctx),
            fontSize:   17,
            fontWeight: FontWeight.w800,
          ),
        ),
        content: Text(
          'You\'ll need to sign in again to mark attendance.',
          style: TextStyle(color: cMuted(ctx), fontSize: 13.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel',
                style: TextStyle(
                    color: cMuted(ctx), fontWeight: FontWeight.w600)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sign Out',
                style: TextStyle(
                    color: kError, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    await TeacherFirebaseService.clearSession();
    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const TeacherLoginScreen()),
        (_) => false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final initial = teacher.name.isNotEmpty
        ? teacher.name[0].toUpperCase()
        : 'T';

    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'My Account',
          style: TextStyle(
            color:      cNavy(context),
            fontSize:   17,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
        child: Column(
          children: [

            // ── Avatar ────────────────────────────────────
            Container(
              width: 88, height: 88,
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(24),
                border:       Border.all(
                    color: kPink.withValues(alpha: 0.45), width: 2),
                boxShadow: [
                  BoxShadow(
                    color:      kNavy.withValues(alpha: 0.10),
                    blurRadius: 24,
                    offset:     const Offset(0, 8),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  initial,
                  style: TextStyle(
                    color:      isDark(context) ? kDarkPink : kNavy,
                    fontSize:   36,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Name ──────────────────────────────────────
            Text(
              teacher.name,
              style: TextStyle(
                color:      cNavy(context),
                fontSize:   22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 4),

            // ── Teacher badge ─────────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(30),
                border:       Border.all(color: kPink.withValues(alpha: 0.35)),
              ),
              child: Text(
                '✦  Teacher',
                style: TextStyle(
                  color:         isDark(context) ? kDarkPink : kNavy,
                  fontSize:      12,
                  fontWeight:    FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ),
            const SizedBox(height: 32),

            // ── Info card ─────────────────────────────────
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(18),
                border:       Border.all(color: cBorder(context)),
                boxShadow: [
                  BoxShadow(
                    color:      kNavy.withValues(alpha: 0.05),
                    blurRadius: 20,
                    offset:     const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _infoRow(
                    context,
                    icon:  Icons.badge_outlined,
                    label: 'Teacher ID',
                    value: teacher.id,
                  ),
                  Divider(height: 1, color: cBorder(context)),
                  _infoRow(
                    context,
                    icon:  Icons.business_outlined,
                    label: 'School ID',
                    value: schoolId,
                  ),
                  Divider(height: 1, color: cBorder(context)),
                  _infoRow(
                    context,
                    icon:  Icons.class_outlined,
                    label: 'Classes Assigned',
                    value: '${teacher.assignedClassIds.length} class'
                        '${teacher.assignedClassIds.length == 1 ? '' : 'es'}',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // ── Powered by ────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(18),
                border:       Border.all(color: cBorder(context)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color:        kTeal.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(10),
                      border:       Border.all(color: kTeal.withValues(alpha: 0.3)),
                    ),
                    child: Icon(Icons.verified_outlined,
                        color: isDark(context) ? kDarkTeal : kTeal,
                        size: 20),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Powered by App_Name',
                        style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        'Teacher Attendance System',
                        style: TextStyle(
                          color:    cMuted(context),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Privacy Policy link ───────────────────────
            GestureDetector(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(
                      builder: (_) => const PrivacyPolicyScreen())),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color:        cCard(context),
                  borderRadius: BorderRadius.circular(14),
                  border:       Border.all(color: cBorder(context)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.privacy_tip_outlined,
                        color: cMuted(context), size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text('Privacy Policy',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   14,
                              fontWeight: FontWeight.w600)),
                    ),
                    Icon(Icons.chevron_right_rounded,
                        color: cMuted(context), size: 18),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Logout button ─────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kError.withValues(alpha: 0.10),
                  foregroundColor: kError,
                  elevation:       0,
                  side:            BorderSide(
                      color: kError.withValues(alpha: 0.35), width: 1.5),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                onPressed: () => _logout(context),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.logout_rounded, size: 20, color: kError),
                    SizedBox(width: 8),
                    Text(
                      'Sign Out',
                      style: TextStyle(
                        color:      kError,
                        fontSize:   16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Info row ──────────────────────────────────────────────
  Widget _infoRow(
    BuildContext context, {
    required IconData icon,
    required String   label,
    required String   value,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Icon(icon, color: cMuted(context), size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color:      cMuted(context),
                  fontSize:   11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}