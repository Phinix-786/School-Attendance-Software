// lib/screens/login_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../services/teacher_firebase_service.dart';
import 'class_selection_screen.dart';
import 'privacy_consent_screen.dart';

class TeacherLoginScreen extends StatefulWidget {
  const TeacherLoginScreen({super.key});
  @override
  State<TeacherLoginScreen> createState() => _TeacherLoginScreenState();
}

class _TeacherLoginScreenState extends State<TeacherLoginScreen> {
  final _schoolCtrl    = TextEditingController();
  final _teacherIdCtrl = TextEditingController();
  final _passCtrl      = TextEditingController();
  bool    _loading  = false;
  String? _error;
  bool    _obscure  = true;

  @override
  void dispose() {
    _schoolCtrl.dispose();
    _teacherIdCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 30),

              // ── Logo ──────────────────────────────────────
              Container(
                width: 86, height: 86,
                decoration: BoxDecoration(
                  color:        const Color(0xFFEEDFC8),
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                      color:      kNavy.withValues(alpha: 0.12),
                      blurRadius: 24,
                      offset:     const Offset(0, 8),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(22),
                  child: Image.asset(
                    'assets/icon.png',
                    width: 86, height: 86,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // ── Title ─────────────────────────────────────
              Text(
                'Teacher Portal',
                style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color:        kPink.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(30),
                  border:       Border.all(color: kPink.withValues(alpha: 0.35)),
                ),
                child: Text(
                  '✦  Sign in to mark attendance',
                  style: TextStyle(
                    color:         isDark(context) ? kDarkPink : kNavy,
                    fontSize:      12,
                    fontWeight:    FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // ── Form card ─────────────────────────────────
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color:         cCard(context),
                  borderRadius:  BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color:      kNavy.withValues(alpha: 0.07),
                      blurRadius: 40,
                      offset:     const Offset(0, 16),
                    ),
                  ],
                  border: Border.all(color: cBorder(context)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _field(context, 'School ID', _schoolCtrl,
                        icon: Icons.business_outlined),
                    const SizedBox(height: 16),
                    _field(context, 'Teacher ID', _teacherIdCtrl,
                        icon: Icons.badge_outlined),
                    const SizedBox(height: 16),
                    _field(context, 'Password', _passCtrl,
                        icon:    Icons.lock_outline_rounded,
                        obscure: _obscure,
                        suffix:  IconButton(
                          icon: Icon(
                            _obscure
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: cMuted(context), size: 20,
                          ),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        )),

                    // ── Error ──────────────────────────────
                    AnimatedSize(
                      duration: const Duration(milliseconds: 220),
                      curve:    Curves.easeOut,
                      child: _error != null
                          ? Padding(
                              padding: const EdgeInsets.only(top: 14),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 11),
                                decoration: BoxDecoration(
                                  color:        kError.withValues(alpha: 0.08),
                                  borderRadius: BorderRadius.circular(12),
                                  border:       Border.all(
                                      color: kError.withValues(alpha: 0.3)),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.warning_amber_rounded,
                                        color: kError, size: 18),
                                    const SizedBox(width: 9),
                                    Expanded(
                                      child: Text(
                                        _error!,
                                        style: const TextStyle(
                                          color:      kError,
                                          fontSize:   13,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ),

                    const SizedBox(height: 24),

                    // ── Sign In button ─────────────────────
                    SizedBox(
                      width: double.infinity, height: 54,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kNavy,
                          foregroundColor: Colors.white,
                          elevation:       0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                        onPressed: _loading ? null : _login,
                        child: _loading
                            ? const SizedBox(
                                width: 22, height: 22,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2.5))
                            : const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text('Sign In',
                                      style: TextStyle(
                                          fontSize:   16,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 0.2)),
                                  SizedBox(width: 8),
                                  Icon(Icons.arrow_forward_rounded, size: 18),
                                ],
                              ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ── Footer ────────────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_outlined,
                      size: 12,
                      color: cMuted(context).withValues(alpha: 0.6)),
                  const SizedBox(width: 5),
                  Text(
                    'Powered By App_Name',
                    style: TextStyle(
                      color:      cMuted(context).withValues(alpha: 0.6),
                      fontSize:   11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Field widget ──────────────────────────────────────────
  Widget _field(
    BuildContext context,
    String label,
    TextEditingController ctrl, {
    IconData? icon,
    bool obscure = false,
    TextInputType? keyboard,
    Widget? suffix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color:      cNavy(context),
            fontSize:   12,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.2,
          ),
        ),
        const SizedBox(height: 7),
        TextField(
          controller:   ctrl,
          obscureText:  obscure,
          keyboardType: keyboard,
          onSubmitted:  (_) => _login(),
          style: TextStyle(
            color:      cNavy(context),
            fontSize:   15,
            fontWeight: FontWeight.w500,
          ),
          decoration: InputDecoration(
            prefixIcon: icon != null
                ? Icon(icon, color: cMuted(context), size: 20)
                : null,
            suffixIcon: suffix,
            hintStyle:  TextStyle(
                color: cMuted(context).withValues(alpha: 0.5), fontSize: 14),
            filled:     true,
            fillColor:  cBg(context),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: cBorder(context))),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: cBorder(context))),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: kTeal, width: 2)),
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 16),
          ),
        ),
      ],
    );
  }

  // ── Login logic ───────────────────────────────────────────
  Future<void> _login() async {
    final schoolId  = _schoolCtrl.text.trim();
    final teacherId = _teacherIdCtrl.text.trim();
    final pass      = _passCtrl.text.trim();

    if (schoolId.isEmpty || teacherId.isEmpty || pass.isEmpty) {
      setState(() => _error = 'Please fill all fields.');
      return;
    }

    setState(() { _loading = true; _error = null; });

    try {
      final teacher =
          await TeacherFirebaseService.login(schoolId, teacherId, pass);
      if (teacher == null) {
        setState(() => _error = 'Invalid Teacher ID or password.');
        return;
      }

      await TeacherFirebaseService.saveSession(
          schoolId, teacher.id, teacher.name);


      if (mounted) {
        final destination = ClassSelectionScreen(
            schoolId: schoolId, teacher: teacher);
        final agreed = await PrivacyConsentScreen.hasAgreed();
        if (!mounted) return;
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) => agreed
                    ? destination
                    : PrivacyConsentScreen(nextScreen: destination)));
      }
    } catch (e) {
      setState(() => _error = 'Error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}