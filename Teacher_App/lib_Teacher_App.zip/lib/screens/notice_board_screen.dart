// lib/screens/notice_board_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';

class NoticesScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;

  const NoticesScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
  });

  @override
  State<NoticesScreen> createState() => _NoticesScreenState();
}

class _NoticesScreenState extends State<NoticesScreen> {
  List<SchoolNotice> _notices = [];
  bool               _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final notices = await TeacherFirebaseService.getNotices(widget.schoolId);
    if (mounted) setState(() { _notices = notices; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Notices',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   17,
                    fontWeight: FontWeight.w800)),
            Text(widget.schoolName,
                style: TextStyle(color: cMuted(context), fontSize: 11)),
          ],
        ),
      ),
      body: _loading
          ? Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal))
          : _notices.isEmpty
              ? _empty()
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                    itemCount: _notices.length,
                    itemBuilder: (_, i) => _NoticeCard(notice: _notices[i]),
                  ),
                ),
    );
  }

  Widget _empty() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Center(
                  child: Text('📣', style: TextStyle(fontSize: 28))),
            ),
            const SizedBox(height: 14),
            Text('No notices yet.',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   16,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text('Pull to refresh.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );
}

class _NoticeCard extends StatelessWidget {
  final SchoolNotice notice;
  const _NoticeCard({required this.notice});

  @override
  Widget build(BuildContext context) {
    final date = '${notice.createdAt.day}/${notice.createdAt.month}/${notice.createdAt.year}';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 10,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(notice.targetAudience.toUpperCase(),
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   9,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5)),
              ),
              const Spacer(),
              Text(date,
                  style: TextStyle(color: cMuted(context), fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(notice.title,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   15,
                  fontWeight: FontWeight.w700)),
          if (notice.body.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(notice.body,
                style: TextStyle(
                    color:    cBlue(context),
                    fontSize: 13,
                    height:   1.5)),
          ],
          if (notice.createdBy.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('By: ${notice.createdBy}',
                style: TextStyle(color: cMuted(context), fontSize: 11)),
          ],
        ],
      ),
    );
  }
}
