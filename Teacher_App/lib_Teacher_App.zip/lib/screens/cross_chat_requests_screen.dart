// lib/screens/cross_chat_requests_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';

class CrossChatRequestsScreen extends StatefulWidget {
  final String      schoolId;
  final SchoolClass cls;

  const CrossChatRequestsScreen({
    super.key,
    required this.schoolId,
    required this.cls,
  });

  @override
  State<CrossChatRequestsScreen> createState() =>
      _CrossChatRequestsScreenState();
}

class _CrossChatRequestsScreenState extends State<CrossChatRequestsScreen> {
  List<CrossChatRequest> _requests = [];
  bool                   _loading  = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final reqs = await TeacherFirebaseService.getCrossClassRequests(
        widget.schoolId, widget.cls.id);
    if (mounted) setState(() { _requests = reqs; _loading = false; });
  }

  Future<void> _approve(CrossChatRequest req) async {
    await TeacherFirebaseService.approveCrossClassRequest(
        widget.schoolId, widget.cls.id, req);
    _load();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Chat request approved!'),
            backgroundColor: Color(0xFF16A34A)),
      );
    }
  }

  Future<void> _reject(CrossChatRequest req) async {
    await TeacherFirebaseService.rejectCrossClassRequest(
        widget.schoolId, widget.cls.id, req.id);
    _load();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Request rejected.'),
            backgroundColor: Color(0xFFE53E6B)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(
          child: CircularProgressIndicator(
              color: isDark(context) ? kDarkTeal : kTeal));
    }

    if (_requests.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('💬', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            Text('No pending chat requests.',
                style: TextStyle(color: cMuted(context), fontSize: 15)),
            const SizedBox(height: 4),
            Text('Pull to refresh.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
        itemCount: _requests.length,
        itemBuilder: (_, i) => _RequestCard(
          req:      _requests[i],
          onApprove: () => _approve(_requests[i]),
          onReject:  () => _reject(_requests[i]),
        ),
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  final CrossChatRequest req;
  final VoidCallback     onApprove;
  final VoidCallback     onReject;

  const _RequestCard({
    required this.req,
    required this.onApprove,
    required this.onReject,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 10,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color:        kPink.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                  child: Text(req.requesterName.isNotEmpty
                          ? req.requesterName[0].toUpperCase()
                          : '?',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   16,
                          fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(req.requesterName,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   14,
                            fontWeight: FontWeight.w700)),
                    Text('wants to chat with  ${req.targetStudentName}',
                        style: TextStyle(
                            color: cMuted(context), fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color:        cBg(context),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                Icon(Icons.swap_horiz_rounded,
                    size: 14, color: cMuted(context)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Target class: ${req.targetClassId.isNotEmpty ? req.targetClassId : "N/A"}',
                    style: TextStyle(color: cMuted(context), fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: onReject,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color:        kError.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: kError.withValues(alpha: 0.3)),
                    ),
                    child: const Center(
                      child: Text('Reject',
                          style: TextStyle(
                              color:      kError,
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: onApprove,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color:        const Color(0xFF16A34A).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: const Color(0xFF16A34A).withValues(alpha: 0.35)),
                    ),
                    child: const Center(
                      child: Text('Approve',
                          style: TextStyle(
                              color:      Color(0xFF16A34A),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
