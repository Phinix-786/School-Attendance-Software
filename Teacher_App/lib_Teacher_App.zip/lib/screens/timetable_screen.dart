// lib/screens/timetable_screen.dart
// Teacher app — view own timetable. Shows "Updated" badge when the
// timetable was saved after the teacher last viewed it.
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';

class TimetableScreen extends StatefulWidget {
  final String  schoolId;
  final Teacher teacher;

  const TimetableScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
  });

  @override
  State<TimetableScreen> createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  TeacherTimetable? _timetable;
  bool              _loading  = true;
  bool              _isNew    = false;  // true = updated since last viewed

  static const _days    = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  static const _periods = ['1','2','3','4','5','6','7','8'];
  static const _prefKey = 'timetable_last_viewed_';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final tt = await TeacherFirebaseService.getMyTimetable(
        widget.schoolId, widget.teacher.id);

    // Check if it's new since last view
    final prefs   = await SharedPreferences.getInstance();
    final lastKey = '$_prefKey${widget.teacher.id}';
    final lastMs  = prefs.getInt(lastKey) ?? 0;
    bool isNew    = false;
    if (tt != null) {
      isNew = tt.updatedAt.millisecondsSinceEpoch > lastMs;
      // Mark as viewed
      await prefs.setInt(lastKey,
          DateTime.now().millisecondsSinceEpoch);
    }

    if (mounted) setState(() { _timetable = tt; _loading = false; _isNew = isNew; });
  }

  // Build a lookup: day → period → entry
  Map<String, Map<String, TimetableEntry>> _buildMap() {
    final m = <String, Map<String, TimetableEntry>>{};
    if (_timetable == null) return m;
    for (final e in _timetable!.entries) {
      m[e.day] ??= {};
      m[e.day]![e.period] = e;
    }
    return m;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            Text('My Timetable',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   17,
                    fontWeight: FontWeight.w800)),
            if (_isNew) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        kError.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: kError.withValues(alpha: 0.4)),
                ),
                child: const Text('Updated',
                    style: TextStyle(
                        color:      kError,
                        fontSize:   10,
                        fontWeight: FontWeight.w800)),
              ),
            ],
          ],
        ),
      ),
      body: _loading
          ? Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal))
          : _timetable == null || _timetable!.entries.isEmpty
              ? _empty()
              : _buildTable(),
    );
  }

  Widget _empty() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('📅', style: TextStyle(fontSize: 52)),
            const SizedBox(height: 14),
            Text('No timetable set yet.',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   16,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text('Your section head will add your schedule.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );

  Widget _buildTable() {
    final map    = _buildMap();
    final updStr = '${_timetable!.updatedAt.day}/'
        '${_timetable!.updatedAt.month}/'
        '${_timetable!.updatedAt.year}';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
          child: Text('Last updated: $updStr',
              style: TextStyle(color: cMuted(context), fontSize: 12)),
        ),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Table(
                defaultColumnWidth: const FixedColumnWidth(110),
                border: TableBorder.all(
                    color: cBorder(context), width: 0.5,
                    borderRadius: BorderRadius.circular(4)),
                children: [
                  // Header
                  TableRow(
                    decoration: BoxDecoration(
                        color: kNavy),
                    children: [
                      _hCell('Period'),
                      ..._days.map((d) => _hCell(
                          d.substring(0, 3))), // Mon, Tue…
                    ],
                  ),
                  // Rows
                  ..._periods.map((p) {
                    final rowBg = int.parse(p).isOdd
                        ? Colors.transparent
                        : cBg(context).withValues(alpha: 0.4);
                    return TableRow(
                      decoration: BoxDecoration(color: rowBg),
                      children: [
                        // Period label
                        Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 8),
                          child: Text('P$p',
                              style: TextStyle(
                                  color:      cNavy(context),
                                  fontSize:   12,
                                  fontWeight: FontWeight.w700)),
                        ),
                        // Day cells
                        ..._days.map((d) {
                          final entry = map[d]?[p];
                          if (entry == null || entry.subject.isEmpty) {
                            return Container(
                              padding: const EdgeInsets.all(8),
                              child: Text('—',
                                  style: TextStyle(
                                      color: cBorder(context),
                                      fontSize: 12)),
                            );
                          }
                          return Container(
                            padding: const EdgeInsets.all(8),
                            color: kTeal.withValues(alpha: 0.1),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(entry.subject,
                                    style: TextStyle(
                                        color:      cNavy(context),
                                        fontSize:   12,
                                        fontWeight: FontWeight.w700)),
                                if (entry.className.isNotEmpty)
                                  Text(entry.className,
                                      style: TextStyle(
                                          color:    cMuted(context),
                                          fontSize: 10)),
                              ],
                            ),
                          );
                        }),
                      ],
                    );
                  }),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _hCell(String text) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        child: Text(text,
            style: const TextStyle(
                color:      Colors.white,
                fontSize:   11,
                fontWeight: FontWeight.w700)),
      );
}
