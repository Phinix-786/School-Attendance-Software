// lib/screens/tests_tab.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'shared_widgets.dart';

// ── Tests tab (list + FAB) ────────────────────────────────────
class TestsTab extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;

  const TestsTab({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
  });

  @override
  State<TestsTab> createState() => _TestsTabState();
}

class _TestsTabState extends State<TestsTab> {
  List<SchoolTest> _items   = [];
  bool             _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final ts = await TeacherFirebaseService.getTests(
        widget.schoolId, widget.cls.id);
    if (mounted) setState(() { _items = ts; _loading = false; });
  }

  Future<void> _openAdd({SchoolTest? existing}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AddTestScreen(
          schoolId: widget.schoolId,
          teacher:  widget.teacher,
          cls:      widget.cls,
          existing: existing,
        ),
      ),
    );
    _load();
  }

  void _openResults(SchoolTest test) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TestResultsScreen(
          schoolId: widget.schoolId,
          teacher:  widget.teacher,
          cls:      widget.cls,
          test:     test,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        _loading
            ? Center(
                child: CircularProgressIndicator(
                    color: isDark(context) ? kDarkTeal : kTeal,
                    strokeWidth: 2.5))
            : _items.isEmpty
                ? _empty()
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                      itemCount: _items.length,
                      itemBuilder: (_, i) => _TestCard(
                        test:        _items[i],
                        onEdit:      () => _openAdd(existing: _items[i]),
                        onResults:   () => _openResults(_items[i]),
                      ),
                    ),
                  ),
        Positioned(
          bottom: 16, right: 16,
          child: FloatingActionButton.extended(
            heroTag: 'test_fab',
            backgroundColor: kNavy,
            foregroundColor: Colors.white,
            icon:  const Icon(Icons.add_rounded),
            label: const Text('Add Test',
                style: TextStyle(fontWeight: FontWeight.w700)),
            onPressed: () => _openAdd(),
          ),
        ),
      ],
    );
  }

  Widget _empty() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('📝', style: TextStyle(fontSize: 52)),
            const SizedBox(height: 12),
            Text('No tests yet.',
                style: TextStyle(color: cMuted(context), fontSize: 15)),
            const SizedBox(height: 4),
            Text('Tap + Add Test to create one.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );
}

// ── Test card ─────────────────────────────────────────────────
class _TestCard extends StatelessWidget {
  final SchoolTest  test;
  final VoidCallback onEdit;
  final VoidCallback onResults;
  const _TestCard({
    required this.test,
    required this.onEdit,
    required this.onResults,
  });

  @override
  Widget build(BuildContext context) {
    final testDate =
        '${test.testDate.day}/${test.testDate.month}/${test.testDate.year}';
    final isPast   = test.testDate.isBefore(DateTime.now());

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 12,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title row
          Row(
            children: [
              Expanded(
                child: Text(test.topic,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   15,
                        fontWeight: FontWeight.w700)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        isPast
                      ? cBorder(context)
                      : kTeal.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(isPast ? 'Past' : 'Upcoming',
                    style: TextStyle(
                        color:      isPast ? cMuted(context) : kTeal,
                        fontSize:   10,
                        fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(Icons.calendar_today_outlined,
                  size: 13, color: cMuted(context)),
              const SizedBox(width: 4),
              Text('Test: $testDate',
                  style: TextStyle(color: cMuted(context), fontSize: 12)),
              if (test.pageNumbers.isNotEmpty) ...[
                const SizedBox(width: 12),
                Icon(Icons.menu_book_outlined,
                    size: 13, color: cMuted(context)),
                const SizedBox(width: 4),
                Text('pp. ${test.pageNumbers}',
                    style: TextStyle(
                        color: cMuted(context), fontSize: 12)),
              ],
            ],
          ),
          if (test.instructions.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(test.instructions,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: cBlue(context), fontSize: 13)),
          ],
          const SizedBox(height: 10),
          // Action buttons
          Row(
            children: [
              if (test.isEditable)
                _ActionChip(
                  icon:  Icons.edit_outlined,
                  label: 'Edit',
                  color: cNavy(context),
                  onTap: onEdit,
                ),
              if (test.isEditable) const SizedBox(width: 8),
              if (isPast)
                _ActionChip(
                  icon:  Icons.bar_chart_rounded,
                  label: 'Results',
                  color: kTeal,
                  onTap: onResults,
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  final IconData     icon;
  final String       label;
  final Color        color;
  final VoidCallback onTap;
  const _ActionChip({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color:        color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
            border:       Border.all(color: color.withValues(alpha: 0.25)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 13, color: color),
              const SizedBox(width: 5),
              Text(label,
                  style: TextStyle(
                      color:      color,
                      fontSize:   12,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      );
}

// ── Add / Edit Test screen ────────────────────────────────────
class AddTestScreen extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;
  final SchoolTest? existing;

  const AddTestScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
    this.existing,
  });

  @override
  State<AddTestScreen> createState() => _AddTestScreenState();
}

class _AddTestScreenState extends State<AddTestScreen> {
  final _topicCtrl = TextEditingController();
  final _pagesCtrl = TextEditingController();
  final _instrCtrl = TextEditingController();
  final _picker    = ImagePicker();

  List<String> _existingUrls = [];
  List<File>   _newFiles     = [];
  DateTime     _testDate = DateTime.now().add(const Duration(days: 1));
  bool         _uploading = false;
  bool         _saving    = false;
  String?      _error;

  bool get _isEdit => widget.existing != null;
  int  get _totalImages => _existingUrls.length + _newFiles.length;

  @override
  void initState() {
    super.initState();
    if (_isEdit) {
      final t = widget.existing!;
      _topicCtrl.text = t.topic;
      _pagesCtrl.text = t.pageNumbers;
      _instrCtrl.text = t.instructions;
      _existingUrls   = List.from(t.imageUrls);
      _testDate       = t.testDate;
    }
  }

  @override
  void dispose() {
    _topicCtrl.dispose();
    _pagesCtrl.dispose();
    _instrCtrl.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    if (_totalImages >= 20) {
      setState(() => _error = 'Maximum 20 images allowed.');
      return;
    }
    final picked =
        await _picker.pickMultiImage(limit: 20 - _totalImages);
    if (picked.isNotEmpty) {
      setState(() {
        _newFiles.addAll(picked.map((x) => File(x.path)));
        if (_totalImages > 20) {
          _newFiles =
              _newFiles.take(20 - _existingUrls.length).toList();
        }
      });
    }
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context:     context,
      initialDate: _testDate,
      firstDate:   DateTime.now(),
      lastDate:    DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null) setState(() => _testDate = d);
  }

  Future<void> _submit() async {
    if (_topicCtrl.text.trim().isEmpty) {
      setState(() => _error = 'Please enter a topic.');
      return;
    }
    setState(() { _saving = true; _error = null; });

    try {
      final id = _isEdit ? widget.existing!.id : const Uuid().v4();

      setState(() => _uploading = true);
      TeacherFirebaseService.setUploadContext(widget.cls.id);
      final uploaded = <String>[];
      for (int i = 0; i < _newFiles.length; i++) {
        final url = await TeacherFirebaseService.uploadImage(
            _newFiles[i], widget.schoolId,
            'tests', id, _existingUrls.length + i);
        uploaded.add(url);
      }
      setState(() => _uploading = false);

      final test = SchoolTest(
        id:           id,
        schoolId:     widget.schoolId,
        classId:      widget.cls.id,
        teacherId:    widget.teacher.id,
        subject:      widget.teacher.subjectFor(widget.cls.id),
        topic:        _topicCtrl.text.trim(),
        instructions: _instrCtrl.text.trim(),
        pageNumbers:  _pagesCtrl.text.trim(),
        imageUrls:    [..._existingUrls, ...uploaded],
        createdAt:    _isEdit ? widget.existing!.createdAt : DateTime.now(),
        testDate:     _testDate,
      );

      if (_isEdit) {
        await TeacherFirebaseService.updateTest(test);
      } else {
        await TeacherFirebaseService.submitTest(test);
      }

      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() {
          _saving = false;
          _error  = 'Failed to save. Try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ds =
        '${_testDate.day}/${_testDate.month}/${_testDate.year}';

    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Text(_isEdit ? 'Edit Test' : 'Add Test',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   19,
                          fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FormLabel('Topic *'),
                    LabeledTextField(ctrl: _topicCtrl, hint: 'e.g. Chapter 6 Quiz'),
                    const SizedBox(height: 16),

                    FormLabel('Test Date *'),
                    GestureDetector(
                      onTap: _pickDate,
                      child: Container(
                        padding: const EdgeInsets.all(13),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(12),
                          border:       Border.all(color: cBorder(context)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.calendar_today_outlined,
                                color: cMuted(context), size: 17),
                            const SizedBox(width: 10),
                            Text(ds,
                                style: TextStyle(
                                    color:      cNavy(context),
                                    fontSize:   14,
                                    fontWeight: FontWeight.w600)),
                            const Spacer(),
                            Icon(Icons.edit_calendar_outlined,
                                color: cMuted(context), size: 15),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    FormLabel('Book Page Numbers (optional)'),
                    LabeledTextField(ctrl: _pagesCtrl, hint: 'e.g. 60–65'),
                    const SizedBox(height: 16),

                    FormLabel('Photos ($_totalImages / 20)'),
                    ImageGrid(
                      existingUrls: _existingUrls,
                      newFiles:     _newFiles,
                      onAdd:        _pick,
                      onRemoveExisting: (i) =>
                          setState(() => _existingUrls.removeAt(i)),
                      onRemoveNew: (i) =>
                          setState(() => _newFiles.removeAt(i)),
                    ),
                    const SizedBox(height: 16),

                    FormLabel('Instructions'),
                    LabeledTextField(
                        ctrl:     _instrCtrl,
                        hint:     'e.g. Study all highlighted topics.',
                        maxLines: 4),
                    const SizedBox(height: 16),

                    if (_error != null) ErrorBox(_error!),

                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kNavy,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        onPressed: (_saving || _uploading) ? null : _submit,
                        child: _saving
                            ? Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                children: [
                                  const SizedBox(
                                      width: 18, height: 18,
                                      child: CircularProgressIndicator(
                                          color:       Colors.white,
                                          strokeWidth: 2.5)),
                                  const SizedBox(width: 10),
                                  Text(_uploading
                                      ? 'Uploading…'
                                      : 'Saving…'),
                                ],
                              )
                            : Text(_isEdit ? 'Update Test' : 'Submit Test',
                                style: const TextStyle(
                                    fontSize:   16,
                                    fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Test Results screen ───────────────────────────────────────
class TestResultsScreen extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;
  final SchoolTest  test;

  const TestResultsScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
    required this.test,
  });

  @override
  State<TestResultsScreen> createState() => _TestResultsScreenState();
}

class _TestResultsScreenState extends State<TestResultsScreen> {
  List<Student>    _students = [];
  List<TestResult> _results  = [];
  bool             _loading  = true;
  final _totalCtrl = TextEditingController(text: '100');
  int _totalMarks  = 100;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() { _totalCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    final students = await TeacherFirebaseService.getStudentsByClass(
        widget.schoolId, widget.cls.id);
    final results  = await TeacherFirebaseService.getResults(
        widget.schoolId, widget.cls.id, widget.test.id);
    if (!mounted) return;
    if (results.isNotEmpty) {
      _totalMarks      = results.first.marksTotal;
      _totalCtrl.text  = _totalMarks.toString();
    }
    setState(() {
      _students = students;
      _results  = results;
      _loading  = false;
    });
  }

  TestResult? _resultFor(String studentId) {
    try { return _results.firstWhere((r) => r.studentId == studentId); }
    catch (_) { return null; }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Test Results',
                            style: TextStyle(
                                color:      cNavy(context),
                                fontSize:   19,
                                fontWeight: FontWeight.w800)),
                        Text(widget.test.topic,
                            style: TextStyle(
                                color: cMuted(context), fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
              child: Row(
                children: [
                  Text('Total Marks:',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: 70,
                    child: TextField(
                      controller:   _totalCtrl,
                      keyboardType: TextInputType.number,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontWeight: FontWeight.w700),
                      decoration: InputDecoration(
                        isDense:        true,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 8),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: cBorder(context))),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide(color: cBorder(context))),
                      ),
                      onChanged: (v) {
                        final n = int.tryParse(v);
                        if (n != null && n > 0) setState(() => _totalMarks = n);
                      },
                    ),
                  ),
                  const SizedBox(width: 14),
                  Text('${_results.length}/${_students.length} submitted',
                      style: TextStyle(color: cMuted(context), fontSize: 12)),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? Center(
                      child: CircularProgressIndicator(
                          color: isDark(context) ? kDarkTeal : kTeal))
                  : _students.isEmpty
                      ? Center(
                          child: Text('No students in this class.',
                              style: TextStyle(color: cMuted(context))))
                      : ListView.builder(
                          padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
                          itemCount: _students.length,
                          itemBuilder: (_, i) {
                            final s = _students[i];
                            final r = _resultFor(s.id);
                            return _StudentTile(
                              student:    s,
                              result:     r,
                              totalMarks: _totalMarks,
                              onTap: () => _openEntry(s, r),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }

  void _openEntry(Student student, TestResult? existing) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: cCard(context),
      shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _ResultSheet(
        student:    student,
        test:       widget.test,
        schoolId:   widget.schoolId,
        cls:        widget.cls,
        totalMarks: _totalMarks,
        existing:   existing,
        onSaved: () { Navigator.pop(context); _load(); },
      ),
    );
  }
}

class _StudentTile extends StatelessWidget {
  final Student     student;
  final TestResult? result;
  final int         totalMarks;
  final VoidCallback onTap;
  const _StudentTile({
    required this.student, required this.result,
    required this.totalMarks, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final has      = result != null;
    final absent   = has && result!.wasAbsent;
    final pct      = (has && !absent) ? result!.percentage : null;
    Color col      = cBorder(context);
    if (absent) {
      col = const Color(0xFFF59E0B);
    } else if (pct != null) {
      col = pct >= 80
          ? const Color(0xFF16A34A)
          : pct >= 50
              ? const Color(0xFFF59E0B)
              : kError;
    }
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color:      kNavy.withValues(alpha: 0.04),
                blurRadius: 10,
                offset:     const Offset(0, 3)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(student.name[0].toUpperCase(),
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   17,
                        fontWeight: FontWeight.w800)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(student.name,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   14,
                          fontWeight: FontWeight.w700)),
                  Text('Roll: ${student.rollNo}',
                      style: TextStyle(
                          color: cMuted(context), fontSize: 12)),
                ],
              ),
            ),
            if (absent)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color:        const Color(0xFFF59E0B).withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFF59E0B).withValues(alpha: 0.4)),
                ),
                child: const Text('Absent',
                    style: TextStyle(
                        color:      Color(0xFFF59E0B),
                        fontSize:   12,
                        fontWeight: FontWeight.w700)),
              )
            else if (has) ...[
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('${result!.marksObtained}/$totalMarks',
                      style: TextStyle(
                          color:      col,
                          fontSize:   15,
                          fontWeight: FontWeight.w800)),
                  Text('${pct!.toStringAsFixed(1)}%',
                      style:
                          TextStyle(color: col, fontSize: 11)),
                ],
              ),
            ] else
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color:        kNavy.withValues(alpha: 0.07),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text('Enter',
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   12,
                        fontWeight: FontWeight.w600)),
              ),
            const SizedBox(width: 4),
            Icon(Icons.chevron_right_rounded,
                color: cMuted(context), size: 18),
          ],
        ),
      ),
    );
  }
}

class _ResultSheet extends StatefulWidget {
  final Student     student;
  final SchoolTest  test;
  final String      schoolId;
  final SchoolClass cls;
  final int         totalMarks;
  final TestResult? existing;
  final VoidCallback onSaved;
  const _ResultSheet({
    required this.student, required this.test, required this.schoolId,
    required this.cls, required this.totalMarks,
    required this.existing, required this.onSaved,
  });

  @override
  State<_ResultSheet> createState() => _ResultSheetState();
}

class _ResultSheetState extends State<_ResultSheet> {
  late final TextEditingController _marksCtrl;
  late final TextEditingController _remCtrl;
  bool    _saving   = false;
  bool    _isAbsent = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _isAbsent  = widget.existing?.wasAbsent ?? false;
    _marksCtrl = TextEditingController(
        text: _isAbsent ? '0' : (widget.existing?.marksObtained.toString() ?? ''));
    _remCtrl   = TextEditingController(
        text: widget.existing?.remarks ?? '');
  }

  @override
  void dispose() { _marksCtrl.dispose(); _remCtrl.dispose(); super.dispose(); }

  void _toggleAbsent(bool val) {
    setState(() {
      _isAbsent = val;
      if (val) _marksCtrl.text = '0';
    });
  }

  Future<void> _save() async {
    int marks = 0;
    if (!_isAbsent) {
      final parsed = int.tryParse(_marksCtrl.text.trim());
      if (parsed == null || parsed < 0 || parsed > widget.totalMarks) {
        setState(() =>
            _error = 'Enter marks between 0 and ${widget.totalMarks}.');
        return;
      }
      marks = parsed;
    }
    setState(() { _saving = true; _error = null; });

    final result = TestResult(
      id:            widget.existing?.id ?? const Uuid().v4(),
      schoolId:      widget.schoolId,
      classId:       widget.cls.id,
      testId:        widget.test.id,
      studentId:     widget.student.id,
      studentName:   widget.student.name,
      marksObtained: marks,
      marksTotal:    widget.totalMarks,
      remarks:       _remCtrl.text.trim(),
      submittedAt:   DateTime.now(),
      wasAbsent:     _isAbsent,
    );

    try {
      await TeacherFirebaseService.submitResult(result);
      widget.onSaved();
    } catch (_) {
      if (mounted) setState(() { _saving = false; _error = 'Failed to save.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          24, 24, 24, MediaQuery.of(context).viewInsets.bottom + 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.student.name,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   18,
                  fontWeight: FontWeight.w800)),
          Text('Roll: ${widget.student.rollNo}',
              style: TextStyle(color: cMuted(context), fontSize: 13)),
          const SizedBox(height: 16),

          // Absent toggle
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: _isAbsent
                  ? const Color(0xFFF59E0B).withValues(alpha: 0.08)
                  : cBg(context),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: _isAbsent
                      ? const Color(0xFFF59E0B).withValues(alpha: 0.4)
                      : cBorder(context)),
            ),
            child: Row(
              children: [
                Icon(Icons.event_busy_rounded,
                    size: 18,
                    color: _isAbsent
                        ? const Color(0xFFF59E0B)
                        : cMuted(context)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text('Student was absent on test day',
                      style: TextStyle(
                          color: _isAbsent
                              ? const Color(0xFFF59E0B)
                              : cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w600)),
                ),
                Switch(
                  value:           _isAbsent,
                  onChanged:       _toggleAbsent,
                  activeColor:     const Color(0xFFF59E0B),
                  inactiveThumbColor: cMuted(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          if (!_isAbsent) ...[
            Text('Marks Obtained (out of ${widget.totalMarks})',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   13,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(
              controller:   _marksCtrl,
              keyboardType: TextInputType.number,
              enabled:      !_isAbsent,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   20,
                  fontWeight: FontWeight.w700),
              decoration: InputDecoration(
                suffix: Text('/ ${widget.totalMarks}',
                    style: TextStyle(color: cMuted(context), fontSize: 15)),
                filled:    true,
                fillColor: cBg(context),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: cBorder(context))),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: cBorder(context))),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: kTeal, width: 2)),
              ),
            ),
            const SizedBox(height: 14),
          ],

          Text("Teacher's Remarks",
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   13,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          TextField(
            controller: _remCtrl,
            maxLines:   3,
            style:      TextStyle(color: cNavy(context), fontSize: 14),
            decoration: InputDecoration(
              hintText:  'e.g. Excellent work! Keep it up.',
              hintStyle: TextStyle(color: cMuted(context), fontSize: 13),
              filled:    true,
              fillColor: cBg(context),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: cBorder(context))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: cBorder(context))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: kTeal, width: 2)),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(_error!, style: const TextStyle(color: kError, fontSize: 13)),
          ],
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kNavy,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              onPressed: _saving ? null : _save,
              child: _saving
                  ? const SizedBox(
                      width: 20, height: 20,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2.5))
                  : const Text('Submit Result',
                      style: TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }
}