// lib/screens/shared_widgets.dart
// Shared form-helper widgets used by homework_tab.dart and tests_tab.dart.
import 'dart:io';
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../backend_image.dart';

class FormLabel extends StatelessWidget {
  final String text;
  const FormLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Text(text,
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   13,
                fontWeight: FontWeight.w700)),
      );
}

class LabeledTextField extends StatelessWidget {
  final TextEditingController ctrl;
  final String                hint;
  final int                   maxLines;
  const LabeledTextField(
      {super.key, required this.ctrl, required this.hint, this.maxLines = 1});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(12),
          border:       Border.all(color: cBorder(context)),
        ),
        child: TextField(
          controller: ctrl,
          maxLines:   maxLines,
          style: TextStyle(color: cNavy(context), fontSize: 14),
          decoration: InputDecoration(
            hintText:       hint,
            hintStyle:      TextStyle(color: cMuted(context), fontSize: 14),
            border:         InputBorder.none,
            contentPadding: const EdgeInsets.all(13),
          ),
        ),
      );
}

class ErrorBox extends StatelessWidget {
  final String msg;
  const ErrorBox(this.msg, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color:        kError.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(10),
          border:       Border.all(color: kError.withValues(alpha: 0.3)),
        ),
        child: Text(msg, style: const TextStyle(color: kError, fontSize: 13)),
      );
}

class ImageGrid extends StatelessWidget {
  final List<String>      existingUrls;
  final List<File>        newFiles;
  final VoidCallback      onAdd;
  final ValueChanged<int> onRemoveExisting;
  final ValueChanged<int> onRemoveNew;

  const ImageGrid({
    super.key,
    required this.existingUrls,
    required this.newFiles,
    required this.onAdd,
    required this.onRemoveExisting,
    required this.onRemoveNew,
  });

  @override
  Widget build(BuildContext context) {
    final total = existingUrls.length + newFiles.length;
    return Wrap(
      spacing: 8, runSpacing: 8,
      children: [
        ...List.generate(existingUrls.length, (i) => _Thumb(
              child:    BackendImage(existingUrls[i], fit: BoxFit.cover),
              onRemove: () => onRemoveExisting(i),
            )),
        ...List.generate(newFiles.length, (i) => _Thumb(
              child:    Image.file(newFiles[i], fit: BoxFit.cover),
              onRemove: () => onRemoveNew(i),
            )),
        if (total < 20)
          GestureDetector(
            onTap: onAdd,
            child: Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(12),
                border:       Border.all(color: cBorder(context)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_photo_alternate_outlined,
                      color: cMuted(context), size: 24),
                  const SizedBox(height: 4),
                  Text('Add',
                      style: TextStyle(color: cMuted(context), fontSize: 11)),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _Thumb extends StatelessWidget {
  final Widget       child;
  final VoidCallback onRemove;
  const _Thumb({required this.child, required this.onRemove});

  @override
  Widget build(BuildContext context) => Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(width: 80, height: 80, child: child),
          ),
          Positioned(
            top: 2, right: 2,
            child: GestureDetector(
              onTap: onRemove,
              child: Container(
                width: 22, height: 22,
                decoration: BoxDecoration(
                  color:        kError,
                  borderRadius: BorderRadius.circular(11),
                ),
                child: const Icon(Icons.close_rounded,
                    color: Colors.white, size: 14),
              ),
            ),
          ),
        ],
      );
}