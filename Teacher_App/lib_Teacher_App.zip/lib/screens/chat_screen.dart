// lib/screens/chat_screen.dart
// Generic real-time chat screen used by teacher→parent and teacher→student.
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';

class ChatScreen extends StatefulWidget {
  final String                          title;
  final String                          subtitle;
  final String                          myId;
  final String                          myName;
  final String                          myType; // 'teacher'
  final Stream<List<ChatMessage>>       messagesStream;
  final Future<void> Function(ChatMessage) onSend;

  const ChatScreen({
    super.key,
    required this.title,
    required this.subtitle,
    required this.myId,
    required this.myName,
    required this.myType,
    required this.messagesStream,
    required this.onSend,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _msgCtrl = TextEditingController();
  final _scroll  = ScrollController();
  bool  _sending = false;

  @override
  void dispose() {
    _msgCtrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    _msgCtrl.clear();

    final msg = ChatMessage(
      id:         const Uuid().v4(),
      senderId:   widget.myId,
      senderType: widget.myType,
      senderName: widget.myName,
      text:       text,
      timestamp:  DateTime.now(),
    );

    try {
      await widget.onSend(msg);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(
            _scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve:    Curves.easeOut,
          );
        }
      });
    } catch (_) {}
    if (mounted) setState(() => _sending = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.title,
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   16,
                    fontWeight: FontWeight.w800)),
            if (widget.subtitle.isNotEmpty)
              Text(widget.subtitle,
                  style: TextStyle(
                      color: cMuted(context), fontSize: 11)),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<ChatMessage>>(
              stream: widget.messagesStream,
              builder: (ctx, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return Center(
                      child: CircularProgressIndicator(
                          color: isDark(context)
                              ? kDarkTeal
                              : kTeal,
                          strokeWidth: 2));
                }
                final msgs = snap.data ?? [];
                if (msgs.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.chat_bubble_outline_rounded,
                            color: cBorder(context), size: 48),
                        const SizedBox(height: 12),
                        Text('No messages yet.',
                            style: TextStyle(
                                color:      cNavy(context),
                                fontSize:   15,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('Start the conversation below.',
                            style: TextStyle(
                                color:    cMuted(context),
                                fontSize: 13)),
                      ],
                    ),
                  );
                }
                return ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) => _Bubble(
                    msg:  msgs[i],
                    isMe: msgs[i].senderId == widget.myId,
                  ),
                );
              },
            ),
          ),
          _buildInput(),
        ],
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      padding: EdgeInsets.fromLTRB(
          16, 10, 16,
          MediaQuery.of(context).viewInsets.bottom + 16),
      decoration: BoxDecoration(
        color:  cCard(context),
        border: Border(top: BorderSide(color: cBorder(context))),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller:  _msgCtrl,
              maxLines:    4,
              minLines:    1,
              style:       TextStyle(color: cNavy(context), fontSize: 14),
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                hintText:  'Type a message…',
                hintStyle: TextStyle(
                    color: cMuted(context), fontSize: 14),
                filled:         true,
                fillColor:      cBg(context),
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide:  BorderSide.none),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _sending ? null : _send,
            child: Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color:        kNavy,
                borderRadius: BorderRadius.circular(12),
              ),
              child: _sending
                  ? const Center(
                      child: SizedBox(
                          width: 18, height: 18,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2)))
                  : const Icon(Icons.send_rounded,
                      color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Bubble ────────────────────────────────────────────────────
class _Bubble extends StatelessWidget {
  final ChatMessage msg;
  final bool        isMe;
  const _Bubble({required this.msg, required this.isMe});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.72),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(
            horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: isMe ? kNavy : cCard(context),
          borderRadius: BorderRadius.only(
            topLeft:     const Radius.circular(16),
            topRight:    const Radius.circular(16),
            bottomLeft:  Radius.circular(isMe ? 16 : 4),
            bottomRight: Radius.circular(isMe ? 4 : 16),
          ),
          boxShadow: [
            BoxShadow(
                color:      kNavy.withValues(alpha: 0.06),
                blurRadius: 6,
                offset:     const Offset(0, 2)),
          ],
        ),
        child: Column(
          crossAxisAlignment:
              isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isMe)
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(msg.senderName,
                    style: const TextStyle(
                        color:      kTeal,
                        fontSize:   10,
                        fontWeight: FontWeight.w700)),
              ),
            Text(msg.text,
                style: TextStyle(
                    color:    isMe ? Colors.white : cNavy(context),
                    fontSize: 14,
                    height:   1.4)),
            const SizedBox(height: 3),
            Text(
              '${msg.timestamp.hour.toString().padLeft(2, '0')}:'
              '${msg.timestamp.minute.toString().padLeft(2, '0')}',
              style: TextStyle(
                  color:    isMe
                      ? Colors.white.withValues(alpha: 0.55)
                      : cMuted(context),
                  fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}
