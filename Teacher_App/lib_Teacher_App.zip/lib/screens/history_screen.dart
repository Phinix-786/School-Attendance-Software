// lib/screens/history_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';

class HistoryScreen extends StatefulWidget {
  final String schoolId;
  final Teacher teacher;

  const HistoryScreen(
      {super.key, required this.schoolId, required this.teacher});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<AttendanceSession> _sessions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final sessions = await TeacherFirebaseService.getRecentSessions(
        widget.schoolId, widget.teacher.id);
    setState(() {
      _sessions = sessions;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        foregroundColor: Colors.white,
        title: const Text('Attendance History'),
        // ← subtitle param doesn't exist; use bottom instead
        bottom: const PreferredSize(
          preferredSize: Size.fromHeight(20),
          child: Padding(
            padding: EdgeInsets.only(left: 16, bottom: 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Last 7 days',
                style: TextStyle(fontSize: 12, color: Color(0xFF64748B)),
              ),
            ),
          ),
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF38BDF8)))
          : _sessions.isEmpty
              ? const Center(
                  child: Text('No history found.',
                      style: TextStyle(color: Color(0xFF64748B))))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _sessions.length,
                    itemBuilder: (_, i) => _sessionCard(_sessions[i]),
                  ),
                ),
    );
  }

  Widget _sessionCard(AttendanceSession session) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: ExpansionTile(
        iconColor: const Color(0xFF38BDF8),
        collapsedIconColor: const Color(0xFF64748B),
        title: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    DateFormat('EEEE, dd MMM yyyy').format(session.date),
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14),
                  ),
                  Text(
                    'Class ID: ...${session.classId.substring(session.classId.length > 8 ? session.classId.length - 8 : 0)}',
                    style: const TextStyle(
                        color: Color(0xFF64748B), fontSize: 11),
                  ),
                ],
              ),
            ),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                // ← withOpacity → withValues
                color: session.messagesSent
                    ? const Color(0xFF22C55E).withValues(alpha: 0.15)
                    : const Color(0xFF38BDF8).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                session.messagesSent ? 'Msgs Sent' : 'Submitted',
                style: TextStyle(
                    color: session.messagesSent
                        ? const Color(0xFF22C55E)
                        : const Color(0xFF38BDF8),
                    fontSize: 10,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        children: [
          FutureBuilder<List<AttendanceRecord>>(
            future: TeacherFirebaseService.getSessionRecords(
                widget.schoolId, session.id),
            builder: (context, snap) {
              if (!snap.hasData) {
                return const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(
                      child: CircularProgressIndicator(
                          color: Color(0xFF38BDF8), strokeWidth: 2)),
                );
              }

              final records = snap.data!;
              final absent = records
                  .where((r) => r.status == AttendanceStatus.absent)
                  .length;
              final late = records
                  .where((r) => r.status == AttendanceStatus.late)
                  .length;
              final present = records
                  .where((r) => r.status == AttendanceStatus.present)
                  .length;

              return Column(
                children: [
                  Container(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 12),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F172A),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisAlignment:
                          MainAxisAlignment.spaceAround,
                      children: [
                        _mini('Present', present,
                            const Color(0xFF22C55E)),
                        _mini('Absent', absent,
                            const Color(0xFFEF4444)),
                        _mini('Late', late, const Color(0xFFF59E0B)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  ...records.map((r) => _recordRow(r, session)),
                  const SizedBox(height: 8),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _recordRow(AttendanceRecord record, AttendanceSession session) {
    Color color;
    switch (record.status) {
      case AttendanceStatus.present:
        color = const Color(0xFF22C55E);
        break;
      case AttendanceStatus.absent:
        color = const Color(0xFFEF4444);
        break;
      case AttendanceStatus.late:
        color = const Color(0xFFF59E0B);
        break;
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(
        children: [
          Container(
              width: 8,
              height: 8,
              decoration:
                  BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(record.studentId,
                style: const TextStyle(
                    color: Color(0xFF94A3B8), fontSize: 12)),
          ),
          if (!session.messagesSent)
            PopupMenuButton<AttendanceStatus>(
              color: const Color(0xFF1E293B),
              icon: Text(record.status.name.toUpperCase(),
                  style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.bold)),
              onSelected: (newStatus) async {
                record.status = newStatus;
                await TeacherFirebaseService.updateRecord(
                    widget.schoolId, session.id, record);
                setState(() {});
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('Record updated!'),
                          backgroundColor: Color(0xFF22C55E),
                          duration: Duration(seconds: 1)));
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(
                    value: AttendanceStatus.present,
                    child: Text('Mark Present',
                        style:
                            TextStyle(color: Color(0xFF22C55E)))),
                const PopupMenuItem(
                    value: AttendanceStatus.absent,
                    child: Text('Mark Absent',
                        style:
                            TextStyle(color: Color(0xFFEF4444)))),
                const PopupMenuItem(
                    value: AttendanceStatus.late,
                    child: Text('Mark Late',
                        style:
                            TextStyle(color: Color(0xFFF59E0B)))),
              ],
            )
          else
            Text(record.status.name.toUpperCase(),
                style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _mini(String label, int value, Color color) {
    return Column(
      children: [
        Text('$value',
            style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 16)),
        Text(label,
            style: const TextStyle(
                color: Color(0xFF64748B), fontSize: 10)),
      ],
    );
  }
}