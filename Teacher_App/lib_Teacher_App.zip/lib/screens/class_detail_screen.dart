// lib/screens/class_detail_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'homework_tab.dart';
import 'tests_tab.dart';
import 'attendance_screen.dart';
import 'cross_chat_requests_screen.dart';
import 'teacher_inbox_screen.dart';

class ClassDetailScreen extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;

  const ClassDetailScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
  });

  @override
  State<ClassDetailScreen> createState() => _ClassDetailScreenState();
}

class _ClassDetailScreenState extends State<ClassDetailScreen> {
  int _tab = 0; // 0=Homework 1=Tests 2=Attendance(CT only)

  bool get _isCT => widget.teacher.isClassTeacherOf(widget.cls.id);

  // Tab list built depending on role
  // 0=Homework  1=Tests  2=Inbox
  // CT-only: 3=Attendance  4=Requests
  List<_TabDef> get _tabs => [
        const _TabDef('📚', 'Homework'),
        const _TabDef('📝', 'Tests'),
        const _TabDef('✉️', 'Inbox'),
        if (_isCT) const _TabDef('✅', 'Attend.'),
        if (_isCT) const _TabDef('💬', 'Requests'),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 8),
            _buildTabBar(),
            const SizedBox(height: 4),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────
  Widget _buildHeader() {
    final isCT    = _isCT;
    final subject = widget.teacher.subjectFor(widget.cls.id);
    final color   = isCT
        ? (isDark(context) ? kDarkTeal : kTeal)
        : kPink;

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back_ios_new_rounded,
                color: cNavy(context), size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.cls.name,
                  style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Row(
                  children: [
                    if (subject.isNotEmpty) ...[
                      Text(subject,
                          style: TextStyle(
                              color: cMuted(context), fontSize: 12)),
                      const SizedBox(width: 8),
                    ],
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color:        color.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                        border:       Border.all(
                            color: color.withValues(alpha: 0.35)),
                      ),
                      child: Text(
                        isCT ? '★ Class Teacher' : 'Subject Teacher',
                        style: TextStyle(
                          color:      color,
                          fontSize:   10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Tab bar ───────────────────────────────────────────────
  Widget _buildTabBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color:      kNavy.withValues(alpha: 0.06),
              blurRadius: 12,
              offset:     const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: List.generate(_tabs.length, (i) {
            final t      = _tabs[i];
            final active = _tab == i;
            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _tab = i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  decoration: BoxDecoration(
                    color: active ? kNavy : Colors.transparent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(t.emoji,
                          style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 5),
                      Text(
                        t.label,
                        style: TextStyle(
                          color: active ? Colors.white : cMuted(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  // ── Body ──────────────────────────────────────────────────
  Widget _buildBody() {
    switch (_tab) {
      case 0:
        return HomeworkTab(
          schoolId: widget.schoolId,
          teacher:  widget.teacher,
          cls:      widget.cls,
        );
      case 1:
        return TestsTab(
          schoolId: widget.schoolId,
          teacher:  widget.teacher,
          cls:      widget.cls,
        );
      case 2:
        return TeacherInboxScreen(
          schoolId: widget.schoolId,
          teacher:  widget.teacher,
          cls:      widget.cls,
        );
      case 3:
        if (!_isCT) return const SizedBox.shrink();
        return AttendanceScreen(
          schoolId:    widget.schoolId,
          teacher:     widget.teacher,
          schoolClass: widget.cls,
          embedded:    true,
        );
      default:
        return CrossChatRequestsScreen(
          schoolId: widget.schoolId,
          cls:      widget.cls,
        );
    }
  }
}

class _TabDef {
  final String emoji;
  final String label;
  const _TabDef(this.emoji, this.label);
}
