// lib/screens/attendance_screen.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uuid/uuid.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import '../services/sms_request_service.dart';

class AttendanceScreen extends StatefulWidget {
  final String schoolId;
  final Teacher teacher;
  final SchoolClass schoolClass;
  /// When true the screen is embedded inside ClassDetailScreen's tab body,
  /// so the AppBar back arrow is suppressed (the tab bar acts as navigation).
  final bool embedded;

  const AttendanceScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.schoolClass,
    this.embedded = false,
  });

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

// ── Local persistence data holder ─────────────────────────────────────────────
class _LocalData {
  final Map<String, AttendanceStatus> statuses;
  final Map<String, int> lateMinutes;
  _LocalData({required this.statuses, required this.lateMinutes});
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  List<Student> _students = [];

  /// Attendance status per studentId.
  Map<String, AttendanceStatus> _statuses = {};

  /// How many minutes late per studentId — only populated for late students.
  Map<String, int> _lateMinutes = {};

  bool _loading    = true;
  bool _submitting = false;

  // Status colours (semantic — same in light & dark)
  static const _green = Color(0xFF22C55E);
  static const _red   = Color(0xFFEF4444);
  static const _amber = Color(0xFFF59E0B);

  // ── Prefs key helpers ──────────────────────────────────────────────────────
  // Key format:  attendance_v2_<classId>_<YYYY-MM-DD>
  // (v2 distinguishes from the old single-map format)
  String get _todayDateStr {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-'
        '${now.day.toString().padLeft(2, '0')}';
  }

  String get _prefsKey =>
      'attendance_v2_${widget.schoolClass.id}_$_todayDateStr';

  // ── Persist ────────────────────────────────────────────────────────────────

  Future<void> _saveLocally() async {
    final prefs = await SharedPreferences.getInstance();
    final data = {
      'statuses': _statuses.map((k, v) => MapEntry(k, _statusToString(v))),
      // Only store entries that have a non-null minute value.
      'lateMinutes': Map.fromEntries(
        _lateMinutes.entries.map((e) => MapEntry(e.key, e.value)),
      ),
    };
    await prefs.setString(_prefsKey, jsonEncode(data));
  }

  Future<_LocalData?> _loadLocally() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getString(_prefsKey);
    if (raw == null) return null;

    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;

      final statuses = (decoded['statuses'] as Map<String, dynamic>)
          .map((k, v) => MapEntry(k, _statusFromString(v as String)));

      final lateMinutes = <String, int>{};
      final rawLate = decoded['lateMinutes'] as Map<String, dynamic>?;
      if (rawLate != null) {
        rawLate.forEach((k, v) {
          if (v != null) lateMinutes[k] = (v as num).toInt();
        });
      }

      return _LocalData(statuses: statuses, lateMinutes: lateMinutes);
    } catch (_) {
      // Corrupted or old-format data — start fresh.
      return null;
    }
  }

  // ── Status ↔ String ────────────────────────────────────────────────────────
  static String _statusToString(AttendanceStatus s) {
    switch (s) {
      case AttendanceStatus.present: return 'present';
      case AttendanceStatus.absent:  return 'absent';
      case AttendanceStatus.late:    return 'late';
    }
  }

  static AttendanceStatus _statusFromString(String s) {
    switch (s) {
      case 'absent': return AttendanceStatus.absent;
      case 'late':   return AttendanceStatus.late;
      default:       return AttendanceStatus.present;
    }
  }

  // ── Init ───────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _loadStudents();
  }

  Future<void> _loadStudents() async {
    final students = await TeacherFirebaseService.getStudentsByClass(
        widget.schoolId, widget.schoolClass.id);
    students.sort((a, b) => a.rollNo.compareTo(b.rollNo));

    final defaultStatuses = {
      for (final s in students) s.id: AttendanceStatus.present,
    };

    final saved = await _loadLocally();

    setState(() {
      _students   = students;
      _statuses   = {...defaultStatuses, if (saved != null) ...saved.statuses};
      _lateMinutes = saved?.lateMinutes ?? {};
      _loading    = false;
    });
  }

  // ── Counters ───────────────────────────────────────────────────────────────
  int get _presentCount =>
      _statuses.values.where((s) => s == AttendanceStatus.present).length;
  int get _absentCount =>
      _statuses.values.where((s) => s == AttendanceStatus.absent).length;
  int get _lateCount =>
      _statuses.values.where((s) => s == AttendanceStatus.late).length;

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        automaticallyImplyLeading: !widget.embedded,
        title: Text(
          widget.schoolClass.name,
          style: TextStyle(
            color: cNavy(context),
            fontWeight: FontWeight.w800,
            fontSize: 17,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(28),
          child: Padding(
            padding: const EdgeInsets.only(left: 16, bottom: 10),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: kTeal.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kTeal.withValues(alpha: 0.3)),
                ),
                child: Text(
                  'Tap = Absent  •  Double tap = Late',
                  style: TextStyle(
                    fontSize: 11,
                    color: isDark(context) ? kDarkTeal : kTeal,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton(
              onPressed: _markAllPresent,
              child: Text(
                'All Present',
                style: TextStyle(
                  color: _green,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ),
      body: _loading
          ? Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal,
                  strokeWidth: 2.5))
          : Column(
              children: [
                // ── Stats bar ────────────────────────────────────────────────
                Container(
                  color: cCard(context),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _counter('Present', _presentCount, _green),
                      _divider(context),
                      _counter('Absent',  _absentCount,  _red),
                      _divider(context),
                      _counter('Late',    _lateCount,    _amber),
                      _divider(context),
                      _counter('Total',   _students.length, cNavy(context)),
                    ],
                  ),
                ),

                // ── Legend chips ─────────────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                  child: Row(
                    children: [
                      _legendChip('✓ Present', _green),
                      const SizedBox(width: 8),
                      _legendChip('✗ Absent',  _red),
                      const SizedBox(width: 8),
                      _legendChip('⏰ Late',    _amber),
                    ],
                  ),
                ),

                // ── Student list ─────────────────────────────────────────────
                Expanded(
                  child: _students.isEmpty
                      ? Center(
                          child: Text(
                            'No students in this class.',
                            style: TextStyle(color: cMuted(context)),
                          ),
                        )
                      : ListView.builder(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 12),
                          itemCount: _students.length,
                          itemBuilder: (_, i) =>
                              _studentTile(_students[i]),
                        ),
                ),

                // ── Submit button ────────────────────────────────────────────
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cCard(context),
                    border:
                        Border(top: BorderSide(color: cBorder(context))),
                  ),
                  child: SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kNavy,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: _submitting ? null : _submit,
                      child: _submitting
                          ? const SizedBox(
                              width: 22,
                              height: 22,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2.5))
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.send_rounded, size: 18),
                                const SizedBox(width: 8),
                                Text(
                                  'Submit Attendance'
                                  ' (${_students.length} students)',
                                  style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w800),
                                ),
                              ],
                            ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  // ── Student tile ───────────────────────────────────────────────────────────
  Widget _studentTile(Student student) {
    final status     = _statuses[student.id] ?? AttendanceStatus.present;
    final lateMin    = _lateMinutes[student.id];

    Color bgColor, borderColor, textColor;
    IconData icon;
    String statusLabel;

    switch (status) {
      case AttendanceStatus.present:
        bgColor     = _green.withValues(alpha: 0.08);
        borderColor = _green.withValues(alpha: 0.3);
        textColor   = cNavy(context);
        icon        = Icons.check_circle_outline_rounded;
        statusLabel = 'Present';
        break;
      case AttendanceStatus.absent:
        bgColor     = _red.withValues(alpha: 0.10);
        borderColor = _red.withValues(alpha: 0.45);
        textColor   = _red;
        icon        = Icons.cancel_outlined;
        statusLabel = 'Absent';
        break;
      case AttendanceStatus.late:
        bgColor     = _amber.withValues(alpha: 0.08);
        borderColor = _amber.withValues(alpha: 0.45);
        textColor   = _amber;
        icon        = Icons.access_time_rounded;
        // Show minutes on the badge if captured.
        statusLabel = lateMin != null ? 'Late · ${lateMin}m' : 'Late';
        break;
    }

    final iconColor = status == AttendanceStatus.present
        ? _green
        : status == AttendanceStatus.absent
            ? _red
            : _amber;

    return GestureDetector(
      onTap:       () => _cycle(student.id),
      onDoubleTap: () => _openLatePicker(student),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin:  const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color:        bgColor,
          borderRadius: BorderRadius.circular(12),
          border:       Border.all(color: borderColor, width: 1.5),
        ),
        child: Row(
          children: [
            // Roll number badge
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color:        cBg(context),
                borderRadius: BorderRadius.circular(8),
                border:       Border.all(color: cBorder(context)),
              ),
              child: Center(
                child: Text(
                  student.rollNo.isNotEmpty
                      ? student.rollNo
                      : '${_students.indexOf(student) + 1}',
                  style: TextStyle(
                    color:      cMuted(context),
                    fontSize:   11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),

            // Name
            Expanded(
              child: Text(
                student.name,
                style: TextStyle(
                  color:      textColor,
                  fontSize:   15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),

            // Status badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color:        borderColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, color: iconColor, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    statusLabel,
                    style: TextStyle(
                      color:      textColor,
                      fontSize:   12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Interaction handlers ───────────────────────────────────────────────────

  /// Single tap — cycles Present ↔ Absent (clears late state if leaving late).
  void _cycle(String studentId) {
    setState(() {
      final current = _statuses[studentId] ?? AttendanceStatus.present;
      _statuses[studentId] = current == AttendanceStatus.present
          ? AttendanceStatus.absent
          : AttendanceStatus.present;
      // If we're moving away from late, wipe the stored minutes.
      _lateMinutes.remove(studentId);
    });
    _saveLocally();
  }

  /// Double tap — opens the late-minutes picker bottom sheet.
  Future<void> _openLatePicker(Student student) async {
    final existing = _lateMinutes[student.id];

    final minutes = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _LatePickerSheet(
        studentName:    student.name,
        initialMinutes: existing,
      ),
    );

    if (minutes != null) {
      setState(() {
        _statuses[student.id]    = AttendanceStatus.late;
        _lateMinutes[student.id] = minutes;
      });
      _saveLocally();
    }
  }

  void _markAllPresent() {
    setState(() {
      for (final key in _statuses.keys) {
        _statuses[key] = AttendanceStatus.present;
      }
      _lateMinutes.clear();
    });
    _saveLocally();
  }

  // ── Submit ─────────────────────────────────────────────────────────────────
  Future<void> _submit() async {
    setState(() => _submitting = true);

    final sessionId = const Uuid().v4();
    final now       = DateTime.now();
    final session   = AttendanceSession(
      id:          sessionId,
      schoolId:    widget.schoolId,
      classId:     widget.schoolClass.id,
      teacherId:   widget.teacher.id,
      date:        now,
      isSubmitted: true,
    );

    final records = _students.map((s) {
      final status = _statuses[s.id] ?? AttendanceStatus.present;
      return AttendanceRecord(
        id:          const Uuid().v4(),
        schoolId:    widget.schoolId,
        classId:     widget.schoolClass.id,
        studentId:   s.id,
        teacherId:   widget.teacher.id,
        status:      status,
        date:        now,
        // Only include lateMinutes for late students.
        lateMinutes: status == AttendanceStatus.late
            ? _lateMinutes[s.id]
            : null,
      );
    }).toList();

    try {
      final connectivity = await Connectivity().checkConnectivity();
      final isOnline     = connectivity != ConnectivityResult.none;

      if (isOnline) {
        await TeacherFirebaseService.submitAttendance(
            session: session, records: records);

        // Queue SMS alerts for absent/late students immediately
        final absentLate = records
            .where((r) =>
                r.status == AttendanceStatus.absent ||
                r.status == AttendanceStatus.late)
            .toList();

        if (absentLate.isNotEmpty) {
          final schoolName = await TeacherFirebaseService
              .getSchoolName(widget.schoolId);
          await SmsRequestService.queueSmsRequests(
            schoolId:      widget.schoolId,
            schoolName:    schoolName,
            absentRecords: absentLate,
            students:      _students,
            classes:       [widget.schoolClass],
          );
        }

        if (mounted) {
          final smsNote = absentLate.isNotEmpty
              ? ' SMS alerts queued for ${absentLate.length} student(s).'
              : '';
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Attendance submitted!$smsNote'),
              backgroundColor: const Color(0xFF22C55E)));
          Navigator.pop(context);
        }
      } else {
        final recordMaps = records.map((r) {
          final m = r.toMap();
          m['dateStr'] = now.toIso8601String();
          return m.map((k, v) => MapEntry(k, v.toString()));
        }).toList();

        await TeacherFirebaseService.saveToOfflineQueue(OfflineQueueItem(
            sessionId: sessionId,
            classId:   widget.schoolClass.id,
            records:   recordMaps,
            timestamp: now));

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text(
                  '📴 No internet. Saved offline — will sync automatically.'),
              backgroundColor: Color(0xFFF59E0B),
              duration: Duration(seconds: 4)));
          Navigator.pop(context);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Error: $e'), backgroundColor: kError));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  Widget _counter(String label, int value, Color color) {
    return Column(
      children: [
        Text('$value',
            style: TextStyle(
                color: color, fontSize: 20, fontWeight: FontWeight.w800)),
        Text(label,
            style: TextStyle(color: cMuted(context), fontSize: 11)),
      ],
    );
  }

  Widget _divider(BuildContext context) =>
      Container(width: 1, height: 28, color: cBorder(context));

  Widget _legendChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color:        color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border:       Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Text(label,
          style: TextStyle(
              color: color, fontSize: 11, fontWeight: FontWeight.w600)),
    );
  }
}

// ── Late-minutes picker bottom sheet ──────────────────────────────────────────
//
// Returns an int (minutes) when the teacher confirms, or null if dismissed.
// ─────────────────────────────────────────────────────────────────────────────

class _LatePickerSheet extends StatefulWidget {
  final String studentName;
  final int?   initialMinutes;

  const _LatePickerSheet({
    required this.studentName,
    this.initialMinutes,
  });

  @override
  State<_LatePickerSheet> createState() => _LatePickerSheetState();
}

class _LatePickerSheetState extends State<_LatePickerSheet> {
  static const _presets = [5, 10, 15, 20, 30];

  static const _amber = Color(0xFFF59E0B);
  static const _navy  = Color(0xFF001858);
  static const _muted = Color(0xFF8896AA);

  int?   _selected;
  bool   _customMode = false;
  final  _customCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final init = widget.initialMinutes;
    if (init != null) {
      if (_presets.contains(init)) {
        _selected = init;
      } else {
        _customMode = true;
        _customCtrl.text = init.toString();
        _selected = init;
      }
    }
  }

  @override
  void dispose() {
    _customCtrl.dispose();
    super.dispose();
  }

  int? get _effectiveMinutes {
    if (_customMode) {
      return int.tryParse(_customCtrl.text.trim());
    }
    return _selected;
  }

  void _confirm() {
    final result = _effectiveMinutes;
    if (result == null || result <= 0) return;
    Navigator.pop(context, result);
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      padding: EdgeInsets.fromLTRB(20, 24, 20, 20 + bottomInset),
      decoration: BoxDecoration(
        color:        Theme.of(context).brightness == Brightness.dark
            ? const Color(0xFF1E293B)
            : Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
              color:      Colors.black.withValues(alpha: 0.14),
              blurRadius: 24,
              offset:     const Offset(0, -4)),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // ── Header ─────────────────────────────────────────────────────────
          Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color:        _amber.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.access_time_rounded,
                    color: _amber, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'How late?',
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          color: _navy),
                    ),
                    Text(
                      widget.studentName,
                      style: const TextStyle(
                          color: _muted, fontSize: 13),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              // Close handle
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: Colors.grey.withValues(alpha: 0.10),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close_rounded,
                      size: 16, color: _muted),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // ── Preset chips ────────────────────────────────────────────────────
          const Text(
            'SELECT DURATION',
            style: TextStyle(
                color:       _muted,
                fontSize:    10.5,
                fontWeight:  FontWeight.w700,
                letterSpacing: 0.8),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              ..._presets.map((min) => _PresetChip(
                    label:    '$min min',
                    selected: !_customMode && _selected == min,
                    onTap: () => setState(() {
                      _selected   = min;
                      _customMode = false;
                    }),
                  )),
              // Custom chip
              _PresetChip(
                label:    'Custom',
                selected: _customMode,
                icon:     Icons.edit_outlined,
                onTap: () => setState(() {
                  _customMode = true;
                  _selected   = null;
                }),
              ),
            ],
          ),

          // ── Custom input ────────────────────────────────────────────────────
          AnimatedSize(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            child: _customMode
                ? Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Row(
                      children: [
                        // Decrement
                        _StepButton(
                          icon: Icons.remove_rounded,
                          onTap: () {
                            final v = int.tryParse(_customCtrl.text) ?? 0;
                            if (v > 1) _customCtrl.text = '${v - 1}';
                          },
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextField(
                            controller:  _customCtrl,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize:   16,
                                color:      _navy),
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.symmetric(
                                  vertical: 12),
                              suffixText: 'min',
                              suffixStyle: const TextStyle(
                                  color: _muted, fontSize: 13),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                    color: Color(0xFFE8EEF4)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                    color: Color(0xFFE8EEF4)),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                    color: _amber, width: 1.8),
                              ),
                            ),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        const SizedBox(width: 10),
                        // Increment
                        _StepButton(
                          icon: Icons.add_rounded,
                          onTap: () {
                            final v = int.tryParse(_customCtrl.text) ?? 0;
                            _customCtrl.text = '${v + 1}';
                          },
                        ),
                      ],
                    ),
                  )
                : const SizedBox.shrink(),
          ),

          const SizedBox(height: 24),

          // ── Confirm button ──────────────────────────────────────────────────
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _effectiveMinutes != null &&
                        _effectiveMinutes! > 0
                    ? _amber
                    : _muted,
                foregroundColor: Colors.white,
                elevation:   0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: (_effectiveMinutes != null && _effectiveMinutes! > 0)
                  ? _confirm
                  : null,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.access_time_rounded, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    _effectiveMinutes != null && _effectiveMinutes! > 0
                        ? 'Mark Late · $_effectiveMinutes min'
                        : 'Select a duration',
                    style: const TextStyle(
                        fontSize:   15,
                        fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Preset chip ───────────────────────────────────────────────────────────────

class _PresetChip extends StatelessWidget {
  final String    label;
  final bool      selected;
  final IconData? icon;
  final VoidCallback onTap;

  const _PresetChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
  });

  static const _amber = Color(0xFFF59E0B);
  static const _navy  = Color(0xFF001858);
  static const _muted = Color(0xFF8896AA);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected
              ? _amber.withValues(alpha: 0.14)
              : Colors.grey.withValues(alpha: 0.07),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected
                ? _amber.withValues(alpha: 0.60)
                : Colors.grey.withValues(alpha: 0.20),
            width: selected ? 1.8 : 1.2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 14,
                  color: selected ? _amber : _muted),
              const SizedBox(width: 5),
            ],
            Text(
              label,
              style: TextStyle(
                color:      selected ? _amber : _navy,
                fontWeight: FontWeight.w700,
                fontSize:   13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Step button (+/-) ─────────────────────────────────────────────────────────

class _StepButton extends StatelessWidget {
  final IconData     icon;
  final VoidCallback onTap;
  const _StepButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          color:        Colors.grey.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(10),
          border:       Border.all(color: Colors.grey.withValues(alpha: 0.18)),
        ),
        child: Icon(icon, size: 20, color: const Color(0xFF001858)),
      ),
    );
  }
}