// lib/screens/homework_tab.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'shared_widgets.dart';

// ── Homework tab (list + FAB) ─────────────────────────────────
class HomeworkTab extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;

  const HomeworkTab({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
  });

  @override
  State<HomeworkTab> createState() => _HomeworkTabState();
}

class _HomeworkTabState extends State<HomeworkTab> {
  List<Homework> _items   = [];
  bool           _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final hw = await TeacherFirebaseService.getHomeworks(
        widget.schoolId, widget.cls.id);
    if (mounted) setState(() { _items = hw; _loading = false; });
  }

  Future<void> _openAdd({Homework? existing}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AddHomeworkScreen(
          schoolId:  widget.schoolId,
          teacher:   widget.teacher,
          cls:       widget.cls,
          existing:  existing,
        ),
      ),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        _loading
            ? Center(
                child: CircularProgressIndicator(
                  color:       isDark(context) ? kDarkTeal : kTeal,
                  strokeWidth: 2.5,
                ))
            : _items.isEmpty
                ? _emptyState()
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                      itemCount: _items.length,
                      itemBuilder: (_, i) => _HwCard(
                        hw:      _items[i],
                        onEdit:  () => _openAdd(existing: _items[i]),
                      ),
                    ),
                  ),
        // FAB
        Positioned(
          bottom: 16, right: 16,
          child: FloatingActionButton.extended(
            heroTag: 'hw_fab',
            backgroundColor: kNavy,
            foregroundColor: Colors.white,
            icon:  const Icon(Icons.add_rounded),
            label: const Text('Add Homework',
                style: TextStyle(fontWeight: FontWeight.w700)),
            onPressed: () => _openAdd(),
          ),
        ),
      ],
    );
  }

  Widget _emptyState() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('📚', style: TextStyle(fontSize: 52)),
            const SizedBox(height: 12),
            Text('No homework yet.',
                style: TextStyle(color: cMuted(context), fontSize: 15)),
            const SizedBox(height: 4),
            Text('Tap + Add Homework to create one.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );
}

// ── Homework list card ────────────────────────────────────────
class _HwCard extends StatelessWidget {
  final Homework     hw;
  final VoidCallback onEdit;
  const _HwCard({required this.hw, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    final date =
        '${hw.createdAt.day}/${hw.createdAt.month}/${hw.createdAt.year}';
    return GestureDetector(
      onTap: hw.isEditable ? onEdit : null,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 12,
              offset:     const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(hw.topic,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   15,
                          fontWeight: FontWeight.w700)),
                ),
                if (hw.isEditable)
                  _SmallBadge(label: 'Editable', color: kPink),
              ],
            ),
            if (hw.pageNumbers.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('Pages: ${hw.pageNumbers}',
                  style: TextStyle(color: cMuted(context), fontSize: 12)),
            ],
            if (hw.instructions.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(hw.instructions,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: cBlue(context), fontSize: 13)),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.image_outlined,
                    size: 13, color: cMuted(context)),
                const SizedBox(width: 4),
                Text('${hw.imageUrls.length} image(s)',
                    style: TextStyle(color: cMuted(context), fontSize: 12)),
                const Spacer(),
                Text(date,
                    style: TextStyle(color: cMuted(context), fontSize: 12)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Add / Edit Homework screen ────────────────────────────────
class AddHomeworkScreen extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;
  final Homework?   existing;

  const AddHomeworkScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
    this.existing,
  });

  @override
  State<AddHomeworkScreen> createState() => _AddHomeworkScreenState();
}

class _AddHomeworkScreenState extends State<AddHomeworkScreen> {
  final _topicCtrl = TextEditingController();
  final _pagesCtrl = TextEditingController();
  final _instrCtrl = TextEditingController();
  final _picker    = ImagePicker();

  List<String> _existingUrls = [];
  List<File>   _newFiles     = [];
  bool         _uploading    = false;
  bool         _saving       = false;
  String?      _error;

  bool get _isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    if (_isEdit) {
      _topicCtrl.text = widget.existing!.topic;
      _pagesCtrl.text = widget.existing!.pageNumbers;
      _instrCtrl.text = widget.existing!.instructions;
      _existingUrls   = List.from(widget.existing!.imageUrls);
    }
  }

  @override
  void dispose() {
    _topicCtrl.dispose();
    _pagesCtrl.dispose();
    _instrCtrl.dispose();
    super.dispose();
  }

  int get _totalImages => _existingUrls.length + _newFiles.length;

  Future<void> _pick() async {
    if (_totalImages >= 20) {
      setState(() => _error = 'Maximum 20 images allowed.');
      return;
    }
    final picked = await _picker.pickMultiImage(
        limit: 20 - _totalImages);
    if (picked.isNotEmpty) {
      setState(() {
        _newFiles.addAll(picked.map((x) => File(x.path)));
        if (_totalImages > 20) {
          _newFiles = _newFiles
              .take(20 - _existingUrls.length)
              .toList();
        }
      });
    }
  }

  Future<void> _submit() async {
    if (_topicCtrl.text.trim().isEmpty) {
      setState(() => _error = 'Please enter a topic.');
      return;
    }
    setState(() { _saving = true; _error = null; });

    try {
      final id = _isEdit ? widget.existing!.id : const Uuid().v4();

      setState(() => _uploading = true);
      TeacherFirebaseService.setUploadContext(widget.cls.id);
      final uploaded = <String>[];
      for (int i = 0; i < _newFiles.length; i++) {
        final url = await TeacherFirebaseService.uploadImage(
            _newFiles[i], widget.schoolId,
            'homework', id, _existingUrls.length + i);
        uploaded.add(url);
      }
      setState(() => _uploading = false);

      final hw = Homework(
        id:           id,
        schoolId:     widget.schoolId,
        classId:      widget.cls.id,
        teacherId:    widget.teacher.id,
        subject:      widget.teacher.subjectFor(widget.cls.id),
        topic:        _topicCtrl.text.trim(),
        instructions: _instrCtrl.text.trim(),
        pageNumbers:  _pagesCtrl.text.trim(),
        imageUrls:    [..._existingUrls, ...uploaded],
        createdAt:    _isEdit
            ? widget.existing!.createdAt
            : DateTime.now(),
      );

      if (_isEdit) {
        await TeacherFirebaseService.updateHomework(hw);
      } else {
        await TeacherFirebaseService.submitHomework(hw);
      }

      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        setState(() { _saving = false; _error = 'Failed to save. Try again.'; });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Text(_isEdit ? 'Edit Homework' : 'Add Homework',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   19,
                          fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FormLabel('Topic *'),
                    LabeledTextField(ctrl: _topicCtrl, hint: 'e.g. Chapter 5 – Fractions'),
                    const SizedBox(height: 16),

                    FormLabel('Book Page Numbers (optional)'),
                    LabeledTextField(ctrl: _pagesCtrl, hint: 'e.g. 42–45'),
                    const SizedBox(height: 16),

                    FormLabel('Photos ($_totalImages / 20)'),
                    ImageGrid(
                      existingUrls: _existingUrls,
                      newFiles:     _newFiles,
                      onAdd:        _pick,
                      onRemoveExisting: (i) =>
                          setState(() => _existingUrls.removeAt(i)),
                      onRemoveNew: (i) =>
                          setState(() => _newFiles.removeAt(i)),
                    ),
                    const SizedBox(height: 16),

                    FormLabel('Instructions'),
                    LabeledTextField(
                        ctrl:     _instrCtrl,
                        hint:     'e.g. Solve all questions and show your working.',
                        maxLines: 4),
                    const SizedBox(height: 16),

                    if (_error != null) ErrorBox(_error!),

                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kNavy,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        onPressed: (_saving || _uploading) ? null : _submit,
                        child: _saving
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const SizedBox(
                                      width: 18, height: 18,
                                      child: CircularProgressIndicator(
                                          color:       Colors.white,
                                          strokeWidth: 2.5)),
                                  const SizedBox(width: 10),
                                  Text(_uploading
                                      ? 'Uploading…'
                                      : 'Saving…'),
                                ],
                              )
                            : Text(
                                _isEdit
                                    ? 'Update Homework'
                                    : 'Submit Homework',
                                style: const TextStyle(
                                    fontSize:   16,
                                    fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Shared small widgets ──────────────────────────────────────
class _SmallBadge extends StatelessWidget {
  final String label;
  final Color  color;
  const _SmallBadge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color:        color.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(label,
            style: TextStyle(
                color:      color,
                fontSize:   10,
                fontWeight: FontWeight.w700)),
      );
}