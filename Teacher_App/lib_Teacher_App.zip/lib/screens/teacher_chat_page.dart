// lib/screens/teacher_chat_page.dart
//
// Teacher Chat — top-level page reachable from ClassSelectionScreen.
// Two tabs:
//   Parents  → search student name → select → open chat with their parent
//   Students → pick a class → list all students → tap to DM
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'chat_screen.dart';

class TeacherChatPage extends StatefulWidget {
  final String  schoolId;
  final Teacher teacher;

  const TeacherChatPage({
    super.key,
    required this.schoolId,
    required this.teacher,
  });

  @override
  State<TeacherChatPage> createState() => _TeacherChatPageState();
}

class _TeacherChatPageState extends State<TeacherChatPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Chat',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   18,
                fontWeight: FontWeight.w800)),
        bottom: TabBar(
          controller:           _tabs,
          indicatorColor:       kNavy,
          labelColor:           cNavy(context) as Color,
          unselectedLabelColor: cMuted(context),
          labelStyle: const TextStyle(
              fontSize: 13, fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: 'Parents'),
            Tab(text: 'Students'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _ParentsTab(
              schoolId: widget.schoolId, teacher: widget.teacher),
          _StudentsTab(
              schoolId: widget.schoolId, teacher: widget.teacher),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// PARENTS tab — search by student name → contact parent
// ══════════════════════════════════════════════════════════════
class _ParentsTab extends StatefulWidget {
  final String  schoolId;
  final Teacher teacher;
  const _ParentsTab({required this.schoolId, required this.teacher});

  @override
  State<_ParentsTab> createState() => _ParentsTabState();
}

class _ParentsTabState extends State<_ParentsTab> {
  final _searchCtrl   = TextEditingController();
  List<Student> _results   = [];
  List<Student> _all        = [];
  bool          _loading    = true;

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_filter);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    // Load all students across teacher's assigned classes
    final classes = await TeacherFirebaseService.getTeacherClasses(
        widget.schoolId, widget.teacher.assignedClassIds);
    final futures = classes.map((c) =>
        TeacherFirebaseService.getStudentsByClass(
            widget.schoolId, c.id));
    final lists  = await Future.wait(futures);
    final all    = lists.expand((l) => l).toList()
      ..sort((a, b) => a.name.compareTo(b.name));
    if (mounted) setState(() { _all = all; _results = all; _loading = false; });
  }

  void _filter() {
    final q = _searchCtrl.text.toLowerCase().trim();
    setState(() {
      _results = q.isEmpty
          ? _all
          : _all
              .where((s) => s.name.toLowerCase().contains(q))
              .toList();
    });
  }

  Future<void> _openParentChat(Student s) async {
    final chatId = await TeacherFirebaseService.getOrCreateParentChatId(
      widget.schoolId,
      widget.teacher.id,
      widget.teacher.name,
      widget.teacher.subjectFor(s.classId),
      s.id,
      s.name,
      s.classId,
    );
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          title:          s.name,
          subtitle:       "Parent of ${s.name}",
          myId:           widget.teacher.id,
          myName:         widget.teacher.name,
          myType:         'teacher',
          messagesStream: TeacherFirebaseService.parentChatMessagesStream(
              widget.schoolId, chatId),
          onSend: (msg) =>
              TeacherFirebaseService.sendTeacherParentMessage(
                  widget.schoolId, chatId, msg),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search bar
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Container(
            decoration: BoxDecoration(
              color:        cCard(context),
              borderRadius: BorderRadius.circular(12),
              border:       Border.all(color: cBorder(context)),
            ),
            child: TextField(
              controller: _searchCtrl,
              style: TextStyle(color: cNavy(context), fontSize: 14),
              decoration: InputDecoration(
                hintText:       'Search student name…',
                hintStyle:      TextStyle(
                    color: cMuted(context), fontSize: 14),
                prefixIcon:     Icon(Icons.search_rounded,
                    color: cMuted(context), size: 20),
                border:         InputBorder.none,
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 13),
              ),
            ),
          ),
        ),

        // List
        Expanded(
          child: _loading
              ? Center(
                  child: CircularProgressIndicator(
                      color: isDark(context) ? kDarkTeal : kTeal,
                      strokeWidth: 2))
              : _results.isEmpty
                  ? Center(
                      child: Text(
                          _searchCtrl.text.isEmpty
                              ? 'No students found.'
                              : 'No match for "${_searchCtrl.text}".',
                          style: TextStyle(
                              color: cMuted(context), fontSize: 14)))
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(
                          16, 4, 16, 40),
                      itemCount: _results.length,
                      separatorBuilder: (_, __) =>
                          Divider(height: 1, color: cBorder(context)),
                      itemBuilder: (_, i) {
                        final s = _results[i];
                        return _ContactTile(
                          name:     s.name,
                          sub:      'Roll: ${s.rollNo} · Parent contact',
                          icon:     Icons.family_restroom_rounded,
                          iconColor: kTeal,
                          onTap: () => _openParentChat(s),
                        );
                      },
                    ),
        ),
      ],
    );
  }
}

// ══════════════════════════════════════════════════════════════
// STUDENTS tab — pick class → list students → DM
// ══════════════════════════════════════════════════════════════
class _StudentsTab extends StatefulWidget {
  final String  schoolId;
  final Teacher teacher;
  const _StudentsTab({required this.schoolId, required this.teacher});

  @override
  State<_StudentsTab> createState() => _StudentsTabState();
}

class _StudentsTabState extends State<_StudentsTab> {
  List<SchoolClass> _classes  = [];
  SchoolClass?      _selClass;
  List<Student>     _students = [];
  bool _loadingClasses  = true;
  bool _loadingStudents = false;

  @override
  void initState() {
    super.initState();
    _loadClasses();
  }

  Future<void> _loadClasses() async {
    setState(() => _loadingClasses = true);
    final cls = await TeacherFirebaseService.getTeacherClasses(
        widget.schoolId, widget.teacher.assignedClassIds);
    if (mounted)
      setState(() { _classes = cls; _loadingClasses = false; });
  }

  Future<void> _selectClass(SchoolClass c) async {
    setState(() { _selClass = c; _loadingStudents = true; _students = []; });
    final students = await TeacherFirebaseService.getStudentsByClass(
        widget.schoolId, c.id);
    if (mounted) {
      setState(() {
        _students = students
          ..sort((a, b) => a.name.compareTo(b.name));
        _loadingStudents = false;
      });
    }
  }

  Future<void> _openStudentChat(Student s) async {
    final chatId = await TeacherFirebaseService.getOrCreateStudentChatId(
      widget.schoolId,
      widget.teacher.id,
      widget.teacher.name,
      s.id,
      s.name,
      s.classId,
    );
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          title:          s.name,
          subtitle:       _selClass?.name ?? '',
          myId:           widget.teacher.id,
          myName:         widget.teacher.name,
          myType:         'teacher',
          messagesStream: TeacherFirebaseService.studentChatMessagesStream(
              widget.schoolId, chatId),
          onSend: (msg) =>
              TeacherFirebaseService.sendTeacherStudentMessage(
                  widget.schoolId, chatId, msg),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loadingClasses) {
      return Center(
          child: CircularProgressIndicator(
              color: isDark(context) ? kDarkTeal : kTeal, strokeWidth: 2));
    }

    return Row(
      children: [
        // Class list (left panel)
        Container(
          width: 130,
          decoration: BoxDecoration(
            border: Border(right: BorderSide(color: cBorder(context))),
          ),
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: _classes.length,
            itemBuilder: (_, i) {
              final c   = _classes[i];
              final sel = _selClass?.id == c.id;
              return GestureDetector(
                onTap: () => _selectClass(c),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    color: sel
                        ? kNavy.withValues(alpha: 0.07)
                        : Colors.transparent,
                    border: Border(
                        left: BorderSide(
                            color: sel ? kNavy : Colors.transparent,
                            width: 3)),
                  ),
                  child: Text(c.name,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: sel
                              ? FontWeight.w700
                              : FontWeight.w500)),
                ),
              );
            },
          ),
        ),

        // Students list (right panel)
        Expanded(
          child: _selClass == null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.touch_app_rounded,
                          color: cBorder(context), size: 40),
                      const SizedBox(height: 10),
                      Text('Select a class',
                          style: TextStyle(
                              color: cMuted(context), fontSize: 14)),
                    ],
                  ),
                )
              : _loadingStudents
                  ? const Center(
                      child: CircularProgressIndicator(
                          strokeWidth: 2))
                  : _students.isEmpty
                      ? Center(
                          child: Text('No students.',
                              style: TextStyle(
                                  color: cMuted(context),
                                  fontSize: 14)))
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(
                              12, 8, 12, 40),
                          itemCount: _students.length,
                          separatorBuilder: (_, __) => Divider(
                              height: 1, color: cBorder(context)),
                          itemBuilder: (_, i) {
                            final s = _students[i];
                            return _ContactTile(
                              name:     s.name,
                              sub:      'Roll: ${s.rollNo}',
                              icon:     Icons.person_rounded,
                              iconColor: kNavy,
                              onTap:    () => _openStudentChat(s),
                            );
                          },
                        ),
        ),
      ],
    );
  }
}

// ── Shared contact tile ───────────────────────────────────────
class _ContactTile extends StatelessWidget {
  final String   name;
  final String   sub;
  final IconData icon;
  final Color    iconColor;
  final VoidCallback onTap;

  const _ContactTile({
    required this.name,
    required this.sub,
    required this.icon,
    required this.iconColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      leading: Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color:        iconColor.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Center(
          child: Text(
            name.isNotEmpty ? name[0].toUpperCase() : '?',
            style: TextStyle(
                color:      iconColor,
                fontSize:   17,
                fontWeight: FontWeight.w800),
          ),
        ),
      ),
      title: Text(name,
          style: TextStyle(
              color:      cNavy(context),
              fontSize:   14,
              fontWeight: FontWeight.w700)),
      subtitle: Text(sub,
          style: TextStyle(color: cMuted(context), fontSize: 11)),
      trailing: Icon(Icons.chevron_right_rounded,
          color: cMuted(context), size: 18),
      onTap: onTap,
    );
  }
}
