// lib/screens/teacher_inbox_screen.dart
// Teacher's unified inbox:  Parent chats  |  Student chats
// Teacher can start a conversation with any parent or student.
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/teacher_firebase_service.dart';
import 'chat_screen.dart';

class TeacherInboxScreen extends StatefulWidget {
  final String      schoolId;
  final Teacher     teacher;
  final SchoolClass cls;

  const TeacherInboxScreen({
    super.key,
    required this.schoolId,
    required this.teacher,
    required this.cls,
  });

  @override
  State<TeacherInboxScreen> createState() => _TeacherInboxScreenState();
}

class _TeacherInboxScreenState extends State<TeacherInboxScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;

  List<Map<String, dynamic>> _parentChats  = [];
  List<Map<String, dynamic>> _studentChats = [];
  List<Student>              _students     = [];
  bool _loadingParent  = true;
  bool _loadingStudent = true;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _loadParentChats();
    _loadStudentChats();
    _loadStudents();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadParentChats() async {
    setState(() => _loadingParent = true);
    final chats = await TeacherFirebaseService.getMyParentChats(
        widget.schoolId, widget.teacher.id);
    if (mounted) setState(() { _parentChats = chats; _loadingParent = false; });
  }

  Future<void> _loadStudentChats() async {
    setState(() => _loadingStudent = true);
    final chats = await TeacherFirebaseService.getMyStudentChats(
        widget.schoolId, widget.teacher.id, widget.cls.id);
    if (mounted)
      setState(() { _studentChats = chats; _loadingStudent = false; });
  }

  Future<void> _loadStudents() async {
    final s = await TeacherFirebaseService.getStudentsByClass(
        widget.schoolId, widget.cls.id);
    if (mounted) setState(() => _students = s);
  }

  // ── Open a parent chat ─────────────────────────────────────
  Future<void> _openParentChat(
      String studentId, String studentName) async {
    final chatId =
        await TeacherFirebaseService.getOrCreateParentChatId(
      widget.schoolId,
      widget.teacher.id,
      widget.teacher.name,
      widget.teacher.subjectFor(widget.cls.id),
      studentId,
      studentName,
      widget.cls.id,
    );

    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          title:          studentName,
          subtitle:       'Parent of $studentName',
          myId:           widget.teacher.id,
          myName:         widget.teacher.name,
          myType:         'teacher',
          messagesStream: TeacherFirebaseService.parentChatMessagesStream(
              widget.schoolId, chatId),
          onSend: (msg) => TeacherFirebaseService.sendTeacherParentMessage(
              widget.schoolId, chatId, msg),
        ),
      ),
    );
    _loadParentChats();
  }

  // ── Open a student chat ────────────────────────────────────
  Future<void> _openStudentChat(
      String studentId, String studentName) async {
    final chatId =
        await TeacherFirebaseService.getOrCreateStudentChatId(
      widget.schoolId,
      widget.teacher.id,
      widget.teacher.name,
      studentId,
      studentName,
      widget.cls.id,
    );

    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatScreen(
          title:          studentName,
          subtitle:       'Student · ${widget.cls.name}',
          myId:           widget.teacher.id,
          myName:         widget.teacher.name,
          myType:         'teacher',
          messagesStream: TeacherFirebaseService.studentChatMessagesStream(
              widget.schoolId, chatId),
          onSend: (msg) => TeacherFirebaseService.sendTeacherStudentMessage(
              widget.schoolId, chatId, msg),
        ),
      ),
    );
    _loadStudentChats();
  }

  // ── Pick a student to start a new chat ─────────────────────
  void _pickStudent({required bool forParent}) {
    if (_students.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('No students found in ${widget.cls.name}.'),
            backgroundColor: kError));
      return;
    }
    showModalBottomSheet(
      context: context,
      backgroundColor: cCard(context),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 6),
          Container(
              width: 40, height: 4,
              decoration: BoxDecoration(
                  color:        cBorder(ctx),
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              forParent
                  ? 'Select a student to message their parent'
                  : 'Select a student to message directly',
              style: TextStyle(
                  color:      cNavy(ctx),
                  fontSize:   15,
                  fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _students.length,
              itemBuilder: (_, i) {
                final s = _students[i];
                return ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 20),
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                        color:        kPink.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(9)),
                    child: Center(
                      child: Text(
                          s.name.isNotEmpty
                              ? s.name[0].toUpperCase()
                              : '?',
                          style: TextStyle(
                              color:      cNavy(ctx),
                              fontSize:   15,
                              fontWeight: FontWeight.w800)),
                    ),
                  ),
                  title: Text(s.name,
                      style: TextStyle(
                          color:      cNavy(ctx),
                          fontSize:   14,
                          fontWeight: FontWeight.w600)),
                  subtitle: Text('Roll: ${s.rollNo}',
                      style: TextStyle(
                          color: cMuted(ctx), fontSize: 11)),
                  onTap: () {
                    Navigator.pop(ctx);
                    if (forParent) {
                      _openParentChat(s.id, s.name);
                    } else {
                      _openStudentChat(s.id, s.name);
                    }
                  },
                );
              },
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Inbox',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   17,
                    fontWeight: FontWeight.w800)),
            Text(widget.cls.name,
                style: TextStyle(
                    color: cMuted(context), fontSize: 11)),
          ],
        ),
        actions: [
          // Start new chat button
          PopupMenuButton<String>(
            icon: Icon(Icons.edit_square, color: cNavy(context), size: 20),
            tooltip: 'New Conversation',
            color: cCard(context),
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'parent',
                child: Row(
                  children: [
                    Icon(Icons.family_restroom_rounded,
                        color: cNavy(context), size: 18),
                    const SizedBox(width: 10),
                    Text('Message a Parent',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   13,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'student',
                child: Row(
                  children: [
                    Icon(Icons.school_rounded,
                        color: cNavy(context), size: 18),
                    const SizedBox(width: 10),
                    Text('Message a Student',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   13,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
            onSelected: (v) => _pickStudent(forParent: v == 'parent'),
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller:           _tabCtrl,
          indicatorColor:       kNavy,
          labelColor:           cNavy(context) as Color,
          unselectedLabelColor: cMuted(context),
          labelStyle: const TextStyle(
              fontSize: 13, fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: 'Parents'),
            Tab(text: 'Students'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _ChatList(
            loading: _loadingParent,
            chats:   _parentChats,
            nameKey: 'parentStudentName',
            subKey:  'teacherSubject',
            onTap:   (c) => _openParentChat(
                c['parentStudentId'] ?? '', c['parentStudentName'] ?? ''),
            onRefresh: _loadParentChats,
            emptyMsg: 'No parent conversations yet.\nTap ✏ to start one.',
          ),
          _ChatList(
            loading: _loadingStudent,
            chats:   _studentChats,
            nameKey: 'studentName',
            subKey:  'classId',
            onTap:   (c) => _openStudentChat(
                c['studentId'] ?? '', c['studentName'] ?? ''),
            onRefresh: _loadStudentChats,
            emptyMsg: 'No student conversations yet.\nTap ✏ to start one.',
          ),
        ],
      ),
    );
  }
}

// ── Chat list ─────────────────────────────────────────────────
class _ChatList extends StatelessWidget {
  final bool                              loading;
  final List<Map<String, dynamic>>        chats;
  final String                            nameKey;
  final String                            subKey;
  final void Function(Map<String, dynamic>) onTap;
  final VoidCallback                      onRefresh;
  final String                            emptyMsg;

  const _ChatList({
    required this.loading,
    required this.chats,
    required this.nameKey,
    required this.subKey,
    required this.onTap,
    required this.onRefresh,
    required this.emptyMsg,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Center(
          child: CircularProgressIndicator(
              color: isDark(context) ? kDarkTeal : kTeal, strokeWidth: 2));
    }
    if (chats.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.chat_bubble_outline_rounded,
                color: cBorder(context), size: 48),
            const SizedBox(height: 14),
            Text(emptyMsg,
                textAlign: TextAlign.center,
                style:
                    TextStyle(color: cMuted(context), fontSize: 14)),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        itemCount: chats.length,
        itemBuilder: (_, i) {
          final c    = chats[i];
          final name = (c[nameKey] as String?) ?? '?';
          final sub  = (c[subKey]  as String?) ?? '';
          final last = (c['lastMessage'] as String?) ?? '';
          return GestureDetector(
            onTap: () => onTap(c),
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                      color:      kNavy.withValues(alpha: 0.04),
                      blurRadius: 8,
                      offset:     const Offset(0, 2)),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color:        kPink.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        name.isNotEmpty
                            ? name[0].toUpperCase()
                            : '?',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   18,
                            fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name,
                            style: TextStyle(
                                color:      cNavy(context),
                                fontSize:   14,
                                fontWeight: FontWeight.w700)),
                        if (last.isNotEmpty)
                          Text(last,
                              maxLines:  1,
                              overflow:  TextOverflow.ellipsis,
                              style: TextStyle(
                                  color:    cMuted(context),
                                  fontSize: 12)),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      color: cMuted(context), size: 18),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
