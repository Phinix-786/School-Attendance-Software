// lib/services/teacher_firebase_service.dart
import 'dart:convert';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../backend_config.dart';

class TeacherFirebaseService {
  static final _db = FirebaseFirestore.instance;

  // ── Session helpers ───────────────────────────────────────
  static Future<String> _sid() async {
    final p = await SharedPreferences.getInstance();
    return p.getString('sectionId') ?? '';
  }

  // ── Auth ──────────────────────────────────────────────────
  static Future<Teacher?> login(
      String schoolId, String teacherId, String password) async {
    final sectionsSnap =
        await _db.collection('schools/$schoolId/sections').get();
    for (final section in sectionsSnap.docs) {
      final doc = await _db
          .collection(
              'schools/$schoolId/sections/${section.id}/teachers')
          .doc(teacherId)
          .get();
      if (doc.exists) {
        final teacher = Teacher.fromMap(doc.data()!);
        if (teacher.password != password) return null;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('sectionId', section.id);
        return teacher;
      }
    }
    return null;
  }

  static Future<void> saveSession(
      String schoolId, String teacherId, String teacherName) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('schoolId',    schoolId);
    await p.setString('teacherId',   teacherId);
    await p.setString('teacherName', teacherName);
  }

  static Future<Map<String, String>?> getSavedSession() async {
    final p         = await SharedPreferences.getInstance();
    final schoolId  = p.getString('schoolId');
    final teacherId = p.getString('teacherId');
    if (schoolId == null || teacherId == null) return null;
    return {
      'schoolId':    schoolId,
      'teacherId':   teacherId,
      'teacherName': p.getString('teacherName') ?? '',
      'sectionId':   p.getString('sectionId')   ?? '',
    };
  }

  static Future<Map<String, String>?> getSession() => getSavedSession();

  static Future<void> clearSession() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('schoolId');
    await p.remove('teacherId');
    await p.remove('teacherName');
    await p.remove('sectionId');
  }

  // ── School name ───────────────────────────────────────────
  static Future<String> getSchoolName(String schoolId) async {
    try {
      final doc = await _db.collection('schools').doc(schoolId).get();
      return (doc.data()?['name'] as String?) ?? schoolId;
    } catch (_) {
      return schoolId;
    }
  }

  // ── Teacher ───────────────────────────────────────────────
  static Future<Teacher?> getTeacher(
      String schoolId, String teacherId) async {
    final sid = await _sid();
    if (sid.isNotEmpty) {
      final doc = await _db
          .collection('schools/$schoolId/sections/$sid/teachers')
          .doc(teacherId)
          .get();
      if (doc.exists) return Teacher.fromMap(doc.data()!);
    }
    final sectionsSnap =
        await _db.collection('schools/$schoolId/sections').get();
    for (final s in sectionsSnap.docs) {
      final doc = await _db
          .collection('schools/$schoolId/sections/${s.id}/teachers')
          .doc(teacherId)
          .get();
      if (doc.exists) return Teacher.fromMap(doc.data()!);
    }
    return null;
  }

  // ── Classes ───────────────────────────────────────────────
  static Future<List<SchoolClass>> getTeacherClasses(
      String schoolId, List<String> assignedClassIds) async {
    if (assignedClassIds.isEmpty) return [];
    final sid = await _sid();
    if (sid.isEmpty) return [];
    final futures = assignedClassIds.map((id) => _db
        .collection('schools/$schoolId/sections/$sid/classes')
        .doc(id)
        .get());
    final docs = await Future.wait(futures);
    return docs
        .where((d) => d.exists)
        .map((d) => SchoolClass.fromMap(d.data()!))
        .toList();
  }

  static Future<List<SchoolClass>> getAssignedClasses(
      String schoolId, String teacherId) async {
    final teacher = await getTeacher(schoolId, teacherId);
    if (teacher == null) return [];
    return getTeacherClasses(schoolId, teacher.assignedClassIds);
  }

  // ── Students ──────────────────────────────────────────────
  static Future<List<Student>> getStudentsByClass(
      String schoolId, String classId) async {
    final sid = await _sid();
    if (sid.isEmpty) return [];
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sid/classes/$classId/students')
        .get();
    return snap.docs.map((d) => Student.fromMap(d.data())).toList();
  }

  // ── Attendance ────────────────────────────────────────────
  static String _sessionPath(String schoolId, String sid) =>
      sid.isNotEmpty
          ? 'schools/$schoolId/sections/$sid/attendance_sessions'
          : 'schools/$schoolId/attendance_sessions';

  static Future<void> submitAttendance({
    required AttendanceSession  session,
    required List<AttendanceRecord> records,
  }) async {
    final sid     = await _sid();
    final path    = _sessionPath(session.schoolId, sid);
    final batch   = _db.batch();
    final sessRef = _db.collection(path).doc(session.id);
    batch.set(sessRef, session.toMap());
    for (final r in records) {
      batch.set(sessRef.collection('records').doc(r.id), r.toMap());
    }
    await batch.commit();
  }

  static Future<AttendanceSession?> getTodaySession(
      String schoolId, String classId, String teacherId) async {
    final sid   = await _sid();
    final path  = _sessionPath(schoolId, sid);
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final end   = start.add(const Duration(days: 1));
    final snap  = await _db
        .collection(path)
        .where('classId',   isEqualTo: classId)
        .where('teacherId', isEqualTo: teacherId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return null;
    return AttendanceSession.fromMap(snap.docs.first.data());
  }

  static Future<List<AttendanceRecord>> getSessionRecords(
      String schoolId, String sessionId) async {
    final sid  = await _sid();
    final path = _sessionPath(schoolId, sid);
    final snap =
        await _db.collection('$path/$sessionId/records').get();
    return snap.docs
        .map((d) => AttendanceRecord.fromMap(d.data()))
        .toList();
  }

  static Future<void> updateRecord(String schoolId, String sessionId,
      AttendanceRecord record) async {
    final sid  = await _sid();
    final path = _sessionPath(schoolId, sid);
    await _db
        .collection('$path/$sessionId/records')
        .doc(record.id)
        .update(record.toMap());
  }

  static Future<List<AttendanceSession>> getRecentSessions(
      String schoolId, String teacherId) async {
    final sid    = await _sid();
    final path   = _sessionPath(schoolId, sid);
    final cutoff =
        DateTime.now().subtract(const Duration(days: 7));
    final snap   = await _db
        .collection(path)
        .where('teacherId', isEqualTo: teacherId)
        .where('date',
            isGreaterThanOrEqualTo: Timestamp.fromDate(cutoff))
        .orderBy('date', descending: true)
        .get();
    return snap.docs
        .map((d) => AttendanceSession.fromMap(d.data()))
        .toList();
  }

  // ── Offline queue ─────────────────────────────────────────
  static Future<void> saveToOfflineQueue(OfflineQueueItem item) async {
    final p        = await SharedPreferences.getInstance();
    final existing = p.getStringList('offline_queue') ?? [];
    existing.add(jsonEncode(item.toJson()));
    await p.setStringList('offline_queue', existing);
  }

  static Future<List<OfflineQueueItem>> getOfflineQueue() async {
    final p   = await SharedPreferences.getInstance();
    final raw = p.getStringList('offline_queue') ?? [];
    return raw
        .map((s) =>
            OfflineQueueItem.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
  }

  static Future<void> clearOfflineQueue() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('offline_queue');
  }

  // ── Image upload ──────────────────────────────────────────
  /// Uploads [file] to the Ubuntu backend, returns its relative URL.
  /// Falls back to a base64 data URI if the backend is unreachable.
  static Future<String> uploadImage(File file, String schoolId,
      String type, String itemId, int index) async {
    final sid     = await _sid();
    final classId = _lastClassId;
    final uri     = Uri.parse(
        '$kBackendBaseUrl/upload/$schoolId/$sid/$classId/$type/$itemId');

    try {
      final bytes    = await file.readAsBytes();
      final boundary = 'App_Name/DomainBound${DateTime.now().millisecondsSinceEpoch}';

      // Build multipart body manually (no extra package needed)
      final headerBytes = utf8.encode(
        '--$boundary\r\n'
        'Content-Disposition: form-data; name="file"; filename="image.jpg"\r\n'
        'Content-Type: image/jpeg\r\n'
        '\r\n',
      );
      final footerBytes = utf8.encode('\r\n--$boundary--\r\n');
      final body = <int>[...headerBytes, ...bytes, ...footerBytes];

      final client  = HttpClient()
        ..connectionTimeout = const Duration(seconds: 15);
      final request = await client.postUrl(uri);
      request.headers
        ..set('X-API-Key', kBackendApiKey)
        ..set(HttpHeaders.contentTypeHeader,
            'multipart/form-data; boundary=$boundary')
        ..set(HttpHeaders.contentLengthHeader, body.length.toString());
      request.add(body);

      final response = await request.close();
      final raw      = await response.transform(utf8.decoder).join();
      client.close();

      if (response.statusCode == 200) {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        return map['url'] as String; // e.g. "/files/school/sec/cls/..."
      }
    } catch (_) {
      // Backend unreachable or timed out — use base64 fallback
    }

    // Fallback: base64 data URI stored directly in Firestore
    final bytes = await file.readAsBytes();
    return 'data:image/jpeg;base64,${base64Encode(bytes)}';
  }

  /// Call this just before uploadImage so the service knows the classId path.
  static String _lastClassId = '';
  static void setUploadContext(String classId) => _lastClassId = classId;

  // ── Homework ──────────────────────────────────────────────
  static String _hwPath(String schoolId, String sid, String classId) =>
      'schools/$schoolId/sections/$sid/classes/$classId/homeworks';

  static Future<void> submitHomework(Homework hw) async {
    final sid = await _sid();
    await _db
        .collection(_hwPath(hw.schoolId, sid, hw.classId))
        .doc(hw.id)
        .set(hw.toMap());
  }

  static Future<void> updateHomework(Homework hw) async {
    final sid = await _sid();
    await _db
        .collection(_hwPath(hw.schoolId, sid, hw.classId))
        .doc(hw.id)
        .update(hw.toMap());
  }

  static Future<List<Homework>> getHomeworks(
      String schoolId, String classId) async {
    final sid  = await _sid();
    final snap = await _db
        .collection(_hwPath(schoolId, sid, classId))
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => Homework.fromMap(d.data())).toList();
  }

  // ── Tests ─────────────────────────────────────────────────
  static String _testPath(String schoolId, String sid, String classId) =>
      'schools/$schoolId/sections/$sid/classes/$classId/tests';

  static Future<void> submitTest(SchoolTest test) async {
    final sid = await _sid();
    await _db
        .collection(_testPath(test.schoolId, sid, test.classId))
        .doc(test.id)
        .set(test.toMap());
  }

  static Future<void> updateTest(SchoolTest test) async {
    final sid = await _sid();
    await _db
        .collection(_testPath(test.schoolId, sid, test.classId))
        .doc(test.id)
        .update(test.toMap());
  }

  static Future<List<SchoolTest>> getTests(
      String schoolId, String classId) async {
    final sid  = await _sid();
    final snap = await _db
        .collection(_testPath(schoolId, sid, classId))
        .orderBy('testDate', descending: true)
        .get();
    return snap.docs
        .map((d) => SchoolTest.fromMap(d.data()))
        .toList();
  }

  // ── Test Results ──────────────────────────────────────────
  static String _resultPath(
          String schoolId, String sid, String classId, String testId) =>
      'schools/$schoolId/sections/$sid/classes/$classId/tests/$testId/results';

  static Future<void> submitResult(TestResult result) async {
    final sid = await _sid();
    await _db
        .collection(
            _resultPath(result.schoolId, sid, result.classId, result.testId))
        .doc(result.id)
        .set(result.toMap());
  }

  static Future<List<TestResult>> getResults(
      String schoolId, String classId, String testId) async {
    final sid  = await _sid();
    final snap = await _db
        .collection(_resultPath(schoolId, sid, classId, testId))
        .get();
    return snap.docs
        .map((d) => TestResult.fromMap(d.data()))
        .toList();
  }

  // ── Search students across assigned classes (for parent lookup) ──
  /// Returns students whose names contain [query] (case-insensitive).
  static Future<List<Student>> searchStudents(
      String schoolId, String query) async {
    final sid = await _sid();
    if (sid.isEmpty) return [];
    final snap = await _db
        .collection('schools/$schoolId/sections/$sid/classes')
        .get();
    final all = <Student>[];
    for (final clsDoc in snap.docs) {
      final sSnap = await _db
          .collection(
              'schools/$schoolId/sections/$sid/classes/${clsDoc.id}/students')
          .get();
      all.addAll(sSnap.docs.map((d) => Student.fromMap(d.data())));
    }
    if (query.trim().isEmpty) return all;
    final q = query.toLowerCase();
    return all.where((s) => s.name.toLowerCase().contains(q)).toList();
  }

  // ── Teacher → Parent chat ─────────────────────────────────────
  // Reuses the same path the Parent app writes to:
  // sections/{secId}/teacher_parent_chats/{teacherId}_{studentId}/messages

  static String _tpChatPath(String schoolId, String sid) =>
      'schools/$schoolId/sections/$sid/teacher_parent_chats';

  static Future<List<Map<String, dynamic>>> getMyParentChats(
      String schoolId, String teacherId) async {
    final sid  = await _sid();
    if (sid.isEmpty) return [];
    final snap = await _db
        .collection(_tpChatPath(schoolId, sid))
        .where('teacherId', isEqualTo: teacherId)
        .orderBy('updatedAt', descending: true)
        .get();
    return snap.docs.map((d) => d.data()).toList();
  }

  /// Get or create a teacher↔parent chat doc. chatId = '{teacherId}_{studentId}'.
  static Future<String> getOrCreateParentChatId(
      String schoolId, String teacherId, String teacherName,
      String teacherSubject, String studentId, String studentName,
      String classId) async {
    final sid    = await _sid();
    final chatId = '${teacherId}_$studentId';
    final ref    = _db.collection(_tpChatPath(schoolId, sid)).doc(chatId);
    final snap   = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'id':               chatId,
        'teacherId':        teacherId,
        'teacherName':      teacherName,
        'teacherSubject':   teacherSubject,
        'parentStudentId':  studentId,
        'parentStudentName': studentName,
        'classId':          classId,
        'lastMessage':      '',
        'updatedAt':        FieldValue.serverTimestamp(),
      });
    }
    return chatId;
  }

  static Stream<List<ChatMessage>> parentChatMessagesStream(
      String schoolId, String chatId) async* {
    final sid = await _sid();
    if (sid.isEmpty) return;
    yield* _db
        .collection('${_tpChatPath(schoolId, sid)}/$chatId/messages')
        .orderBy('timestamp')
        .snapshots()
        .map((s) =>
            s.docs.map((d) => ChatMessage.fromMap(d.data())).toList());
  }

  static Future<void> sendTeacherParentMessage(
      String schoolId, String chatId, ChatMessage msg) async {
    final sid    = await _sid();
    final chatRef = _db.collection(_tpChatPath(schoolId, sid)).doc(chatId);
    await chatRef.collection('messages').doc(msg.id).set(msg.toMap());
    await chatRef.update({
      'lastMessage': msg.text,
      'updatedAt':   FieldValue.serverTimestamp(),
    });
  }

  // ── Teacher → Student chat ────────────────────────────────────
  // New path: sections/{secId}/teacher_student_chats/{teacherId}_{studentId}/messages

  static String _tsChatPath(String schoolId, String sid) =>
      'schools/$schoolId/sections/$sid/teacher_student_chats';

  static Future<List<Map<String, dynamic>>> getMyStudentChats(
      String schoolId, String teacherId, String classId) async {
    final sid = await _sid();
    if (sid.isEmpty) return [];
    final snap = await _db
        .collection(_tsChatPath(schoolId, sid))
        .where('teacherId', isEqualTo: teacherId)
        .where('classId',   isEqualTo: classId)
        .orderBy('updatedAt', descending: true)
        .get();
    return snap.docs.map((d) => d.data()).toList();
  }

  static Future<String> getOrCreateStudentChatId(
      String schoolId, String teacherId, String teacherName,
      String studentId, String studentName, String classId) async {
    final sid    = await _sid();
    final chatId = '${teacherId}_$studentId';
    final ref    = _db.collection(_tsChatPath(schoolId, sid)).doc(chatId);
    final snap   = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'id':          chatId,
        'teacherId':   teacherId,
        'teacherName': teacherName,
        'studentId':   studentId,
        'studentName': studentName,
        'classId':     classId,
        'lastMessage': '',
        'updatedAt':   FieldValue.serverTimestamp(),
      });
    }
    return chatId;
  }

  static Stream<List<ChatMessage>> studentChatMessagesStream(
      String schoolId, String chatId) async* {
    final sid = await _sid();
    if (sid.isEmpty) return;
    yield* _db
        .collection('${_tsChatPath(schoolId, sid)}/$chatId/messages')
        .orderBy('timestamp')
        .snapshots()
        .map((s) =>
            s.docs.map((d) => ChatMessage.fromMap(d.data())).toList());
  }

  static Future<void> sendTeacherStudentMessage(
      String schoolId, String chatId, ChatMessage msg) async {
    final sid     = await _sid();
    final chatRef = _db.collection(_tsChatPath(schoolId, sid)).doc(chatId);
    await chatRef.collection('messages').doc(msg.id).set(msg.toMap());
    await chatRef.update({
      'lastMessage': msg.text,
      'updatedAt':   FieldValue.serverTimestamp(),
    });
  }

  // ── Timetable ─────────────────────────────────────────────────
  static Future<TeacherTimetable?> getMyTimetable(
      String schoolId, String teacherId) async {
    final sid = await _sid();
    if (sid.isEmpty) return null;
    final doc = await _db
        .collection('schools/$schoolId/sections/$sid/timetables')
        .doc(teacherId)
        .get();
    if (!doc.exists) return null;
    return TeacherTimetable.fromMap(doc.data()!);
  }

  // ── Notices ───────────────────────────────────────────────────
  static Future<List<SchoolNotice>> getNotices(String schoolId) async {
    final sid  = await _sid();
    if (sid.isEmpty) return [];
    final snap = await _db
        .collection('schools/$schoolId/sections/$sid/notices')
        .where('targetAudience', whereIn: ['teachers', 'all'])
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => SchoolNotice.fromMap(d.data())).toList();
  }

  // ── Cross-class chat requests ─────────────────────────────────
  static String _crossReqPath(String schoolId, String sid, String classId) =>
      'schools/$schoolId/sections/$sid/classes/$classId/cross_chat_requests';

  static Future<List<CrossChatRequest>> getCrossClassRequests(
      String schoolId, String classId) async {
    final sid  = await _sid();
    if (sid.isEmpty) return [];
    final snap = await _db
        .collection(_crossReqPath(schoolId, sid, classId))
        .where('status', isEqualTo: 'pending')
        .get();
    return snap.docs
        .map((d) => CrossChatRequest.fromMap(d.data()))
        .toList();
  }

  static Future<void> approveCrossClassRequest(
      String schoolId, String classId, CrossChatRequest req) async {
    final sid    = await _sid();
    if (sid.isEmpty) return;
    final chatId = '${req.requesterId}_${req.targetStudentId}';
    final batch  = _db.batch();

    batch.update(
      _db.collection(_crossReqPath(schoolId, sid, classId)).doc(req.id),
      {'status': 'approved'},
    );

    batch.set(
      _db.collection(
          'schools/$schoolId/sections/$sid/classes/$classId/cross_class_chats')
          .doc(chatId),
      {
        'id': chatId,
        'student1Id':   req.requesterId,
        'student1Name': req.requesterName,
        'student2Id':   req.targetStudentId,
        'student2Name': req.targetStudentName,
        'requesterClassId': req.requesterClassId,
        'approvedAt': FieldValue.serverTimestamp(),
      },
    );

    await batch.commit();
  }

  static Future<void> rejectCrossClassRequest(
      String schoolId, String classId, String requestId) async {
    final sid = await _sid();
    if (sid.isEmpty) return;
    await _db
        .collection(_crossReqPath(schoolId, sid, classId))
        .doc(requestId)
        .update({'status': 'rejected'});
  }
}
