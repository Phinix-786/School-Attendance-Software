// lib/privacy_policy_content.dart
// ─────────────────────────────────────────────────────────────────────────────
// All privacy policy text lives here. Edit this file to update the policy
// across the entire Teacher app without touching any screen code.
// ─────────────────────────────────────────────────────────────────────────────

const kAppName    = 'App_Name';
const kAppRole    = 'Teacher Portal';
const kContactEmail = 'App_Name@gmail.com';
const kLastUpdated  = 'June 2025';

const kPrivacyPolicyTitle = 'Privacy Policy';

const kPrivacyIntro = '''
This Privacy Policy explains how $kAppName ("we", "our", or "the app") handles information in the $kAppRole. Please read it carefully before using the app. By using $kAppName you agree to this policy.
''';

const kPrivacyDataCollectedTitle = 'Information We Collect';
const kPrivacyDataCollected = '''
$kAppName is an offline-first school management tool. We do not collect, transmit, or store any personal data on external servers beyond what your school's own Firebase project holds.

The following data is stored in your school's Firebase database, which is controlled entirely by the school administrator:

• Your teacher name, phone number, email address, and teacher ID
• Attendance records you submit for your assigned classes
• Homework and test assignments you create
• Test results you enter for students
• Messages sent through the in-app chat features
• Your timetable schedule set by the school

We do not collect analytics, crash reports, advertising identifiers, or device information.
''';

const kPrivacyChildrenTitle = 'Children\'s Privacy';
const kPrivacyChildren = '''
$kAppName does not knowingly collect personal information from any person under the age of 13 or above the age of 13 for any commercial purpose. The app is a management tool for school staff and does not target children as end users. Student data stored in the system is controlled solely by the school and its administrators.

We do not collect, share, or sell any data belonging to minors.
''';

const kPrivacyDataUseTitle = 'How Data Is Used';
const kPrivacyDataUse = '''
All data stored through $kAppName is used exclusively to operate the school management features you use: marking attendance, uploading homework, entering test results, and communicating with parents and students. No data is used for advertising, profiling, or any purpose outside of school operations.
''';

const kPrivacySharingTitle = 'Data Sharing';
const kPrivacySharing = '''
We do not sell, rent, or share your data with any third party. Your school's data remains within the Firebase project set up and managed by your school administrator. We have no access to it.
''';

const kPrivacySecurityTitle = 'Security';
const kPrivacySecurity = '''
Your school administrator is responsible for the security of the Firebase project that stores school data. We encourage the use of strong passwords and access controls. The app enforces rate limiting on login attempts to protect against unauthorized access.
''';

const kPrivacyContactTitle = 'Contact Us';
const kPrivacyContact = '''
If you have any questions about this Privacy Policy, please contact us at:

$kContactEmail
''';

const kPrivacyAgreementText =
    'I have read and agree to the Privacy Policy.';

const kPrivacyDeclineWarning =
    'You must agree to the Privacy Policy to use $kAppName. The app will close.';
