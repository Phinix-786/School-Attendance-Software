// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'app_theme.dart';
import 'services/teacher_firebase_service.dart';
import 'screens/login_screen.dart';
import 'screens/class_selection_screen.dart';
import 'screens/privacy_consent_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    if (!e.toString().contains('duplicate-app')) rethrow;
  }
  runApp(const TeacherApp());
}

class TeacherApp extends StatelessWidget {
  const TeacherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        title: 'App_Name – Teacher',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme:     lightThemeData,
        darkTheme: darkThemeData,
        home: const _SplashScreen(),
      ),
    );
  }
}

class _SplashScreen extends StatefulWidget {
  const _SplashScreen();
  @override
  State<_SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<_SplashScreen> {
  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await Future.delayed(const Duration(milliseconds: 700));
    final session = await TeacherFirebaseService.getSavedSession();
    if (!mounted) return;

    if (session == null) {
      _goLogin();
      return;
    }

    try {
      final teacher = await TeacherFirebaseService.getTeacher(
          session['schoolId']!, session['teacherId']!);
      if (!mounted) return;
      if (teacher == null) {
        await TeacherFirebaseService.clearSession();
        _goLogin();
        return;
      }
      final destination = ClassSelectionScreen(
        schoolId: session['schoolId']!,
        teacher:  teacher,
      );

      final agreed = await PrivacyConsentScreen.hasAgreed();
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => agreed
              ? destination
              : PrivacyConsentScreen(nextScreen: destination),
        ),
      );
    } catch (_) {
      if (mounted) _goLogin();
    }
  }

  void _goLogin() => Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const TeacherLoginScreen()),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Container(
              width: 86, height: 86,
              decoration: BoxDecoration(
                color:        const Color(0xFFEEDFC8),
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color:      kNavy.withValues(alpha: 0.12),
                    blurRadius: 24,
                    offset:     const Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset(
                  'assets/icon.png',
                  width: 86, height: 86,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'App_Name',
              style: TextStyle(
                color:      cNavy(context),
                fontSize:   22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(30),
                border:       Border.all(color: kPink.withValues(alpha: 0.35)),
              ),
              child: Text(
                '✦  Teacher Portal',
                style: TextStyle(
                  color:         isDark(context) ? kDarkPink : kNavy,
                  fontSize:      12,
                  fontWeight:    FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: 26, height: 26,
              child: CircularProgressIndicator(
                color:       isDark(context) ? kDarkTeal : kTeal,
                strokeWidth: 2.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
