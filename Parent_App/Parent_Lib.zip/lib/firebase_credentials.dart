// lib/firebase_credentials.dart
// Replace the values below with your actual Firebase project credentials.

const String kApiKey            = 'YOUR_API_KEY';
const String kAppIdAndroid      = 'YOUR_ANDROID_APP_ID';
const String kAppIdIos          = 'YOUR_IOS_APP_ID';
const String kMessagingSenderId = 'YOUR_MESSAGING_SENDER_ID';
const String kProjectId         = 'YOUR_PROJECT_ID';
const String kStorageBucket     = 'YOUR_PROJECT_ID.appspot.com';
const String kIosBundleId       = 'YOUR_IOS_BUNDLE_ID';
