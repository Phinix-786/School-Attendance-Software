// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_credentials.dart';
import 'app_theme.dart';
import 'services/parent_firebase_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/app_tour_screen.dart';
import 'screens/privacy_consent_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey:            kApiKey,
        appId:             defaultTargetPlatform == TargetPlatform.iOS
                               ? kAppIdIos
                               : kAppIdAndroid,
        messagingSenderId: kMessagingSenderId,
        projectId:         kProjectId,
        storageBucket:     kStorageBucket,
        iosBundleId:       kIosBundleId,
      ),
    );
  } catch (e) {
    if (!e.toString().contains('duplicate-app')) rethrow;
  }
  runApp(const ParentApp());
}

class ParentApp extends StatelessWidget {
  const ParentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, _x) => MaterialApp(
        title: 'App_Name – Parent',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme:     lightThemeData,
        darkTheme: darkThemeData,
        home: const SplashScreen(),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted) return;

    final prefs    = await SharedPreferences.getInstance();
    final tourDone = prefs.getBool('tour_done') ?? false;

    if (!tourDone) {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const AppTourScreen()));
      return;
    }

    final session = await ParentFirebaseService.getSavedSession();
    if (!mounted) return;

    if (session == null) {
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const ParentLoginScreen()));
      return;
    }

    final destination = HomeScreen(session: session);
    final agreed      = await PrivacyConsentScreen.hasAgreed();
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (_) => agreed
                ? destination
                : PrivacyConsentScreen(nextScreen: destination)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 86, height: 86,
              decoration: BoxDecoration(
                color:        const Color(0xFFEEDFC8),
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                      color:      kNavy.withValues(alpha: 0.12),
                      blurRadius: 24,
                      offset:     const Offset(0, 8)),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset('assets/icon.png',
                    width: 86, height: 86, fit: BoxFit.cover),
              ),
            ),
            const SizedBox(height: 20),
            Text('App_Name',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.5)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: kPink.withValues(alpha: 0.35)),
              ),
              child: Text('✦  Parent Portal',
                  style: TextStyle(
                      color:         isDark(context) ? kDarkPink : kNavy,
                      fontSize:      12,
                      fontWeight:    FontWeight.w700,
                      letterSpacing: 0.5)),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: 28, height: 28,
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal, strokeWidth: 3),
            ),
          ],
        ),
      ),
    );
  }
}
