// lib/screens/homework_detail_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../backend_image.dart';

class HomeworkDetailScreen extends StatefulWidget {
  final Homework hw;
  const HomeworkDetailScreen({super.key, required this.hw});

  @override
  State<HomeworkDetailScreen> createState() => _HomeworkDetailScreenState();
}

class _HomeworkDetailScreenState extends State<HomeworkDetailScreen> {
  int _imgIndex = 0;

  @override
  Widget build(BuildContext context) {
    final hw   = widget.hw;
    final date = '${hw.createdAt.day}/${hw.createdAt.month}/${hw.createdAt.year}';

    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Back + title
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Text('Homework Details',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   19,
                            fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Subject + date
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color:        kTeal.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(hw.subject,
                              style: TextStyle(
                                  color:      cNavy(context),
                                  fontSize:   12,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const Spacer(),
                        Text(date,
                            style: TextStyle(
                                color: cMuted(context), fontSize: 12)),
                      ],
                    ),
                    const SizedBox(height: 12),

                    // Topic
                    Text(hw.topic,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   20,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 16),

                    // Page numbers
                    if (hw.pageNumbers.isNotEmpty) ...[
                      _InfoRow(
                          icon: Icons.menu_book_outlined,
                          label: 'Book Pages',
                          value: hw.pageNumbers),
                      const SizedBox(height: 12),
                    ],

                    // Images
                    if (hw.imageUrls.isNotEmpty) ...[
                      Text('Homework Images (${hw.imageUrls.length})',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      _ImageCarousel(
                        urls:      hw.imageUrls,
                        index:     _imgIndex,
                        onChanged: (i) => setState(() => _imgIndex = i),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Instructions
                    if (hw.instructions.isNotEmpty) ...[
                      Text('Instructions',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Container(
                        width:   double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(14),
                          border:       Border.all(color: cBorder(context)),
                        ),
                        child: Text(hw.instructions,
                            style: TextStyle(
                                color:    cBlue(context),
                                fontSize: 14,
                                height:   1.5)),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String   label;
  final String   value;
  const _InfoRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16, color: cMuted(context)),
        const SizedBox(width: 6),
        Text('$label: ',
            style: TextStyle(
                color:      cMuted(context),
                fontSize:   13,
                fontWeight: FontWeight.w600)),
        Text(value,
            style: TextStyle(color: cNavy(context), fontSize: 13)),
      ],
    );
  }
}

class _ImageCarousel extends StatelessWidget {
  final List<String> urls;
  final int          index;
  final ValueChanged<int> onChanged;
  const _ImageCarousel(
      {required this.urls, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: GestureDetector(
            onTap: () => _showFullscreen(context),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: BackendImage(urls[index], fit: BoxFit.cover),
            ),
          ),
        ),
        if (urls.length > 1) ...[
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(urls.length, (i) {
                final isSel = i == index;
                return GestureDetector(
                  onTap: () => onChanged(i),
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    width:  54, height: 54,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: isSel ? kNavy : Colors.transparent,
                          width: 2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: BackendImage(urls[i], fit: BoxFit.cover),
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ],
    );
  }

  void _showFullscreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _FullscreenImage(urls: urls, initial: index),
      ),
    );
  }
}

class _FullscreenImage extends StatefulWidget {
  final List<String> urls;
  final int          initial;
  const _FullscreenImage({required this.urls, required this.initial});

  @override
  State<_FullscreenImage> createState() => _FullscreenImageState();
}

class _FullscreenImageState extends State<_FullscreenImage> {
  late final PageController _ctrl;
  late int _current;

  @override
  void initState() {
    super.initState();
    _current = widget.initial;
    _ctrl    = PageController(initialPage: widget.initial);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('${_current + 1} / ${widget.urls.length}'),
      ),
      body: PageView.builder(
        controller: _ctrl,
        itemCount:  widget.urls.length,
        onPageChanged: (i) => setState(() => _current = i),
        itemBuilder: (_, i) => Center(
          child: InteractiveViewer(
            child: BackendImage(widget.urls[i]),
          ),
        ),
      ),
    );
  }
}
