// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/parent_firebase_service.dart';
import 'login_screen.dart';
import 'homework_detail_screen.dart';
import 'test_detail_screen.dart';
import 'notices_screen.dart';
import 'teacher_chat_list_screen.dart';
import 'leave_request_screen.dart';
import 'add_child_screen.dart';
import 'privacy_policy_screen.dart';

// ── Home Shell with Drawer ────────────────────────────────────
class HomeScreen extends StatefulWidget {
  final Map<String, String> session;
  const HomeScreen({super.key, required this.session});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Map<String, String> _session;

  // Tab: 0=Homework 1=Tests 2=Teachers
  int _tab = 0;

  List<Homework>   _homeworks = [];
  List<SchoolTest> _tests     = [];
  bool             _loading   = true;

  // Multi-child
  List<Map<String, String>> _children   = [];
  int                       _activeIdx  = 0;

  String get _schoolId  => _session['schoolId']!;
  String get _sectionId => _session['sectionId'] ?? '';
  String get _classId   => _session['classId']!;
  String get _studentId => _session['studentId']!;
  String get _name      => _session['studentName'] ?? 'Student';

  @override
  void initState() {
    super.initState();
    _session = Map.from(widget.session);
    _loadChildren();
    _load();
  }

  Future<void> _loadChildren() async {
    final children = await ParentFirebaseService.getAllChildren();
    final idx      = await ParentFirebaseService.getActiveChildIndex();
    if (mounted) setState(() { _children = children; _activeIdx = idx; });
  }

  Future<void> _switchChild(int idx) async {
    await ParentFirebaseService.setActiveChild(idx);
    final session = await ParentFirebaseService.getSavedSession();
    if (!mounted || session == null) return;
    setState(() {
      _session    = session;
      _activeIdx  = idx;
      _tab        = 0;
      _homeworks  = [];
      _tests      = [];
    });
    Navigator.pop(context); // close drawer
    _load();
  }

  Future<void> _load() async {
    if (_tab == 2) {
      setState(() => _loading = false);
      return;
    }
    setState(() => _loading = true);
    if (_tab == 0) {
      final hw = await ParentFirebaseService.getHomeworks(
          _schoolId, _sectionId, _classId);
      if (mounted) setState(() { _homeworks = hw; _loading = false; });
    } else if (_tab == 1) {
      final ts = await ParentFirebaseService.getTests(
          _schoolId, _sectionId, _classId);
      if (mounted) setState(() { _tests = ts; _loading = false; });
    }
  }

  Future<void> _logout() async {
    await ParentFirebaseService.clearSession();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const ParentLoginScreen()),
        (_) => false);
  }

  // ── Build ─────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      drawer: _buildDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 12),
            _buildTabBar(),
            const SizedBox(height: 8),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  // ── Drawer ────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: cCard(context),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color:        kNavy,
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(13),
                      child: Image.asset('assets/icon.png',
                          width: 44, height: 44, fit: BoxFit.cover),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text('App_Name',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   18,
                          fontWeight: FontWeight.w900)),
                  Text('Parent Portal',
                      style: TextStyle(
                          color: cMuted(context), fontSize: 12)),
                ],
              ),
            ),
            Divider(height: 1, color: cBorder(context)),
            const SizedBox(height: 8),

            // Children section label
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 6),
              child: Text('MY CHILDREN',
                  style: TextStyle(
                      color:         cMuted(context),
                      fontSize:      10,
                      fontWeight:    FontWeight.w800,
                      letterSpacing: 1.0)),
            ),

            // Children list
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  ..._children.asMap().entries.map((e) {
                    final idx     = e.key;
                    final child   = e.value;
                    final name    = child['studentName'] ?? 'Child ${idx + 1}';
                    final active  = idx == _activeIdx;
                    return ListTile(
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 20),
                      leading: Container(
                        width: 38, height: 38,
                        decoration: BoxDecoration(
                          color:        active
                              ? kNavy
                              : cBg(context),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: active
                                  ? kNavy
                                  : cBorder(context)),
                        ),
                        child: Center(
                          child: Text(
                            name.isNotEmpty
                                ? name[0].toUpperCase()
                                : '?',
                            style: TextStyle(
                                color:      active
                                    ? Colors.white
                                    : cNavy(context),
                                fontSize:   16,
                                fontWeight: FontWeight.w800),
                          ),
                        ),
                      ),
                      title: Text(name,
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   14,
                              fontWeight: active
                                  ? FontWeight.w700
                                  : FontWeight.w500)),
                      subtitle: Text(
                          'ID: ${child['loginId'] ?? ''}',
                          style: TextStyle(
                              color: cMuted(context), fontSize: 11)),
                      trailing: active
                          ? Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color:        kNavy,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Text('Active',
                                  style: TextStyle(
                                      color:      Colors.white,
                                      fontSize:   10,
                                      fontWeight: FontWeight.w700)),
                            )
                          : null,
                      onTap: active ? null : () => _switchChild(idx),
                    );
                  }),

                  // Add another child
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
                    child: GestureDetector(
                      onTap: () async {
                        Navigator.pop(context); // close drawer
                        final added = await Navigator.push<bool>(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const AddChildScreen()),
                        );
                        if (added == true && mounted) {
                          await _loadChildren();
                          final newIdx = _children.length - 1;
                          await _switchChild(
                              newIdx >= 0 ? newIdx : 0);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 13),
                        decoration: BoxDecoration(
                          color:        kTeal.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: kTeal.withValues(alpha: 0.35),
                              style: BorderStyle.solid),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.person_add_rounded,
                                color: kTeal, size: 18),
                            const SizedBox(width: 10),
                            Text('Add Another Child',
                                style: TextStyle(
                                    color:      cNavy(context),
                                    fontSize:   13,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Privacy Policy
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                      builder: (_) => const PrivacyPolicyScreen()));
                },
                child: Row(
                  children: [
                    Icon(Icons.privacy_tip_outlined,
                        color: cMuted(context), size: 16),
                    const SizedBox(width: 10),
                    Text('Privacy Policy',
                        style: TextStyle(
                            color:    cMuted(context),
                            fontSize: 12)),
                    const Spacer(),
                    Icon(Icons.chevron_right_rounded,
                        color: cMuted(context), size: 15),
                  ],
                ),
              ),
            ),

            // Sign out
            Divider(height: 1, color: cBorder(context)),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              child: GestureDetector(
                onTap: _logout,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 13),
                  decoration: BoxDecoration(
                    color:        kError.withValues(alpha: 0.06),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: kError.withValues(alpha: 0.25)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.logout_rounded,
                          color: kError, size: 18),
                      const SizedBox(width: 10),
                      const Text('Sign Out',
                          style: TextStyle(
                              color:      kError,
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 16, 0),
      child: Row(
        children: [
          // Hamburger
          Builder(builder: (ctx) => GestureDetector(
            onTap: () => Scaffold.of(ctx).openDrawer(),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(11),
                border:       Border.all(color: cBorder(context)),
                boxShadow: [
                  BoxShadow(color: kNavy.withValues(alpha: 0.04),
                      blurRadius: 6, offset: const Offset(0, 2))
                ],
              ),
              child: Icon(Icons.menu_rounded,
                  color: cNavy(context), size: 20),
            ),
          )),
          const SizedBox(width: 12),

          // Name + portal badge
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_name,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   20,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 9, vertical: 3),
                  decoration: BoxDecoration(
                    color:        kPink.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('Parent Portal',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   10,
                          fontWeight: FontWeight.w700)),
                ),
              ],
            ),
          ),

          // Leave
          IconButton(
            tooltip:  'Leave Request',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(
                    builder: (_) => ParentLeaveRequestScreen(
                        session: _session))),
            icon: Icon(Icons.event_busy_rounded,
                color: cMuted(context), size: 22),
          ),
          // Notices
          IconButton(
            tooltip:  'Notices',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(
                    builder: (_) => ParentNoticesScreen(
                        session: _session))),
            icon: Icon(Icons.notifications_outlined,
                color: cMuted(context), size: 22),
          ),
        ],
      ),
    );
  }

  // ── Tab bar ───────────────────────────────────────────────────
  Widget _buildTabBar() {
    const tabs = [
      ('📚', 'Homework'),
      ('📝', 'Tests'),
      ('💬', 'Teachers'),
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color:      kNavy.withValues(alpha: 0.06),
                blurRadius: 12,
                offset:     const Offset(0, 3)),
          ],
        ),
        child: Row(
          children: List.generate(tabs.length, (i) {
            final (emoji, label) = tabs[i];
            final active = _tab == i;
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  setState(() { _tab = i; });
                  _load();
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color:        active ? kNavy : Colors.transparent,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(
                    children: [
                      Text(emoji,
                          style: const TextStyle(fontSize: 14)),
                      const SizedBox(height: 2),
                      Text(label,
                          style: TextStyle(
                              color:      active
                                  ? Colors.white
                                  : cMuted(context),
                              fontSize:   10,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  // ── Body ──────────────────────────────────────────────────────
  Widget _buildBody() {
    switch (_tab) {
      case 0:
        if (_loading) {
          return Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal));
        }
        return _HomeworkFeed(
            homeworks: _homeworks, onRefresh: _load);
      case 1:
        if (_loading) {
          return Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal));
        }
        return _TestFeed(
          tests:     _tests,
          schoolId:  _schoolId,
          sectionId: _sectionId,
          classId:   _classId,
          studentId: _studentId,
          onRefresh: _load,
        );
      case 2:
        return TeacherChatListScreen(session: _session);
      default:
        return const SizedBox.shrink();
    }
  }
}

// ── Tab widget ────────────────────────────────────────────────
class _Tab extends StatelessWidget {
  final String label;
  final bool   active;
  final VoidCallback onTap;
  const _Tab({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 13),
          decoration: BoxDecoration(
            color:        active ? kNavy : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Text(label,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color:      active ? Colors.white : cMuted(context),
                  fontSize:   14,
                  fontWeight: FontWeight.w700)),
        ),
      ),
    );
  }
}

// ── Homework feed ─────────────────────────────────────────────
class _HomeworkFeed extends StatelessWidget {
  final List<Homework> homeworks;
  final VoidCallback   onRefresh;
  const _HomeworkFeed({required this.homeworks, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    if (homeworks.isEmpty) {
      return Center(
        child: Text('No homework assigned yet.',
            style: TextStyle(color: cMuted(context), fontSize: 14)),
      );
    }
    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        itemCount: homeworks.length,
        itemBuilder: (ctx, i) {
          final hw = homeworks[i];
          return GestureDetector(
            onTap: () => Navigator.push(ctx,
                MaterialPageRoute(
                    builder: (_) => HomeworkDetailScreen(hw: hw))),
            child: _HomeworkCard(hw: hw),
          );
        },
      ),
    );
  }
}

class _HomeworkCard extends StatelessWidget {
  final Homework hw;
  const _HomeworkCard({required this.hw});

  @override
  Widget build(BuildContext context) {
    final date =
        '${hw.createdAt.day}/${hw.createdAt.month}/${hw.createdAt.year}';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 10,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(hw.subject,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   11,
                        fontWeight: FontWeight.w700)),
              ),
              const Spacer(),
              Text(date,
                  style: TextStyle(color: cMuted(context), fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(hw.topic,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   15,
                  fontWeight: FontWeight.w700)),
          if (hw.instructions.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(hw.instructions,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: cBlue(context), fontSize: 13)),
          ],
          if (hw.pageNumbers.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text('Pages: ${hw.pageNumbers}',
                style: TextStyle(color: cMuted(context), fontSize: 12)),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.image_outlined, size: 13, color: cMuted(context)),
              const SizedBox(width: 4),
              Text('${hw.imageUrls.length} image(s)',
                  style: TextStyle(color: cMuted(context), fontSize: 12)),
              const Spacer(),
              Icon(Icons.chevron_right_rounded,
                  color: cMuted(context), size: 18),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Test feed ─────────────────────────────────────────────────
class _TestFeed extends StatelessWidget {
  final List<SchoolTest> tests;
  final String schoolId, sectionId, classId, studentId;
  final VoidCallback onRefresh;

  const _TestFeed({
    required this.tests, required this.schoolId, required this.sectionId,
    required this.classId, required this.studentId, required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    if (tests.isEmpty) {
      return Center(
        child: Text('No tests scheduled yet.',
            style: TextStyle(color: cMuted(context), fontSize: 14)),
      );
    }
    return RefreshIndicator(
      onRefresh: () async => onRefresh(),
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        itemCount: tests.length,
        itemBuilder: (ctx, i) {
          final test = tests[i];
          return GestureDetector(
            onTap: () => Navigator.push(
              ctx,
              MaterialPageRoute(
                builder: (_) => TestDetailScreen(
                  test:      test,
                  schoolId:  schoolId,
                  sectionId: sectionId,
                  classId:   classId,
                  studentId: studentId,
                ),
              ),
            ),
            child: _TestCard(test: test),
          );
        },
      ),
    );
  }
}

class _TestCard extends StatelessWidget {
  final SchoolTest test;
  const _TestCard({required this.test});

  @override
  Widget build(BuildContext context) {
    final date =
        '${test.testDate.day}/${test.testDate.month}/${test.testDate.year}';
    final isUpcoming = test.testDate.isAfter(DateTime.now());

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.05),
              blurRadius: 10,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color:        kTeal.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(test.subject,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   11,
                        fontWeight: FontWeight.w700)),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: isUpcoming
                      ? kPink.withValues(alpha: 0.2)
                      : cBorder(context),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(isUpcoming ? 'Upcoming' : 'Past',
                    style: TextStyle(
                        color:      isUpcoming ? kNavy : cMuted(context),
                        fontSize:   11,
                        fontWeight: FontWeight.w600)),
              ),
              const Spacer(),
              Icon(Icons.calendar_today_outlined,
                  size: 13, color: cMuted(context)),
              const SizedBox(width: 4),
              Text(date,
                  style: TextStyle(color: cMuted(context), fontSize: 11)),
            ],
          ),
          const SizedBox(height: 8),
          Text(test.topic,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   15,
                  fontWeight: FontWeight.w700)),
          if (test.pageNumbers.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text('Pages: ${test.pageNumbers}',
                style: TextStyle(color: cMuted(context), fontSize: 12)),
          ],
          if (!isUpcoming) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.bar_chart_rounded, size: 14, color: kTeal),
                const SizedBox(width: 4),
                Text('Tap to view result',
                    style: TextStyle(
                        color:      kTeal,
                        fontSize:   12,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
