// lib/screens/add_child_screen.dart
// Add another child's account without logging out.
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../services/parent_firebase_service.dart';

class AddChildScreen extends StatefulWidget {
  const AddChildScreen({super.key});
  @override
  State<AddChildScreen> createState() => _AddChildScreenState();
}

class _AddChildScreenState extends State<AddChildScreen> {
  final _schoolCtrl = TextEditingController();
  final _loginCtrl  = TextEditingController();
  final _passCtrl   = TextEditingController();
  bool    _loading = false;
  String? _error;
  bool    _obscure = true;

  @override
  void dispose() {
    _schoolCtrl.dispose();
    _loginCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final schoolId = _schoolCtrl.text.trim();
    final loginId  = _loginCtrl.text.trim();
    final pass     = _passCtrl.text;

    if (schoolId.isEmpty || loginId.isEmpty || pass.isEmpty) {
      setState(() => _error = 'Please fill in all fields.');
      return;
    }
    setState(() { _loading = true; _error = null; });

    try {
      final result = await ParentFirebaseService.login(schoolId, loginId, pass);
      if (!mounted) return;
      if (result == null) {
        setState(() { _loading = false; _error = 'Invalid ID or password.'; });
        return;
      }

      final student   = result['student'] as dynamic;
      final sectionId = result['sectionId'] as String;
      final classId   = result['classId']   as String;

      // Check not already added
      final existing = await ParentFirebaseService.getAllChildren();
      final alreadyAdded =
          existing.any((c) => c['studentId'] == student.id);
      if (!mounted) return;
      if (alreadyAdded) {
        setState(() {
          _loading = false;
          _error   = 'This child is already added to your account.';
        });
        return;
      }

      await ParentFirebaseService.saveSession(
        schoolId:    schoolId,
        sectionId:   sectionId,
        classId:     classId,
        studentId:   student.id,
        studentName: student.name,
        loginId:     loginId,
      );

      if (!mounted) return;
      Navigator.pop(context, true); // signal success
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Connection error. Try again.'; });
    }
  }

  Widget _field({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboardType,
  }) {
    return Container(
      decoration: BoxDecoration(
        color:        cBg(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: TextField(
        controller:   ctrl,
        obscureText:  obscure,
        keyboardType: keyboardType,
        style: TextStyle(color: cNavy(context), fontSize: 15),
        decoration: InputDecoration(
          labelText:      label,
          labelStyle:     TextStyle(color: cMuted(context), fontSize: 14),
          prefixIcon:     Icon(icon, color: cMuted(context), size: 20),
          suffixIcon:     suffix,
          border:         InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context, false),
        ),
        title: Text('Add Another Child',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   17,
                fontWeight: FontWeight.w800)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Info banner
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:        kTeal.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kTeal.withValues(alpha: 0.3)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline_rounded,
                      color: isDark(context) ? kDarkTeal : kNavy,
                      size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Enter the Parent App credentials provided by the school '
                      'for your other child. Each child has separate login details.',
                      style: TextStyle(
                          color:    cNavy(context),
                          fontSize: 12,
                          height:   1.5),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            _field(ctrl: _schoolCtrl, label: 'School ID',
                icon: Icons.school_outlined),
            const SizedBox(height: 14),
            _field(ctrl: _loginCtrl, label: 'Parent Login ID',
                icon: Icons.badge_outlined),
            const SizedBox(height: 14),
            _field(
              ctrl:    _passCtrl,
              label:   'Password',
              icon:    Icons.lock_outline,
              obscure: _obscure,
              suffix: IconButton(
                icon: Icon(
                    _obscure
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    color: cMuted(context), size: 20),
                onPressed: () =>
                    setState(() => _obscure = !_obscure),
              ),
            ),

            if (_error != null) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color:        kError.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: kError.withValues(alpha: 0.3)),
                ),
                child: Text(_error!,
                    style:
                        const TextStyle(color: kError, fontSize: 13)),
              ),
            ],

            const SizedBox(height: 28),
            SizedBox(
              width:  double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _loading ? null : _add,
                style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
                child: _loading
                    ? const SizedBox(
                        width: 22, height: 22,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2.5))
                    : const Text('Add Child',
                        style: TextStyle(
                            fontSize:   16,
                            fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
