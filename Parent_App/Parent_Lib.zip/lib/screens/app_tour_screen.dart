// lib/screens/app_tour_screen.dart
// First-launch walkthrough. Pure text, professional, one-time only.
// Stored flag: 'tour_done' in SharedPreferences.
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import 'login_screen.dart';

class AppTourScreen extends StatefulWidget {
  const AppTourScreen({super.key});
  @override
  State<AppTourScreen> createState() => _AppTourScreenState();
}

class _AppTourScreenState extends State<AppTourScreen> {
  final _ctrl = PageController();
  int _page   = 0;

  static const _slides = [
    _Slide(
      step:     '01',
      title:    'Welcome to App_Name',
      subtitle: 'Your child\'s school, in your pocket.',
      body:
          'App_Name connects you directly to your child\'s school. '
          'Get homework updates, test results, attendance alerts, and more — '
          'all in one place, in real time.',
    ),
    _Slide(
      step:     '02',
      title:    'Homework & Tests',
      subtitle: 'Never miss an assignment.',
      body:
          'View all homework and upcoming tests assigned by teachers. '
          'Each entry shows the subject, topic, instructions, and '
          'any reference images uploaded by the teacher. '
          'Tap a test to see your child\'s result once it\'s published.',
    ),
    _Slide(
      step:     '03',
      title:    'Classroom Feed',
      subtitle: 'See what happened today.',
      body:
          'Teachers post daily updates from the classroom — '
          'a short note about what was covered, along with photos. '
          'You\'ll always know how your child\'s day went, '
          'without waiting for the weekly parent meeting.',
    ),
    _Slide(
      step:     '04',
      title:    'Chat with Teachers',
      subtitle: 'Direct, private conversations.',
      body:
          'Tap the Teachers tab to see all teachers assigned to your child\'s class. '
          'Start a private chat with any of them — ask questions, '
          'share concerns, or follow up on progress. '
          'Teachers respond directly in the app.',
    ),
    _Slide(
      step:     '05',
      title:    'Leave Requests',
      subtitle: 'One tap to inform the school.',
      body:
          'Need to take your child out of school? '
          'Submit a short leave request for tomorrow or the day after — '
          'add a reason and it goes straight to the section head for approval. '
          'You can track the status (pending, approved, rejected) anytime.',
    ),
    _Slide(
      step:     '06',
      title:    'Multiple Children',
      subtitle: 'One app for the whole family.',
      body:
          'Have more than one child in the school? '
          'Tap the menu on the top-left of the home screen to switch between children '
          'or add another child\'s account. '
          'Each child has their own login credentials provided by the school.',
    ),
    _Slide(
      step:     '07',
      title:    'Notices & Alerts',
      subtitle: 'Stay informed, always.',
      body:
          'The bell icon on the home screen shows all notices published by the school '
          'for parents. Important announcements, event reminders, and '
          'policy updates are posted here by section heads or administrators.',
    ),
  ];

  Future<void> _finish() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('tour_done', true);
    if (!mounted) return;
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const ParentLoginScreen()));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final slide = _slides[_page];
    final isLast = _page == _slides.length - 1;

    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          children: [
            // ── Top bar ──────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Logo + brand
                  Row(
                    children: [
                      Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color:        const Color(0xFFEEDFC8),
                          borderRadius: BorderRadius.circular(9),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(9),
                          child: Image.asset('assets/icon.png',
                              width: 32, height: 32, fit: BoxFit.cover),
                        ),
                      ),
                      const SizedBox(width: 9),
                      Text('App_Name',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   15,
                              fontWeight: FontWeight.w800)),
                    ],
                  ),
                  // Skip
                  GestureDetector(
                    onTap: _finish,
                    child: Text('Skip',
                        style: TextStyle(
                            color:      cMuted(context),
                            fontSize:   13,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),

            // ── Page content ─────────────────────────────────
            Expanded(
              child: PageView.builder(
                controller: _ctrl,
                itemCount:  _slides.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (_, i) => _SlidePage(slide: _slides[i]),
              ),
            ),

            // ── Bottom nav ───────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  // Dot indicators
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_slides.length, (i) {
                      final active = i == _page;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width:  active ? 22 : 7,
                        height: 7,
                        decoration: BoxDecoration(
                          color: active
                              ? kNavy
                              : cBorder(context),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 24),

                  // Action button
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () {
                        if (isLast) {
                          _finish();
                        } else {
                          _ctrl.nextPage(
                            duration: const Duration(milliseconds: 350),
                            curve:    Curves.easeInOut,
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kNavy,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text(
                        isLast ? 'Get Started' : 'Next',
                        style: const TextStyle(
                            fontSize:   16,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Slide page ────────────────────────────────────────────────
class _SlidePage extends StatelessWidget {
  final _Slide slide;
  const _SlidePage({required this.slide});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 40, 28, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Step chip
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color:        kTeal.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              'Step ${slide.step} of 07',
              style: TextStyle(
                  color:      isDark(context) ? kDarkTeal : kNavy,
                  fontSize:   11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5),
            ),
          ),
          const SizedBox(height: 28),

          // Title
          Text(slide.title,
              style: TextStyle(
                  color:         cNavy(context),
                  fontSize:      30,
                  fontWeight:    FontWeight.w900,
                  height:        1.15,
                  letterSpacing: -0.5)),
          const SizedBox(height: 10),

          // Subtitle
          Text(slide.subtitle,
              style: TextStyle(
                  color:      isDark(context) ? kDarkTeal : kTeal,
                  fontSize:   16,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 20),

          // Divider line
          Container(
            width: 48, height: 3,
            decoration: BoxDecoration(
              color:        kNavy,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),

          // Body text
          Text(slide.body,
              style: TextStyle(
                  color:  cBlue(context),
                  fontSize: 15,
                  height:   1.7)),
        ],
      ),
    );
  }
}

// ── Data ──────────────────────────────────────────────────────
class _Slide {
  final String step;
  final String title;
  final String subtitle;
  final String body;
  const _Slide({
    required this.step,
    required this.title,
    required this.subtitle,
    required this.body,
  });
}
