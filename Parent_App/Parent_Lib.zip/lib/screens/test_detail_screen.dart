// lib/screens/test_detail_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/parent_firebase_service.dart';
import '../backend_image.dart';


class TestDetailScreen extends StatefulWidget {
  final SchoolTest test;
  final String schoolId, sectionId, classId, studentId;

  const TestDetailScreen({
    super.key,
    required this.test,
    required this.schoolId,
    required this.sectionId,
    required this.classId,
    required this.studentId,
  });

  @override
  State<TestDetailScreen> createState() => _TestDetailScreenState();
}

class _TestDetailScreenState extends State<TestDetailScreen> {
  TestResult? _result;
  bool        _loadingResult = true;
  int         _imgIndex      = 0;

  @override
  void initState() {
    super.initState();
    _loadResult();
  }

  Future<void> _loadResult() async {
    setState(() => _loadingResult = true);
    final r = await ParentFirebaseService.getMyResult(
      widget.schoolId, widget.sectionId, widget.classId,
      widget.test.id, widget.studentId,
    );
    if (mounted) setState(() { _result = r; _loadingResult = false; });
  }

  @override
  Widget build(BuildContext context) {
    final test     = widget.test;
    final testDate =
        '${test.testDate.day}/${test.testDate.month}/${test.testDate.year}';
    final isUpcoming = test.testDate.isAfter(DateTime.now());

    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 16, 16, 0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        color: cNavy(context), size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                  Expanded(
                    child: Text('Test Details',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   19,
                            fontWeight: FontWeight.w800)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Subject + status
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color:        kTeal.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(test.subject,
                              style: TextStyle(
                                  color:      cNavy(context),
                                  fontSize:   12,
                                  fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: isUpcoming
                                ? kPink.withValues(alpha: 0.2)
                                : cBorder(context),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(isUpcoming ? 'Upcoming' : 'Past',
                              style: TextStyle(
                                  color: isUpcoming
                                      ? kNavy
                                      : cMuted(context),
                                  fontSize:   11,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),

                    Text(test.topic,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   20,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 14),

                    _InfoRow(
                        icon:  Icons.calendar_today_outlined,
                        label: 'Test Date',
                        value: testDate),
                    if (test.pageNumbers.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      _InfoRow(
                          icon:  Icons.menu_book_outlined,
                          label: 'Pages',
                          value: test.pageNumbers),
                    ],
                    const SizedBox(height: 14),

                    // Images
                    if (test.imageUrls.isNotEmpty) ...[
                      Text('Test Material (${test.imageUrls.length})',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      _ImageCarousel(
                        urls:      test.imageUrls,
                        index:     _imgIndex,
                        onChanged: (i) => setState(() => _imgIndex = i),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // Instructions
                    if (test.instructions.isNotEmpty) ...[
                      Text('Instructions',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Container(
                        width:   double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(14),
                          border:       Border.all(color: cBorder(context)),
                        ),
                        child: Text(test.instructions,
                            style: TextStyle(
                                color:    cBlue(context),
                                fontSize: 14,
                                height:   1.5)),
                      ),
                      const SizedBox(height: 20),
                    ],

                    // Result section
                    if (!isUpcoming) ...[
                      Text('Result',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   16,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 10),
                      _loadingResult
                          ? Center(
                              child: CircularProgressIndicator(
                                  color: isDark(context)
                                      ? kDarkTeal
                                      : kTeal))
                          : _result == null
                              ? Container(
                                  padding: const EdgeInsets.all(20),
                                  decoration: BoxDecoration(
                                    color:        cCard(context),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                        color: cBorder(context)),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Result not published yet.',
                                      style: TextStyle(
                                          color:    cMuted(context),
                                          fontSize: 14),
                                    ),
                                  ),
                                )
                              : _ResultCard(result: _result!),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final TestResult result;
  const _ResultCard({required this.result});

  @override
  Widget build(BuildContext context) {
    if (result.wasAbsent) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
                color:      kNavy.withValues(alpha: 0.06),
                blurRadius: 16,
                offset:     const Offset(0, 4)),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:  const Color(0xFFF59E0B).withValues(alpha: 0.1),
                border: Border.all(
                    color: const Color(0xFFF59E0B), width: 3),
              ),
              child: const Center(
                child: Text('—',
                    style: TextStyle(
                        color:      Color(0xFFF59E0B),
                        fontSize:   26,
                        fontWeight: FontWeight.w900)),
              ),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Absent on test day',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   16,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF59E0B).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: const Color(0xFFF59E0B).withValues(alpha: 0.4)),
                    ),
                    child: const Text('Absent',
                        style: TextStyle(
                            color:      Color(0xFFF59E0B),
                            fontSize:   12,
                            fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    final pct = result.percentage;

    Color color;
    String grade;
    if (pct >= 90)       { color = const Color(0xFF16A34A); grade = 'A+'; }
    else if (pct >= 80)  { color = const Color(0xFF16A34A); grade = 'A';  }
    else if (pct >= 70)  { color = const Color(0xFF2563EB); grade = 'B';  }
    else if (pct >= 60)  { color = const Color(0xFFF59E0B); grade = 'C';  }
    else if (pct >= 50)  { color = const Color(0xFFF59E0B); grade = 'D';  }
    else                 { color = kError;                  grade = 'F';  }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
              color:      kNavy.withValues(alpha: 0.06),
              blurRadius: 16,
              offset:     const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withValues(alpha: 0.12),
                  border: Border.all(color: color, width: 3),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(grade,
                          style: TextStyle(
                              color:      color,
                              fontSize:   22,
                              fontWeight: FontWeight.w900)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${result.marksObtained} / ${result.marksTotal}',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   26,
                          fontWeight: FontWeight.w900),
                    ),
                    Text(
                      '${pct.toStringAsFixed(1)}%',
                      style: TextStyle(color: color, fontSize: 15,
                          fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (result.remarks.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              width:   double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:        cBg(context),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Teacher's Remarks",
                      style: TextStyle(
                          color:      cMuted(context),
                          fontSize:   11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5)),
                  const SizedBox(height: 6),
                  Text(result.remarks,
                      style: TextStyle(
                          color:    cNavy(context),
                          fontSize: 14,
                          height:   1.4)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String   label;
  final String   value;
  const _InfoRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16, color: cMuted(context)),
        const SizedBox(width: 6),
        Text('$label: ',
            style: TextStyle(
                color:      cMuted(context),
                fontSize:   13,
                fontWeight: FontWeight.w600)),
        Text(value,
            style: TextStyle(color: cNavy(context), fontSize: 13)),
      ],
    );
  }
}

class _ImageCarousel extends StatelessWidget {
  final List<String>      urls;
  final int               index;
  final ValueChanged<int> onChanged;
  const _ImageCarousel(
      {required this.urls, required this.index, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: GestureDetector(
            onTap: () => _showFullscreen(context),
            child: AspectRatio(
              aspectRatio: 4 / 3,
              child: BackendImage(urls[index], fit: BoxFit.cover),
            ),
          ),
        ),
        if (urls.length > 1) ...[
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(urls.length, (i) {
                final isSel = i == index;
                return GestureDetector(
                  onTap: () => onChanged(i),
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    width:  54, height: 54,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: isSel ? kNavy : Colors.transparent,
                          width: 2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: BackendImage(urls[i], fit: BoxFit.cover),
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ],
    );
  }

  void _showFullscreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _FullscreenImage(urls: urls, initial: index),
      ),
    );
  }
}

class _FullscreenImage extends StatefulWidget {
  final List<String> urls;
  final int          initial;
  const _FullscreenImage({required this.urls, required this.initial});

  @override
  State<_FullscreenImage> createState() => _FullscreenImageState();
}

class _FullscreenImageState extends State<_FullscreenImage> {
  late final PageController _ctrl;
  late int _current;

  @override
  void initState() {
    super.initState();
    _current = widget.initial;
    _ctrl    = PageController(initialPage: widget.initial);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('${_current + 1} / ${widget.urls.length}'),
      ),
      body: PageView.builder(
        controller: _ctrl,
        itemCount:  widget.urls.length,
        onPageChanged: (i) => setState(() => _current = i),
        itemBuilder: (_, i) => Center(
          child: InteractiveViewer(
            child: BackendImage(widget.urls[i]),
          ),
        ),
      ),
    );
  }
}