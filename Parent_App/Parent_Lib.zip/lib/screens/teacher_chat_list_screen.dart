// lib/screens/teacher_chat_list_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/parent_firebase_service.dart';
import 'teacher_parent_chat_screen.dart';

class TeacherChatListScreen extends StatefulWidget {
  final Map<String, String> session;
  const TeacherChatListScreen({super.key, required this.session});

  @override
  State<TeacherChatListScreen> createState() => _TeacherChatListScreenState();
}

class _TeacherChatListScreenState extends State<TeacherChatListScreen> {
  List<Teacher> _teachers = [];
  bool          _loading  = true;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final teachers = await ParentFirebaseService.getTeachersForClass(
        _schoolId, _sectionId, _classId);
    if (mounted) setState(() { _teachers = teachers; _loading = false; });
  }

  String _firstName(String fullName) {
    final parts = fullName.trim().split(' ');
    return parts.isNotEmpty ? parts.first : fullName;
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? Center(
              child: CircularProgressIndicator(
                  color: isDark(context) ? kDarkTeal : kTeal))
          : _teachers.isEmpty
              ? Center(
                  child: Text('No teachers found.',
                      style: TextStyle(color: cMuted(context), fontSize: 15)),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                  itemCount: _teachers.length,
                  itemBuilder: (_, i) {
                    final t       = _teachers[i];
                    final subject = t.subjectFor(_classId);
                    final display = subject.isNotEmpty
                        ? '${_firstName(t.name)} ($subject)'
                        : _firstName(t.name);
                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => TeacherParentChatScreen(
                            session:        widget.session,
                            teacherId:      t.id,
                            teacherName:    t.name,
                            teacherSubject: subject,
                          ),
                        ),
                      ),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                                color:      kNavy.withValues(alpha: 0.05),
                                blurRadius: 10,
                                offset:     const Offset(0, 3)),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 44, height: 44,
                              decoration: BoxDecoration(
                                color:        kTeal.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Center(
                                child: Text(
                                  t.name.isNotEmpty
                                      ? t.name[0].toUpperCase()
                                      : 'T',
                                  style: TextStyle(
                                      color:      cNavy(context),
                                      fontSize:   18,
                                      fontWeight: FontWeight.w800),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(display,
                                  style: TextStyle(
                                      color:      cNavy(context),
                                      fontSize:   15,
                                      fontWeight: FontWeight.w700)),
                            ),
                            Icon(Icons.chat_bubble_outline_rounded,
                                color: kTeal, size: 20),
                          ],
                        ),
                      ),
                    );
                  },
                );
  }
}
