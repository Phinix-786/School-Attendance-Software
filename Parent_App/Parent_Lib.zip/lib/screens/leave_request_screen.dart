// lib/screens/leave_request_screen.dart
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/parent_firebase_service.dart';

class ParentLeaveRequestScreen extends StatefulWidget {
  final Map<String, String> session;
  const ParentLeaveRequestScreen({super.key, required this.session});

  @override
  State<ParentLeaveRequestScreen> createState() =>
      _ParentLeaveRequestScreenState();
}

class _ParentLeaveRequestScreenState
    extends State<ParentLeaveRequestScreen> {
  final _reasonCtrl = TextEditingController();

  DateTime? _selectedDate;
  bool      _submitting = false;
  String?   _error;
  bool      _success    = false;

  String get _schoolId  => widget.session['schoolId']!;
  String get _sectionId => widget.session['sectionId'] ?? '';
  String get _classId   => widget.session['classId']!;
  String get _studentId => widget.session['studentId']!;
  String get _name      => widget.session['studentName'] ?? '';

  final _tomorrow     = DateTime.now().add(const Duration(days: 1));
  final _dayAfter     = DateTime.now().add(const Duration(days: 2));

  String _fmt(DateTime d) =>
      '${d.day}/${d.month}/${d.year}';

  @override
  void dispose() { _reasonCtrl.dispose(); super.dispose(); }

  Future<void> _submit() async {
    if (_selectedDate == null) {
      setState(() => _error = 'Please select a date.');
      return;
    }
    if (_reasonCtrl.text.trim().isEmpty) {
      setState(() => _error = 'Please enter a reason.');
      return;
    }

    setState(() { _submitting = true; _error = null; });

    final req = LeaveRequest(
      id:            const Uuid().v4(),
      studentId:     _studentId,
      studentName:   _name,
      classId:       _classId,
      sectionId:     _sectionId,
      requestedDate: _selectedDate!,
      reason:        _reasonCtrl.text.trim(),
      status:        'pending',
      submittedBy:   'parent',
      submittedAt:   DateTime.now(),
    );

    try {
      await ParentFirebaseService.submitLeaveRequest(_schoolId, _sectionId, req);
      if (mounted) setState(() { _submitting = false; _success = true; });
    } catch (e) {
      if (mounted) setState(() { _submitting = false; _error = 'Failed to submit. Try again.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Submit Leave',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   17,
                fontWeight: FontWeight.w800)),
      ),
      body: _success
          ? _buildSuccess()
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Leave Date',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _DateOption(
                        label:    'Tomorrow',
                        date:     _tomorrow,
                        selected: _selectedDate == _tomorrow,
                        onTap: () => setState(() => _selectedDate = _tomorrow),
                      ),
                      const SizedBox(width: 12),
                      _DateOption(
                        label:    'Day After',
                        date:     _dayAfter,
                        selected: _selectedDate == _dayAfter,
                        onTap: () => setState(() => _selectedDate = _dayAfter),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text('Reason',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _reasonCtrl,
                    maxLines:   4,
                    style: TextStyle(color: cNavy(context), fontSize: 14),
                    decoration: InputDecoration(
                      hintText:  'e.g. Family function, medical appointment…',
                      hintStyle: TextStyle(color: cMuted(context), fontSize: 13),
                      filled:    true,
                      fillColor: cCard(context),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: cBorder(context))),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: cBorder(context))),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: const BorderSide(color: kTeal, width: 2)),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color:        kError.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kError.withValues(alpha: 0.3)),
                      ),
                      child: Text(_error!,
                          style: const TextStyle(color: kError, fontSize: 13)),
                    ),
                  ],
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      onPressed: _submitting ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kNavy,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                        elevation: 0,
                      ),
                      child: _submitting
                          ? const SizedBox(
                              width: 22, height: 22,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2.5))
                          : const Text('Submit Leave Request',
                              style: TextStyle(
                                  fontSize:   16,
                                  fontWeight: FontWeight.w700)),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildSuccess() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color:        const Color(0xFF16A34A).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Center(
                  child: Icon(Icons.check_circle_rounded,
                      color: Color(0xFF16A34A), size: 38)),
            ),
            const SizedBox(height: 16),
            Text('Leave Request Submitted!',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   18,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('The section head will review it.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
            const SizedBox(height: 28),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Back',
                  style: TextStyle(
                      color:      kNavy,
                      fontSize:   15,
                      fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      );
}

class _DateOption extends StatelessWidget {
  final String   label;
  final DateTime date;
  final bool     selected;
  final VoidCallback onTap;
  const _DateOption({
    required this.label,
    required this.date,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color:        selected ? kNavy : cCard(context),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: selected ? kNavy : cBorder(context), width: 1.5),
            boxShadow: selected
                ? [BoxShadow(
                    color:      kNavy.withValues(alpha: 0.18),
                    blurRadius: 12,
                    offset:     const Offset(0, 4))]
                : [],
          ),
          child: Column(
            children: [
              Text(label,
                  style: TextStyle(
                      color:      selected ? Colors.white : cNavy(context),
                      fontSize:   13,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('${date.day}/${date.month}/${date.year}',
                  style: TextStyle(
                      color: selected
                          ? Colors.white.withValues(alpha: 0.8)
                          : cMuted(context),
                      fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
