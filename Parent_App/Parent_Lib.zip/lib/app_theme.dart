// lib/app_theme.dart
import 'package:flutter/material.dart';

// ── Light Theme (Happy Hues Palette) ────────────────────────
const kBg    = Color(0xFFFEF6E4);
const kNavy  = Color(0xFF001858);
const kBlue  = Color(0xFF172C66);
const kPink  = Color.fromARGB(255, 130, 245, 178);
const kTeal  = Color(0xFF8BD3DD);
const kCard  = Color(0xFFFFFFFF);
const kMuted = Color(0xFF8896AA);
const kBorder= Color(0xFFE8EEF4);
const kError = Color(0xFFE53E6B);

// ── Dark Theme ───────────────────────────────────────────────
const kDarkBg    = Color(0xFF0D1117);
const kDarkCard  = Color(0xFF161B22);
const kDarkNavy  = Color(0xFFE6EDF3);
const kDarkBlue  = Color(0xFFC9D1D9);
const kDarkMuted = Color(0xFF8B949E);
const kDarkBorder= Color(0xFF30363D);
const kDarkPink  = Color(0xFF56D364);
const kDarkTeal  = Color(0xFF79C0FF);

final themeNotifier = ValueNotifier<ThemeMode>(ThemeMode.light);

bool isDark(BuildContext ctx) =>
    Theme.of(ctx).brightness == Brightness.dark;

Color cBg(BuildContext c)     => isDark(c) ? kDarkBg     : kBg;
Color cCard(BuildContext c)   => isDark(c) ? kDarkCard   : kCard;
Color cNavy(BuildContext c)   => isDark(c) ? kDarkNavy   : kNavy;
Color cBlue(BuildContext c)   => isDark(c) ? kDarkBlue   : kBlue;
Color cMuted(BuildContext c)  => isDark(c) ? kDarkMuted  : kMuted;
Color cBorder(BuildContext c) => isDark(c) ? kDarkBorder : kBorder;
Color cError(BuildContext c)  => kError;

final lightThemeData = ThemeData(
  brightness:              Brightness.light,
  scaffoldBackgroundColor: kBg,
  colorScheme: const ColorScheme.light(
    primary:   kNavy,
    secondary: kTeal,
    surface:   kBg,
  ),
  textTheme: const TextTheme(
    bodyMedium: TextStyle(color: kBlue),
  ),
  dividerColor: kBorder,
);

final darkThemeData = ThemeData(
  brightness:              Brightness.dark,
  scaffoldBackgroundColor: kDarkBg,
  colorScheme: const ColorScheme.dark(
    primary:   kDarkTeal,
    secondary: kDarkPink,
    surface:   kDarkCard,
  ),
  textTheme: const TextTheme(
    bodyMedium: TextStyle(color: kDarkBlue),
  ),
  dividerColor: kDarkBorder,
);
