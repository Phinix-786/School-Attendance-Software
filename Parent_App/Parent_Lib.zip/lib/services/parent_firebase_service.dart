// lib/services/parent_firebase_service.dart
import 'dart:async';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';

class ParentFirebaseService {
  static final _db = FirebaseFirestore.instance;

  // ── Auth ──────────────────────────────────────────────────────
  /// Searches all sections/classes for a student whose studentLoginId
  /// and studentPassword match. Returns (schoolId, sectionId, student)
  static Future<Map<String, dynamic>?> login(
      String schoolId, String loginId, String password) async {
    final sectionsSnap =
        await _db.collection('schools/$schoolId/sections').get();

    for (final section in sectionsSnap.docs) {
      final classesSnap = await _db
          .collection('schools/$schoolId/sections/${section.id}/classes')
          .get();

      for (final cls in classesSnap.docs) {
        // Query by parentLoginId first; fall back to studentLoginId for
        // accounts created before the split-credentials update.
        QuerySnapshot<Map<String, dynamic>> stuSnap;
        stuSnap = await _db
            .collection(
                'schools/$schoolId/sections/${section.id}/classes/${cls.id}/students')
            .where('parentLoginId', isEqualTo: loginId)
            .limit(1)
            .get();
        if (stuSnap.docs.isEmpty) {
          stuSnap = await _db
              .collection(
                  'schools/$schoolId/sections/${section.id}/classes/${cls.id}/students')
              .where('studentLoginId', isEqualTo: loginId)
              .limit(1)
              .get();
        }

        if (stuSnap.docs.isNotEmpty) {
          final data = stuSnap.docs.first.data();
          final stu  = Student.fromMap({
            ...data,
            'sectionId': section.id,
          });
          // Check parentPassword; fall back to studentPassword for legacy accounts
          final storedPass = stu.parentPassword.isNotEmpty
              ? stu.parentPassword
              : stu.studentPassword;
          if (storedPass != password) return null;
          return {
            'student':   stu,
            'sectionId': section.id,
            'classId':   cls.id,
          };
        }
      }
    }
    return null;
  }

  // ── Multi-child session ───────────────────────────────────────
  //
  // Children are stored as a JSON list under 'p_children'.
  // Active child index stored under 'p_active_child'.
  // Each entry: { schoolId, sectionId, classId, studentId,
  //               studentName, loginId }

  static const _kChildren    = 'p_children';
  static const _kActiveChild = 'p_active_child';

  static Future<void> saveSession({
    required String schoolId,
    required String sectionId,
    required String classId,
    required String studentId,
    required String studentName,
    required String loginId,
  }) async {
    final prefs    = await SharedPreferences.getInstance();
    final children = await getAllChildren();

    final entry = {
      'schoolId':    schoolId,
      'sectionId':   sectionId,
      'classId':     classId,
      'studentId':   studentId,
      'studentName': studentName,
      'loginId':     loginId,
    };

    // Replace existing entry for same studentId, or append
    final idx = children.indexWhere((c) => c['studentId'] == studentId);
    if (idx >= 0) {
      children[idx] = entry;
    } else {
      children.add(entry);
    }

    await prefs.setString(_kChildren, jsonEncode(children));
    // Set the active child to the one we just saved
    final activeIdx =
        children.indexWhere((c) => c['studentId'] == studentId);
    await prefs.setInt(_kActiveChild, activeIdx >= 0 ? activeIdx : 0);

    // Legacy single-session keys for backward compat
    await prefs.setString('p_schoolId',    schoolId);
    await prefs.setString('p_sectionId',   sectionId);
    await prefs.setString('p_classId',     classId);
    await prefs.setString('p_studentId',   studentId);
    await prefs.setString('p_studentName', studentName);
    await prefs.setString('p_loginId',     loginId);
  }

  static Future<Map<String, String>?> getSavedSession() async {
    final prefs    = await SharedPreferences.getInstance();
    final children = await getAllChildren();
    if (children.isEmpty) return null;

    final idx     = (prefs.getInt(_kActiveChild) ?? 0)
        .clamp(0, children.length - 1);
    final child   = children[idx];
    if ((child['schoolId']  ?? '').isEmpty) return null;
    if ((child['classId']   ?? '').isEmpty) return null;
    if ((child['studentId'] ?? '').isEmpty) return null;
    return Map<String, String>.from(child);
  }

  static Future<List<Map<String, String>>> getAllChildren() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getString(_kChildren);
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => Map<String, String>.from(e as Map))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<int> getActiveChildIndex() async {
    final prefs    = await SharedPreferences.getInstance();
    final children = await getAllChildren();
    if (children.isEmpty) return 0;
    return (prefs.getInt(_kActiveChild) ?? 0)
        .clamp(0, children.length - 1);
  }

  static Future<void> setActiveChild(int index) async {
    final prefs    = await SharedPreferences.getInstance();
    final children = await getAllChildren();
    if (index < 0 || index >= children.length) return;
    final child    = children[index];
    await prefs.setInt(_kActiveChild, index);
    // Update legacy keys
    await prefs.setString('p_schoolId',    child['schoolId']    ?? '');
    await prefs.setString('p_sectionId',   child['sectionId']   ?? '');
    await prefs.setString('p_classId',     child['classId']     ?? '');
    await prefs.setString('p_studentId',   child['studentId']   ?? '');
    await prefs.setString('p_studentName', child['studentName'] ?? '');
    await prefs.setString('p_loginId',     child['loginId']     ?? '');
  }

  static Future<void> removeChild(int index) async {
    final prefs    = await SharedPreferences.getInstance();
    final children = await getAllChildren();
    if (index < 0 || index >= children.length) return;
    children.removeAt(index);
    await prefs.setString(_kChildren, jsonEncode(children));
    if (children.isEmpty) {
      await clearSession();
    } else {
      await setActiveChild(0);
    }
  }

  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kChildren);
    await prefs.remove(_kActiveChild);
    await prefs.remove('p_schoolId');
    await prefs.remove('p_sectionId');
    await prefs.remove('p_classId');
    await prefs.remove('p_studentId');
    await prefs.remove('p_studentName');
    await prefs.remove('p_loginId');
  }

  // ── Homework ──────────────────────────────────────────────────
  static Future<List<Homework>> getHomeworks(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/homeworks')
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => Homework.fromMap(d.data())).toList();
  }

  // ── Tests ─────────────────────────────────────────────────────
  static Future<List<SchoolTest>> getTests(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/tests')
        .orderBy('testDate', descending: true)
        .get();
    return snap.docs.map((d) => SchoolTest.fromMap(d.data())).toList();
  }

  // ── Results ───────────────────────────────────────────────────
  static Future<TestResult?> getMyResult(
      String schoolId, String sectionId, String classId,
      String testId, String studentId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/tests/$testId/results')
        .where('studentId', isEqualTo: studentId)
        .limit(1)
        .get();
    if (snap.docs.isEmpty) return null;
    return TestResult.fromMap(snap.docs.first.data());
  }

  // ── Teachers for class ────────────────────────────────────────
  static Future<List<Teacher>> getTeachersForClass(
      String schoolId, String sectionId, String classId) async {
    final snap = await _db
        .collection(
            'schools/$schoolId/sections/$sectionId/classes/$classId/teachers')
        .get();
    return snap.docs.map((d) => Teacher.fromMap(d.data())).toList();
  }

  // ── Teacher-Parent Chat ───────────────────────────────────────
  static String _chatPath(String schoolId, String sectionId) =>
      'schools/$schoolId/sections/$sectionId/teacher_parent_chats';

  static Future<String> getOrCreateChatId(
      String schoolId, String sectionId, String teacherId,
      String teacherName, String teacherSubject,
      String studentId, String studentName, String classId) async {
    final chatId = '${teacherId}_$studentId';
    final ref = _db.collection(_chatPath(schoolId, sectionId)).doc(chatId);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'id': chatId, 'teacherId': teacherId, 'teacherName': teacherName,
        'teacherSubject': teacherSubject, 'parentStudentId': studentId,
        'parentStudentName': studentName, 'classId': classId,
        'lastMessage': '', 'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    return chatId;
  }

  static Stream<List<ChatMessage>> chatMessagesStream(
      String schoolId, String sectionId, String chatId) {
    return _db
        .collection('${_chatPath(schoolId, sectionId)}/$chatId/messages')
        .orderBy('timestamp')
        .snapshots()
        .map((s) => s.docs.map((d) => ChatMessage.fromMap(d.data())).toList());
  }

  static Future<void> sendParentMessage(
      String schoolId, String sectionId, String chatId,
      ChatMessage msg) async {
    final chatRef = _db.collection(_chatPath(schoolId, sectionId)).doc(chatId);
    await chatRef
        .collection('messages')
        .doc(msg.id)
        .set(msg.toMap());
    await chatRef.update({
      'lastMessage': msg.text,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ── Leave request ─────────────────────────────────────────────
  static Future<void> submitLeaveRequest(
      String schoolId, String sectionId, LeaveRequest req) async {
    await _db
        .collection('schools/$schoolId/sections/$sectionId/leaves')
        .doc(req.id)
        .set(req.toMap());
  }

  static Future<List<LeaveRequest>> getMyLeaveRequests(
      String schoolId, String sectionId, String studentId) async {
    final snap = await _db
        .collection('schools/$schoolId/sections/$sectionId/leaves')
        .where('studentId', isEqualTo: studentId)
        .orderBy('submittedAt', descending: true)
        .get();
    return snap.docs.map((d) => LeaveRequest.fromMap(d.data())).toList();
  }

  // ── Notices ───────────────────────────────────────────────────
  static Future<List<SchoolNotice>> getNotices(
      String schoolId, String sectionId) async {
    final snap = await _db
        .collection('schools/$schoolId/sections/$sectionId/notices')
        .where('targetAudience', whereIn: ['parents', 'all'])
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => SchoolNotice.fromMap(d.data())).toList();
  }
}
