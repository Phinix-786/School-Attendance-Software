// lib/models/models.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class Homework {
  final String  id;
  final String  schoolId;
  final String  classId;
  final String  subject;
  final String  topic;
  final String  instructions;
  final String  pageNumbers;
  final List<String> imageUrls;
  final DateTime createdAt;

  Homework({
    required this.id, required this.schoolId, required this.classId,
    required this.subject, required this.topic, required this.instructions,
    required this.pageNumbers, required this.imageUrls, required this.createdAt,
  });

  factory Homework.fromMap(Map<String, dynamic> m) => Homework(
        id:           m['id']           ?? '',
        schoolId:     m['schoolId']     ?? '',
        classId:      m['classId']      ?? '',
        subject:      m['subject']      ?? '',
        topic:        m['topic']        ?? '',
        instructions: m['instructions'] ?? '',
        pageNumbers:  m['pageNumbers']  ?? '',
        imageUrls:    List<String>.from(m['imageUrls'] ?? []),
        createdAt:    (m['createdAt'] as Timestamp).toDate(),
      );
}

class SchoolTest {
  final String  id;
  final String  schoolId;
  final String  classId;
  final String  subject;
  final String  topic;
  final String  instructions;
  final String  pageNumbers;
  final List<String> imageUrls;
  final DateTime createdAt;
  final DateTime testDate;

  SchoolTest({
    required this.id, required this.schoolId, required this.classId,
    required this.subject, required this.topic, required this.instructions,
    required this.pageNumbers, required this.imageUrls,
    required this.createdAt, required this.testDate,
  });

  factory SchoolTest.fromMap(Map<String, dynamic> m) => SchoolTest(
        id:           m['id']           ?? '',
        schoolId:     m['schoolId']     ?? '',
        classId:      m['classId']      ?? '',
        subject:      m['subject']      ?? '',
        topic:        m['topic']        ?? '',
        instructions: m['instructions'] ?? '',
        pageNumbers:  m['pageNumbers']  ?? '',
        imageUrls:    List<String>.from(m['imageUrls'] ?? []),
        createdAt:    (m['createdAt'] as Timestamp).toDate(),
        testDate:     (m['testDate']  as Timestamp).toDate(),
      );
}

class TestResult {
  final String id;
  final String testId;
  final String studentId;
  final String studentName;
  final int    marksObtained;
  final int    marksTotal;
  final String remarks;
  final DateTime submittedAt;
  final bool   wasAbsent;

  TestResult({
    required this.id, required this.testId, required this.studentId,
    required this.studentName, required this.marksObtained,
    required this.marksTotal, required this.remarks, required this.submittedAt,
    this.wasAbsent = false,
  });

  double get percentage =>
      marksTotal > 0 ? (marksObtained / marksTotal) * 100 : 0;

  factory TestResult.fromMap(Map<String, dynamic> m) => TestResult(
        id:            m['id']            ?? '',
        testId:        m['testId']        ?? '',
        studentId:     m['studentId']     ?? '',
        studentName:   m['studentName']   ?? '',
        marksObtained: m['marksObtained'] ?? 0,
        marksTotal:    m['marksTotal']    ?? 0,
        remarks:       m['remarks']       ?? '',
        submittedAt:   (m['submittedAt'] as Timestamp).toDate(),
        wasAbsent:     m['wasAbsent']     ?? false,
      );
}

class Teacher {
  final String id;
  final String name;
  final Map<String, String> classSubjects;

  Teacher({required this.id, required this.name, required this.classSubjects});

  factory Teacher.fromMap(Map<String, dynamic> m) => Teacher(
        id:            m['id']   ?? '',
        name:          m['name'] ?? '',
        classSubjects: Map<String, String>.from(m['classSubjects'] ?? {}),
      );

  String subjectFor(String classId) => classSubjects[classId] ?? '';
}

class ChatMessage {
  final String   id;
  final String   senderId;
  final String   senderType; // 'teacher' | 'parent'
  final String   senderName;
  final String   text;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.senderId,
    required this.senderType,
    required this.senderName,
    required this.text,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'senderId': senderId, 'senderType': senderType,
        'senderName': senderName, 'text': text,
        'timestamp': Timestamp.fromDate(timestamp),
      };

  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
        id:         m['id']         ?? '',
        senderId:   m['senderId']   ?? '',
        senderType: m['senderType'] ?? '',
        senderName: m['senderName'] ?? '',
        text:       m['text']       ?? '',
        timestamp: m['timestamp'] != null
            ? (m['timestamp'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class LeaveRequest {
  final String   id;
  final String   studentId;
  final String   studentName;
  final String   classId;
  final String   sectionId;
  final DateTime requestedDate;
  final String   reason;
  final String   status; // 'pending' | 'approved' | 'rejected'
  final String   submittedBy; // 'student' | 'parent'
  final DateTime submittedAt;
  final String   remarks;

  LeaveRequest({
    required this.id,
    required this.studentId,
    required this.studentName,
    required this.classId,
    required this.sectionId,
    required this.requestedDate,
    required this.reason,
    required this.status,
    required this.submittedBy,
    required this.submittedAt,
    this.remarks = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'studentId': studentId, 'studentName': studentName,
        'classId': classId, 'sectionId': sectionId,
        'requestedDate': Timestamp.fromDate(requestedDate),
        'reason': reason, 'status': status, 'submittedBy': submittedBy,
        'submittedAt': Timestamp.fromDate(submittedAt),
        'remarks': remarks,
      };

  factory LeaveRequest.fromMap(Map<String, dynamic> m) => LeaveRequest(
        id:            m['id']          ?? '',
        studentId:     m['studentId']   ?? '',
        studentName:   m['studentName'] ?? '',
        classId:       m['classId']     ?? '',
        sectionId:     m['sectionId']   ?? '',
        requestedDate: m['requestedDate'] != null
            ? (m['requestedDate'] as Timestamp).toDate()
            : DateTime.now(),
        reason:        m['reason']      ?? '',
        status:        m['status']      ?? 'pending',
        submittedBy:   m['submittedBy'] ?? 'parent',
        submittedAt:   m['submittedAt'] != null
            ? (m['submittedAt'] as Timestamp).toDate()
            : DateTime.now(),
        remarks:       m['remarks']     ?? '',
      );
}


class SchoolNotice {
  final String   id;
  final String   schoolId;
  final String   sectionId;
  final String   title;
  final String   body;
  final String   targetAudience;
  final String   createdBy;
  final DateTime createdAt;

  SchoolNotice({
    required this.id,
    required this.schoolId,
    required this.sectionId,
    required this.title,
    required this.body,
    required this.targetAudience,
    required this.createdBy,
    required this.createdAt,
  });

  factory SchoolNotice.fromMap(Map<String, dynamic> m) => SchoolNotice(
        id:             m['id']             ?? '',
        schoolId:       m['schoolId']       ?? '',
        sectionId:      m['sectionId']      ?? '',
        title:          m['title']          ?? '',
        body:           m['body']           ?? '',
        targetAudience: m['targetAudience'] ?? 'all',
        createdBy:      m['createdBy']      ?? '',
        createdAt: m['createdAt'] != null
            ? (m['createdAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class Student {
  final String id;
  final String schoolId;
  final String classId;
  final String sectionId;
  final String name;
  final String rollNo;
  final String studentLoginId;
  final String studentPassword;
  final String parentLoginId;
  final String parentPassword;

  Student({
    required this.id, required this.schoolId, required this.classId,
    required this.sectionId, required this.name, required this.rollNo,
    required this.studentLoginId, required this.studentPassword,
    this.parentLoginId  = '',
    this.parentPassword = '',
  });

  factory Student.fromMap(Map<String, dynamic> m) => Student(
        id:              m['id']              ?? '',
        schoolId:        m['schoolId']        ?? '',
        classId:         m['classId']         ?? '',
        sectionId:       m['sectionId']       ?? '',
        name:            m['name']            ?? '',
        rollNo:          m['rollNo']          ?? '',
        studentLoginId:  m['studentLoginId']  ?? '',
        studentPassword: m['studentPassword'] ?? '',
        parentLoginId:   m['parentLoginId']   ?? '',
        parentPassword:  m['parentPassword']  ?? '',
      );
}
