// lib/screens/template_settings_screen.dart
//
// Lets the admin view and edit the SMS templates for Absent and Late messages.
// Templates are stored in Firestore at:
//   schools/{schoolId}/config/templates
// and sync in real-time — changes made in Firebase Console or by another
// device appear here instantly, and saves here are reflected immediately
// everywhere.
//
// Supported placeholders:
//   {schoolName}  – filled from the school config
//   {studentName} – student's full name
//   {rollNo}      – roll number / CID
//   {class}       – full class name, e.g. "10th A"
//   {section}     – section letter only, e.g. "A"
//   {date}        – date the attendance was recorded
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/firebase_request_service.dart';
import 'login_screen.dart';

// ── Colours ───────────────────────────────────────────────────────────────────
const _kBg     = Color(0xFFFEF6E4);
const _kNavy   = Color(0xFF001858);
const _kCard   = Color(0xFFFFFFFF);
const _kMuted  = Color(0xFF8896AA);
const _kBorder = Color(0xFFE8EEF4);
const _kTeal   = Color(0xFF0D9488);
const _kGreen  = Color(0xFF16A34A);
const _kRed    = Color(0xFFE53E6B);
const _kAmber  = Color(0xFFD97706);

// ── Default templates ─────────────────────────────────────────────────────────
const kDefaultAbsentTemplate =
    '{schoolName}\n'
    '\n'
    'Dear Parent/Guardian,\n'
    '\n'
    'Your child, {studentName} (Roll No: {rollNo}), of Class {class} – Section {section}, '
    'has been marked ABSENT for today, {date}.\n'
    '\n'
    'Regular attendance is essential for your child\'s academic progress '
    'and overall development. Consistent absences can significantly '
    'impact their learning and performance.\n'
    '\n'
    'If you have already informed the school about this absence or if '
    'this notification has reached you in error, please disregard '
    'this message.\n'
    '\n'
    'This is an automated notification from {schoolName}.\n'
    '\n'
    'Thank You';

const kDefaultLateTemplate =
    '{schoolName}\n'
    '\n'
    'Dear Parent/Guardian,\n'
    '\n'
    'Your child, {studentName} (Roll No: {rollNo}), of Class {class} – Section {section}, '
    'arrived {lateMinutes} minutes late today ({date}).\n'
    '\n'
    'If you have already provided a reason for this delay or if this '
    'notification has reached you in error, please disregard this message.\n'
    '\n'
    'This is an automated notification from {schoolName}.\n'
    '\n'
    'Thank You';

// ─────────────────────────────────────────────────────────────────────────────
// Public helpers — called from message_request.dart / background service
// Now reads from Firestore with SharedPreferences as offline cache fallback.
// ─────────────────────────────────────────────────────────────────────────────

/// Loads the absent template from Firestore, falling back to cached/default.
Future<String> loadAbsentTemplate() async {
  try {
    final prefs    = await SharedPreferences.getInstance();
    final schoolId = prefs.getString('schoolId') ?? '';
    if (schoolId.isEmpty) return kDefaultAbsentTemplate;

    final data = await FirebaseRequestService.fetchTemplates(schoolId);
    final t    = data?['absentTemplate'] as String?;
    if (t != null && t.isNotEmpty) {
      // Cache locally so background isolate can use it offline.
      await prefs.setString('sms_template_absent', t);
      return t;
    }
  } catch (_) { /* fall through to cache */ }

  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('sms_template_absent') ?? kDefaultAbsentTemplate;
}

/// Loads the late template from Firestore, falling back to cached/default.
Future<String> loadLateTemplate() async {
  try {
    final prefs    = await SharedPreferences.getInstance();
    final schoolId = prefs.getString('schoolId') ?? '';
    if (schoolId.isEmpty) return kDefaultLateTemplate;

    final data = await FirebaseRequestService.fetchTemplates(schoolId);
    final t    = data?['lateTemplate'] as String?;
    if (t != null && t.isNotEmpty) {
      await prefs.setString('sms_template_late', t);
      return t;
    }
  } catch (_) { /* fall through to cache */ }

  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('sms_template_late') ?? kDefaultLateTemplate;
}

/// Fills all placeholders in a template string.
///
/// [lateMinutes] is optional: pass the actual integer for late students,
/// or null (the default) for absent students — the placeholder is then
/// replaced with an empty string so it doesn't appear in absent SMSes.
String fillTemplate(
  String template, {
  required String schoolName,
  required String studentName,
  required String rollNo,
  required String className,
  required String section,
  required String date,
  int? lateMinutes,
}) {
  return template
      .replaceAll('{schoolName}',  schoolName)
      .replaceAll('{studentName}', studentName)
      .replaceAll('{rollNo}',      rollNo)
      .replaceAll('{class}',       className)
      .replaceAll('{section}',     section)
      .replaceAll('{date}',        date)
      // Replace with the number of minutes, or '' if not applicable.
      .replaceAll('{lateMinutes}', lateMinutes != null ? '$lateMinutes' : '');
}

// ─────────────────────────────────────────────────────────────────────────────
// TemplateSettingsScreen
// ─────────────────────────────────────────────────────────────────────────────
class TemplateSettingsScreen extends StatefulWidget {
  const TemplateSettingsScreen({super.key});

  @override
  State<TemplateSettingsScreen> createState() =>
      _TemplateSettingsScreenState();
}

class _TemplateSettingsScreenState extends State<TemplateSettingsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  late final TextEditingController _absentCtrl;
  late final TextEditingController _lateCtrl;

  bool _loading = true;
  bool _saving  = false;
  bool _saved   = false;

  // Tracks whether the text fields are out of sync with what's in Firebase
  // (i.e. the user has typed something but not yet saved).
  bool _dirty = false;

  // Which tab is previewing
  bool _absentPreview = false;
  bool _latePreview   = false;

  String  _schoolId = '';
  StreamSubscription<Map<String, dynamic>?>? _templateSub;

  @override
  void initState() {
    super.initState();
    _tabs       = TabController(length: 2, vsync: this);
    _absentCtrl = TextEditingController();
    _lateCtrl   = TextEditingController();
    _absentCtrl.addListener(_onEdited);
    _lateCtrl.addListener(_onEdited);
    _init();
  }

  Future<void> _init() async {
    final prefs = await SharedPreferences.getInstance();
    _schoolId   = prefs.getString('schoolId') ?? '';
    if (_schoolId.isEmpty) {
      // No school — load defaults and stop.
      _absentCtrl.text = kDefaultAbsentTemplate;
      _lateCtrl.text   = kDefaultLateTemplate;
      if (mounted) setState(() => _loading = false);
      return;
    }

    // Subscribe to the Firestore document for real-time updates.
    _templateSub = FirebaseRequestService
        .templatesStream(_schoolId)
        .listen(_onFirebaseUpdate, onError: (_) {
      // If stream errors, fall back to prefs cache.
      if (mounted && _loading) {
        _absentCtrl.text =
            prefs.getString('sms_template_absent') ?? kDefaultAbsentTemplate;
        _lateCtrl.text =
            prefs.getString('sms_template_late') ?? kDefaultLateTemplate;
        setState(() => _loading = false);
      }
    });
  }

  /// Called every time Firestore pushes a new snapshot.
  void _onFirebaseUpdate(Map<String, dynamic>? data) async {
    if (!mounted) return;

    final absent = (data?['absentTemplate'] as String?)?.isNotEmpty == true
        ? data!['absentTemplate'] as String
        : kDefaultAbsentTemplate;
    final late_ = (data?['lateTemplate'] as String?)?.isNotEmpty == true
        ? data!['lateTemplate'] as String
        : kDefaultLateTemplate;

    // Cache locally for offline / background service use.
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('sms_template_absent', absent);
    await prefs.setString('sms_template_late',   late_);

    // Only overwrite the text fields when the user hasn't made unsaved edits.
    // This prevents the cursor jumping while someone is actively typing.
    if (!_dirty) {
      _absentCtrl.removeListener(_onEdited);
      _lateCtrl.removeListener(_onEdited);
      _absentCtrl.text = absent;
      _lateCtrl.text   = late_;
      _absentCtrl.addListener(_onEdited);
      _lateCtrl.addListener(_onEdited);
    }

    if (_loading) setState(() => _loading = false);
  }

  void _onEdited() {
    // Mark dirty as soon as the user types anything.
    if (!_dirty && !_loading) setState(() => _dirty = true);
  }

  Future<void> _signOut() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.logout, color: _kRed, size: 22),
            SizedBox(width: 10),
            Text('Sign Out',
                style: TextStyle(
                    color: _kNavy, fontWeight: FontWeight.w700, fontSize: 17)),
          ],
        ),
        content: const Text(
          'Are you sure you want to sign out?\nYou will need to log in again to access the app.',
          style: TextStyle(color: _kMuted, fontSize: 13.5, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel',
                style: TextStyle(
                    color: _kMuted, fontWeight: FontWeight.w600)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _kRed,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sign Out',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    // Clear all stored credentials and setup flags
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Future<void> _save() async {
    if (_schoolId.isEmpty) return;
    setState(() => _saving = true);

    try {
      await FirebaseRequestService.saveTemplates(
        _schoolId,
        absentTemplate: _absentCtrl.text,
        lateTemplate:   _lateCtrl.text,
      );
      // Also update local cache immediately.
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('sms_template_absent', _absentCtrl.text);
      await prefs.setString('sms_template_late',   _lateCtrl.text);

      if (!mounted) return;
      setState(() { _saving = false; _saved = true; _dirty = false; });
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) setState(() => _saved = false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save: $e'),
          backgroundColor: _kRed,
        ),
      );
    }
  }

  void _resetAbsent() {
    _absentCtrl.text = kDefaultAbsentTemplate;
    setState(() => _dirty = true);
  }

  void _resetLate() {
    _lateCtrl.text = kDefaultLateTemplate;
    setState(() => _dirty = true);
  }

  @override
  void dispose() {
    _templateSub?.cancel();
    _tabs.dispose();
    _absentCtrl.dispose();
    _lateCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kNavy,
        foregroundColor: Colors.white,
        title: const Text('Message Templates',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        bottom: TabBar(
          controller: _tabs,
          labelColor:           Colors.white,
          unselectedLabelColor: Colors.white54,
          indicatorColor:       _kTeal,
          indicatorWeight:      3,
          tabs: const [
            Tab(icon: Icon(Icons.cancel_outlined,  size: 18), text: 'Absent'),
            Tab(icon: Icon(Icons.schedule_outlined, size: 18), text: 'Late'),
          ],
        ),
        actions: [
          // Sign-out button
          IconButton(
            tooltip: 'Sign Out',
            icon: const Icon(Icons.logout, size: 20),
            onPressed: _signOut,
          ),
          // "Synced" badge when saved and Firebase stream is live
          if (_saved)
            const Padding(
              padding: EdgeInsets.only(right: 8),
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.cloud_done_outlined,
                        color: Color(0xFF4ADE80), size: 16),
                    SizedBox(width: 4),
                    Text('Saved',
                        style: TextStyle(
                            color: Color(0xFF4ADE80),
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          // Live indicator (not dirty = in sync with Firebase)
          if (!_loading && !_dirty && !_saved)
            const Padding(
              padding: EdgeInsets.only(right: 12),
              child: Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.cloud_outlined,
                        color: Colors.white54, size: 15),
                    SizedBox(width: 4),
                    Text('Live',
                        style: TextStyle(
                            color: Colors.white54, fontSize: 12)),
                  ],
                ),
              ),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _kNavy))
          : Column(
              children: [
                // ── Firebase sync notice ────────────────────────────────
                _SyncBanner(dirty: _dirty),

                // ── Placeholder legend ──────────────────────────────────
                const _PlaceholderLegend(),

                // ── Tab views ───────────────────────────────────────────
                Expanded(
                  child: TabBarView(
                    controller: _tabs,
                    children: [
                      _TemplateTab(
                        controller:     _absentCtrl,
                        color:          _kRed,
                        label:          'Absent Message',
                        preview:        _absentPreview,
                        onTogglePreview: () =>
                            setState(() => _absentPreview = !_absentPreview),
                        onReset: _resetAbsent,
                      ),
                      _TemplateTab(
                        controller:     _lateCtrl,
                        color:          _kAmber,
                        label:          'Late Message',
                        preview:        _latePreview,
                        onTogglePreview: () =>
                            setState(() => _latePreview = !_latePreview),
                        onReset: _resetLate,
                      ),
                    ],
                  ),
                ),

                // ── Save button ─────────────────────────────────────────
                _SaveBar(saving: _saving, dirty: _dirty, onSave: _save),
              ],
            ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _SyncBanner  — shown when the user has unsaved local edits
// ─────────────────────────────────────────────────────────────────────────────
class _SyncBanner extends StatelessWidget {
  final bool dirty;
  const _SyncBanner({required this.dirty});

  @override
  Widget build(BuildContext context) {
    if (!dirty) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      color: _kAmber.withOpacity(0.12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          const Icon(Icons.edit_outlined, color: _kAmber, size: 14),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'You have unsaved changes — tap Save to sync to Firebase.',
              style: TextStyle(color: _kAmber, fontSize: 12,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _PlaceholderLegend
// ─────────────────────────────────────────────────────────────────────────────
class _PlaceholderLegend extends StatelessWidget {
  final _chips = const [
    ('{schoolName}',  'School name'),
    ('{studentName}', 'Student name'),
    ('{rollNo}',      'Roll No / CID'),
    ('{class}',       'Full class, e.g. 10th A'),
    ('{section}',     'Section letter, e.g. A'),
    ('{date}',        'Attendance date'),
  ];

  const _PlaceholderLegend();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: _kCard,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Available Placeholders',
            style: TextStyle(
              color: _kNavy,
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.6,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: _chips.map((c) => _Chip(tag: c.$1, tip: c.$2)).toList(),
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String tag;
  final String tip;
  const _Chip({required this.tag, required this.tip});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tip,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: _kTeal.withOpacity(0.10),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _kTeal.withOpacity(0.30)),
        ),
        child: Text(
          tag,
          style: const TextStyle(
            color: _kTeal,
            fontSize: 11.5,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _TemplateTab
// ─────────────────────────────────────────────────────────────────────────────
class _TemplateTab extends StatelessWidget {
  final TextEditingController controller;
  final Color        color;
  final String       label;
  final bool         preview;
  final VoidCallback onTogglePreview;
  final VoidCallback onReset;

  const _TemplateTab({
    required this.controller,
    required this.color,
    required this.label,
    required this.preview,
    required this.onTogglePreview,
    required this.onReset,
  });

  String get _previewText => fillTemplate(
        controller.text,
        schoolName:  'Beaconhouse School',
        studentName: 'Ahmed Raza',
        rollNo:      'C-1042',
        className:   '10th A',
        section:     'A',
        date:        '5 May 2026',
        // Show a sample value in previews for the Late template.
        lateMinutes: label.toLowerCase().contains('late') ? 10 : null,
      );

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // ── Toolbar row ──────────────────────────────────────────────────
        Row(
          children: [
            Container(
              width: 8, height: 8,
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            Text(
              label,
              style: const TextStyle(
                  color: _kNavy, fontWeight: FontWeight.w700, fontSize: 13),
            ),
            const Spacer(),
            // Preview toggle
            GestureDetector(
              onTap: onTogglePreview,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color:        preview ? _kNavy.withOpacity(0.08) : Colors.transparent,
                  border:       Border.all(color: _kBorder),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      preview ? Icons.edit_outlined : Icons.visibility_outlined,
                      size: 14, color: _kNavy,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      preview ? 'Edit' : 'Preview',
                      style: const TextStyle(
                          color: _kNavy, fontSize: 12,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Reset button
            GestureDetector(
              onTap: onReset,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  border:       Border.all(color: _kBorder),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.restore, size: 14, color: _kMuted),
                    SizedBox(width: 4),
                    Text('Reset',
                        style: TextStyle(
                            color: _kMuted, fontSize: 12,
                            fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ── Editor or Preview ────────────────────────────────────────────
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: preview
              ? _PreviewBox(
                  key: const ValueKey('preview'),
                  text: _previewText,
                  color: color)
              : _EditorBox(
                  key: const ValueKey('editor'),
                  controller: controller),
        ),

        const SizedBox(height: 12),

        // ── Character count ──────────────────────────────────────────────
        Align(
          alignment: Alignment.centerRight,
          child: ValueListenableBuilder(
            valueListenable: controller,
            builder: (_, __, ___) {
              final len  = controller.text.length;
              final msgs = (len / 160).ceil();
              return Text(
                '$len chars · $msgs SMS segment${msgs == 1 ? '' : 's'} (approx)',
                style: const TextStyle(color: _kMuted, fontSize: 11.5),
              );
            },
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _EditorBox
// ─────────────────────────────────────────────────────────────────────────────
class _EditorBox extends StatelessWidget {
  final TextEditingController controller;
  const _EditorBox({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kBorder, width: 1.5),
      ),
      child: TextField(
        controller: controller,
        maxLines:   null,
        minLines:   16,
        style: const TextStyle(
          color:      _kNavy,
          fontSize:   13.5,
          height:     1.55,
          fontFamily: 'monospace',
        ),
        decoration: const InputDecoration(
          border:         InputBorder.none,
          contentPadding: EdgeInsets.all(16),
          hintText:       'Type your template here…',
          hintStyle:      TextStyle(color: _kMuted),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _PreviewBox
// ─────────────────────────────────────────────────────────────────────────────
class _PreviewBox extends StatelessWidget {
  final String text;
  final Color  color;
  const _PreviewBox({super.key, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: color.withOpacity(0.07),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            border: Border.all(color: color.withOpacity(0.25)),
          ),
          child: Row(
            children: [
              Icon(Icons.info_outline, color: color, size: 14),
              const SizedBox(width: 6),
              Text(
                'Preview with sample data — not the actual message',
                style: TextStyle(
                    color: color, fontSize: 11.5,
                    fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _kCard,
            borderRadius:
                const BorderRadius.vertical(bottom: Radius.circular(12)),
            border: Border(
              left:   BorderSide(color: color.withOpacity(0.25)),
              right:  BorderSide(color: color.withOpacity(0.25)),
              bottom: BorderSide(color: color.withOpacity(0.25)),
            ),
          ),
          child: Text(
            text,
            style: const TextStyle(
                color: _kNavy, fontSize: 13.5, height: 1.6),
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _SaveBar
// ─────────────────────────────────────────────────────────────────────────────
class _SaveBar extends StatelessWidget {
  final bool         saving;
  final bool         dirty;
  final VoidCallback onSave;
  const _SaveBar({required this.saving, required this.dirty, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(
          16, 12, 16, 12 + MediaQuery.of(context).padding.bottom),
      decoration: const BoxDecoration(
        color:  _kCard,
        border: Border(top: BorderSide(color: _kBorder)),
      ),
      child: SizedBox(
        width:  double.infinity,
        height: 50,
        child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: dirty ? _kGreen : _kMuted,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
          icon: saving
              ? const SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2.5))
              : const Icon(Icons.cloud_upload_outlined, size: 20),
          label: Text(
            saving ? 'Saving to Firebase…' : 'Save to Firebase',
            style: const TextStyle(
                fontSize: 15, fontWeight: FontWeight.w700),
          ),
          onPressed: (saving || !dirty) ? null : onSave,
        ),
      ),
    );
  }
}