// lib/screens/login_screen.dart
//
// First screen on first launch.
// On success → SimSelectionScreen (which then goes to HomeScreen).
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import 'sim_selection_screen.dart';   // ← NEW: go to SIM picker after login

// ─────────────────────────────────────────────────────────────────────────────
// RateLimiter — all state stored locally via SharedPreferences
// Rules:
//   • Max  5 attempts per 15 minutes
//   • Max 10 attempts per  1 hour
//   • Max 20 attempts per 24 hours
//   • After 30 total lifetime failed attempts → permanent ban
// ─────────────────────────────────────────────────────────────────────────────
class _RateLimiter {
  static const _kAttemptTimestamps = 'rl_attempt_timestamps';
  static const _kTotalFailed       = 'rl_total_failed';
  static const _kBanned            = 'rl_banned';

  static Future<String?> checkAndRecord(SharedPreferences prefs) async {
    if (prefs.getBool(_kBanned) ?? false) {
      return 'Your account has been permanently banned due to too many failed '
          'login attempts. Please contact support.';
    }

    final now        = DateTime.now().millisecondsSinceEpoch;
    final rawList    = prefs.getStringList(_kAttemptTimestamps) ?? [];
    final timestamps = rawList.map(int.parse).toList();

    final in15Min = timestamps
        .where((t) => now - t <= const Duration(minutes: 15).inMilliseconds)
        .length;
    final in1Hr   = timestamps
        .where((t) => now - t <= const Duration(hours: 1).inMilliseconds)
        .length;
    final in24Hr  = timestamps
        .where((t) => now - t <= const Duration(hours: 24).inMilliseconds)
        .length;

    if (in15Min >= 5)  return 'Too many attempts. You can try again in 15 minutes.';
    if (in1Hr  >= 10)  return 'Too many attempts. Please wait 1 hour before trying again.';
    if (in24Hr >= 20)  return 'Daily limit reached. Please try again after 24 hours.';

    timestamps.add(now);
    final pruned = timestamps
        .where((t) => now - t <= const Duration(hours: 24).inMilliseconds)
        .toList();
    await prefs.setStringList(
        _kAttemptTimestamps, pruned.map((t) => t.toString()).toList());

    final total = (prefs.getInt(_kTotalFailed) ?? 0) + 1;
    await prefs.setInt(_kTotalFailed, total);

    if (total >= 30) {
      await prefs.setBool(_kBanned, true);
      return 'Your account has been permanently banned due to too many failed '
          'login attempts. Please contact support.';
    }

    return null;
  }

  static Future<void> onSuccess(SharedPreferences prefs) async {
    await prefs.remove(_kAttemptTimestamps);
    final current = prefs.getInt(_kTotalFailed) ?? 0;
    if (current > 0) await prefs.setInt(_kTotalFailed, current - 1);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LoginScreen
// ─────────────────────────────────────────────────────────────────────────────
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with TickerProviderStateMixin {
  final _schoolIdCtrl = TextEditingController();
  final _passCtrl     = TextEditingController();
  bool  _loading      = false;
  bool  _obscure      = true;
  String? _error;
  bool _blocked = false;

  late final AnimationController _entranceCtrl;
  late final AnimationController _pulseCtrl;
  late final AnimationController _shakeCtrl;
  late final AnimationController _bgOrbitCtrl;
  late final AnimationController _logoCtrl;

  late final Animation<double> _fadeAnim;
  late final Animation<Offset> _cardSlideAnim;
  late final Animation<double> _cardScaleAnim;
  late final Animation<Offset> _logoSlideAnim;
  late final Animation<double> _logoFadeAnim;
  late final Animation<Offset> _field1SlideAnim;
  late final Animation<double> _field1FadeAnim;
  late final Animation<Offset> _field2SlideAnim;
  late final Animation<double> _field2FadeAnim;
  late final Animation<Offset> _btnSlideAnim;
  late final Animation<double> _btnFadeAnim;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _bgOrbitAnim;
  late final Animation<double> _shakeAnim;
  late final Animation<double> _logoScaleAnim;

  @override
  void initState() {
    super.initState();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1100));

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _entranceCtrl,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut)));

    _cardSlideAnim = Tween<Offset>(
            begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl,
            curve: const Interval(0.0, 0.55, curve: Curves.easeOutCubic)));

    _cardScaleAnim = Tween<double>(begin: 0.93, end: 1.0).animate(
        CurvedAnimation(
            parent: _entranceCtrl,
            curve: const Interval(0.0, 0.55, curve: Curves.easeOutBack)));

    _logoSlideAnim = Tween<Offset>(
            begin: const Offset(0, -0.3), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl,
            curve: const Interval(0.1, 0.5, curve: Curves.easeOutBack)));

    _logoFadeAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _entranceCtrl,
        curve: const Interval(0.1, 0.45, curve: Curves.easeOut)));

    _field1SlideAnim = Tween<Offset>(
            begin: const Offset(0.12, 0), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl,
            curve: const Interval(0.3, 0.65, curve: Curves.easeOutCubic)));
    _field1FadeAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _entranceCtrl,
        curve: const Interval(0.3, 0.6, curve: Curves.easeOut)));

    _field2SlideAnim = Tween<Offset>(
            begin: const Offset(0.12, 0), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl,
            curve: const Interval(0.42, 0.75, curve: Curves.easeOutCubic)));
    _field2FadeAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _entranceCtrl,
        curve: const Interval(0.42, 0.72, curve: Curves.easeOut)));

    _btnSlideAnim = Tween<Offset>(
            begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl,
            curve: const Interval(0.58, 0.9, curve: Curves.easeOutCubic)));
    _btnFadeAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _entranceCtrl,
        curve: const Interval(0.58, 0.88, curve: Curves.easeOut)));

    _logoCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _logoScaleAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut));

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.97, end: 1.03).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _bgOrbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 9))
      ..repeat();
    _bgOrbitAnim = CurvedAnimation(parent: _bgOrbitCtrl, curve: Curves.linear);

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 450));
    _shakeAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -8.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 80), () {
      if (mounted) {
        _entranceCtrl.forward();
        _logoCtrl.forward();
      }
    });

    _checkBanOnStartup();
  }

  Future<void> _checkBanOnStartup() async {
    final prefs  = await SharedPreferences.getInstance();
    final banned = prefs.getBool('rl_banned') ?? false;
    if (banned && mounted) {
      setState(() {
        _blocked = true;
        _error   = 'Your account has been permanently banned due to too many '
            'failed login attempts. Please contact support.';
      });
    }
  }

  @override
  void dispose() {
    _schoolIdCtrl.dispose();
    _passCtrl.dispose();
    _entranceCtrl.dispose();
    _pulseCtrl.dispose();
    _shakeCtrl.dispose();
    _bgOrbitCtrl.dispose();
    _logoCtrl.dispose();
    super.dispose();
  }

  // ── Login logic ─────────────────────────────────────────────────────────────
  Future<void> _login() async {
    final schoolId = _schoolIdCtrl.text.trim();
    final password = _passCtrl.text.trim();

    if (schoolId.isEmpty || password.isEmpty) {
      _triggerError('Please enter School ID and Password.');
      return;
    }

    setState(() { _loading = true; _error = null; });

    try {
      final prefs       = await SharedPreferences.getInstance();
      final blockReason = await _RateLimiter.checkAndRecord(prefs);
      if (!mounted) return;
      if (blockReason != null) {
        setState(() {
          _blocked = blockReason.contains('permanently');
          _error   = blockReason;
          _loading = false;
        });
        _shakeCtrl.forward(from: 0);
        return;
      }
    } catch (e) {
      if (mounted) _triggerError('Error: $e');
      return;
    }

    try {
      final doc = await FirebaseFirestore.instance
          .collection('schools')
          .doc(schoolId)
          .get();

      if (!mounted) return;

      if (!doc.exists) {
        _triggerError('School ID not found.');
        return;
      }

      final data       = doc.data()!;
      final storedPass = data['adminPassword'] ?? '';

      if (storedPass != password) {
        _triggerError('Incorrect password.');
        return;
      }

      if (data['isActive'] != true) {
        final prefs = await SharedPreferences.getInstance();
        await _RateLimiter.onSuccess(prefs);
        _triggerError('School account is locked. Contact support.');
        return;
      }

      if (mounted) {
        final prefs = await SharedPreferences.getInstance();
        await _RateLimiter.onSuccess(prefs);
        await prefs.setString('schoolId',   schoolId);
        await prefs.setString('schoolName', data['name'] ?? '');
        // Note: setupDone is set by SimSelectionScreen after SIM is chosen.

        // ── Navigate to SIM picker (replaces this screen) ──────────────
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 600),
            pageBuilder: (_, animation, __) => const SimSelectionScreen(),
            transitionsBuilder: (_, animation, __, child) {
              return FadeTransition(
                opacity: CurvedAnimation(
                    parent: animation, curve: Curves.easeOut),
                child: SlideTransition(
                  position: Tween<Offset>(
                          begin: const Offset(0.04, 0), end: Offset.zero)
                      .animate(CurvedAnimation(
                          parent: animation, curve: Curves.easeOutCubic)),
                  child: child,
                ),
              );
            },
          ),
        );
      }
    } catch (e) {
      if (mounted) _triggerError('Error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _triggerError(String msg) {
    setState(() { _error = msg; _loading = false; });
    _shakeCtrl.forward(from: 0);
  }

  // ── Build ───────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          // ── Animated background blobs ────────────────────────
          AnimatedBuilder(
            animation: _bgOrbitAnim,
            builder: (_, __) {
              final t = _bgOrbitAnim.value * 2 * math.pi;
              return Stack(children: [
                Container(color: kBg),
                Positioned(
                  right: -80 + math.sin(t) * 30,
                  top:   -60 + math.cos(t * 0.7) * 25,
                  child: _blob(280, kTeal.withValues(alpha: 0.20)),
                ),
                Positioned(
                  left:   -100 + math.cos(t * 0.6) * 20,
                  bottom: -80  + math.sin(t * 0.9) * 20,
                  child: _blob(320, kPink.withValues(alpha: 0.16)),
                ),
                Positioned(
                  right:  50 + math.sin(t * 1.1) * 15,
                  bottom: 150 + math.cos(t * 0.8) * 20,
                  child: _blob(160, kNavy.withValues(alpha: 0.05)),
                ),
              ]);
            },
          ),

          // ── Login card ───────────────────────────────────────
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _cardSlideAnim,
                child: ScaleTransition(
                  scale: _cardScaleAnim,
                  child: AnimatedBuilder(
                    animation: _shakeAnim,
                    builder: (_, child) => Transform.translate(
                      offset: Offset(_shakeAnim.value, 0),
                      child: child,
                    ),
                    child: Container(
                      width: 420,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 36, vertical: 24),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: kBorder, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: kNavy.withValues(alpha: 0.08),
                            blurRadius: 40,
                            offset: const Offset(0, 16),
                          ),
                          BoxShadow(
                            color: kTeal.withValues(alpha: 0.10),
                            blurRadius: 20,
                            offset: const Offset(-6, 6),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [

                          // ── Logo ───────────────────────────
                          SlideTransition(
                            position: _logoSlideAnim,
                            child: FadeTransition(
                              opacity: _logoFadeAnim,
                              child: ScaleTransition(
                                scale: _logoScaleAnim,
                                child: Container(
                                  width: 72, height: 72,
                                  decoration: BoxDecoration(
                                    color: kNavy,
                                    borderRadius: BorderRadius.circular(18),
                                    boxShadow: [
                                      BoxShadow(
                                        color: kNavy.withValues(alpha: 0.30),
                                        blurRadius: 18,
                                        offset: const Offset(0, 8),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(Icons.sms_rounded,
                                      color: kPink, size: 36),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),

                          // ── Title ──────────────────────────
                          FadeTransition(
                            opacity: _logoFadeAnim,
                            child: const Column(children: [
                              Text(
                                'SMS Sender',
                                style: TextStyle(
                                  color: kNavy,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.4,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'School Admin Login',
                                style: TextStyle(
                                  color: kMuted,
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 0.2,
                                ),
                              ),
                            ]),
                          ),

                          // ── Divider ────────────────────────
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 24),
                            child: FadeTransition(
                              opacity: _field1FadeAnim,
                              child: Row(children: [
                                const Expanded(
                                    child: Divider(color: kBorder, thickness: 1.2)),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  child: Text('SIGN IN',
                                      style: TextStyle(
                                        color: kMuted,
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 1.2,
                                      )),
                                ),
                                const Expanded(
                                    child: Divider(color: kBorder, thickness: 1.2)),
                              ]),
                            ),
                          ),

                          // ── School ID ──────────────────────
                          SlideTransition(
                            position: _field1SlideAnim,
                            child: FadeTransition(
                              opacity: _field1FadeAnim,
                              child: _buildField('School ID', _schoolIdCtrl,
                                  prefixIcon: Icons.badge_rounded,
                                  enabled: !_blocked),
                            ),
                          ),
                          const SizedBox(height: 14),

                          // ── Password ───────────────────────
                          SlideTransition(
                            position: _field2SlideAnim,
                            child: FadeTransition(
                              opacity: _field2FadeAnim,
                              child: _buildField('Password', _passCtrl,
                                  obscure: _obscure,
                                  prefixIcon: Icons.lock_rounded,
                                  enabled: !_blocked,
                                  suffix: IconButton(
                                    icon: Icon(
                                      _obscure
                                          ? Icons.visibility_off_rounded
                                          : Icons.visibility_rounded,
                                      color: kMuted, size: 19,
                                    ),
                                    onPressed: _blocked
                                        ? null
                                        : () => setState(() => _obscure = !_obscure),
                                  )),
                            ),
                          ),

                          // ── Error message ──────────────────
                          AnimatedSize(
                            duration: const Duration(milliseconds: 260),
                            curve: Curves.easeOut,
                            child: _error != null
                                ? Padding(
                                    padding: const EdgeInsets.only(top: 12),
                                    child: Container(
                                      padding: const EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                        color: kError.withValues(alpha: 0.07),
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                            color: kError.withValues(alpha: 0.25)),
                                      ),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Icon(
                                            _blocked
                                                ? Icons.block_rounded
                                                : Icons.error_outline_rounded,
                                            color: kError, size: 15,
                                          ),
                                          const SizedBox(width: 6),
                                          Expanded(
                                            child: Text(_error!,
                                                style: const TextStyle(
                                                  color: kError,
                                                  fontSize: 12.5,
                                                  fontWeight: FontWeight.w500,
                                                )),
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                : const SizedBox.shrink(),
                          ),

                          const SizedBox(height: 24),

                          // ── Login button ───────────────────
                          SlideTransition(
                            position: _btnSlideAnim,
                            child: FadeTransition(
                              opacity: _btnFadeAnim,
                              child: AnimatedBuilder(
                                animation: _pulseAnim,
                                builder: (_, child) => Transform.scale(
                                  scale: (_loading || _blocked)
                                      ? 1.0
                                      : _pulseAnim.value,
                                  child: child,
                                ),
                                child: SizedBox(
                                  width: double.infinity,
                                  height: 50,
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 200),
                                    decoration: BoxDecoration(
                                      gradient: (_loading || _blocked)
                                          ? null
                                          : const LinearGradient(
                                              colors: [
                                                Color(0xFF001858),
                                                Color(0xFF172C66),
                                              ],
                                              begin: Alignment.topLeft,
                                              end:   Alignment.bottomRight,
                                            ),
                                      color: (_loading || _blocked)
                                          ? kMuted
                                          : null,
                                      borderRadius: BorderRadius.circular(12),
                                      boxShadow: (_loading || _blocked)
                                          ? []
                                          : [
                                              BoxShadow(
                                                color: kNavy.withValues(alpha: 0.28),
                                                blurRadius: 16,
                                                offset: const Offset(0, 6),
                                              ),
                                            ],
                                    ),
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        shadowColor: Colors.transparent,
                                        foregroundColor: Colors.white,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(12)),
                                      ),
                                      onPressed:
                                          (_loading || _blocked) ? null : _login,
                                      child: _loading
                                          ? const SizedBox(
                                              width: 22, height: 22,
                                              child: CircularProgressIndicator(
                                                  color: Colors.white,
                                                  strokeWidth: 2.5))
                                          : _blocked
                                              ? const Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Icon(Icons.block_rounded,
                                                        size: 18),
                                                    SizedBox(width: 8),
                                                    Text('Access Blocked',
                                                        style: TextStyle(
                                                          fontSize: 15,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          letterSpacing: 0.3,
                                                        )),
                                                  ],
                                                )
                                              : const Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Text('Login',
                                                        style: TextStyle(
                                                          fontSize: 15,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          letterSpacing: 0.3,
                                                        )),
                                                    SizedBox(width: 8),
                                                    Icon(Icons.arrow_forward_rounded,
                                                        size: 18),
                                                  ],
                                                ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 20),

                          FadeTransition(
                            opacity: _btnFadeAnim,
                            child: Text(
                              _blocked
                                  ? 'Too many failed attempts. Contact support.'
                                  : 'Contact your administrator for access',
                              style: TextStyle(
                                  color: _blocked ? kError : kMuted,
                                  fontSize: 11.5),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildField(
    String hint,
    TextEditingController ctrl, {
    bool      obscure    = false,
    bool      enabled    = true,
    IconData? prefixIcon,
    Widget?   suffix,
  }) {
    return TextField(
      controller:  ctrl,
      obscureText: obscure,
      enabled:     enabled,
      style: TextStyle(
        color:      enabled ? kNavy : kMuted,
        fontSize:   14.5,
        fontWeight: FontWeight.w500,
      ),
      decoration: InputDecoration(
        hintText:  hint,
        hintStyle: const TextStyle(color: kMuted, fontSize: 14),
        filled:    true,
        fillColor: enabled ? kBg : kBorder,
        prefixIcon: prefixIcon != null
            ? Icon(prefixIcon, color: kMuted, size: 19)
            : null,
        suffixIcon: suffix,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: kBorder, width: 1.4),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: kBorder, width: 1.4),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: BorderSide(
              color: kBorder.withValues(alpha: 0.5), width: 1.4),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: kNavy, width: 1.8),
        ),
        contentPadding: const EdgeInsets.symmetric(
            horizontal: 14, vertical: 15),
      ),
    );
  }

  Widget _blob(double size, Color color) => Container(
        width: size, height: size,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      );
}