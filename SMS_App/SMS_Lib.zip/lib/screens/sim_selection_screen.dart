// lib/screens/sim_selection_screen.dart
//
// Shown once after first login so the user picks which SIM to send SMS from.
// The chosen subscription ID is persisted in SharedPreferences as 'simSubId'
// and the display label as 'simLabel'.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'home_screen.dart';

// ── Colours (same as home_screen) ────────────────────────────────────────────
const _kBg     = Color(0xFFFEF6E4);
const _kNavy   = Color(0xFF001858);
const _kCard   = Color(0xFFFFFFFF);
const _kMuted  = Color(0xFF8896AA);
const _kBorder = Color(0xFFE8EEF4);
const _kGreen  = Color(0xFF16A34A);
const _kTeal   = Color(0xFF0D9488);

// ── SIM info model ────────────────────────────────────────────────────────────
class _SimInfo {
  final int    subscriptionId;
  final String displayName;
  final String carrierName;
  final int    slotIndex;  // 0-based

  const _SimInfo({
    required this.subscriptionId,
    required this.displayName,
    required this.carrierName,
    required this.slotIndex,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// SimSelectionScreen
// ─────────────────────────────────────────────────────────────────────────────
class SimSelectionScreen extends StatefulWidget {
  const SimSelectionScreen({super.key});

  @override
  State<SimSelectionScreen> createState() => _SimSelectionScreenState();
}

class _SimSelectionScreenState extends State<SimSelectionScreen> {
  static const _channel = MethodChannel('com.App_Name.sms/sms');

  List<_SimInfo> _sims    = [];
  int?           _selected; // subscriptionId
  bool           _loading = true;
  String?        _error;

  @override
  void initState() {
    super.initState();
    _loadSims();
  }

  /// Ask native side for available SIM subscriptions.
  /// Falls back to a single default entry if the platform channel is not
  /// implemented, if READ_PHONE_STATE was denied, or if a MissingPluginException
  /// (or any other unexpected error) is thrown.
  Future<void> _loadSims() async {
    try {
      final raw = await _channel.invokeMethod<List<dynamic>>('getSimCards');
      if (raw == null || raw.isEmpty) {
        _useFallback();
        return;
      }
      final sims = raw.map((e) {
        final m = Map<String, dynamic>.from(e as Map);
        return _SimInfo(
          subscriptionId: (m['subscriptionId'] as int?) ?? -1,
          displayName:    (m['displayName']    as String?) ?? 'SIM',
          carrierName:    (m['carrierName']     as String?) ?? '',
          slotIndex:      (m['slotIndex']       as int?)    ?? 0,
        );
      }).toList();
      setState(() {
        _sims     = sims;
        _selected = sims.first.subscriptionId;
        _loading  = false;
      });
    } on PlatformException {
      // Permission denied or other Android platform error.
      _useFallback();
    } catch (_) {
      // Catches MissingPluginException (channel not registered on native side)
      // and any other unexpected errors — prevents infinite loading spinner.
      _useFallback();
    }
  }

  void _useFallback() {
    setState(() {
      _sims = [
        const _SimInfo(
          subscriptionId: -1,
          displayName:    'Default SIM',
          carrierName:    'System default',
          slotIndex:      0,
        ),
      ];
      _selected = -1;
      _loading  = false;
    });
  }

  Future<void> _confirm() async {
    if (_selected == null) return;

    final chosen = _sims.firstWhere((s) => s.subscriptionId == _selected);
    final prefs  = await SharedPreferences.getInstance();
    await prefs.setInt   ('simSubId',  chosen.subscriptionId);
    await prefs.setString('simLabel',
        'SIM ${chosen.slotIndex + 1} – ${chosen.displayName}');
    await prefs.setBool  ('setupDone', true);

    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ─────────────────────────────────────────────────
              Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  color: _kNavy,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.sim_card_outlined,
                    color: Colors.white, size: 28),
              ),
              const SizedBox(height: 20),
              const Text(
                'Choose Your SIM',
                style: TextStyle(
                  color: _kNavy,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Select the SIM card that will be used to send SMS notifications to parents.',
                style: TextStyle(color: _kMuted, fontSize: 14, height: 1.5),
              ),
              const SizedBox(height: 32),

              // ── SIM list ───────────────────────────────────────────────
              if (_loading)
                const Expanded(
                  child: Center(
                    child: CircularProgressIndicator(color: _kNavy),
                  ),
                )
              else if (_error != null)
                _ErrorBanner(message: _error!)
              else
                Expanded(
                  child: ListView.separated(
                    itemCount:  _sims.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) {
                      final sim      = _sims[i];
                      final selected = sim.subscriptionId == _selected;
                      return _SimTile(
                        sim:      sim,
                        selected: selected,
                        onTap:    () =>
                            setState(() => _selected = sim.subscriptionId),
                      );
                    },
                  ),
                ),

              const SizedBox(height: 24),

              // ── Confirm button ─────────────────────────────────────────
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _kNavy,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                  icon: const Icon(Icons.check_circle_outline, size: 20),
                  label: const Text(
                    'Continue',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  onPressed: _selected == null ? null : _confirm,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _SimTile
// ─────────────────────────────────────────────────────────────────────────────
class _SimTile extends StatelessWidget {
  final _SimInfo sim;
  final bool     selected;
  final VoidCallback onTap;

  const _SimTile({
    required this.sim,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          color:  selected ? _kNavy : _kCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? _kNavy : _kBorder,
            width: selected ? 2 : 1.5,
          ),
          boxShadow: selected
              ? [BoxShadow(
                  color:      _kNavy.withOpacity(0.20),
                  blurRadius: 16,
                  offset:     const Offset(0, 6),
                )]
              : [BoxShadow(
                  color:      Colors.black.withOpacity(0.04),
                  blurRadius: 8,
                  offset:     const Offset(0, 2),
                )],
        ),
        child: Row(
          children: [
            // Slot chip
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(
                color: selected
                    ? Colors.white.withOpacity(0.15)
                    : _kTeal.withOpacity(0.10),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  'S${sim.slotIndex + 1}',
                  style: TextStyle(
                    color:      selected ? Colors.white : _kTeal,
                    fontWeight: FontWeight.w800,
                    fontSize:   13,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),

            // Name + carrier
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    sim.displayName,
                    style: TextStyle(
                      color:      selected ? Colors.white : _kNavy,
                      fontWeight: FontWeight.w700,
                      fontSize:   15,
                    ),
                  ),
                  if (sim.carrierName.isNotEmpty)
                    Text(
                      sim.carrierName,
                      style: TextStyle(
                        color:    selected
                            ? Colors.white.withOpacity(0.65)
                            : _kMuted,
                        fontSize: 12.5,
                      ),
                    ),
                ],
              ),
            ),

            // Radio indicator
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 22, height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? Colors.white : Colors.transparent,
                border: Border.all(
                  color:  selected ? Colors.white : _kBorder,
                  width:  2,
                ),
              ),
              child: selected
                  ? const Icon(Icons.check,
                      color: _kNavy, size: 14)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _ErrorBanner
// ─────────────────────────────────────────────────────────────────────────────
class _ErrorBanner extends StatelessWidget {
  final String message;
  const _ErrorBanner({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFE4E8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE53E6B).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline,
              color: Color(0xFFE53E6B), size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(message,
                style: const TextStyle(
                    color: Color(0xFFE53E6B), fontSize: 13)),
          ),
        ],
      ),
    );
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// Public helper — checks if we should show SIM picker again (e.g. from Settings)
// ─────────────────────────────────────────────────────────────────────────────
Future<String> getSavedSimLabel() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('simLabel') ?? 'Default SIM';
}