// lib/screens/home_screen.dart
//
// Main dashboard.
// Settings bottom sheet now includes:
//   • Current SIM label + "Change SIM" button
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/message_request.dart';
import '../services/firebase_request_service.dart';
import '../services/background_sms_service.dart';
import '../services/sms_service.dart';
import '../services/contact_service.dart';
import 'sim_selection_screen.dart';
import 'login_screen.dart';

const kBg     = Color(0xFFFEF6E4);
const kNavy   = Color(0xFF001858);
const kGreen  = Color(0xFF16A34A);
const kRed    = Color(0xFFE53E6B);
const kAmber  = Color(0xFFD97706);
const kCard   = Color(0xFFFFFFFF);
const kMuted  = Color(0xFF8896AA);
const kBorder = Color(0xFFE8EEF4);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _schoolId   = '';
  String _schoolName = '';
  String _simLabel   = '';
  bool   _isRunning  = false;

  int _lastSent   = 0;
  int _lastFailed = 0;
  bool _isSending = false;

  StreamSubscription?                       _bgStatusSub;
  StreamSubscription?                       _bgSmsSub;
  StreamSubscription<List<MessageRequest>>? _queueSub;
  List<MessageRequest> _queue = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs   = await SharedPreferences.getInstance();
    final id      = prefs.getString('schoolId')   ?? '';
    final name    = prefs.getString('schoolName') ?? '';
    final simLbl  = prefs.getString('simLabel')   ?? 'Default SIM';
    final running = await isBackgroundServiceRunning();

    setState(() {
      _schoolId   = id;
      _schoolName = name;
      _simLabel   = simLbl;
      _isRunning  = running;
    });

    if (id.isNotEmpty) _subscribeQueue(id);
    _subscribeServiceEvents();
  }

  void _subscribeQueue(String schoolId) {
    _queueSub?.cancel();
    _queueSub = FirebaseRequestService.todayStream(schoolId).listen((list) {
      if (mounted) setState(() => _queue = list);
    });
  }

  void _subscribeServiceEvents() {
    final svc = FlutterBackgroundService();

    _bgStatusSub?.cancel();
    _bgStatusSub = svc.on('status').listen((data) {
      if (data == null) return;
      if (mounted) {
        setState(() {
          _lastSent   = (data['sent']   as int?) ?? _lastSent;
          _lastFailed = (data['failed'] as int?) ?? _lastFailed;
          _isRunning  = true;
        });
      }
    });

    _bgSmsSub?.cancel();
    _bgSmsSub = svc.on('sendSms').listen((data) async {
      // NOTE: Do NOT guard with !mounted here. The SMS send + smsResult reply
      // must always complete so the background service never hangs on a timeout.
      // None of the code below touches the widget tree.
      if (data == null) return;
      final phone       = data['phoneNumber']  as String? ?? '';
      final message     = data['message']      as String? ?? '';
      final requestId   = data['requestId']    as String? ?? '';
      final studentName = data['studentName']  as String? ?? 'Parent';

      bool   success  = false;
      String errorMsg = '';

      try {
        // ── Step 1: Ensure contact exists (create if missing) ─────────────
        // We must NOT send an SMS to a number that isn't saved as a contact.
        final contactResult = await ContactService.ensureContact(
          rawPhone:    phone,
          studentName: studentName,
        );

        if (!contactResult.canSend) {
          // Contact creation failed — report failure, do NOT send SMS.
          errorMsg = contactResult.error ?? 'Failed to create contact for $phone';
          debugPrint('[Home] ❌ Contact not ready — skipping SMS. $errorMsg');
        } else {
          // ── Step 2: Send SMS using the normalised local number ────────────
          success = await SmsService.sendSms(
            phoneNumber: contactResult.localNumber,
            message:     message,
          );
        }
      } catch (e) {
        errorMsg = e.toString();
      }

      svc.invoke('smsResult', {
        'requestId': requestId,
        'success':   success,
        'error':     errorMsg,
      });
    });
  }

  Future<void> _manualSendNow() async {
    if (_isSending) return;
    setState(() => _isSending = true);

    final pending = _queue.where((r) => r.smsStatus == SmsStatus.pending).toList();
    if (pending.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No pending requests to send.')),
        );
        setState(() => _isSending = false);
      }
      return;
    }

    final svc = FlutterBackgroundService();
    int sent = 0, failed = 0;

    for (final req in pending) {
      try {
        await FirebaseRequestService.markProcessing(_schoolId, req.id);

        final contactResult = await ContactService.ensureContact(
          rawPhone:    req.parentPhone,
          studentName: req.studentName,
        );

        bool success = false;
        String errorMsg = '';

        if (!contactResult.canSend) {
          errorMsg = contactResult.error ?? 'Failed to create contact';
        } else {
          success = await SmsService.sendSms(
            phoneNumber: contactResult.localNumber,
            message:     await req.buildSmsBody(),
          );
        }

        if (success) {
          await FirebaseRequestService.markSent(_schoolId, req.id);
          sent++;
        } else {
          await FirebaseRequestService.markFailed(_schoolId, req.id, errorMsg.isNotEmpty ? errorMsg : 'Send failed');
          failed++;
        }
      } catch (e) {
        await FirebaseRequestService.markFailed(_schoolId, req.id, e.toString());
        failed++;
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Done — $sent sent, $failed failed.')),
      );
      setState(() => _isSending = false);
    }
  }

  Future<void> _toggleService() async {
    if (_isRunning) {
      await stopBackgroundService();
      setState(() => _isRunning = false);
    } else {
      await startBackgroundService();
      await Future.delayed(const Duration(milliseconds: 600));
      final running = await isBackgroundServiceRunning();
      setState(() => _isRunning = running);
    }
  }

  @override
  void dispose() {
    _bgStatusSub?.cancel();
    _bgSmsSub?.cancel();
    _queueSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kNavy,
        foregroundColor: Colors.white,
        title: const Text('SMS Sender',
            style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            icon: _isSending
                ? const SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.send_outlined),
            tooltip: 'Send pending now',
            onPressed: _isSending ? null : _manualSendNow,
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: _showSettings,
          ),
        ],
      ),
      body: _buildMain(),
    );
  }

  // ── Main dashboard ─────────────────────────────────────────────────────────
  Widget _buildMain() {
    final pending = _queue.where((r) => !r.processed).length;
    final sent    = _queue.where((r) => r.smsStatus == SmsStatus.sent).length;
    final failed  = _queue.where((r) => r.smsStatus == SmsStatus.failed).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _StatusCard(
          isRunning:  _isRunning,
          schoolName: _schoolName,
          simLabel:   _simLabel,
          onToggle:   _toggleService,
        ),
        const SizedBox(height: 14),
        Row(children: [
          _StatChip(label: 'Pending',    value: pending, color: kAmber),
          const SizedBox(width: 10),
          _StatChip(label: 'Sent Today', value: sent,    color: kGreen),
          const SizedBox(width: 10),
          _StatChip(label: 'Failed',     value: failed,  color: kRed),
        ]),
        const SizedBox(height: 18),
        Text("Today's Queue (${_queue.length})",
            style: const TextStyle(
                fontWeight: FontWeight.w700, fontSize: 15, color: kNavy)),
        const SizedBox(height: 8),
        if (_queue.isEmpty)
          const _EmptyState()
        else
          ..._queue.map((r) => _RequestTile(request: r)),
      ],
    );
  }

  // ── Settings bottom sheet ──────────────────────────────────────────────────
  void _showSettings() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: kCard,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _SettingsSheet(
        schoolId:   _schoolId,
        schoolName: _schoolName,
        simLabel:   _simLabel,
        onChangeSim: () async {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SimSelectionScreen()),
          ).then((_) => _load());
        },
        onSignOut: _signOut,
      ),
    );
  }

  Future<void> _signOut() async {
    Navigator.pop(context); // close the bottom sheet first
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.logout, color: kRed, size: 22),
            SizedBox(width: 10),
            Text('Sign Out',
                style: TextStyle(
                    color: kNavy, fontWeight: FontWeight.w700, fontSize: 17)),
          ],
        ),
        content: const Text(
          'Are you sure you want to sign out?\nYou will need to log in again to access the app.',
          style: TextStyle(color: kMuted, fontSize: 13.5, height: 1.5),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel',
                style: TextStyle(color: kMuted, fontWeight: FontWeight.w600)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: kRed,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sign Out',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// _SettingsSheet
// ─────────────────────────────────────────────────────────────────────────────
class _SettingsSheet extends StatelessWidget {
  final String     schoolId;
  final String     schoolName;
  final String     simLabel;
  final VoidCallback onChangeSim;
  final VoidCallback onSignOut;

  const _SettingsSheet({
    required this.schoolId,
    required this.schoolName,
    required this.simLabel,
    required this.onChangeSim,
    required this.onSignOut,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle bar
          Center(
            child: Container(
              width: 36, height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                  color: kBorder,
                  borderRadius: BorderRadius.circular(99)),
            ),
          ),

          const Text('Settings',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: kNavy)),
          const SizedBox(height: 20),

          // ── School info (read-only) ─────────────────────────────────
          _InfoRow(
            icon:  Icons.school_outlined,
            label: 'School',
            value: schoolName.isNotEmpty ? schoolName : schoolId,
          ),
          const SizedBox(height: 10),

          // ── SIM info ────────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: kBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kBorder),
            ),
            child: Row(
              children: [
                const Icon(Icons.sim_card_outlined,
                    color: kNavy, size: 20),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Active SIM',
                          style: TextStyle(
                              color: kMuted,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.5)),
                      Text(
                        simLabel.isNotEmpty ? simLabel : 'Not set',
                        style: const TextStyle(
                            color: kNavy,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.5),
                      ),
                    ],
                  ),
                ),
                TextButton(
                  onPressed: onChangeSim,
                  style: TextButton.styleFrom(
                    foregroundColor: kNavy,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  ),
                  child: const Text('Change',
                      style: TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 13)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 4),

          // ── Sign Out ────────────────────────────────────────────────
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: kRed.withOpacity(0.08),
                foregroundColor: kRed,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: kRed.withOpacity(0.30))),
              ),
              icon: const Icon(Icons.logout, size: 18),
              label: const Text('Sign Out',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              onPressed: onSignOut,
            ),
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String   label;
  final String   value;
  const _InfoRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: kBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder),
      ),
      child: Row(children: [
        Icon(icon, color: kNavy, size: 20),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label,
              style: const TextStyle(
                  color: kMuted,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5)),
          Text(value,
              style: const TextStyle(
                  color: kNavy,
                  fontWeight: FontWeight.w700,
                  fontSize: 13.5)),
        ]),
      ]),
    );
  }
}

class _SettingsButton extends StatelessWidget {
  final IconData icon;
  final String   label;
  final String   sublabel;
  final VoidCallback onTap;
  const _SettingsButton({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kBorder),
        ),
        child: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
                color: kNavy.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: kNavy, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label,
                  style: const TextStyle(
                      color: kNavy,
                      fontWeight: FontWeight.w700,
                      fontSize: 14)),
              Text(sublabel,
                  style: const TextStyle(
                      color: kMuted, fontSize: 12)),
            ]),
          ),
          const Icon(Icons.chevron_right_rounded, color: kMuted),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SUB-WIDGETS (unchanged from original)
// ─────────────────────────────────────────────────────────────────────────────

class _StatusCard extends StatelessWidget {
  final bool       isRunning;
  final String     schoolName;
  final String     simLabel;
  final VoidCallback onToggle;

  const _StatusCard({
    required this.isRunning,
    required this.schoolName,
    required this.simLabel,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04),
            blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Column(
        children: [
          Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: isRunning
                    ? kGreen.withOpacity(0.12)
                    : kRed.withOpacity(0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(
                isRunning ? Icons.sensors : Icons.sensors_off,
                color: isRunning ? kGreen : kRed,
                size: 22,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isRunning ? 'Service Running' : 'Service Stopped',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: isRunning ? kGreen : kRed),
                  ),
                  Text(
                    schoolName.isNotEmpty ? schoolName : 'No school connected',
                    style: const TextStyle(color: kMuted, fontSize: 12),
                  ),
                ],
              ),
            ),
            Switch(
              value: isRunning,
              activeColor: kGreen,
              onChanged: (_) => onToggle(),
            ),
          ]),
          // SIM row
          if (simLabel.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: kBorder.withOpacity(0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.sim_card_outlined,
                      color: kMuted, size: 13),
                  const SizedBox(width: 5),
                  Text(simLabel,
                      style: const TextStyle(
                          color: kMuted,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final int    value;
  final Color  color;
  const _StatChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Column(children: [
          Text('$value',
              style: TextStyle(fontSize: 22,
                  fontWeight: FontWeight.w800, color: color)),
          Text(label,
              style: TextStyle(fontSize: 11, color: color.withOpacity(0.8))),
        ]),
      ),
    );
  }
}

class _RequestTile extends StatelessWidget {
  final MessageRequest request;
  const _RequestTile({required this.request});

  @override
  Widget build(BuildContext context) {
    final statusColor = switch (request.smsStatus) {
      SmsStatus.sent       => kGreen,
      SmsStatus.failed     => kRed,
      SmsStatus.processing => kAmber,
      _                    => kMuted,
    };
    final statusIcon = switch (request.smsStatus) {
      SmsStatus.sent       => Icons.check_circle_outline,
      SmsStatus.failed     => Icons.error_outline,
      SmsStatus.processing => Icons.hourglass_top_outlined,
      _                    => Icons.schedule_outlined,
    };
    final statusLabel = switch (request.smsStatus) {
      SmsStatus.sent       => 'Sent',
      SmsStatus.failed     => 'Failed',
      SmsStatus.processing => 'Sending…',
      _                    => 'Pending',
    };
    final badgeColor =
        request.attendanceStatus == 'absent' ? kRed : kAmber;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kBorder),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          decoration: BoxDecoration(
            color: badgeColor.withOpacity(0.12),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text(
            request.attendanceStatus == 'absent' ? 'ABSENT' : 'LATE',
            style: TextStyle(fontSize: 9,
                fontWeight: FontWeight.w800, color: badgeColor),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(request.studentName,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, color: kNavy)),
              Text(
                'Roll: ${request.rollNo}  •  ${request.className} ${request.section}  •  ${request.parentPhone}',
                style: const TextStyle(fontSize: 11, color: kMuted),
              ),
              if (request.smsStatus == SmsStatus.failed &&
                  request.errorMsg != null)
                Text(request.errorMsg!,
                    style: const TextStyle(fontSize: 10, color: kRed)),
            ],
          ),
        ),
        Column(children: [
          Icon(statusIcon, color: statusColor, size: 18),
          Text(statusLabel,
              style: TextStyle(fontSize: 9, color: statusColor)),
        ]),
      ]),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Column(children: [
          Icon(Icons.inbox_outlined, size: 48, color: kMuted),
          SizedBox(height: 8),
          Text('No requests today',
              style: TextStyle(color: kMuted, fontSize: 14)),
          Text('The main app will send requests here.',
              style: TextStyle(color: kMuted, fontSize: 12)),
        ]),
      ),
    );
  }
}