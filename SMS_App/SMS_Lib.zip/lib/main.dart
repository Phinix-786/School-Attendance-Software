// lib/main.dart
//
// Entry point.
// First-run flow:  LoginScreen → SimSelectionScreen → HomeScreen
// Returning user:  HomeScreen (setupDone flag is set)
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';
import 'services/background_sms_service.dart';
import 'screens/login_screen.dart';
import 'screens/sim_selection_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Init Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Request all permissions needed for SMS + background service
  await [
    Permission.sms,
    Permission.notification,
    Permission.phone,                     // READ_PHONE_STATE for telephony pkg
    Permission.contacts,
    Permission.ignoreBatteryOptimizations,
  ].request();

  // Start background service
  await initBackgroundService();

  // Decide which screen to show on launch
  final prefs     = await SharedPreferences.getInstance();
  final setupDone = prefs.getBool('setupDone') ?? false;

  Widget home;
  if (!setupDone) {
    // First launch: show login (login navigates to SIM picker, then home)
    home = const LoginScreen();
  } else {
    home = const HomeScreen();
  }

  runApp(SmsSenderApp(home: home));
}

class SmsSenderApp extends StatelessWidget {
  final Widget home;
  const SmsSenderApp({super.key, required this.home});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title:                     'SMS Sender',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3:           true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF001858)),
        scaffoldBackgroundColor: const Color(0xFFFEF6E4),
        fontFamily:             'Roboto',
      ),
      home: home,
    );
  }
}