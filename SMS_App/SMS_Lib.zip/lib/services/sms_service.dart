// lib/services/sms_service.dart
//
// Sends real SMS via the device SIM card using Android SmsManager.
// Communicates with native Android code through a MethodChannel.
// Only called from the main isolate (HomeScreen._bgSmsSub listener),
// never directly from the background isolate.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/services.dart';

class SmsService {
  static const _channel = MethodChannel('com.App_Name.sms/sms');

  /// Sends a single SMS via the device SIM card.
  /// Returns true on success, throws [SmsException] on failure.
  static Future<bool> sendSms({
    required String phoneNumber,
    required String message,
  }) async {
    try {
      final result = await _channel.invokeMethod<bool>('sendSms', {
        'phoneNumber': _cleanPhone(phoneNumber),
        'message':     message,
      });
      return result == true;
    } on PlatformException catch (e) {
      throw SmsException('SmsManager error: ${e.message ?? e.code}');
    }
  }

  /// Strips everything except digits so any format works.
  /// "+92 300-1234567" → "923001234567"
  static String _cleanPhone(String raw) =>
      raw.replaceAll(RegExp(r'[^\d]'), '');
}

class SmsException implements Exception {
  final String message;
  const SmsException(this.message);
  @override
  String toString() => 'SmsException: $message';
}
