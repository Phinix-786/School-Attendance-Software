// lib/services/contact_service.dart
//
// Handles contact lookup and creation before sending an SMS.
//
// NUMBER NORMALISATION
// ────────────────────
// Phone numbers stored in Firestore may arrive in various formats:
//   +923001234567   →  03001234567
//   923001234567    →  03001234567
//   03001234567     →  03001234567  (already correct, no change)
//
// The normalised form (starting with 0) is what Pakistani contacts
// are saved under on a phone/SIM, so we always compare and create
// using this form.
//
// FLOW (called from HomeScreen before every send)
// ────────────────────────────────────────────────
//   1. Normalise the raw phone number.
//   2. Ask the native side whether a contact with that number exists.
//   3a. Exists  → return {exists: true,  localNumber: normalised}.
//   3b. Missing → attempt to create the contact.
//       • Success → return {exists: false, created: true,  localNumber: ...}.
//       • Failure → return {exists: false, created: false, error: '...'}.
//
// The caller MUST NOT send the SMS if created == false.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

class ContactResult {
  /// The normalised local number (starts with 0).
  final String localNumber;

  /// True if the contact was already on the device before this call.
  final bool alreadyExisted;

  /// True if the contact was successfully created during this call.
  /// Irrelevant (and false) when [alreadyExisted] is true.
  final bool created;

  /// Non-null only when [alreadyExisted] is false AND [created] is false.
  final String? error;

  const ContactResult._({
    required this.localNumber,
    required this.alreadyExisted,
    required this.created,
    this.error,
  });

  /// Contact was already present — safe to send.
  bool get canSend => alreadyExisted || created;
}

class ContactService {
  static const _channel = MethodChannel('com.App_Name.sms/contacts');

  // ── Public API ────────────────────────────────────────────────────────────

  /// Ensures a contact exists for [rawPhone] before an SMS is sent.
  ///
  /// [studentName] is used as the display name when creating the contact.
  ///
  /// Returns a [ContactResult] describing what happened.
  /// The caller must check [ContactResult.canSend] before proceeding.
  static Future<ContactResult> ensureContact({
    required String rawPhone,
    required String studentName,
  }) async {
    final local = normalise(rawPhone);

    // 1. Check whether the contact already exists
    final exists = await _contactExists(local);
    if (exists) {
      debugPrint('[Contact] ✅ Already exists: $local');
      return ContactResult._(
        localNumber:   local,
        alreadyExisted: true,
        created:       false,
      );
    }

    // 2. Contact missing — try to create it
    debugPrint('[Contact] ➕ Not found, creating contact for $studentName ($local)…');
    try {
      await _createContact(displayName: studentName, phoneNumber: local);
      debugPrint('[Contact] ✅ Created: $studentName ($local)');
      return ContactResult._(
        localNumber:   local,
        alreadyExisted: false,
        created:       true,
      );
    } on PlatformException catch (e) {
      final msg = e.message ?? e.code;
      debugPrint('[Contact] ❌ Create failed for $local: $msg');
      return ContactResult._(
        localNumber:   local,
        alreadyExisted: false,
        created:       false,
        error:         'Contact creation failed: $msg',
      );
    } catch (e) {
      debugPrint('[Contact] ❌ Create failed for $local: $e');
      return ContactResult._(
        localNumber:   local,
        alreadyExisted: false,
        created:       false,
        error:         'Contact creation failed: $e',
      );
    }
  }

  // ── Number normalisation ──────────────────────────────────────────────────

  /// Converts any Pakistani number format to the local 0XXXXXXXXX form.
  ///
  ///   +923001234567  →  03001234567
  ///   923001234567   →  03001234567
  ///   03001234567    →  03001234567
  ///   3001234567     →  03001234567   (10-digit without leading 0)
  static String normalise(String raw) {
    // Strip everything except digits
    String digits = raw.replaceAll(RegExp(r'[^\d]'), '');

    // +92 / 92 prefix → strip and prepend 0
    if (digits.startsWith('92') && digits.length >= 12) {
      digits = '0${digits.substring(2)}';
    }

    // 10-digit number without leading 0 (e.g. "3001234567") → prepend 0
    if (!digits.startsWith('0') && digits.length == 10) {
      digits = '0$digits';
    }

    return digits;
  }

  // ── Private helpers (talk to native Android) ──────────────────────────────

  static Future<bool> _contactExists(String localNumber) async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'contactExists',
        {'phoneNumber': localNumber},
      );
      return result == true;
    } on PlatformException catch (e) {
      debugPrint('[Contact] contactExists error: ${e.message}');
      // If we can't query contacts, treat as non-existent so we attempt creation
      return false;
    }
  }

  static Future<void> _createContact({
    required String displayName,
    required String phoneNumber,
  }) async {
    await _channel.invokeMethod<void>('createContact', {
      'displayName': displayName,
      'phoneNumber': phoneNumber,
    });
  }
}