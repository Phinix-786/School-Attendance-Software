// lib/services/firebase_request_service.dart
//
// Reads pending SMS requests from Firestore and manages their lifecycle.
// Also owns the SMS template document at:
//   schools/{schoolId}/config/sms_template
// ─────────────────────────────────────────────────────────────────────────────

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/message_request.dart';

class FirebaseRequestService {
  static final _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> _col(String schoolId) =>
      _db.collection('schools/$schoolId/sms_requests');

  /// Reference to the templates document for a given school.
  static DocumentReference<Map<String, dynamic>> _templatesDoc(
          String schoolId) =>
      _db.doc('schools/$schoolId/config/sms_template');

  // ── Fetch all pending (unprocessed) requests ─────────────────────────────
  static Future<List<MessageRequest>> fetchPending(String schoolId) async {
    final snap = await _col(schoolId)
        .where('smsStatus', isEqualTo: 'pending')
        .orderBy('createdAt')
        .get();
    return snap.docs.map((d) => MessageRequest.fromDoc(d)).toList();
  }

  // ── Stream pending requests (used by the UI to show live queue) ──────────
  static Stream<List<MessageRequest>> pendingStream(String schoolId) {
    return _col(schoolId)
        .where('processed', isEqualTo: false)
        .where('smsStatus', isEqualTo: 'pending')
        .orderBy('createdAt')
        .snapshots()
        .map((s) => s.docs.map((d) => MessageRequest.fromDoc(d)).toList());
  }

  // ── Stream ALL today's requests (for the history log in UI) ─────────────
  static Stream<List<MessageRequest>> todayStream(String schoolId) {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    return _col(schoolId)
        .where('createdAt', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => MessageRequest.fromDoc(d)).toList());
  }

  // ── Mark a request as "processing" ──────────────────────────────────────
  static Future<void> markProcessing(String schoolId, String docId) async {
    await _col(schoolId).doc(docId).update({'smsStatus': 'processing'});
  }

  // ── Mark a request as sent ───────────────────────────────────────────────
  static Future<void> markSent(String schoolId, String docId) async {
    await _col(schoolId).doc(docId).update({
      'smsStatus': 'sent',
      'processed': true,
      'sentAt':    FieldValue.serverTimestamp(),
    });
  }

  // ── Mark a request as failed ─────────────────────────────────────────────
  static Future<void> markFailed(
      String schoolId, String docId, String error) async {
    await _col(schoolId).doc(docId).update({
      'smsStatus': 'failed',
      'processed': true,
      'errorMsg':  error,
      'failedAt':  FieldValue.serverTimestamp(),
    });
  }

  // ── Delete all requests older than 24 hours ──────────────────────────────
  static Future<int> deleteExpired(String schoolId) async {
    final cutoff = DateTime.now().subtract(const Duration(hours: 24));
    final snap   = await _col(schoolId)
        .where('createdAt', isLessThan: Timestamp.fromDate(cutoff))
        .get();
    if (snap.docs.isEmpty) return 0;

    int deleted = 0;
    for (int i = 0; i < snap.docs.length; i += 499) {
      final batch = _db.batch();
      final chunk = snap.docs.sublist(i, (i + 499).clamp(0, snap.docs.length));
      for (final doc in chunk) {
        batch.delete(doc.reference);
      }
      await batch.commit();
      deleted += chunk.length;
    }
    return deleted;
  }

  // ── Get school config (same doc as main app uses) ────────────────────────
  static Future<Map<String, dynamic>?> getSchoolConfig(String schoolId) async {
    final doc = await _db.collection('schools').doc(schoolId).get();
    return doc.data();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Template helpers
  // ─────────────────────────────────────────────────────────────────────────

  /// Real-time stream of the templates document.
  /// Emits a map with keys 'absentTemplate' and 'lateTemplate' (may be null
  /// if the document doesn't exist yet — callers should fall back to defaults).
  static Stream<Map<String, dynamic>?> templatesStream(String schoolId) {
    return _templatesDoc(schoolId)
        .snapshots()
        .map((snap) => snap.data());
  }

  /// One-shot fetch of both templates.
  /// Returns null values for keys that are not set yet.
  static Future<Map<String, dynamic>?> fetchTemplates(String schoolId) async {
    final snap = await _templatesDoc(schoolId).get();
    return snap.data();
  }

  /// Persist both templates to Firestore (merge so other fields are preserved).
  static Future<void> saveTemplates(
    String schoolId, {
    required String absentTemplate,
    required String lateTemplate,
  }) async {
    await _templatesDoc(schoolId).set(
      {
        'absentTemplate': absentTemplate,
        'lateTemplate':   lateTemplate,
        'updatedAt':      FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }
}