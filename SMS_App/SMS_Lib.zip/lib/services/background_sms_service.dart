// lib/services/background_sms_service.dart
//
// The MissingPluginException fix:
// MethodChannels only work on the engine they were registered on.
// flutter_background_service creates a SECOND engine for its isolate,
// and SmsPlugin is only registered on the MAIN engine (via MainActivity).
//
// Solution: The background isolate tells the main isolate to send the SMS
// via service.invoke('sendSms', ...) and waits for the result via
// service.on('smsResult'). The main isolate (HomeScreen) listens for
// 'sendSms' events and calls SmsService, then fires back 'smsResult'.
//
// ─────────────────────────────────────────────────────────────────────────────
// RATE LIMITS & INTER-MESSAGE DELAY
// ─────────────────────────────────────────────────────────────────────────────
// Hard limits enforced by this app:
//   90  / 15 min  |  200 / 1 hr  |  500 / 24 hr
//
// Inter-message delay:
//   After each SMS is dispatched and locally marked as sent, the service
//   waits exactly 10 seconds before sending the next one.  This delay is
//   applied IN ADDITION to any rate-limit waits.
//
// How it works:
//   _PtaRateLimiter tracks timestamps of every sent SMS in three sliding
//   windows (15 min, 1 hr, 24 hr).  Before each send it checks all three
//   windows.  If ANY window is full it calculates exactly how long to wait
//   until the oldest entry in that window falls out, sleeps that long, then
//   re-checks.  This guarantees we never exceed the limits regardless of
//   how many pending requests pile up.
//
// ─────────────────────────────────────────────────────────────────────────────
// FIX: "First request ignored until restart"
// ─────────────────────────────────────────────────────────────────────────────
// Root cause: The original code only ran a cycle via Timer.periodic every
// 30 seconds.  When the very first request arrived, the service was already
// waiting for the next timer tick, so nothing happened until the timer fired.
//
// Fix: A Firestore real-time listener (_PendingWatcher) watches for any
// document in the school's requests collection with status == 'pending'.
// The moment a new pending request appears it immediately triggers a cycle
// (with debounce so rapid bursts don't spawn concurrent cycles).
// The periodic timer is kept as a safety net for any missed snapshots.
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../firebase_options.dart';
import 'firebase_request_service.dart';

const int    kForegroundNotifId  = 1;
const String kNotifChannelId     = 'sms_sender_bg';
const String kNotifChannelName   = 'SMS Sender Background';
const String kPrefSchoolId       = 'schoolId';

/// Fixed gap enforced between every two consecutive outgoing SMS.
const Duration kInterMessageDelay = Duration(seconds: 10);

// ─────────────────────────────────────────────────────────────
// PTA RATE LIMITER
// ─────────────────────────────────────────────────────────────

class _PtaRateLimiter {
  // Enforced limits
  static const int _max15Min  = 90;    // 90 per 15 minutes
  static const int _maxHour   = 200;   // 200 per hour
  static const int _maxDay    = 500;   // 500 per 24 hours

  static const Duration _window15Min = Duration(minutes: 15);
  static const Duration _windowHour  = Duration(hours: 1);
  static const Duration _windowDay   = Duration(hours: 24);

  // Sliding-window queues — store the DateTime of each sent SMS
  final Queue<DateTime> _ts15Min = Queue();
  final Queue<DateTime> _tsHour  = Queue();
  final Queue<DateTime> _tsDay   = Queue();

  // Callback so the limiter can update the notification while waiting
  final void Function(String, String) _updateNotif;

  _PtaRateLimiter(this._updateNotif);

  void _prune(Queue<DateTime> q, Duration window) {
    final cutoff = DateTime.now().subtract(window);
    while (q.isNotEmpty && q.first.isBefore(cutoff)) {
      q.removeFirst();
    }
  }

  Duration _waitNeeded(Queue<DateTime> q, Duration window) {
    if (q.isEmpty) return Duration.zero;
    final expiresAt = q.first.add(window);
    final diff = expiresAt.difference(DateTime.now());
    return diff.isNegative ? Duration.zero : diff + const Duration(milliseconds: 200);
  }

  Future<void> waitForSlot() async {
    while (true) {
      _prune(_ts15Min, _window15Min);
      _prune(_tsHour,  _windowHour);
      _prune(_tsDay,   _windowDay);

      Duration wait = Duration.zero;
      String reason = '';

      if (_ts15Min.length >= _max15Min) {
        final w = _waitNeeded(_ts15Min, _window15Min);
        if (w > wait) { wait = w; reason = '15-min limit (${_ts15Min.length}/$_max15Min)'; }
      }
      if (_tsHour.length >= _maxHour) {
        final w = _waitNeeded(_tsHour, _windowHour);
        if (w > wait) { wait = w; reason = 'hourly limit (${_tsHour.length}/$_maxHour)'; }
      }
      if (_tsDay.length >= _maxDay) {
        final w = _waitNeeded(_tsDay, _windowDay);
        if (w > wait) { wait = w; reason = 'daily limit (${_tsDay.length}/$_maxDay)'; }
      }

      if (wait == Duration.zero) return;

      final mins = wait.inSeconds < 60
          ? '${wait.inSeconds}s'
          : '${wait.inMinutes}m ${wait.inSeconds % 60}s';

      debugPrint('[RateLimit] Hit $reason — waiting $mins');
      _updateNotif(
        'SMS Sender — Rate Limit',
        'Paused $mins ($reason). PTA anti-spam protection.',
      );

      await Future.delayed(wait);
    }
  }

  void recordSent() {
    final now = DateTime.now();
    _ts15Min.addLast(now);
    _tsHour.addLast(now);
    _tsDay.addLast(now);
  }

  String get stats =>
      '15min: ${_ts15Min.length}/$_max15Min  '
      '1hr: ${_tsHour.length}/$_maxHour  '
      '24hr: ${_tsDay.length}/$_maxDay';
}

// ─────────────────────────────────────────────────────────────
// PENDING WATCHER
// ─────────────────────────────────────────────────────────────
// Watches the school's requests collection in real time.
// The moment a document with status == 'pending' appears, it
// calls onPendingDetected() — which is debounced so rapid
// Firestore events don't spawn concurrent send cycles.
// ─────────────────────────────────────────────────────────────

class _PendingWatcher {
  final String   schoolId;
  final VoidCallback onPendingDetected;

  StreamSubscription? _sub;
  Timer?              _debounce;

  _PendingWatcher({required this.schoolId, required this.onPendingDetected});

  void start() {
    final query = FirebaseFirestore.instance
        .collection('schools')
        .doc(schoolId)
        .collection('sms_requests')
        .where('status', isEqualTo: 'pending')
        .limit(1); // We only need to know IF there's at least one

    _sub = query.snapshots().listen((snap) {
      if (snap.docs.isEmpty) return; // no pending — nothing to do

      // Debounce: wait 800 ms before triggering so rapid consecutive
      // Firestore writes don't fire many concurrent cycles.
      _debounce?.cancel();
      _debounce = Timer(const Duration(milliseconds: 800), () {
        debugPrint('[Watcher] 🔔 Pending request detected — triggering cycle');
        onPendingDetected();
      });
    }, onError: (e) {
      debugPrint('[Watcher] Stream error: $e');
    });

    debugPrint('[Watcher] Started watching $schoolId for pending requests');
  }

  void stop() {
    _debounce?.cancel();
    _sub?.cancel();
    _sub = null;
    debugPrint('[Watcher] Stopped');
  }
}

// ─────────────────────────────────────────────────────────────
// PUBLIC INIT
// ─────────────────────────────────────────────────────────────
Future<void> initBackgroundService() async {
  final service = FlutterBackgroundService();

  final notif = FlutterLocalNotificationsPlugin();
  await notif.initialize(const InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
  ));
  await notif
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(const AndroidNotificationChannel(
        kNotifChannelId,
        kNotifChannelName,
        description: 'Shows SMS sending progress',
        importance: Importance.low,
      ));

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart:                    onBgStart,
      isForegroundMode:           true,
      notificationChannelId:      kNotifChannelId,
      initialNotificationTitle:   'SMS Sender',
      initialNotificationContent: 'Waiting for requests…',
      foregroundServiceNotificationId: kForegroundNotifId,
      autoStart: true,
    ),
    iosConfiguration: IosConfiguration(
      autoStart:    true,
      onForeground: onBgStart,
      onBackground: _iosBackground,
    ),
  );

  await service.startService();
}

@pragma('vm:entry-point')
Future<bool> _iosBackground(ServiceInstance service) async {
  WidgetsFlutterBinding.ensureInitialized();
  return true;
}

// ─────────────────────────────────────────────────────────────
// BACKGROUND ENTRY POINT
// ─────────────────────────────────────────────────────────────
@pragma('vm:entry-point')
Future<void> onBgStart(ServiceInstance service) async {
  WidgetsFlutterBinding.ensureInitialized();
  // The background isolate runs on a separate Flutter engine. Firebase.apps
  // may appear empty from Dart's side even though Firebase is already
  // initialised at the native (Java) level — so initializeApp() throws
  // "FirebaseApp name [DEFAULT] already exists!".  Catch and ignore that
  // specific case so the service doesn't crash before it can do any work.
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  } catch (e) {
    // Ignore "already exists" — Firebase is already ready on this engine.
    debugPrint('[BG] Firebase.initializeApp skipped: $e');
  }

  final notif = FlutterLocalNotificationsPlugin();

  void updateNotif(String title, String body) {
    notif.show(
      kForegroundNotifId,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          kNotifChannelId,
          kNotifChannelName,
          channelDescription: 'SMS Sender background service',
          importance: Importance.low,
          priority:   Priority.low,
          ongoing:    true,
          icon:       '@mipmap/ic_launcher',
        ),
      ),
    );
  }

  final rateLimiter = _PtaRateLimiter(updateNotif);

  service.on('stopService').listen((_) => service.stopSelf());
  updateNotif('SMS Sender', 'Running — waiting for requests…');

  // ── Cycle lock: prevents concurrent cycles ──────────────────────────────
  bool _cycleRunning = false;

  Future<void> safeCycle() async {
    if (_cycleRunning) {
      debugPrint('[BG] Cycle already running — skipping trigger');
      return;
    }
    _cycleRunning = true;
    try {
      await _runCycle(service, updateNotif, rateLimiter);
    } finally {
      _cycleRunning = false;
    }
  }

  // ── Get schoolId and start watcher ──────────────────────────────────────
  final prefs    = await SharedPreferences.getInstance();
  final schoolId = prefs.getString(kPrefSchoolId);

  _PendingWatcher? watcher;

  if (schoolId != null && schoolId.isNotEmpty) {
    watcher = _PendingWatcher(
      schoolId:          schoolId,
      onPendingDetected: () => safeCycle(),
    );
    watcher.start();
  } else {
    debugPrint('[BG] No schoolId stored — watcher not started');
  }

  // ── Stop listener ────────────────────────────────────────────────────────
  service.on('stopService').listen((_) {
    watcher?.stop();
    service.stopSelf();
  });

  // ── Periodic safety-net (every 30 s) ────────────────────────────────────
  // This catches any requests that might be missed due to connectivity
  // blips or Firestore snapshot delivery delays.
  Timer.periodic(const Duration(seconds: 30), (_) => safeCycle());

  // ── Run immediately on start ─────────────────────────────────────────────
  await safeCycle();
}

// ─────────────────────────────────────────────────────────────
// SEND SMS via main isolate
// ─────────────────────────────────────────────────────────────
Future<bool> _sendSmsViaMainIsolate(
  ServiceInstance service, {
  required String phoneNumber,
  required String message,
  required String requestId,
  required String studentName,
}) async {
  service.invoke('sendSms', {
    'phoneNumber': phoneNumber,
    'message':     message,
    'requestId':   requestId,
    'studentName': studentName,
  });

  final completer = Completer<bool>();
  StreamSubscription? sub;

  sub = service.on('smsResult').listen((data) {
    if (data == null) return;
    if (data['requestId'] != requestId) return;
    sub?.cancel();
    if (!completer.isCompleted) {
      completer.complete(data['success'] == true);
    }
  });

  Future.delayed(const Duration(seconds: 15), () {
    sub?.cancel();
    if (!completer.isCompleted) {
      completer.completeError('SMS timeout for $phoneNumber');
    }
  });

  return completer.future;
}

// ─────────────────────────────────────────────────────────────
// ONE POLL CYCLE
// ─────────────────────────────────────────────────────────────
Future<void> _runCycle(
  ServiceInstance service,
  void Function(String, String) updateNotif,
  _PtaRateLimiter rateLimiter,
) async {
  try {
    final prefs    = await SharedPreferences.getInstance();
    final schoolId = prefs.getString(kPrefSchoolId);
    if (schoolId == null || schoolId.isEmpty) return;

    final deleted = await FirebaseRequestService.deleteExpired(schoolId);
    if (deleted > 0) debugPrint('[BG] Deleted $deleted expired requests');

    final pending = await FirebaseRequestService.fetchPending(schoolId);
    if (pending.isEmpty) {
      updateNotif('SMS Sender', 'Running — no pending requests.');
      service.invoke('status', {'pending': 0, 'sent': 0, 'failed': 0});
      return;
    }

    debugPrint('[BG] Found ${pending.length} pending request(s)');
    updateNotif('SMS Sender', 'Sending SMS to ${pending.length} student(s)…');

    int sent = 0, failed = 0;

    for (int i = 0; i < pending.length; i++) {
      final req = pending[i];

      // ── Rate limit check — waits here if any window is full ──────────────
      await rateLimiter.waitForSlot();
      debugPrint('[RateLimit] Slot OK — ${rateLimiter.stats}');

      updateNotif(
        'SMS Sender',
        'Sending ${i + 1}/${pending.length}: ${req.studentName}…',
      );

      await FirebaseRequestService.markProcessing(schoolId, req.id);

      try {
        final ok = await _sendSmsViaMainIsolate(
          service,
          phoneNumber:  req.parentPhone,
          message:      await req.buildSmsBody(),
          requestId:    req.id,
          studentName:  req.studentName,
        );

        if (ok) {
          // ── 1. Record in rate-limiter windows ────────────────────────────
          rateLimiter.recordSent();

          // ── 2. Mark LOCALLY as sent (in-memory counter) ──────────────────
          debugPrint('[BG] ✅ Locally marked sent: ${req.studentName} | ${rateLimiter.stats}');
          sent++;

          // ── 3. Wait exactly 10 seconds before the next send ───────────────
          if (i < pending.length - 1) {
            updateNotif(
              'SMS Sender',
              'Sent ${req.studentName} — waiting ${kInterMessageDelay.inSeconds}s before next…',
            );
            debugPrint('[BG] ⏱  Waiting ${kInterMessageDelay.inSeconds}s before next SMS…');
            await Future.delayed(kInterMessageDelay);
          }

          // ── 4. Persist to Firebase ────────────────────────────────────────
          await FirebaseRequestService.markSent(schoolId, req.id);

        } else {
          await FirebaseRequestService.markFailed(
              schoolId, req.id, 'SmsManager returned false');
          debugPrint('[BG] ❌ Failed: ${req.studentName}');
          failed++;

          if (i < pending.length - 1) {
            await Future.delayed(kInterMessageDelay);
          }
        }
      } catch (e) {
        await FirebaseRequestService.markFailed(
            schoolId, req.id, e.toString());
        debugPrint('[BG] ❌ Exception for ${req.studentName}: $e');
        failed++;

        if (i < pending.length - 1) {
          await Future.delayed(kInterMessageDelay);
        }
      }
    }

    updateNotif(
      'SMS Sender',
      'Done — $sent sent, $failed failed. Watching for new requests…',
    );
    service.invoke('status', {'pending': 0, 'sent': sent, 'failed': failed});
    debugPrint('[BG] Cycle complete — sent=$sent failed=$failed | ${rateLimiter.stats}');

  } catch (e, stack) {
    debugPrint('[BG] Cycle error: $e\n$stack');
    updateNotif('SMS Sender', 'Error in background cycle — retrying…');
  }
}

// ─────────────────────────────────────────────────────────────
// HELPERS called from UI
// ─────────────────────────────────────────────────────────────
Future<void> startBackgroundService() async {
  final svc = FlutterBackgroundService();
  if (!await svc.isRunning()) await svc.startService();
}

Future<void> stopBackgroundService() async {
  FlutterBackgroundService().invoke('stopService');
}

Future<bool> isBackgroundServiceRunning() =>
    FlutterBackgroundService().isRunning();