// lib/models/message_request.dart  (SMS Sender app)
//
// Firestore path:  schools/{schoolId}/sms_requests/{docId}
//
// buildSmsBody() loads the saved template and fills in all placeholders:
//   {schoolName}, {studentName}, {rollNo}, {class}, {section}, {date},
//   {lateMinutes}
//
// {lateMinutes} is only populated for late students and is stored on the
// Firestore request document as the integer field 'lateMinutes'.
// In the SMS body it renders as the plain number, e.g.:
//   "Your child arrived {lateMinutes} minutes late."  →  "… 10 minutes late."
// For absent students the placeholder is replaced with '' so any accidental
// use in the absent template is silently removed.
// ─────────────────────────────────────────────────────────────────────────────

import 'package:cloud_firestore/cloud_firestore.dart';
import '../screens/template_settings_screen.dart'
    show loadAbsentTemplate, loadLateTemplate, fillTemplate;

enum SmsStatus { pending, processing, sent, failed }

class MessageRequest {
  final String    id;
  final String    schoolId;
  final String    schoolName;
  final String    studentName;
  final String    rollNo;
  final String    parentPhone;
  final String    attendanceStatus; // 'absent' | 'late'
  final String    className;        // e.g. "10th A"
  final String    section;          // e.g. "A"
  final String    date;             // e.g. "4 May 2026"
  final SmsStatus smsStatus;
  final bool      processed;
  final DateTime  createdAt;
  final String?   errorMsg;

  /// Minutes the student arrived late.
  /// Only non-null when [attendanceStatus] == 'late'.
  final int?      lateMinutes;

  const MessageRequest({
    required this.id,
    required this.schoolId,
    required this.schoolName,
    required this.studentName,
    required this.rollNo,
    required this.parentPhone,
    required this.attendanceStatus,
    required this.className,
    required this.section,
    required this.date,
    required this.smsStatus,
    required this.processed,
    required this.createdAt,
    this.errorMsg,
    this.lateMinutes,
  });

  factory MessageRequest.fromDoc(DocumentSnapshot doc) {
    final m = doc.data() as Map<String, dynamic>;
    return MessageRequest(
      id:               doc.id,
      schoolId:         m['schoolId']          ?? '',
      schoolName:       m['schoolName']         ?? '',
      studentName:      m['studentName']        ?? '',
      rollNo:           m['rollNo']             ?? '',
      parentPhone:      m['parentPhone']        ?? '',
      attendanceStatus: m['attendanceStatus']   ?? 'absent',
      className:        m['className']          ?? '',
      section:          m['section']            ?? '',
      date:             m['date']               ?? '',
      smsStatus:        _parseStatus(m['smsStatus'] as String?),
      processed:        m['processed']          ?? false,
      createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      errorMsg:         m['errorMsg']           as String?,
      // Stored as int in Firestore; absent for non-late records → null.
      lateMinutes:      (m['lateMinutes'] as num?)?.toInt(),
    );
  }

  static SmsStatus _parseStatus(String? s) {
    switch (s) {
      case 'processing': return SmsStatus.processing;
      case 'sent':       return SmsStatus.sent;
      case 'failed':     return SmsStatus.failed;
      default:           return SmsStatus.pending;
    }
  }

  /// Builds the SMS text body by loading the saved template and substituting
  /// all placeholders. Falls back to hard-coded defaults if prefs are empty.
  Future<String> buildSmsBody() async {
    final template = attendanceStatus == 'late'
        ? await loadLateTemplate()
        : await loadAbsentTemplate();

    return fillTemplate(
      template,
      schoolName:  schoolName,
      studentName: studentName,
      rollNo:      rollNo,
      className:   className,
      section:     section,
      date:        date,
      // Pass the actual value for late students; null for absent (will be
      // replaced with '' so the placeholder disappears from absent SMSes).
      lateMinutes: lateMinutes,
    );
  }
}
