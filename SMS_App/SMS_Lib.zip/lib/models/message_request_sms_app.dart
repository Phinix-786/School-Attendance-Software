// lib/models/message_request.dart
//
// MessageRequest model for the SMS sender app.
//
// KEY CHANGE: buildSmsBody() no longer uses a hardcoded template.
// It fetches the school's template from Firebase at:
//   schools/{schoolId}/config/sms_template
//
// The HQ app writes to exactly this path via TemplateScreen.
// Templates are cached in memory for the lifetime of the isolate
// so we don't hit Firestore on every single SMS.
//
// Available placeholders in templates (set from HQ):
//   {studentName}      {rollNo}     {className}
//   {section}          {schoolName} {attendanceStatus}
//   {date}             {time}
//   {lateMinutes}      ← minutes late; only populated for late students
//                        (blank string substituted for absent students)

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── SMS Status enum ────────────────────────────────────────────────────────

enum SmsStatus { pending, processing, sent, failed }

SmsStatus _parseSmsStatus(String? s) {
  switch (s) {
    case 'processing': return SmsStatus.processing;
    case 'sent':       return SmsStatus.sent;
    case 'failed':     return SmsStatus.failed;
    default:           return SmsStatus.pending;
  }
}

// ── In-memory template cache ──────────────────────────────────────────────
// Shared across all MessageRequest instances in the same isolate.
// Key: schoolId, Value: {absentTemplate, lateTemplate}

final Map<String, Map<String, String>> _templateCache = {};

Future<Map<String, String>> _fetchTemplates(String schoolId) async {
  if (_templateCache.containsKey(schoolId)) return _templateCache[schoolId]!;

  try {
    final doc = await FirebaseFirestore.instance
        .doc('schools/$schoolId/config/sms_template')
        .get();

    if (doc.exists && doc.data() != null) {
      final data = doc.data()!;
      final entry = {
        'absent': (data['absentTemplate'] as String?) ?? _fallbackAbsent,
        'late':   (data['lateTemplate']   as String?) ?? _fallbackLate,
      };
      _templateCache[schoolId] = entry;
      return entry;
    }
  } catch (e) {
    // If Firestore fetch fails, fall back to defaults below
  }

  // Fallback if template not yet created in Firebase
  final fallback = {
    'absent': _fallbackAbsent,
    'late':   _fallbackLate,
  };
  _templateCache[schoolId] = fallback;
  return fallback;
}

// ── Plain-text fallbacks (used only if Firebase template is missing) ───────

const _fallbackAbsent =
    'Dear Parent, your child {studentName} (Roll: {rollNo}, '
    '{className}-{section}) was ABSENT today ({date}). '
    'Please contact the school.';

// Default late template now includes {lateMinutes}.
const _fallbackLate =
    'Dear Parent, your child {studentName} (Roll: {rollNo}, '
    '{className}-{section}) arrived {lateMinutes} minutes late today '
    '({date} at {time}). Please ensure punctuality.';

// ── MessageRequest ─────────────────────────────────────────────────────────

class MessageRequest {
  final String    id;
  final String    studentName;
  final String    rollNo;
  final String    className;
  final String    section;
  final String    parentPhone;
  final String    attendanceStatus; // 'absent' | 'late'
  final SmsStatus smsStatus;
  final String?   errorMsg;
  final DateTime  createdAt;
  final bool      processed;

  /// Minutes the student arrived late.
  /// Only non-null when [attendanceStatus] == 'late'.
  final int?      lateMinutes;

  const MessageRequest({
    required this.id,
    required this.studentName,
    required this.rollNo,
    required this.className,
    required this.section,
    required this.parentPhone,
    required this.attendanceStatus,
    this.smsStatus  = SmsStatus.pending,
    this.errorMsg,
    required this.createdAt,
    this.processed  = false,
    this.lateMinutes,
  });

  // ── Build SMS body by fetching template from Firebase ───────────────────

  Future<String> buildSmsBody() async {
    // Get schoolId from shared preferences (stored at login)
    final prefs    = await SharedPreferences.getInstance();
    final schoolId = prefs.getString('schoolId') ?? '';

    final templates = await _fetchTemplates(schoolId);
    final raw = attendanceStatus == 'absent'
        ? templates['absent']!
        : templates['late']!;

    return _fillPlaceholders(raw);
  }

  String _fillPlaceholders(String raw) {
    final now = DateTime.now();
    return raw
        .replaceAll('{studentName}',      studentName)
        .replaceAll('{rollNo}',           rollNo)
        .replaceAll('{className}',        className)
        .replaceAll('{section}',          section)
        .replaceAll('{attendanceStatus}', attendanceStatus)
        .replaceAll('{schoolName}',       '') // filled by template text itself
        .replaceAll('{date}',             DateFormat('dd MMM yyyy').format(now))
        .replaceAll('{time}',             DateFormat('hh:mm a').format(now))
        // Replace with the number of minutes, or '' for absent students.
        .replaceAll('{lateMinutes}',
            lateMinutes != null ? '$lateMinutes' : '');
  }

  // ── Serialisation ────────────────────────────────────────────────────────

  factory MessageRequest.fromMap(String id, Map<String, dynamic> map) {
    return MessageRequest(
      id:               id,
      studentName:      map['studentName']      as String? ?? '',
      rollNo:           map['rollNo']           as String? ?? '',
      className:        map['className']        as String? ?? '',
      section:          map['section']          as String? ?? '',
      parentPhone:      map['parentPhone']      as String? ?? '',
      attendanceStatus: map['attendanceStatus'] as String? ?? 'absent',
      smsStatus:        _parseSmsStatus(map['status'] as String?),
      errorMsg:         map['errorMsg']         as String?,
      createdAt:        map['createdAt'] != null
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
      processed:        map['processed']        as bool? ?? false,
      // Stored as int in Firestore; absent for non-late records → null.
      lateMinutes:      (map['lateMinutes'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toMap() => {
        'studentName':      studentName,
        'rollNo':           rollNo,
        'className':        className,
        'section':          section,
        'parentPhone':      parentPhone,
        'attendanceStatus': attendanceStatus,
        'status':           smsStatus.name,
        'errorMsg':         errorMsg,
        'createdAt':        Timestamp.fromDate(createdAt),
        'processed':        processed,
        // Only write lateMinutes when the student is actually late so the
        // field is absent (not null) for present/absent records.
        if (lateMinutes != null) 'lateMinutes': lateMinutes,
      };
}
