// lib/models/global_settings.dart

class GlobalSettings {
  final double metaRate;         // Cost per message from Meta (your cost)
  final double sellingRate;      // Price charged to schools per message
  final double lowWalletThreshold; // Alert principal when wallet < this
  final String nightlyCheckTime; // "HH:mm" 24h format, e.g. "00:00"
  final int warningDaysBeforeExpiry;
  final int gracePeriodDays;
  final String adminEmail;

  const GlobalSettings({
    this.metaRate = 2.80,
    this.sellingRate = 3.20,
    this.lowWalletThreshold = 500.0,
    this.nightlyCheckTime = '00:00',
    this.warningDaysBeforeExpiry = 5,
    this.gracePeriodDays = 1,
    this.adminEmail = '',
  });

  Map<String, dynamic> toMap() => {
        'metaRate': metaRate,
        'sellingRate': sellingRate,
        'lowWalletThreshold': lowWalletThreshold,
        'nightlyCheckTime': nightlyCheckTime,
        'warningDaysBeforeExpiry': warningDaysBeforeExpiry,
        'gracePeriodDays': gracePeriodDays,
        'adminEmail': adminEmail,
      };

  factory GlobalSettings.fromMap(Map<String, dynamic> map) => GlobalSettings(
        metaRate: (map['metaRate'] ?? 2.80).toDouble(),
        sellingRate: (map['sellingRate'] ?? 3.20).toDouble(),
        lowWalletThreshold: (map['lowWalletThreshold'] ?? 500.0).toDouble(),
        nightlyCheckTime: map['nightlyCheckTime'] ?? '00:00',
        warningDaysBeforeExpiry: (map['warningDaysBeforeExpiry'] ?? 5).toInt(),
        gracePeriodDays: (map['gracePeriodDays'] ?? 1).toInt(),
        adminEmail: map['adminEmail'] ?? '',
      );

  static GlobalSettings get defaults => const GlobalSettings();
}