// lib/models/sms_template.dart
//
// Represents the SMS template stored per-school in Firebase at:
//   schools/{schoolId}/config/sms_template
//
// Available placeholders (replaced at send-time by the SMS app):
//   {{studentName}}     — student's full name
//   {{rollNo}}          — roll number
//   {{className}}       — class / grade
//   {{section}}         — section label
//   {{attendanceStatus}} — "absent" or "late"
//   {{schoolName}}      — school name
//   {{date}}            — today's date  (dd MMM yyyy)
//   {{time}}            — current time  (hh:mm a)

import 'package:cloud_firestore/cloud_firestore.dart';

class SmsTemplate {
  final String schoolId;
  final String absentTemplate;
  final String lateTemplate;
  final DateTime updatedAt;

  SmsTemplate({
    required this.schoolId,
    required this.absentTemplate,
    required this.lateTemplate,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  // ── Default templates auto-created when a school is first registered ───────

  static String defaultAbsent(String schoolName) =>
      '{schoolName}\n'
      '\n'
      'Dear Parent/Guardian,\n'
      '\n'
      'Your child, {studentName} (Roll No: {rollNo}), of Class {className} – Section {section}, '
      'has been marked ABSENT for today, {date}.\n'
      '\n'
      'Regular attendance is essential for your child\'s academic progress '
      'and overall development. Consistent absences can significantly '
      'impact their learning and performance.\n'
      '\n'
      'If you have already informed the school about this absence or if '
      'this notification has reached you in error, please disregard '
      'this message.\n'
      '\n'
      'This is an automated notification from {schoolName}.\n'
      '\n'
      'Thank You';

  static String defaultLate(String schoolName) =>
      '{schoolName}\n'
      '\n'
      'Dear Parent/Guardian,\n'
      '\n'
      'Your child, {studentName} (Roll No: {rollNo}), of Class {className} – Section {section}, '
      'has been marked LATE for today, {date}.\n'
      '\n'
      'If you have already provided a reason for this delay or if this '
      'notification has reached you in error, please disregard this message.\n'
      '\n'
      'This is an automated notification from {schoolName}.\n'
      '\n'
      'Thank You';

  // ── Firestore path ─────────────────────────────────────────────────────────

  static String docPath(String schoolId) =>
      'schools/$schoolId/config/sms_template';

  // ── Serialisation ──────────────────────────────────────────────────────────

  Map<String, dynamic> toMap() => {
        'schoolId': schoolId,
        'absentTemplate': absentTemplate,
        'lateTemplate': lateTemplate,
        'updatedAt': Timestamp.fromDate(updatedAt),
      };

  factory SmsTemplate.fromMap(String schoolId, Map<String, dynamic> map) =>
      SmsTemplate(
        schoolId: schoolId,
        absentTemplate: map['absentTemplate'] as String? ?? '',
        lateTemplate: map['lateTemplate'] as String? ?? '',
        updatedAt: map['updatedAt'] != null
            ? (map['updatedAt'] as Timestamp).toDate()
            : DateTime.now(),
      );

  SmsTemplate copyWith({String? absentTemplate, String? lateTemplate}) =>
      SmsTemplate(
        schoolId: schoolId,
        absentTemplate: absentTemplate ?? this.absentTemplate,
        lateTemplate: lateTemplate ?? this.lateTemplate,
      );
}