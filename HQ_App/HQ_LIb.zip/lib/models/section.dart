// lib/models/section.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class Section {
  final String id;
  final String name;
  final String password;
  final DateTime createdAt;

  Section({
    required this.id,
    required this.name,
    required this.password,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'password': password,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }

  factory Section.fromMap(Map<String, dynamic> map) {
    return Section(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      password: map['password'] ?? '',
      createdAt: map['createdAt'] != null
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
    );
  }
}
