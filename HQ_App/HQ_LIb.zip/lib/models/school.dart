// lib/models/school.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class School {
  final String id;
  final String name;
  final String principalName;
  final String principalPhone;
  final String logoUrl;
  final DateTime subscriptionExpiry;
  final bool isActive;
  final DateTime createdAt;
  final String adminPassword;
  final String? city;
  final int? totalStudents;
  final String subscriptionPlan;
  final int? customSubscriptionDays;
  final double monthlyFee;
  final DateTime subscriptionStartDate;
  final String notes;

  School({
    required this.id,
    required this.name,
    required this.principalName,
    required this.principalPhone,
    this.logoUrl = '',
    required this.subscriptionExpiry,
    this.isActive = true,
    required this.createdAt,
    this.adminPassword = '',
    this.city,
    this.totalStudents,
    this.subscriptionPlan = '1month',
    this.customSubscriptionDays,
    this.monthlyFee = 10500,
    DateTime? subscriptionStartDate,
    this.notes = '',
  }) : subscriptionStartDate = subscriptionStartDate ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'principalName': principalName,
      'principalPhone': principalPhone,
      'logoUrl': logoUrl,
      'subscriptionExpiry': Timestamp.fromDate(subscriptionExpiry),
      'isActive': isActive,
      'createdAt': Timestamp.fromDate(createdAt),
      'adminPassword': adminPassword,
      'city': city,
      'totalStudents': totalStudents,
      'subscriptionPlan': subscriptionPlan,
      'customSubscriptionDays': customSubscriptionDays,
      'monthlyFee': monthlyFee,
      'subscriptionStartDate': Timestamp.fromDate(subscriptionStartDate),
      'notes': notes,
    };
  }

  factory School.fromMap(Map<String, dynamic> map) {
    return School(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      principalName: map['principalName'] ?? '',
      principalPhone: map['principalPhone'] ?? '',
      logoUrl: map['logoUrl'] ?? '',
      subscriptionExpiry: map['subscriptionExpiry'] != null
          ? (map['subscriptionExpiry'] as Timestamp).toDate()
          : DateTime.now().add(const Duration(days: 30)),
      isActive: map['isActive'] ?? true,
      createdAt: map['createdAt'] != null
          ? (map['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
      adminPassword: map['adminPassword'] ?? '',
      city: map['city'],
      totalStudents: map['totalStudents'],
      subscriptionPlan: map['subscriptionPlan'] ?? '1month',
      customSubscriptionDays: map['customSubscriptionDays'],
      monthlyFee: (map['monthlyFee'] ?? 10500).toDouble(),
      subscriptionStartDate: map['subscriptionStartDate'] != null
          ? (map['subscriptionStartDate'] as Timestamp).toDate()
          : DateTime.now(),
      notes: map['notes'] ?? '',
    );
  }

  School copyWith({
    String? name,
    String? principalName,
    String? principalPhone,
    String? logoUrl,
    DateTime? subscriptionExpiry,
    bool? isActive,
    String? adminPassword,
    String? city,
    int? totalStudents,
    String? subscriptionPlan,
    int? customSubscriptionDays,
    double? monthlyFee,
    DateTime? subscriptionStartDate,
    String? notes,
  }) {
    return School(
      id: id,
      name: name ?? this.name,
      principalName: principalName ?? this.principalName,
      principalPhone: principalPhone ?? this.principalPhone,
      logoUrl: logoUrl ?? this.logoUrl,
      subscriptionExpiry: subscriptionExpiry ?? this.subscriptionExpiry,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      adminPassword: adminPassword ?? this.adminPassword,
      city: city ?? this.city,
      totalStudents: totalStudents ?? this.totalStudents,
      subscriptionPlan: subscriptionPlan ?? this.subscriptionPlan,
      customSubscriptionDays: customSubscriptionDays ?? this.customSubscriptionDays,
      monthlyFee: monthlyFee ?? this.monthlyFee,
      subscriptionStartDate: subscriptionStartDate ?? this.subscriptionStartDate,
      notes: notes ?? this.notes,
    );
  }

  int get daysUntilExpiry =>
      subscriptionExpiry.difference(DateTime.now()).inDays;
  bool get isExpiringSoon => daysUntilExpiry <= 5 && daysUntilExpiry >= 0;
  bool get isExpired => DateTime.now().isAfter(subscriptionExpiry);
}
