// lib/services/broadcast_service.dart (HQ app)
//
// Firestore layout for messaging:
//   schools/{schoolId}/hq_messages/{messageId}
//     type: 'notification' | 'notice'
//     message: String
//     version: String?       (only for update notices, sent by updater)
//     createdAt: Timestamp
//
// School app listens to this collection, shows message, then DELETES it.
// Nothing is kept after the user dismisses or after it auto-expires.

import 'package:cloud_firestore/cloud_firestore.dart';

class BroadcastService {
  static final _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> _col(String schoolId) =>
      _db.collection('schools/$schoolId/hq_messages');

  /// Send a Windows notification (toast-style) to a specific school.
  static Future<void> sendNotification({
    required String schoolId,
    required String message,
  }) async {
    await _col(schoolId).add({
      'type':      'notification',
      'message':   message,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Send a notice board message to a specific school.
  static Future<void> sendNotice({
    required String schoolId,
    required String message,
  }) async {
    await _col(schoolId).add({
      'type':      'notice',
      'message':   message,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  /// Send an update-available notice (called by updater pipeline, not HQ UI).
  static Future<void> sendUpdateNotice({
    required String schoolId,
    required String version,
  }) async {
    await _col(schoolId).add({
      'type':      'update',
      'message':   'New update available — version $version',
      'version':   version,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }
}