import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/school.dart';
import '../models/section.dart';
import '../models/global_settings.dart';
import '../models/sms_template.dart';

class FirebaseService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ── Schools ───────────────────────────────────────────────────────────────

  static Future<void> addSchool(School school) async {
    await _db.collection('schools').doc(school.id).set(school.toMap());
  }

  /// Creates a school and writes all sections in a single batch.
  static Future<void> addSchoolWithSections(
    School school,
    List<Section> sections,
  ) async {
    final batch = _db.batch();
    final schoolRef = _db.collection('schools').doc(school.id);
    batch.set(schoolRef, school.toMap());
    for (final section in sections) {
      final sectionRef = schoolRef.collection('sections').doc(section.id);
      batch.set(sectionRef, section.toMap());
    }
    await batch.commit();
  }

  // ── Sections ──────────────────────────────────────────────────────────────

  static Future<void> addSection(String schoolId, Section section) async {
    await _db
        .collection('schools')
        .doc(schoolId)
        .collection('sections')
        .doc(section.id)
        .set(section.toMap());
  }

  static Future<void> deleteSection(String schoolId, String sectionId) async {
    await _db
        .collection('schools')
        .doc(schoolId)
        .collection('sections')
        .doc(sectionId)
        .delete();
  }

  static Stream<List<Section>> sectionsStream(String schoolId) {
    return _db
        .collection('schools')
        .doc(schoolId)
        .collection('sections')
        .orderBy('createdAt')
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => Section.fromMap(d.data())).toList());
  }

  static Future<void> updateSchool(School school) async {
    await _db.collection('schools').doc(school.id).update(school.toMap());
  }

  // ── Deep-delete a school (all subcollections + the doc itself) ───────────
  //
  // Firestore does NOT cascade-delete subcollections when a parent doc is
  // deleted.  We must walk every known subcollection path and delete every
  // document before deleting the school document itself.
  //
  // Known tree (mirrors the app's Firestore schema):
  //   schools/{id}/
  //     sections/{sid}/
  //       classes/{cid}/
  //         students/{*}
  //         teachers/{*}
  //         homeworks/{*}
  //         tests/{tid}/results/{*}
  //         class_messages/{*}
  //         cross_chat_requests/{*}
  //         cross_class_chats/{chatId}/messages/{*}
  //       teachers/{*}
  //       attendance_sessions/{sessId}/records/{*}
  //       timetables/{*}
  //       notices/{*}
  //       leaves/{*}
  //       teacher_parent_chats/{chatId}/messages/{*}
  //     sms_requests/{*}
  //     notification_logs/{*}
  //     config/{*}
  //
  static Future<void> deleteSchoolDeep(String schoolId) async {
    final schoolRef = _db.collection('schools').doc(schoolId);

    // 1. Walk sections
    final sections = await schoolRef.collection('sections').get();
    for (final secDoc in sections.docs) {
      final secRef = secDoc.reference;

      // 1a. Walk classes inside each section
      final classes = await secRef.collection('classes').get();
      for (final clsDoc in classes.docs) {
        final clsRef = clsDoc.reference;

        // students, teachers, homeworks, class_messages, cross_chat_requests
        for (final sub in [
          'students', 'teachers', 'homeworks',
          'class_messages', 'cross_chat_requests'
        ]) {
          await _deleteCollection(clsRef.collection(sub));
        }

        // tests → each test has a results subcollection
        final tests = await clsRef.collection('tests').get();
        for (final testDoc in tests.docs) {
          await _deleteCollection(testDoc.reference.collection('results'));
          await testDoc.reference.delete();
        }

        // cross_class_chats → each chat has a messages subcollection
        final chats = await clsRef.collection('cross_class_chats').get();
        for (final chatDoc in chats.docs) {
          await _deleteCollection(chatDoc.reference.collection('messages'));
          await chatDoc.reference.delete();
        }

        await clsDoc.reference.delete();
      }

      // 1b. Section-level subcollections
      final attSessions =
          await secRef.collection('attendance_sessions').get();
      for (final sessDoc in attSessions.docs) {
        await _deleteCollection(sessDoc.reference.collection('records'));
        await sessDoc.reference.delete();
      }

      final tpChats =
          await secRef.collection('teacher_parent_chats').get();
      for (final chatDoc in tpChats.docs) {
        await _deleteCollection(chatDoc.reference.collection('messages'));
        await chatDoc.reference.delete();
      }

      for (final sub in [
        'teachers', 'timetables', 'notices', 'leaves'
      ]) {
        await _deleteCollection(secRef.collection(sub));
      }

      await secDoc.reference.delete();
    }

    // 2. School-level subcollections
    for (final sub in [
      'sms_requests', 'notification_logs', 'config'
    ]) {
      await _deleteCollection(schoolRef.collection(sub));
    }

    // 3. Delete the school document itself
    await schoolRef.delete();
  }

  /// Deletes all documents in [col] in batches of 400.
  static Future<void> _deleteCollection(
      CollectionReference col) async {
    const batchSize = 400;
    while (true) {
      final snap = await col.limit(batchSize).get();
      if (snap.docs.isEmpty) break;
      final batch = _db.batch();
      for (final doc in snap.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
      if (snap.docs.length < batchSize) break;
    }
  }

  static Stream<List<School>> schoolsStream() {
    return _db
        .collection('schools')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => School.fromMap(d.data())).toList());
  }

  static Future<School?> getSchool(String schoolId) async {
    final doc = await _db.collection('schools').doc(schoolId).get();
    if (!doc.exists) return null;
    return School.fromMap(doc.data()!);
  }

  // ── Subscription & Access Control ─────────────────────────────────────────

  static Future<void> setSubscription(
    String schoolId,
    DateTime expiry,
    bool isActive,
  ) async {
    await _db.collection('schools').doc(schoolId).update({
      'subscriptionExpiry': Timestamp.fromDate(expiry),
      'isActive': isActive,
    });
  }

  static Future<void> toggleKillSwitch(String schoolId, bool isActive) async {
    await _db.collection('schools').doc(schoolId).update({
      'isActive': isActive,
    });
  }

  // ── Notification Logs ─────────────────────────────────────────────────────

  static Future<void> logNotification(
    String schoolId,
    String to,
    String message,
    bool success,
  ) async {
    await _db
        .collection('schools')
        .doc(schoolId)
        .collection('notification_logs')
        .add({
      'to': to,
      'message': message,
      'success': success,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  // ── Global Settings ───────────────────────────────────────────────────────

  static const String _settingsDocPath = 'hq_config/global_settings';

  static Stream<GlobalSettings> globalSettingsStream() {
    return _db
        .doc(_settingsDocPath)
        .snapshots()
        .map(
          (snap) => snap.exists && snap.data() != null
              ? GlobalSettings.fromMap(snap.data()!)
              : GlobalSettings.defaults,
        );
  }

  static Future<GlobalSettings> getGlobalSettings() async {
    final doc = await _db.doc(_settingsDocPath).get();
    if (!doc.exists || doc.data() == null) return GlobalSettings.defaults;
    return GlobalSettings.fromMap(doc.data()!);
  }

  static Future<void> saveGlobalSettings(GlobalSettings settings) async {
    await _db
        .doc(_settingsDocPath)
        .set(settings.toMap(), SetOptions(merge: true));
  }

  static Future<void> updateAdminPassword(String newPasswordHash) async {
    await _db.doc(_settingsDocPath).set({
      'adminPasswordHash': newPasswordHash,
    }, SetOptions(merge: true));
  }

  // ── SMS Templates ─────────────────────────────────────────────────────────

  /// Creates the default SMS template for a school (called on school creation).
  static Future<void> createDefaultTemplate(
      String schoolId, String schoolName) async {
    final tmpl = SmsTemplate(
      schoolId: schoolId,
      absentTemplate: SmsTemplate.defaultAbsent(schoolName),
      lateTemplate: SmsTemplate.defaultLate(schoolName),
    );
    await _db.doc(SmsTemplate.docPath(schoolId)).set(tmpl.toMap());
  }

  /// Fetches the template for one school; returns null if not yet created.
  static Future<SmsTemplate?> getTemplate(String schoolId) async {
    final doc = await _db.doc(SmsTemplate.docPath(schoolId)).get();
    if (!doc.exists || doc.data() == null) return null;
    return SmsTemplate.fromMap(schoolId, doc.data()!);
  }

  /// Live stream of a school's template.
  static Stream<SmsTemplate?> templateStream(String schoolId) {
    return _db.doc(SmsTemplate.docPath(schoolId)).snapshots().map((snap) {
      if (!snap.exists || snap.data() == null) return null;
      return SmsTemplate.fromMap(schoolId, snap.data()!);
    });
  }

  /// Saves (overwrites) the template for a school.
  static Future<void> saveTemplate(SmsTemplate template) async {
    await _db
        .doc(SmsTemplate.docPath(template.schoolId))
        .set(template.toMap());
  }
}
