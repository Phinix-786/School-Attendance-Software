// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/dashboard_screen.dart';

// ════════════════════════════════════════════════════════════
// IMPORTANT: Replace with your actual Firebase config below!
// Get these from Firebase Console → Project Settings → Web App
// ════════════════════════════════════════════════════════════
const firebaseOptions = FirebaseOptions(
  apiKey: 'your-api-key',
  authDomain: 'your-auth-domain',
  projectId: 'your-project-id',
  storageBucket: 'your-storage-bucket',
  messagingSenderId: 'your-messaging-sender-id',
  appId: 'your-app-id',
);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: firebaseOptions);
  runApp(const HQApp());
}

class HQApp extends StatelessWidget {
  const HQApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HQ Master Control',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F172A),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF0EA5E9),
          secondary: Color(0xFF38BDF8),
        ),
      ),
      home: const DashboardScreen(),
    );
  }
}
