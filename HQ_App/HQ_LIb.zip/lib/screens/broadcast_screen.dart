// lib/screens/broadcast_screen.dart  (HQ app)
//
// Step 1 — pick a school from the live list
// Step 2 — pick type: Notification or Notice Board
// Step 3 — type message and send
// Clean, dark-themed to match the existing HQ UI.

import 'package:flutter/material.dart';
import '../models/school.dart';
import '../services/firebase_service.dart';
import '../services/broadcast_service.dart';

class BroadcastScreen extends StatefulWidget {
  const BroadcastScreen({super.key});

  @override
  State<BroadcastScreen> createState() => _BroadcastScreenState();
}

class _BroadcastScreenState extends State<BroadcastScreen> {
  // ── State ─────────────────────────────────────────────────
  School? _selectedSchool;
  String  _type    = 'notification'; // 'notification' | 'notice'
  final   _msgCtrl = TextEditingController();
  bool    _sending = false;
  String? _feedback;

  @override
  void dispose() {
    _msgCtrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final school  = _selectedSchool;
    final message = _msgCtrl.text.trim();
    if (school == null || message.isEmpty || _sending) return;

    setState(() { _sending = true; _feedback = null; });

    try {
      if (_type == 'notification') {
        await BroadcastService.sendNotification(
          schoolId: school.id,
          message:  message,
        );
      } else {
        await BroadcastService.sendNotice(
          schoolId: school.id,
          message:  message,
        );
      }
      _msgCtrl.clear();
      setState(() {
        _feedback = '✓ Sent to ${school.name}';
        _sending  = false;
      });
      // Clear feedback after 3 s
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) setState(() => _feedback = null);
      });
    } catch (e) {
      setState(() {
        _feedback = '✗ Failed: $e';
        _sending  = false;
      });
    }
  }

  // ── Build ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Column(
        children: [
          // Top bar
          _topBar(),
          Expanded(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Left panel — school picker
                _schoolPickerPanel(),
                // Divider
                Container(width: 1, color: const Color(0xFF334155)),
                // Right panel — compose
                _composePanel(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _topBar() {
    return Container(
      height:  60,
      color:   const Color(0xFF1E293B),
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child:   const Row(
        children: [
          Icon(Icons.campaign_rounded, color: Color(0xFF38BDF8), size: 22),
          SizedBox(width: 10),
          Text(
            'Broadcast Message',
            style: TextStyle(
              color:      Colors.white,
              fontSize:   18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // ── School picker ─────────────────────────────────────────
  Widget _schoolPickerPanel() {
    return SizedBox(
      width: 300,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 20, 16, 10),
            child: Text(
              'STEP 1 — SELECT SCHOOL',
              style: TextStyle(
                color:         Color(0xFF38BDF8),
                fontSize:      10.5,
                fontWeight:    FontWeight.w700,
                letterSpacing: 1.0,
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<School>>(
              stream: FirebaseService.schoolsStream(),
              builder: (_, snap) {
                final schools = snap.data ?? [];
                if (schools.isEmpty) {
                  return const Center(
                    child: Text('No schools',
                        style: TextStyle(color: Color(0xFF64748B))),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4),
                  itemCount: schools.length,
                  itemBuilder: (_, i) {
                    final s        = schools[i];
                    final selected = _selectedSchool?.id == s.id;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedSchool = s),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 11),
                        decoration: BoxDecoration(
                          color: selected
                              ? const Color(0xFF0EA5E9).withValues(alpha: 0.15)
                              : const Color(0xFF1E293B),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: selected
                                ? const Color(0xFF38BDF8).withValues(alpha: 0.6)
                                : const Color(0xFF334155),
                          ),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 16,
                              backgroundColor: const Color(0xFF0EA5E9)
                                  .withValues(alpha: 0.2),
                              child: Text(
                                s.name[0],
                                style: const TextStyle(
                                  color:      Color(0xFF38BDF8),
                                  fontSize:   13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    s.name,
                                    style: TextStyle(
                                      color: selected
                                          ? Colors.white
                                          : const Color(0xFFCBD5E1),
                                      fontSize:   13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    s.id,
                                    style: const TextStyle(
                                      color:    Color(0xFF64748B),
                                      fontSize: 10.5,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            if (selected)
                              const Icon(Icons.check_circle_rounded,
                                  color: Color(0xFF38BDF8), size: 16),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ── Compose panel ─────────────────────────────────────────
  Widget _composePanel() {
    final schoolSelected = _selectedSchool != null;

    return Expanded(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(32, 28, 32, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Step 2 — type ───────────────────────────────
            const Text(
              'STEP 2 — MESSAGE TYPE',
              style: TextStyle(
                color:         Color(0xFF38BDF8),
                fontSize:      10.5,
                fontWeight:    FontWeight.w700,
                letterSpacing: 1.0,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _TypeCard(
                  icon:     Icons.notifications_rounded,
                  label:    'Notification',
                  subtitle: 'Windows toast — app must be open',
                  selected: _type == 'notification',
                  onTap:    () => setState(() => _type = 'notification'),
                ),
                const SizedBox(width: 14),
                _TypeCard(
                  icon:     Icons.campaign_rounded,
                  label:    'Notice Board',
                  subtitle: 'Banner on top of every screen',
                  selected: _type == 'notice',
                  onTap:    () => setState(() => _type = 'notice'),
                ),
              ],
            ),

            const SizedBox(height: 28),

            // ── Step 3 — message ────────────────────────────
            const Text(
              'STEP 3 — COMPOSE MESSAGE',
              style: TextStyle(
                color:         Color(0xFF38BDF8),
                fontSize:      10.5,
                fontWeight:    FontWeight.w700,
                letterSpacing: 1.0,
              ),
            ),
            const SizedBox(height: 12),

            // Target school chip
            if (_selectedSchool != null) ...[
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color:        const Color(0xFF0EA5E9).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border:       Border.all(
                      color: const Color(0xFF38BDF8).withValues(alpha: 0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.school_rounded,
                        color: Color(0xFF38BDF8), size: 14),
                    const SizedBox(width: 6),
                    Text(
                      'To: ${_selectedSchool!.name}',
                      style: const TextStyle(
                        color:      Color(0xFF38BDF8),
                        fontSize:   12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ] else ...[
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color:        const Color(0xFFF59E0B).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border:       Border.all(
                      color: const Color(0xFFF59E0B).withValues(alpha: 0.3)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.warning_amber_rounded,
                        color: Color(0xFFF59E0B), size: 14),
                    SizedBox(width: 6),
                    Text(
                      'Select a school first',
                      style: TextStyle(
                        color:      Color(0xFFF59E0B),
                        fontSize:   12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ],

            // Message field
            Expanded(
              child: TextField(
                controller: _msgCtrl,
                enabled:    schoolSelected,
                maxLines:   null,
                expands:    true,
                textAlignVertical: TextAlignVertical.top,
                style: const TextStyle(
                    color: Colors.white, fontSize: 14, height: 1.6),
                decoration: InputDecoration(
                  hintText: schoolSelected
                      ? 'Type your message here...'
                      : 'Select a school above to enable',
                  hintStyle: const TextStyle(
                      color: Color(0xFF475569), fontSize: 14),
                  filled:    true,
                  fillColor: schoolSelected
                      ? const Color(0xFF1E293B)
                      : const Color(0xFF1A2233),
                  contentPadding: const EdgeInsets.all(16),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:   const BorderSide(color: Color(0xFF334155)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:   const BorderSide(color: Color(0xFF334155)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                        const BorderSide(color: Color(0xFF38BDF8), width: 1.5),
                  ),
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:   const BorderSide(color: Color(0xFF1E293B)),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Send row
            Row(
              children: [
                if (_feedback != null)
                  Expanded(
                    child: Text(
                      _feedback!,
                      style: TextStyle(
                        color: _feedback!.startsWith('✓')
                            ? const Color(0xFF22C55E)
                            : const Color(0xFFEF4444),
                        fontSize:   13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                else
                  const Spacer(),

                SizedBox(
                  height: 44,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: schoolSelected && !_sending
                          ? const Color(0xFF0EA5E9)
                          : const Color(0xFF334155),
                      foregroundColor: Colors.white,
                      elevation:       0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                    ),
                    onPressed:
                        schoolSelected && !_sending ? _send : null,
                    icon: _sending
                        ? const SizedBox(
                            width:  16,
                            height: 16,
                            child:  CircularProgressIndicator(
                              strokeWidth: 2,
                              color:       Colors.white,
                            ),
                          )
                        : const Icon(Icons.send_rounded, size: 16),
                    label: Text(
                      _sending ? 'Sending...' : 'Send Message',
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 13),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Type selection card ───────────────────────────────────────
class _TypeCard extends StatelessWidget {
  final IconData     icon;
  final String       label;
  final String       subtitle;
  final bool         selected;
  final VoidCallback onTap;

  const _TypeCard({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding:  const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF0EA5E9).withValues(alpha: 0.12)
              : const Color(0xFF1E293B),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected
                ? const Color(0xFF38BDF8)
                : const Color(0xFF334155),
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width:  40,
              height: 40,
              decoration: BoxDecoration(
                color: selected
                    ? const Color(0xFF0EA5E9).withValues(alpha: 0.2)
                    : const Color(0xFF334155).withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon,
                  color: selected
                      ? const Color(0xFF38BDF8)
                      : const Color(0xFF64748B),
                  size: 20),
            ),
            const SizedBox(width: 14),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: selected ? Colors.white : const Color(0xFF94A3B8),
                    fontSize:   14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color:    Color(0xFF64748B),
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            if (selected)
              const Icon(Icons.check_circle_rounded,
                  color: Color(0xFF38BDF8), size: 18),
          ],
        ),
      ),
    );
  }
}