// lib/screens/add_edit_school_screen.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/school.dart';
import '../models/section.dart';
import '../services/firebase_service.dart';

class AddEditSchoolScreen extends StatefulWidget {
  final School? school;
  const AddEditSchoolScreen({super.key, this.school});

  @override
  State<AddEditSchoolScreen> createState() => _AddEditSchoolScreenState();
}

class _AddEditSchoolScreenState extends State<AddEditSchoolScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _loading = false;

  // ── Step tracking (only relevant on create) ────────────────────────────────
  // Step 0 = school info form  |  Step 1 = sections setup
  int _step = 0;

  // ── Section A — General Identity ──────────────────────────────────────────
  late TextEditingController _name;
  late TextEditingController _city;
  late TextEditingController _principalName;
  late TextEditingController _principalPhone;
  late TextEditingController _totalStudents;

  // ── Section B — Subscription ───────────────────────────────────────────────
  String _subscriptionPlan = '1month';
  late TextEditingController _customDays;
  late TextEditingController _monthlyFee;
  late DateTime _subscriptionStartDate;
  late TextEditingController _notes;
  bool _isActive = true;

  // ── Credentials ────────────────────────────────────────────────────────────
  late TextEditingController _schoolIdCtrl;
  late TextEditingController _adminPasswordCtrl;

  // ── Sections ───────────────────────────────────────────────────────────────
  bool _wantSections = false;
  final List<Section> _sections = [];

  // ── Helpers ────────────────────────────────────────────────────────────────
  static String _generateId() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rng = Random.secure();
    return 'SCH-' +
        List.generate(6, (_) => chars[rng.nextInt(chars.length)]).join();
  }

  static String _generatePassword() {
    const letters = 'abcdefghjkmnpqrstuvwxyz';
    const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    const digits = '23456789';
    final rng = Random.secure();
    final parts = [
      upper[rng.nextInt(upper.length)],
      upper[rng.nextInt(upper.length)],
      letters[rng.nextInt(letters.length)],
      letters[rng.nextInt(letters.length)],
      digits[rng.nextInt(digits.length)],
      digits[rng.nextInt(digits.length)],
      digits[rng.nextInt(digits.length)],
      digits[rng.nextInt(digits.length)],
    ]..shuffle(rng);
    return parts.join();
  }

  DateTime _computeExpiry() {
    int days;
    switch (_subscriptionPlan) {
      case '1month':
        days = 30;
        break;
      case '3months':
        days = 90;
        break;
      case 'custom':
        days = int.tryParse(_customDays.text.trim()) ?? 30;
        break;
      default:
        days = 30;
    }
    return _subscriptionStartDate.add(Duration(days: days));
  }

  @override
  void initState() {
    super.initState();
    final s = widget.school;
    _schoolIdCtrl = TextEditingController(text: s?.id ?? _generateId());
    _adminPasswordCtrl = TextEditingController(
      text: s?.adminPassword ?? _generatePassword(),
    );
    _name = TextEditingController(text: s?.name ?? '');
    _city = TextEditingController(text: s?.city ?? '');
    _principalName = TextEditingController(text: s?.principalName ?? '');
    _principalPhone = TextEditingController(text: s?.principalPhone ?? '');
    _totalStudents = TextEditingController(
      text: s?.totalStudents?.toString() ?? '',
    );
    _subscriptionPlan = s?.subscriptionPlan ?? '1month';
    _customDays = TextEditingController(
      text: s?.customSubscriptionDays?.toString() ?? '',
    );
    _monthlyFee = TextEditingController(
      text: (s?.monthlyFee ?? 10500).toString(),
    );
    _subscriptionStartDate = s?.subscriptionStartDate ?? DateTime.now();
    _notes = TextEditingController(text: s?.notes ?? '');
    _isActive = s?.isActive ?? true;
  }

  @override
  void dispose() {
    _name.dispose();
    _city.dispose();
    _principalName.dispose();
    _principalPhone.dispose();
    _totalStudents.dispose();
    _customDays.dispose();
    _monthlyFee.dispose();
    _notes.dispose();
    _schoolIdCtrl.dispose();
    _adminPasswordCtrl.dispose();
    super.dispose();
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.school != null;
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E293B),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            const Text('🏫', style: TextStyle(fontSize: 18)),
            const SizedBox(width: 8),
            Text(
              isEdit
                  ? 'Edit School'
                  : 'Onboard New School',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          if (!isEdit)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _isActive
                        ? const Color(0xFF22C55E).withOpacity(0.15)
                        : const Color(0xFFEF4444).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: _isActive
                          ? const Color(0xFF22C55E).withOpacity(0.5)
                          : const Color(0xFFEF4444).withOpacity(0.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _isActive
                              ? const Color(0xFF22C55E)
                              : const Color(0xFFEF4444),
                        ),
                      ),
                      const SizedBox(width: 5),
                      Text(
                        _isActive ? 'Active' : 'Inactive',
                        style: TextStyle(
                          color: _isActive
                              ? const Color(0xFF22C55E)
                              : const Color(0xFFEF4444),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Switch(
                        value: _isActive,
                        activeColor: const Color(0xFF22C55E),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        onChanged: (v) => setState(() => _isActive = v),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      body: _buildSchoolForm(isEdit: isEdit)
    );
  }

  // ── Step 0: School form ────────────────────────────────────────────────────

  Widget _buildSchoolForm({required bool isEdit}) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _credentialsBox(),
                const SizedBox(height: 28),

                _sectionHeader('A', 'GENERAL IDENTITY'),
                const SizedBox(height: 20),
                _formField('SCHOOL NAME', _name,
                    hint: 'e.g. Sargodha Public School', required: true),
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                        child: _formField('CITY', _city,
                            hint: 'e.g. Sargodha')),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _formField(
                          'PRINCIPAL / OWNER NAME', _principalName,
                          hint: 'e.g. Mr. Tariq Mehmood', required: true),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _formField(
                          'CONTACT (WHATSAPP)', _principalPhone,
                          hint: '923001234567',
                          required: true,
                          keyboardType: TextInputType.phone,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly
                          ]),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _formField(
                          'APPROX. TOTAL STUDENTS', _totalStudents,
                          hint: 'e.g. 450',
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly
                          ]),
                    ),
                  ],
                ),

                const SizedBox(height: 32),
                _sectionHeader('B', 'SUBSCRIPTION'),
                const SizedBox(height: 20),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _label('SUBSCRIPTION PLAN'),
                          const SizedBox(height: 8),
                          _planSelector(),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _formField(
                          'CUSTOM DAYS (IF SELECTED)', _customDays,
                          hint: 'e.g. 45',
                          enabled: _subscriptionPlan == 'custom',
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly
                          ],
                          validator: _subscriptionPlan == 'custom'
                              ? (v) => (v == null || v.isEmpty)
                                    ? 'Enter days'
                                    : null
                              : null),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _formField(
                          'MONTHLY SOFTWARE FEE (RS.)', _monthlyFee,
                          hint: '10500',
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly
                          ]),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: _dateField(
                        'SUBSCRIPTION START DATE',
                        _subscriptionStartDate,
                        onPick: (d) =>
                            setState(() => _subscriptionStartDate = d),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _formField('NOTES / REMARKS', _notes,
                    hint: 'Any special terms, discounts...'),
                const SizedBox(height: 12),
                _expiryPreview(),
                const SizedBox(height: 32),

                // ── Buttons ───────────────────────────────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF94A3B8),
                        side: const BorderSide(color: Color(0xFF334155)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0EA5E9),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 28, vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8)),
                      ),
                      icon: _loading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2),
                            )
                          : Icon(
                              isEdit ? Icons.save : Icons.check_rounded,
                              size: 18),
                      label: Text(
                        _loading
                            ? 'Saving…'
                            : (isEdit
                                ? 'Update School'
                                : 'Create School'),
                        style:
                            const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      onPressed: _loading
                          ? null
                          : (isEdit ? _saveEdit : _saveNewDirect),
                    ),
                  ],
                ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Step 1: Sections ───────────────────────────────────────────────────────

  Widget _buildSectionsStep() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Step indicator
              _stepIndicator(),
              const SizedBox(height: 28),

              // Toggle: want sections?
              _sectionHeader('C', 'SECTIONS'),
              const SizedBox(height: 20),

              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E293B),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF334155)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.grid_view_rounded,
                        color: Color(0xFF38BDF8), size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Create Sections for this School?',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            'Sections are saved under schools > sections in Firestore.',
                            style: TextStyle(
                                color: Color(0xFF64748B), fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: _wantSections,
                      activeColor: const Color(0xFF0EA5E9),
                      onChanged: (v) => setState(() => _wantSections = v),
                    ),
                  ],
                ),
              ),

              if (_wantSections) ...[
                const SizedBox(height: 24),
                // Sections list
                ..._sections.asMap().entries.map((e) =>
                    _sectionTile(e.key, e.value)),
                const SizedBox(height: 12),
                // Add section button
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF38BDF8),
                    side: const BorderSide(color: Color(0xFF0EA5E9)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  icon: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('Add Section',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  onPressed: _showAddSectionDialog,
                ),
              ],

              const SizedBox(height: 40),

              // Action buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF94A3B8),
                      side: const BorderSide(color: Color(0xFF334155)),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                    onPressed: () => setState(() => _step = 0),
                    child: const Text('← Back'),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF22C55E),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                    icon: _loading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2),
                          )
                        : const Icon(Icons.save_rounded, size: 18),
                    label: Text(
                      _loading ? 'Creating…' : 'Create School',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    onPressed: _loading ? null : _saveNew,
                  ),
                ],
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _stepIndicator() {
    return Row(
      children: [
        _stepChip(1, 'School Info', done: true),
        _stepLine(),
        _stepChip(2, 'Sections', done: false, active: true),
      ],
    );
  }

  Widget _stepChip(int n, String label,
      {bool done = false, bool active = false}) {
    final color = done
        ? const Color(0xFF22C55E)
        : active
            ? const Color(0xFF0EA5E9)
            : const Color(0xFF475569);
    return Row(
      children: [
        Container(
          width: 26,
          height: 26,
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            shape: BoxShape.circle,
            border: Border.all(color: color),
          ),
          child: Center(
            child: done
                ? Icon(Icons.check, color: color, size: 14)
                : Text('$n',
                    style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 12)),
          ),
        ),
        const SizedBox(width: 6),
        Text(label,
            style: TextStyle(
                color: color, fontWeight: FontWeight.bold, fontSize: 13)),
      ],
    );
  }

  Widget _stepLine() {
    return Expanded(
      child: Container(
        height: 1,
        margin: const EdgeInsets.symmetric(horizontal: 12),
        color: const Color(0xFF334155),
      ),
    );
  }

  Widget _sectionTile(int index, Section s) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: const Color(0xFF0EA5E9).withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF0EA5E9).withOpacity(0.3)),
            ),
            child: Center(
              child: Text(
                '${index + 1}',
                style: const TextStyle(
                    color: Color(0xFF38BDF8),
                    fontWeight: FontWeight.bold,
                    fontSize: 13),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.name,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14)),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text('ID: ',
                        style: const TextStyle(
                            color: Color(0xFF64748B), fontSize: 12)),
                    Text(s.id,
                        style: const TextStyle(
                            color: Color(0xFF94A3B8),
                            fontSize: 12,
                            fontFamily: 'monospace')),
                    const SizedBox(width: 16),
                    Text('Pass: ',
                        style: const TextStyle(
                            color: Color(0xFF64748B), fontSize: 12)),
                    Text(s.password,
                        style: const TextStyle(
                            color: Color(0xFF94A3B8),
                            fontSize: 12,
                            fontFamily: 'monospace')),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded,
                color: Color(0xFFEF4444), size: 18),
            tooltip: 'Remove',
            onPressed: () => setState(() => _sections.removeAt(index)),
          ),
        ],
      ),
    );
  }

  void _showAddSectionDialog() {
    final nameCtrl = TextEditingController();
    final idCtrl = TextEditingController();
    final passCtrl = TextEditingController(text: _generatePassword());
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setDlgState) => AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.add_circle_outline_rounded,
                  color: Color(0xFF38BDF8), size: 20),
              SizedBox(width: 8),
              Text('Add Section',
                  style: TextStyle(color: Colors.white, fontSize: 16)),
            ],
          ),
          content: SizedBox(
            width: 380,
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _dlgField(nameCtrl, 'Section Name', 'e.g. Class 5-A',
                      required: true),
                  const SizedBox(height: 14),
                  _dlgField(idCtrl, 'Section ID', 'e.g. SEC-001',
                      required: true),
                  const SizedBox(height: 14),
                  // Password row with regenerate
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _label('PASSWORD'),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: passCtrl,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontFamily: 'monospace',
                                  fontSize: 13),
                              validator: (v) => (v == null || v.trim().isEmpty)
                                  ? 'Required'
                                  : null,
                              decoration: _dlgInputDecoration(
                                  'e.g. Sec@1234'),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Tooltip(
                            message: 'Regenerate',
                            child: IconButton(
                              icon: const Icon(Icons.refresh_rounded,
                                  size: 18, color: Color(0xFF38BDF8)),
                              onPressed: () => setDlgState(() =>
                                  passCtrl.text = _generatePassword()),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel',
                  style: TextStyle(color: Color(0xFF94A3B8))),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0EA5E9),
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                if (!formKey.currentState!.validate()) return;
                // Check duplicate ID
                final newId = idCtrl.text.trim();
                if (_sections.any((s) => s.id == newId)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Section ID already exists'),
                      backgroundColor: Color(0xFFEF4444),
                    ),
                  );
                  return;
                }
                setState(() {
                  _sections.add(Section(
                    id: newId,
                    name: nameCtrl.text.trim(),
                    password: passCtrl.text.trim(),
                  ));
                });
                Navigator.pop(ctx);
              },
              child: const Text('Add Section'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dlgField(
    TextEditingController ctrl,
    String label,
    String hint, {
    bool required = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _label(label),
        const SizedBox(height: 8),
        TextFormField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white, fontSize: 13),
          validator: required
              ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null
              : null,
          decoration: _dlgInputDecoration(hint),
        ),
      ],
    );
  }

  InputDecoration _dlgInputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Color(0xFF475569)),
      filled: true,
      fillColor: const Color(0xFF0F172A),
      isDense: true,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF334155)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF334155)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFF0EA5E9), width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: Color(0xFFEF4444)),
      ),
    );
  }

  // ── Navigation & Save ──────────────────────────────────────────────────────

  /// Validates form then saves school directly (no sections step).
  Future<void> _saveNewDirect() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final school = _buildSchool();
      await FirebaseService.addSchool(school);
      // Auto-create default SMS template for this school
      await FirebaseService.createDefaultTemplate(school.id, school.name);
      if (mounted) _showCredentialsDialog();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error: $e'),
              backgroundColor: const Color(0xFFEF4444)),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveNew() async {
    setState(() => _loading = true);
    try {
      final school = _buildSchool();
      await FirebaseService.addSchool(school);
      // Auto-create default SMS template for this school
      await FirebaseService.createDefaultTemplate(school.id, school.name);
      if (mounted) _showCredentialsDialog();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error: $e'),
              backgroundColor: const Color(0xFFEF4444)),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _saveEdit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await FirebaseService.updateSchool(_buildSchool());
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error: $e'),
              backgroundColor: const Color(0xFFEF4444)),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  School _buildSchool() {
    return School(
      id: _schoolIdCtrl.text.trim(),
      name: _name.text.trim(),
      city: _city.text.trim(),
      principalName: _principalName.text.trim(),
      principalPhone: _principalPhone.text.trim(),
      totalStudents: int.tryParse(_totalStudents.text.trim()),
      subscriptionPlan: _subscriptionPlan,
      customSubscriptionDays: _subscriptionPlan == 'custom'
          ? int.tryParse(_customDays.text.trim())
          : null,
      monthlyFee: double.tryParse(_monthlyFee.text.trim()) ?? 10500,
      subscriptionExpiry: _computeExpiry(),
      subscriptionStartDate: _subscriptionStartDate,
      isActive: _isActive,
      createdAt: widget.school?.createdAt ?? DateTime.now(),
      adminPassword: _adminPasswordCtrl.text.trim(),
      notes: _notes.text.trim(),
    );
  }

  void _showCredentialsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.check_circle_rounded,
                color: Color(0xFF22C55E), size: 24),
            SizedBox(width: 8),
            Text('School Created!',
                style: TextStyle(color: Colors.white, fontSize: 18)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Share these credentials with the school admin:',
                style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
            const SizedBox(height: 20),
            _dialogCredRow('School ID', _schoolIdCtrl.text),
            const SizedBox(height: 12),
            _dialogCredRow('Password', _adminPasswordCtrl.text),
            if (_wantSections && _sections.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFF0EA5E9).withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: const Color(0xFF0EA5E9).withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.grid_view_rounded,
                        color: Color(0xFF38BDF8), size: 14),
                    const SizedBox(width: 6),
                    Text(
                      '${_sections.length} section${_sections.length == 1 ? '' : 's'} created.',
                      style: const TextStyle(
                          color: Color(0xFF38BDF8), fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFF59E0B).withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                    color: const Color(0xFFF59E0B).withOpacity(0.4)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.warning_amber_rounded,
                      color: Color(0xFFF59E0B), size: 14),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Save these now — password cannot be recovered later.',
                      style: TextStyle(
                          color: Color(0xFFF59E0B), fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(
                text: '${_schoolIdCtrl.text}\n${_adminPasswordCtrl.text}',
              ));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Both credentials copied!'),
                  backgroundColor: Color(0xFF22C55E),
                ),
              );
            },
            child: const Text('Copy Both',
                style: TextStyle(color: Color(0xFF38BDF8))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0EA5E9),
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  Widget _dialogCredRow(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      color: Color(0xFF64748B), fontSize: 11)),
              const SizedBox(height: 2),
              SelectableText(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.copy, size: 16, color: Color(0xFF64748B)),
            tooltip: 'Copy',
            onPressed: () => Clipboard.setData(ClipboardData(text: value)),
          ),
        ],
      ),
    );
  }

  // ── UI Helpers ─────────────────────────────────────────────────────────────

  Widget _sectionHeader(String letter, String title) {
    return Row(
      children: [
        Container(
          width: 26,
          height: 26,
          decoration: BoxDecoration(
            color: const Color(0xFF0EA5E9).withOpacity(0.12),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFF0EA5E9).withOpacity(0.35)),
          ),
          child: Center(
            child: Text(letter,
                style: const TextStyle(
                    color: Color(0xFF38BDF8),
                    fontWeight: FontWeight.bold,
                    fontSize: 12)),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          'SECTION $letter — $title',
          style: const TextStyle(
            color: Color(0xFF38BDF8),
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
            child: Container(height: 1, color: const Color(0xFF1E3A4A))),
      ],
    );
  }

  Widget _label(String text) => Text(
        text,
        style: const TextStyle(
          color: Color(0xFF94A3B8),
          fontSize: 12,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      );

  Widget _credentialsBox() {
    final isEdit = widget.school != null;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0EA5E9).withOpacity(0.07),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF0EA5E9).withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.key_rounded,
                  color: Color(0xFF38BDF8), size: 15),
              const SizedBox(width: 6),
              Text(
                isEdit
                    ? 'Login Credentials — editable'
                    : 'Login Credentials — saved automatically on creation',
                style: const TextStyle(
                    color: Color(0xFF38BDF8),
                    fontSize: 13,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _credEditRow('School ID', _schoolIdCtrl,
              () => setState(() => _schoolIdCtrl.text = _generateId())),
          const SizedBox(height: 8),
          _credEditRow('Password', _adminPasswordCtrl,
              () => setState(() => _adminPasswordCtrl.text = _generatePassword())),
        ],
      ),
    );
  }

  Widget _credEditRow(
      String label, TextEditingController ctrl, VoidCallback onRegenerate) {
    return Row(
      children: [
        SizedBox(
          width: 90,
          child: Text('$label:',
              style:
                  const TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
        ),
        Expanded(
          child: TextFormField(
            controller: ctrl,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w600,
              fontFamily: 'monospace',
            ),
            decoration: InputDecoration(
              isDense: true,
              filled: true,
              fillColor: const Color(0xFF1E293B),
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(6),
                borderSide: const BorderSide(color: Color(0xFF334155)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(6),
                borderSide: const BorderSide(color: Color(0xFF334155)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(6),
                borderSide: const BorderSide(
                    color: Color(0xFF0EA5E9), width: 1.5),
              ),
            ),
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'Required' : null,
          ),
        ),
        const SizedBox(width: 4),
        Tooltip(
          message: 'Regenerate',
          child: IconButton(
            icon: const Icon(Icons.refresh_rounded,
                size: 16, color: Color(0xFF38BDF8)),
            padding: EdgeInsets.zero,
            constraints:
                const BoxConstraints(minWidth: 30, minHeight: 30),
            onPressed: onRegenerate,
          ),
        ),
        Tooltip(
          message: 'Copy',
          child: IconButton(
            icon: const Icon(Icons.copy,
                size: 15, color: Color(0xFF64748B)),
            padding: EdgeInsets.zero,
            constraints:
                const BoxConstraints(minWidth: 30, minHeight: 30),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: ctrl.text));
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('$label copied'),
                duration: const Duration(seconds: 1),
                backgroundColor: const Color(0xFF1E293B),
              ));
            },
          ),
        ),
      ],
    );
  }

  Widget _formField(
    String label,
    TextEditingController ctrl, {
    bool required = false,
    bool obscure = false,
    String? hint,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    bool enabled = true,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _label(label),
        const SizedBox(height: 8),
        TextFormField(
          controller: ctrl,
          obscureText: obscure,
          keyboardType: keyboardType,
          inputFormatters: inputFormatters,
          enabled: enabled,
          style: TextStyle(
              color: enabled ? Colors.white : const Color(0xFF475569)),
          validator: validator ??
              (required
                  ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null
                  : null),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Color(0xFF475569)),
            filled: true,
            fillColor:
                enabled ? const Color(0xFF1E293B) : const Color(0xFF111827),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF334155)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF334155)),
            ),
            disabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF1F2937)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide:
                  const BorderSide(color: Color(0xFF0EA5E9), width: 1.5),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFFEF4444)),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide:
                  const BorderSide(color: Color(0xFFEF4444), width: 1.5),
            ),
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 14),
          ),
        ),
      ],
    );
  }

  Widget _planSelector() {
    final plans = [
      ('1month', '1 Month'),
      ('3months', '3 Months'),
      ('custom', 'Custom'),
    ];
    return Row(
      children: plans.map((p) {
        final selected = _subscriptionPlan == p.$1;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => setState(() => _subscriptionPlan = p.$1),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              decoration: BoxDecoration(
                color: selected
                    ? const Color(0xFF0EA5E9)
                    : const Color(0xFF1E293B),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: selected
                      ? const Color(0xFF0EA5E9)
                      : const Color(0xFF334155),
                ),
              ),
              child: Text(
                p.$2,
                style: TextStyle(
                  color: selected ? Colors.white : const Color(0xFF94A3B8),
                  fontWeight:
                      selected ? FontWeight.bold : FontWeight.normal,
                  fontSize: 13,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _dateField(String label, DateTime date,
      {required void Function(DateTime) onPick}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _label(label),
        const SizedBox(height: 8),
        InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: date,
              firstDate: DateTime(2020),
              lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
              builder: (context, child) =>
                  Theme(data: ThemeData.dark(), child: child!),
            );
            if (picked != null) onPick(picked);
          },
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            decoration: BoxDecoration(
              color: const Color(0xFF1E293B),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF334155)),
            ),
            child: Row(
              children: [
                const Icon(Icons.calendar_today_rounded,
                    color: Color(0xFF38BDF8), size: 16),
                const SizedBox(width: 10),
                Text(
                  '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}/${date.year}',
                  style: const TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _expiryPreview() {
    final expiry = _computeExpiry();
    final daysLeft = expiry.difference(DateTime.now()).inDays;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF1E293B)),
      ),
      child: Row(
        children: [
          const Icon(Icons.event_available_rounded,
              color: Color(0xFF22C55E), size: 15),
          const SizedBox(width: 8),
          const Text('Subscription will expire on  ',
              style: TextStyle(color: Color(0xFF64748B), fontSize: 12)),
          Text(
            '${expiry.day}/${expiry.month}/${expiry.year}',
            style: const TextStyle(
                color: Color(0xFF22C55E),
                fontSize: 12,
                fontWeight: FontWeight.bold),
          ),
          Text(
            '  ($daysLeft days from start)',
            style: const TextStyle(color: Color(0xFF64748B), fontSize: 12),
          ),
        ],
      ),
    );
  }
}
