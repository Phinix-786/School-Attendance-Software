// lib/screens/school_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/school.dart';
import '../services/firebase_service.dart';
import 'add_edit_school_screen.dart';

class SchoolDetailScreen extends StatefulWidget {
  final School school;
  const SchoolDetailScreen({super.key, required this.school});

  @override
  State<SchoolDetailScreen> createState() => _SchoolDetailScreenState();
}

class _SchoolDetailScreenState extends State<SchoolDetailScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  // ── Delete school confirmation ─────────────────────────────────────────────
  Future<void> _confirmDelete(BuildContext context, School school) async {
    final confirmCtrl = TextEditingController();
    bool  deleting    = false;
    String? err;

    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, ss) => AlertDialog(
          backgroundColor: const Color(0xFF1E293B),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.warning_amber_rounded,
                  color: Color(0xFFEF4444), size: 22),
              SizedBox(width: 10),
              Text('Delete School',
                  style: TextStyle(
                      color:      Colors.white,
                      fontSize:   18,
                      fontWeight: FontWeight.w800)),
            ],
          ),
          content: SizedBox(
            width: 420,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Warning box
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color:        const Color(0xFFEF4444).withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: const Color(0xFFEF4444).withValues(alpha: 0.4)),
                  ),
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('This will permanently delete:',
                          style: TextStyle(
                              color:      Color(0xFFEF4444),
                              fontWeight: FontWeight.w700,
                              fontSize:   13)),
                      SizedBox(height: 8),
                      _BulletLine('All sections and classes'),
                      _BulletLine('All students and teacher accounts'),
                      _BulletLine('All homework, tests and results'),
                      _BulletLine('All attendance records'),
                      _BulletLine('All chats and messages'),
                      _BulletLine('All notices, leaves, timetables'),
                      _BulletLine('All SMS requests'),
                      SizedBox(height: 6),
                      Text('This cannot be undone.',
                          style: TextStyle(
                              color:      Color(0xFFEF4444),
                              fontWeight: FontWeight.w800,
                              fontSize:   13)),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  'Type  "${school.name}"  to confirm:',
                  style: const TextStyle(
                      color: Color(0xFF94A3B8), fontSize: 13),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller:   confirmCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText:    school.name,
                    hintStyle:   const TextStyle(
                        color: Color(0xFF475569), fontSize: 13),
                    filled:      true,
                    fillColor:   const Color(0xFF0F172A),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(
                            color: Color(0xFF334155))),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(
                            color: Color(0xFF334155))),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(
                            color: Color(0xFFEF4444), width: 2)),
                  ),
                  onChanged: (_) => ss(() => err = null),
                ),
                if (err != null) ...[
                  const SizedBox(height: 8),
                  Text(err!,
                      style: const TextStyle(
                          color: Color(0xFFEF4444), fontSize: 12)),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: deleting ? null : () => Navigator.pop(ctx, false),
              child: const Text('Cancel',
                  style: TextStyle(color: Color(0xFF94A3B8))),
            ),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFEF4444),
                foregroundColor: Colors.white,
                elevation:       0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                padding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 12),
              ),
              icon: deleting
                  ? const SizedBox(
                      width: 14, height: 14,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.delete_forever_rounded, size: 16),
              label: Text(deleting ? 'Deleting…' : 'Delete Everything',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              onPressed: deleting
                  ? null
                  : () {
                      if (confirmCtrl.text.trim() != school.name) {
                        ss(() => err =
                            'Name does not match. Type it exactly.');
                        return;
                      }
                      ss(() => deleting = true);
                      Navigator.pop(ctx, true);
                    },
            ),
          ],
        ),
      ),
    );

    confirmCtrl.dispose();
    if (confirmed != true) return;
    if (!mounted) return;

    // Show progress snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2)),
            const SizedBox(width: 14),
            Text('Deleting ${school.name} and all data…'),
          ],
        ),
        backgroundColor: const Color(0xFFEF4444),
        duration: const Duration(seconds: 30),
      ),
    );

    try {
      await FirebaseService.deleteSchoolDeep(school.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${school.name} deleted successfully.'),
          backgroundColor: const Color(0xFF22C55E),
          duration: const Duration(seconds: 3),
        ),
      );
      Navigator.pop(context); // back to dashboard
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).clearSnackBars();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: const Color(0xFFEF4444),
          duration: const Duration(seconds: 5),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<School>>(
      stream: FirebaseService.schoolsStream(),
      builder: (context, snap) {
        final schools = snap.data ?? [];
        final school = schools.firstWhere(
          (s) => s.id == widget.school.id,
          orElse: () => widget.school,
        );

        return Scaffold(
          backgroundColor: const Color(0xFF0F172A),
          appBar: AppBar(
            backgroundColor: const Color(0xFF1E293B),
            foregroundColor: Colors.white,
            title: Row(
              children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: const Color(0xFF0EA5E9).withValues(alpha: 0.2),
                  child: Text(
                    school.name[0],
                    style: const TextStyle(
                      color: Color(0xFF38BDF8),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(school.name),
              ],
            ),
            actions: [
              // Edit button
              IconButton(
                icon: const Icon(Icons.edit, size: 20),
                tooltip: 'Edit School',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddEditSchoolScreen(school: school),
                  ),
                ),
              ),
              // Delete school
              IconButton(
                icon: const Icon(Icons.delete_forever_rounded, size: 22),
                tooltip: 'Delete School & All Data',
                color: const Color(0xFFEF4444),
                onPressed: () => _confirmDelete(context, school),
              ),
              // Kill switch
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Row(
                  children: [
                    const Text(
                      'Kill Switch: ',
                      style: TextStyle(color: Color(0xFF94A3B8)),
                    ),
                    Switch(
                      value: school.isActive,
                      activeThumbColor: const Color(0xFF22C55E),
                      inactiveThumbColor: const Color(0xFFEF4444),
                      onChanged: (v) async {
                        await FirebaseService.toggleKillSwitch(school.id, v);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                v
                                    ? '${school.name} UNLOCKED'
                                    : '${school.name} LOCKED',
                              ),
                              backgroundColor: v
                                  ? const Color(0xFF22C55E)
                                  : const Color(0xFFEF4444),
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
            bottom: TabBar(
              controller: _tabCtrl,
              indicatorColor: const Color(0xFF38BDF8),
              labelColor: const Color(0xFF38BDF8),
              unselectedLabelColor: const Color(0xFF64748B),
              labelStyle: const TextStyle(
                fontSize:   13,
                fontWeight: FontWeight.w600,
              ),
              tabs: const [
                Tab(text: 'Details'),
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.lightbulb_outline_rounded, size: 14),
                      SizedBox(width: 6),
                      Text('Suggested Updates'),
                    ],
                  ),
                ),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabCtrl,
            children: [
              _DetailsTab(school: school),
              _SuggestedUpdatesTab(school: school),
            ],
          ),
        );
      },
    );
  }
}

// ── Details Tab ──────────────────────────────────────────────────────────────
class _DetailsTab extends StatelessWidget {
  final School school;
  const _DetailsTab({required this.school});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sectionLabel('GENERAL INFO'),
              const SizedBox(height: 12),
              _infoCard([
                _infoRow(Icons.school, 'School Name', school.name),
                _divider(),
                _infoRow(Icons.person, 'Principal', school.principalName),
                _divider(),
                _infoRow(
                  Icons.phone,
                  'WhatsApp Contact',
                  school.principalPhone,
                ),
                if (school.city != null && school.city!.isNotEmpty) ...[
                  _divider(),
                  _infoRow(Icons.location_city, 'City', school.city!),
                ],
                if (school.totalStudents != null) ...[
                  _divider(),
                  _infoRow(
                    Icons.people,
                    'Total Students',
                    '${school.totalStudents}',
                  ),
                ],
                _divider(),
                _infoRow(
                  Icons.circle,
                  'Status',
                  school.isActive ? 'Active' : 'Locked',
                  valueColor: school.isActive
                      ? const Color(0xFF22C55E)
                      : const Color(0xFFEF4444),
                ),
                _divider(),
                _infoRow(
                  Icons.calendar_today,
                  'Created',
                  DateFormat('dd MMM yyyy').format(school.createdAt),
                ),
              ]),

              const SizedBox(height: 24),

              _sectionLabel('BILLING OVERVIEW'),
              const SizedBox(height: 12),
              _infoCard([
                _infoRow(
                  Icons.monetization_on,
                  'Monthly Fee',
                  'PKR ${NumberFormat('#,##0').format(school.monthlyFee)}',
                ),
                _divider(),
                _infoRow(
                  Icons.calendar_month,
                  'Subscription Expiry',
                  DateFormat('dd MMM yyyy').format(school.subscriptionExpiry),
                  valueColor: school.isExpired
                      ? const Color(0xFFEF4444)
                      : school.isExpiringSoon
                      ? const Color(0xFFF59E0B)
                      : null,
                ),
                _divider(),
                _infoRow(
                  Icons.timer,
                  'Days Remaining',
                  school.isExpired
                      ? 'Expired'
                      : '${school.daysUntilExpiry} days',
                  valueColor: school.isExpired
                      ? const Color(0xFFEF4444)
                      : school.isExpiringSoon
                      ? const Color(0xFFF59E0B)
                      : const Color(0xFF22C55E),
                ),
              ]),

              if (school.notes.isNotEmpty) ...[
                const SizedBox(height: 24),
                _sectionLabel('NOTES'),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF334155)),
                  ),
                  child: Text(
                    school.notes,
                    style: const TextStyle(
                      color: Color(0xFF94A3B8),
                      fontSize: 14,
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(
    text,
    style: const TextStyle(
      color: Color(0xFF38BDF8),
      fontSize: 12,
      fontWeight: FontWeight.bold,
      letterSpacing: 1.0,
    ),
  );

  Widget _infoCard(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Column(children: children),
    );
  }

  Widget _divider() => const Divider(color: Color(0xFF334155), height: 1);

  Widget _infoRow(
    IconData icon,
    String label,
    String value, {
    Color? valueColor,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF475569), size: 16),
          const SizedBox(width: 12),
          SizedBox(
            width: 160,
            child: Text(
              label,
              style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: valueColor ?? Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Suggested Updates Tab ────────────────────────────────────────────────────
class _SuggestedUpdatesTab extends StatelessWidget {
  final School school;
  const _SuggestedUpdatesTab({required this.school});

  Stream<List<Map<String, dynamic>>> _stream() {
    return FirebaseFirestore.instance
        .collection('schools')
        .doc(school.id)
        .collection('suggested_updates')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) {
              final data = d.data();
              data['_docId'] = d.id;
              return data;
            }).toList());
  }

  Future<void> _delete(String docId) async {
    await FirebaseFirestore.instance
        .collection('schools')
        .doc(school.id)
        .collection('suggested_updates')
        .doc(docId)
        .delete();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _stream(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(Color(0xFF38BDF8)),
            ),
          );
        }

        final items = snap.data ?? [];

        if (items.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width:  64,
                  height: 64,
                  decoration: BoxDecoration(
                    color:        const Color(0xFF1E293B),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Icon(
                    Icons.lightbulb_outline_rounded,
                    color: Color(0xFF475569),
                    size:  30,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'No suggestions yet',
                  style: TextStyle(
                    color:      Colors.white,
                    fontSize:   16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '${school.name} hasn\'t submitted any feature suggestions.',
                  style: const TextStyle(
                    color:   Color(0xFF64748B),
                    fontSize: 13,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 700),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.lightbulb_outline_rounded,
                          color: Color(0xFF38BDF8), size: 16),
                      const SizedBox(width: 8),
                      const Text(
                        'FEATURE SUGGESTIONS',
                        style: TextStyle(
                          color:         Color(0xFF38BDF8),
                          fontSize:      12,
                          fontWeight:    FontWeight.bold,
                          letterSpacing: 1.0,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color:        const Color(0xFF0EA5E9)
                              .withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${items.length}',
                          style: const TextStyle(
                            color:      Color(0xFF38BDF8),
                            fontSize:   11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ...items.map((item) => _SuggestionCard(
                        item:     item,
                        onDelete: () => _delete(item['_docId'] as String),
                      )),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final VoidCallback         onDelete;
  const _SuggestionCard({required this.item, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final suggestion = item['suggestion'] as String? ?? '';
    final ts         = item['createdAt'];
    DateTime? dt;
    if (ts != null && ts is Timestamp) dt = ts.toDate();

    return Container(
      width:  double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width:  32,
                height: 32,
                decoration: BoxDecoration(
                  color:        const Color(0xFF0EA5E9).withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.lightbulb_rounded,
                  color: Color(0xFF38BDF8),
                  size:  16,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  suggestion,
                  style: const TextStyle(
                    color:    Colors.white,
                    fontSize: 14,
                    height:   1.55,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded,
                    color: Color(0xFF475569), size: 18),
                tooltip:     'Dismiss',
                onPressed:   () => _confirmDelete(context),
                visualDensity: VisualDensity.compact,
                padding:     EdgeInsets.zero,
              ),
            ],
          ),
          if (dt != null) ...[
            const SizedBox(height: 10),
            Text(
              DateFormat('dd MMM yyyy · HH:mm').format(dt),
              style: const TextStyle(
                color:   Color(0xFF475569),
                fontSize: 11.5,
              ),
            ),
          ],
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E293B),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14)),
        title: const Text(
          'Dismiss Suggestion?',
          style: TextStyle(
            color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700),
        ),
        content: const Text(
          'This suggestion will be permanently removed.',
          style: TextStyle(color: Color(0xFF94A3B8), fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: Color(0xFF64748B))),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              onDelete();
            },
            child: const Text('Dismiss',
                style: TextStyle(
                    color: Color(0xFFEF4444), fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

class _BulletLine extends StatelessWidget {
  final String text;
  const _BulletLine(this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('• ',
                style: TextStyle(color: Color(0xFFEF4444), fontSize: 12)),
            Expanded(
              child: Text(text,
                  style: const TextStyle(
                      color: Color(0xFFCBD5E1), fontSize: 12)),
            ),
          ],
        ),
      );
}
