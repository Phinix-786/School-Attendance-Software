// lib/screens/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/school.dart';
import '../services/firebase_service.dart';
import 'add_edit_school_screen.dart';
import 'school_detail_screen.dart';
import 'global_settings_screen.dart';
import 'school_billing.dart';
import 'broadcast_screen.dart';
import 'template_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _search = '';
  // 0 = Dashboard, 1 = Billing, 2 = Broadcast, 3 = Templates, 4 = Settings
  int _selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Row(
        children: [
          // ── Sidebar ────────────────────────────────────────────────────────
          Container(
            width: 220,
            color: const Color(0xFF1E293B),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  child: const Column(
                    children: [
                      Icon(
                        Icons.admin_panel_settings,
                        color: Color(0xFF38BDF8),
                        size: 40,
                      ),
                      SizedBox(height: 8),
                      Text(
                        'HQ Control',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Master Panel',
                        style: TextStyle(
                          color: Color(0xFF94A3B8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(color: Color(0xFF334155)),
                _sidebarItem(
                  Icons.dashboard,
                  'Dashboard',
                  _selectedTab == 0,
                  onTap: () => setState(() => _selectedTab = 0),
                ),
                _sidebarItem(
                  Icons.receipt_long,
                  'Billing',
                  _selectedTab == 1,
                  onTap: () => setState(() => _selectedTab = 1),
                ),
                _sidebarItem(
                  Icons.campaign_rounded,
                  'Broadcast',
                  _selectedTab == 2,
                  onTap: () => setState(() => _selectedTab = 2),
                ),
                _sidebarItem(
                  Icons.sms_outlined,
                  'SMS Templates',
                  _selectedTab == 3,
                  onTap: () => setState(() => _selectedTab = 3),
                ),
                _sidebarItem(
                  Icons.settings,
                  'Global Settings',
                  _selectedTab == 4,
                  onTap: () => setState(() => _selectedTab = 4),
                ),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0EA5E9),
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 42),
                    ),
                    icon: const Icon(Icons.add),
                    label: const Text('Add School'),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AddEditSchoolScreen(),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // ── Main content ───────────────────────────────────────────────────
          Expanded(
            child: switch (_selectedTab) {
              1 => const SchoolBillingScreen(),
              2 => const BroadcastScreen(),
              3 => const TemplateScreen(),
              4 => const GlobalSettingsScreen(),
              _ => _dashboardContent(),
            },
          ),
        ],
      ),
    );
  }

  Widget _dashboardContent() {
    return Column(
      children: [
        // Top bar
        Container(
          height: 60,
          color: const Color(0xFF1E293B),
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              const Text(
                'Schools Overview',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              SizedBox(
                width: 260,
                child: TextField(
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: 'Search school...',
                    hintStyle: const TextStyle(color: Color(0xFF64748B)),
                    prefixIcon: const Icon(
                      Icons.search,
                      color: Color(0xFF64748B),
                    ),
                    filled: true,
                    fillColor: const Color(0xFF0F172A),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                  ),
                  onChanged: (v) => setState(() => _search = v),
                ),
              ),
              const SizedBox(width: 12),
            ],
          ),
        ),
        // Schools list
        Expanded(
          child: StreamBuilder<List<School>>(
            stream: FirebaseService.schoolsStream(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(color: Color(0xFF38BDF8)),
                );
              }
              final all = snap.data ?? [];
              final schools = _search.isEmpty
                  ? all
                  : all
                        .where(
                          (s) => s.name.toLowerCase().contains(
                            _search.toLowerCase(),
                          ),
                        )
                        .toList();

              final active = all.where((s) => s.isActive).length;
              final expiring = all.where((s) => s.isExpiringSoon).length;
              final expired = all.where((s) => s.isExpired).length;

              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        _statCard(
                          'Total Schools',
                          '${all.length}',
                          Icons.school,
                          const Color(0xFF38BDF8),
                        ),
                        const SizedBox(width: 12),
                        _statCard(
                          'Active',
                          '$active',
                          Icons.check_circle,
                          const Color(0xFF22C55E),
                        ),
                        const SizedBox(width: 12),
                        _statCard(
                          'Expiring Soon',
                          '$expiring',
                          Icons.warning,
                          const Color(0xFFF59E0B),
                        ),
                        const SizedBox(width: 12),
                        _statCard(
                          'Expired',
                          '$expired',
                          Icons.block,
                          const Color(0xFFEF4444),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: schools.isEmpty
                        ? const Center(
                            child: Text(
                              'No schools found.',
                              style: TextStyle(
                                color: Color(0xFF64748B),
                                fontSize: 16,
                              ),
                            ),
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: schools.length,
                            itemBuilder: (_, i) => _schoolCard(schools[i]),
                          ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  // ── Sidebar item ────────────────────────────────────────────────────────────

  Widget _sidebarItem(
    IconData icon,
    String label,
    bool selected, {
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF0EA5E9).withValues(alpha: 0.15)
              : null,
          borderRadius: BorderRadius.circular(8),
        ),
        child: ListTile(
          leading: Icon(
            icon,
            color: selected ? const Color(0xFF38BDF8) : const Color(0xFF64748B),
            size: 20,
          ),
          title: Text(
            label,
            style: TextStyle(
              color: selected
                  ? const Color(0xFF38BDF8)
                  : const Color(0xFF94A3B8),
              fontSize: 14,
            ),
          ),
          dense: true,
        ),
      ),
    );
  }

  // ── Stat card ───────────────────────────────────────────────────────────────

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1E293B),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    color: color,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFF94A3B8),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── School card ─────────────────────────────────────────────────────────────

  Widget _schoolCard(School school) {
    Color statusColor;
    String statusText;
    if (!school.isActive) {
      statusColor = const Color(0xFFEF4444);
      statusText = 'LOCKED';
    } else if (school.isExpired) {
      statusColor = const Color(0xFFEF4444);
      statusText = 'EXPIRED';
    } else if (school.isExpiringSoon) {
      statusColor = const Color(0xFFF59E0B);
      statusText = 'EXPIRING';
    } else {
      statusColor = const Color(0xFF22C55E);
      statusText = 'ACTIVE';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: ListTile(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SchoolDetailScreen(school: school),
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF0EA5E9).withValues(alpha: 0.2),
          child: Text(
            school.name[0],
            style: const TextStyle(
              color: Color(0xFF38BDF8),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(
          school.name,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Principal: ${school.principalName}',
              style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12),
            ),
            Text(
              'Expires: ${DateFormat('dd MMM yyyy').format(school.subscriptionExpiry)}',
              style: const TextStyle(color: Color(0xFF64748B), fontSize: 11),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: statusColor.withValues(alpha: 0.5)),
              ),
              child: Text(
                statusText,
                style: TextStyle(
                  color: statusColor,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.edit, color: Color(0xFF64748B), size: 18),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AddEditSchoolScreen(school: school),
                ),
              ),
            ),
            IconButton(
              icon: const Icon(
                Icons.open_in_new,
                color: Color(0xFF38BDF8),
                size: 18,
              ),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SchoolDetailScreen(school: school),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}