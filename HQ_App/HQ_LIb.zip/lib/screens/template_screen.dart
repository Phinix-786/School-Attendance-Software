// lib/screens/template_screen.dart
//
// HQ Template Manager
// ───────────────────
// Allows HQ admin to:
//   • Browse all schools (with search)
//   • Select a school and view/edit its Absent & Late SMS templates
//   • Preview the template with sample data filled in
//   • Save changes back to Firebase (schools/{id}/config/sms_template)
//   • Reset to the default template
//
// The SMS sender app reads from exactly this Firestore path, so any
// change here is picked up by the sender on its next cycle.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/school.dart';
import '../models/sms_template.dart';
import '../services/firebase_service.dart';

// ── Colour tokens (match dashboard palette) ───────────────────────────────────
const _bg      = Color(0xFF0F172A);
const _surface = Color(0xFF1E293B);
const _border  = Color(0xFF334155);
const _accent  = Color(0xFF38BDF8);
const _accentD = Color(0xFF0EA5E9);
const _muted   = Color(0xFF94A3B8);
const _muted2  = Color(0xFF64748B);
const _green   = Color(0xFF22C55E);
const _amber   = Color(0xFFF59E0B);
const _red     = Color(0xFFEF4444);

// ── Placeholder tokens shown in the UI ───────────────────────────────────────
const _placeholders = [
  ('{studentName}',      'Student Name'),
  ('{rollNo}',           'Roll No'),
  ('{className}',        'Class'),
  ('{section}',          'Section'),
  ('{attendanceStatus}', 'Status'),
  ('{schoolName}',       'School Name'),
  ('{date}',             'Date'),
  ('{time}',             'Time'),
  // Populated only for late records — contains the number of minutes late
  // e.g. "10". Use like: "arrived {lateMinutes} minutes late".
  ('{lateMinutes}',      'Minutes Late (late only)'),
];

class TemplateScreen extends StatefulWidget {
  const TemplateScreen({super.key});

  @override
  State<TemplateScreen> createState() => _TemplateScreenState();
}

class _TemplateScreenState extends State<TemplateScreen> {
  // ── Left panel state ───────────────────────────────────────────────────────
  String _search = '';
  School? _selected;

  // ── Right panel state ──────────────────────────────────────────────────────
  SmsTemplate? _template;
  bool  _loadingTemplate = false;
  bool  _saving          = false;
  bool  _previewMode     = false;
  int   _activeTab       = 0; // 0 = Absent, 1 = Late

  final _absentCtrl = TextEditingController();
  final _lateCtrl   = TextEditingController();

  // ── Load template when school is selected ─────────────────────────────────
  Future<void> _selectSchool(School school) async {
    setState(() {
      _selected       = school;
      _loadingTemplate = true;
      _previewMode    = false;
    });

    SmsTemplate? tmpl = await FirebaseService.getTemplate(school.id);

    // If no template exists yet, auto-create the default one
    if (tmpl == null) {
      await FirebaseService.createDefaultTemplate(school.id, school.name);
      tmpl = SmsTemplate(
        schoolId:        school.id,
        absentTemplate:  SmsTemplate.defaultAbsent(school.name),
        lateTemplate:    SmsTemplate.defaultLate(school.name),
      );
    }

    setState(() {
      _template        = tmpl;
      _absentCtrl.text = tmpl!.absentTemplate;
      _lateCtrl.text   = tmpl.lateTemplate;
      _loadingTemplate  = false;
    });
  }

  // ── Save ──────────────────────────────────────────────────────────────────
  Future<void> _save() async {
    if (_selected == null || _template == null) return;
    setState(() => _saving = true);
    try {
      final updated = _template!.copyWith(
        absentTemplate: _absentCtrl.text,
        lateTemplate:   _lateCtrl.text,
      );
      await FirebaseService.saveTemplate(updated);
      setState(() => _template = updated);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Template saved successfully'),
          backgroundColor: _green,
          duration: Duration(seconds: 2),
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error: $e'),
          backgroundColor: _red,
        ));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ── Reset to default ──────────────────────────────────────────────────────
  Future<void> _resetDefault() async {
    if (_selected == null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('Reset to Default?',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        content: const Text(
          'This will replace both templates with the school\'s default text. '
          'Any customisations will be lost.',
          style: TextStyle(color: _muted, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel', style: TextStyle(color: _muted2)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: _red, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    final school = _selected!;
    setState(() => _saving = true);
    try {
      final fresh = SmsTemplate(
        schoolId:       school.id,
        absentTemplate: SmsTemplate.defaultAbsent(school.name),
        lateTemplate:   SmsTemplate.defaultLate(school.name),
      );
      await FirebaseService.saveTemplate(fresh);
      setState(() {
        _template        = fresh;
        _absentCtrl.text = fresh.absentTemplate;
        _lateCtrl.text   = fresh.lateTemplate;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Template reset to default'),
          backgroundColor: _amber,
          duration: Duration(seconds: 2),
        ));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ── Build preview text (fill in sample values) ────────────────────────────
  String _buildPreview(String raw) {
    final school = _selected;
    return raw
        .replaceAll('{studentName}',      'Ali Hassan')
        .replaceAll('{rollNo}',           '42')
        .replaceAll('{className}',        'Grade 5')
        .replaceAll('{section}',          'A')
        .replaceAll('{attendanceStatus}', _activeTab == 0 ? 'absent' : 'late')
        .replaceAll('{schoolName}',       school?.name ?? 'Sample School')
        .replaceAll('{date}',             DateFormat('dd MMM yyyy').format(DateTime.now()))
        .replaceAll('{time}',             DateFormat('hh:mm a').format(DateTime.now()))
        .replaceAll('{lateMinutes}',      _activeTab == 1 ? '10' : '—');
  }

  @override
  void dispose() {
    _absentCtrl.dispose();
    _lateCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      // ── LEFT: School list ─────────────────────────────────────────────────
      _SchoolList(
        search:         _search,
        selected:       _selected,
        onSearchChange: (v) => setState(() => _search = v),
        onSelect:       _selectSchool,
      ),
      // ── DIVIDER ───────────────────────────────────────────────────────────
      const VerticalDivider(width: 1, color: _border),
      // ── RIGHT: Editor ─────────────────────────────────────────────────────
      Expanded(
        child: _selected == null
            ? _NoSelection()
            : _loadingTemplate
                ? const Center(child: CircularProgressIndicator(color: _accent))
                : _Editor(
                    school:     _selected!,
                    template:   _template,
                    absentCtrl: _absentCtrl,
                    lateCtrl:   _lateCtrl,
                    activeTab:  _activeTab,
                    previewMode: _previewMode,
                    saving:     _saving,
                    onTabChange: (i) => setState(() => _activeTab = i),
                    onTogglePreview: () =>
                        setState(() => _previewMode = !_previewMode),
                    onSave:    _save,
                    onReset:   _resetDefault,
                    buildPreview: _buildPreview,
                  ),
      ),
    ]);
  }
}

// ── Left panel: school list ───────────────────────────────────────────────────

class _SchoolList extends StatelessWidget {
  final String  search;
  final School? selected;
  final ValueChanged<String>  onSearchChange;
  final ValueChanged<School>  onSelect;

  const _SchoolList({
    required this.search,
    required this.selected,
    required this.onSearchChange,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 280,
      child: Column(children: [
        // Header
        Container(
          height: 60,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          color: _surface,
          alignment: Alignment.centerLeft,
          child: const Text(
            'Select School',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const Divider(height: 1, color: _border),
        // Search
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Search school…',
              hintStyle: const TextStyle(color: _muted2),
              prefixIcon: const Icon(Icons.search, color: _muted2, size: 18),
              filled: true,
              fillColor: _bg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: _border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: _border),
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 8),
            ),
            onChanged: onSearchChange,
          ),
        ),
        // School list
        Expanded(
          child: StreamBuilder<List<School>>(
            stream: FirebaseService.schoolsStream(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(
                    child: CircularProgressIndicator(color: _accent));
              }
              final all    = snap.data ?? [];
              final schools = search.isEmpty
                  ? all
                  : all.where((s) =>
                      s.name.toLowerCase().contains(search.toLowerCase()))
                      .toList();

              if (schools.isEmpty) {
                return const Center(
                  child: Text('No schools found',
                      style: TextStyle(color: _muted2, fontSize: 13)),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: schools.length,
                itemBuilder: (_, i) {
                  final s          = schools[i];
                  final isSelected = selected?.id == s.id;
                  return GestureDetector(
                    onTap: () => onSelect(s),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 4),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? _accentD.withValues(alpha: 0.15)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isSelected ? _accentD : Colors.transparent,
                        ),
                      ),
                      child: Row(children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundColor:
                              _accentD.withValues(alpha: 0.2),
                          child: Text(
                            s.name[0],
                            style: const TextStyle(
                                color: _accent,
                                fontWeight: FontWeight.bold,
                                fontSize: 12),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                s.name,
                                style: TextStyle(
                                  color: isSelected ? _accent : Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                s.isActive ? 'Active' : 'Locked',
                                style: TextStyle(
                                  color: s.isActive ? _green : _red,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isSelected)
                          const Icon(Icons.edit_note,
                              color: _accent, size: 16),
                      ]),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────────────────────

class _NoSelection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: _surface, borderRadius: BorderRadius.circular(20)),
            child: const Icon(Icons.sms_outlined, color: _muted2, size: 34),
          ),
          const SizedBox(height: 16),
          const Text('Select a school to edit its SMS templates',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          const Text(
            'Templates are sent to parents when a student is absent or late.',
            style: TextStyle(color: _muted2, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

// ── Right panel: editor ───────────────────────────────────────────────────────

class _Editor extends StatelessWidget {
  final School         school;
  final SmsTemplate?   template;
  final TextEditingController absentCtrl;
  final TextEditingController lateCtrl;
  final int            activeTab;
  final bool           previewMode;
  final bool           saving;
  final ValueChanged<int>  onTabChange;
  final VoidCallback       onTogglePreview;
  final VoidCallback       onSave;
  final VoidCallback       onReset;
  final String Function(String) buildPreview;

  const _Editor({
    required this.school,
    required this.template,
    required this.absentCtrl,
    required this.lateCtrl,
    required this.activeTab,
    required this.previewMode,
    required this.saving,
    required this.onTabChange,
    required this.onTogglePreview,
    required this.onSave,
    required this.onReset,
    required this.buildPreview,
  });

  @override
  Widget build(BuildContext context) {
    final currentCtrl = activeTab == 0 ? absentCtrl : lateCtrl;

    return Column(children: [
      // ── Top bar ───────────────────────────────────────────────────────────
      Container(
        height: 60,
        color: _surface,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: _accentD.withValues(alpha: 0.2),
            child: Text(school.name[0],
                style: const TextStyle(
                    color: _accent, fontSize: 11, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 10),
          Text(school.name,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold)),
          const SizedBox(width: 8),
          const Text('— SMS Templates',
              style: TextStyle(color: _muted, fontSize: 14)),
          const Spacer(),
          // Preview toggle
          TextButton.icon(
            style: TextButton.styleFrom(
              foregroundColor: previewMode ? _amber : _muted,
            ),
            icon: Icon(
                previewMode ? Icons.edit_outlined : Icons.preview_outlined,
                size: 16),
            label: Text(previewMode ? 'Edit' : 'Preview',
                style: const TextStyle(fontSize: 13)),
            onPressed: onTogglePreview,
          ),
          const SizedBox(width: 8),
          // Reset
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: _red,
              side: const BorderSide(color: _red, width: 0.8),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
            icon: const Icon(Icons.restore, size: 15),
            label: const Text('Reset', style: TextStyle(fontSize: 13)),
            onPressed: saving ? null : onReset,
          ),
          const SizedBox(width: 8),
          // Save
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _accentD,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            ),
            icon: saving
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.save_outlined, size: 15),
            label:
                Text(saving ? 'Saving…' : 'Save', style: const TextStyle(fontSize: 13)),
            onPressed: saving ? null : onSave,
          ),
        ]),
      ),
      const Divider(height: 1, color: _border),

      Expanded(
        child: Row(children: [
          // ── Main editor / preview ────────────────────────────────────────
          Expanded(
            child: Column(children: [
              // Tab row
              Container(
                color: _surface,
                child: Row(children: [
                  _Tab(
                    label: '📵 Absent',
                    active: activeTab == 0,
                    onTap: () => onTabChange(0),
                  ),
                  _Tab(
                    label: '⏰ Late',
                    active: activeTab == 1,
                    onTap: () => onTabChange(1),
                  ),
                ]),
              ),
              const Divider(height: 1, color: _border),

              if (previewMode)
                // Preview pane
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 420),
                        child: Column(children: [
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: _amber.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: _amber.withValues(alpha: 0.4)),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.info_outline,
                                    color: _amber, size: 13),
                                SizedBox(width: 6),
                                Text(
                                  'Preview with sample data — not the real message',
                                  style: TextStyle(
                                      color: _amber, fontSize: 11.5),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: _surface,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: _border),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.3),
                                  blurRadius: 12,
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(children: [
                                  const Icon(Icons.sms,
                                      color: _accent, size: 16),
                                  const SizedBox(width: 8),
                                  Text(
                                    activeTab == 0
                                        ? 'Absent Notification'
                                        : 'Late Notification',
                                    style: const TextStyle(
                                        color: _accent,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12),
                                  ),
                                ]),
                                const SizedBox(height: 14),
                                const Divider(color: _border, height: 1),
                                const SizedBox(height: 14),
                                SelectableText(
                                  buildPreview(currentCtrl.text),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13.5,
                                    height: 1.7,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            '${currentCtrl.text.length} characters',
                            style: const TextStyle(
                                color: _muted2, fontSize: 11),
                          ),
                        ]),
                      ),
                    ),
                  ),
                )
              else
                // Edit pane
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: TextField(
                      controller: currentCtrl,
                      maxLines: null,
                      expands: true,
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'monospace',
                        fontSize: 13.5,
                        height: 1.7,
                      ),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: _surface,
                        hintText: activeTab == 0
                            ? 'Type your absent notification template…'
                            : 'Type your late notification template…',
                        hintStyle: const TextStyle(color: _muted2),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: _border),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: _border),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              const BorderSide(color: _accent, width: 1.5),
                        ),
                        contentPadding: const EdgeInsets.all(16),
                      ),
                      textAlignVertical: TextAlignVertical.top,
                    ),
                  ),
                ),
            ]),
          ),

          // ── Right sidebar: placeholder chips ──────────────────────────────
          if (!previewMode)
            Container(
              width: 220,
              decoration: const BoxDecoration(
                border: Border(left: BorderSide(color: _border)),
                color: _surface,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Text(
                      'PLACEHOLDERS',
                      style: TextStyle(
                        color: _accent,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      'Tap to copy, then paste into the template.',
                      style: TextStyle(color: _muted2, fontSize: 11),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Divider(color: _border, height: 1),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.all(12),
                      children: _placeholders.map((p) {
                        return _PlaceholderChip(
                          token: p.$1, label: p.$2);
                      }).toList(),
                    ),
                  ),
                  const Divider(color: _border, height: 1),
                  if (template != null)
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('LAST UPDATED',
                              style: TextStyle(
                                  color: _muted2,
                                  fontSize: 10,
                                  letterSpacing: 0.8)),
                          const SizedBox(height: 4),
                          Text(
                            DateFormat('dd MMM yyyy HH:mm')
                                .format(template!.updatedAt),
                            style: const TextStyle(
                                color: _muted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
        ]),
      ),
    ]);
  }
}

// ── Tab widget ────────────────────────────────────────────────────────────────

class _Tab extends StatelessWidget {
  final String label;
  final bool   active;
  final VoidCallback onTap;
  const _Tab({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: active ? _accent : Colors.transparent,
              width: 2,
            ),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? _accent : _muted2,
            fontWeight: active ? FontWeight.w600 : FontWeight.normal,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}

// ── Placeholder chip ──────────────────────────────────────────────────────────

class _PlaceholderChip extends StatefulWidget {
  final String token;
  final String label;
  const _PlaceholderChip({required this.token, required this.label});

  @override
  State<_PlaceholderChip> createState() => _PlaceholderChipState();
}

class _PlaceholderChipState extends State<_PlaceholderChip> {
  bool _copied = false;

  Future<void> _copy() async {
    // Copy to clipboard via Flutter services
    await _clipboardSet(widget.token);
    setState(() => _copied = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _copied = false);
  }

  Future<void> _clipboardSet(String text) async {
    // We need ClipboardData from services
    await Clipboard.setData(ClipboardData(text: text));
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _copy,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: _copied
              ? _green.withValues(alpha: 0.15)
              : _bg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: _copied ? _green : _border,
          ),
        ),
        child: Row(children: [
          Icon(
            _copied ? Icons.check : Icons.copy_outlined,
            color: _copied ? _green : _muted2,
            size: 13,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.token,
                  style: TextStyle(
                    color: _copied ? _green : _accent,
                    fontSize: 11,
                    fontFamily: 'monospace',
                  ),
                ),
                Text(
                  widget.label,
                  style: const TextStyle(color: _muted2, fontSize: 10),
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}