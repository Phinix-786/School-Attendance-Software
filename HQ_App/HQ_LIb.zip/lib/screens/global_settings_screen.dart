// lib/screens/global_settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/global_settings.dart';
import '../services/firebase_service.dart';

class GlobalSettingsScreen extends StatefulWidget {
  const GlobalSettingsScreen({super.key});

  @override
  State<GlobalSettingsScreen> createState() => _GlobalSettingsScreenState();
}

class _GlobalSettingsScreenState extends State<GlobalSettingsScreen> {
  bool _loading = true;
  bool _saving = false;

  // WhatsApp Pricing
  late TextEditingController _metaRate;
  late TextEditingController _sellingRate;
  late TextEditingController _lowWalletThreshold;

  // Automation
  TimeOfDay _nightlyTime = const TimeOfDay(hour: 0, minute: 0);
  late TextEditingController _warningDays;
  late TextEditingController _gracePeriod;

  @override
  void initState() {
    super.initState();
    _metaRate = TextEditingController();
    _sellingRate = TextEditingController();
    _lowWalletThreshold = TextEditingController();
    _warningDays = TextEditingController();
    _gracePeriod = TextEditingController();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final s = await FirebaseService.getGlobalSettings();
    final parts = s.nightlyCheckTime.split(':');
    final hour = int.tryParse(parts[0]) ?? 0;
    final minute = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
    setState(() {
      _metaRate.text = s.metaRate.toString();
      _sellingRate.text = s.sellingRate.toString();
      _lowWalletThreshold.text = s.lowWalletThreshold.toString();
      _nightlyTime = TimeOfDay(hour: hour, minute: minute);
      _warningDays.text = s.warningDaysBeforeExpiry.toString();
      _gracePeriod.text = s.gracePeriodDays.toString();
      _loading = false;
    });
  }

  @override
  void dispose() {
    _metaRate.dispose();
    _sellingRate.dispose();
    _lowWalletThreshold.dispose();
    _warningDays.dispose();
    _gracePeriod.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      final settings = GlobalSettings(
        metaRate: double.tryParse(_metaRate.text.trim()) ?? 2.80,
        sellingRate: double.tryParse(_sellingRate.text.trim()) ?? 3.20,
        lowWalletThreshold:
            double.tryParse(_lowWalletThreshold.text.trim()) ?? 500.0,
        nightlyCheckTime:
            '${_nightlyTime.hour.toString().padLeft(2, '0')}:${_nightlyTime.minute.toString().padLeft(2, '0')}',
        warningDaysBeforeExpiry: int.tryParse(_warningDays.text.trim()) ?? 5,
        gracePeriodDays: int.tryParse(_gracePeriod.text.trim()) ?? 1,
      );
      await FirebaseService.saveGlobalSettings(settings);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Settings saved successfully!'),
            backgroundColor: Color(0xFF22C55E),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving: $e'),
            backgroundColor: const Color(0xFFEF4444),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Color(0xFF0F172A),
        body: Center(
          child: CircularProgressIndicator(color: Color(0xFF38BDF8)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: Column(
        children: [
          // Top bar
          Container(
            height: 60,
            color: const Color(0xFF1E293B),
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                const Icon(Icons.settings, color: Color(0xFF38BDF8), size: 20),
                const SizedBox(width: 10),
                const Text(
                  'Global Settings',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                const Text(
                  'Control rates, thresholds, and system behavior.',
                  style: TextStyle(color: Color(0xFF64748B), fontSize: 13),
                ),
              ],
            ),
          ),
          // Scrollable content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  _sectionCard(
                    icon: '💬',
                    title: 'WhatsApp Pricing',
                    children: [
                      _settingRow(
                        label: 'Meta Rate (Cost to you)',
                        description:
                            'Current Meta API rate for Pakistan — April 2026',
                        prefix: 'Rs.',
                        controller: _metaRate,
                      ),
                      _divider(),
                      _settingRow(
                        label: 'Your Selling Rate (Charged to schools)',
                        description:
                            'Price per message billed from school wallets',
                        prefix: 'Rs.',
                        controller: _sellingRate,
                      ),
                      _divider(),
                      _settingRow(
                        label: 'Low Wallet Alert Threshold',
                        description:
                            'Send WhatsApp alert to principal when wallet falls below this amount',
                        prefix: 'Rs.',
                        controller: _lowWalletThreshold,
                        isInt: true,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _sectionCard(
                    icon: '⏰',
                    title: 'Automation Schedule',
                    children: [
                      _timePickerRow(
                        label: 'Nightly Check Time',
                        description:
                            'Cloud Function runs at this time to check expiry dates',
                      ),
                      _divider(),
                      _settingRow(
                        label: 'Warning Days Before Expiry',
                        description:
                            'Send warning message to principal this many days before expiry',
                        controller: _warningDays,
                        isInt: true,
                        compact: true,
                      ),
                      _divider(),
                      _settingRow(
                        label: 'Grace Period After Expiry',
                        description:
                            'School access continues for this many days after expiry date',
                        controller: _gracePeriod,
                        isInt: true,
                        compact: true,
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  // Save button
                  Align(
                    alignment: Alignment.centerLeft,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0EA5E9),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 28,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      icon: _saving
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.save),
                      label: Text(_saving ? 'Saving…' : 'Save All Settings'),
                      onPressed: _saving ? null : _save,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── UI helpers ─────────────────────────────────────────────────────────────

  Widget _sectionCard({
    required String icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            child: Row(
              children: [
                Text(icon, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          ),
          const Divider(color: Color(0xFF334155), height: 1),
          ...children,
        ],
      ),
    );
  }

  Widget _settingRow({
    required String label,
    required String description,
    required TextEditingController controller,
    String? prefix,
    bool isInt = false,
    bool compact = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: const TextStyle(
                    color: Color(0xFF64748B),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              if (prefix != null)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Text(
                    prefix,
                    style: const TextStyle(color: Color(0xFF94A3B8)),
                  ),
                ),
              SizedBox(
                width: compact ? 80 : 120,
                child: _darkTextField(
                  controller: controller,
                  keyboardType: isInt
                      ? TextInputType.number
                      : const TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: isInt
                      ? [FilteringTextInputFormatter.digitsOnly]
                      : [
                          FilteringTextInputFormatter.allow(
                            RegExp(r'^\d*\.?\d*'),
                          ),
                        ],
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _timePickerRow({required String label, required String description}) {
    final h = _nightlyTime.hour.toString().padLeft(2, '0');
    final m = _nightlyTime.minute.toString().padLeft(2, '0');
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  description,
                  style: const TextStyle(
                    color: Color(0xFF64748B),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: _nightlyTime,
                builder: (ctx, child) =>
                    Theme(data: ThemeData.dark(), child: child!),
              );
              if (picked != null) setState(() => _nightlyTime = picked);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFF0F172A),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFF334155)),
              ),
              child: Row(
                children: [
                  Text(
                    '$h:$m ${_nightlyTime.hour < 12 ? 'AM' : 'PM'}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  const SizedBox(width: 8),
                  const Icon(
                    Icons.access_time,
                    size: 16,
                    color: Color(0xFF64748B),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _divider() => const Divider(
    color: Color(0xFF334155),
    height: 1,
    indent: 20,
    endIndent: 20,
  );

  Widget _darkTextField({
    required TextEditingController controller,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    bool obscure = false,
    String? hint,
    Widget? suffix,
    TextAlign textAlign = TextAlign.start,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      obscureText: obscure,
      textAlign: textAlign,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFF475569)),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFF0F172A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF334155)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF334155)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF0EA5E9)),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 10,
        ),
      ),
    );
  }
}
