// lib/screens/school_billing_screen.dart
//
// Replaces subscription_screen.dart AND wallet_screen.dart.
// Update DashboardScreen to use SchoolBillingScreen for both tabs,
// or merge them into one sidebar entry.
//
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/school.dart';
import '../services/firebase_service.dart';

class SchoolBillingScreen extends StatefulWidget {
  const SchoolBillingScreen({super.key});

  @override
  State<SchoolBillingScreen> createState() => _SchoolBillingScreenState();
}

class _SchoolBillingScreenState extends State<SchoolBillingScreen> {
  School? _selected;
  String _search = '';

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<School>>(
      stream: FirebaseService.schoolsStream(),
      builder: (context, snap) {
        final all = snap.data ?? [];
        final filtered = _search.isEmpty
            ? all
            : all
                .where((s) =>
                    s.name.toLowerCase().contains(_search.toLowerCase()))
                .toList();

        // Keep selected in sync with live data
        if (_selected != null) {
          final live = all.where((s) => s.id == _selected!.id);
          if (live.isNotEmpty) _selected = live.first;
        }

        return Row(
          children: [
            // ── School list panel ────────────────────────────────────────
            Container(
              width: 280,
              decoration: const BoxDecoration(
                color: Color(0xFF1E293B),
                border: Border(right: BorderSide(color: Color(0xFF334155))),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.school,
                                color: Color(0xFF38BDF8), size: 18),
                            SizedBox(width: 8),
                            Text(
                              'Billing',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          style: const TextStyle(
                              color: Colors.white, fontSize: 13),
                          decoration: InputDecoration(
                            hintText: 'Search...',
                            hintStyle: const TextStyle(
                                color: Color(0xFF64748B), fontSize: 13),
                            prefixIcon: const Icon(Icons.search,
                                color: Color(0xFF64748B), size: 16),
                            filled: true,
                            fillColor: const Color(0xFF0F172A),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding:
                                const EdgeInsets.symmetric(vertical: 8),
                            isDense: true,
                          ),
                          onChanged: (v) => setState(() => _search = v),
                        ),
                      ],
                    ),
                  ),
                  const Divider(color: Color(0xFF334155), height: 1),
                  Expanded(
                    child: ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (_, i) {
                        final s = filtered[i];
                        final isSelected = _selected?.id == s.id;

                        Color dot;
                        if (!s.isActive || s.isExpired) {
                          dot = const Color(0xFFEF4444);
                        } else if (s.isExpiringSoon) {
                          dot = const Color(0xFFF59E0B);
                        } else {
                          dot = const Color(0xFF22C55E);
                        }

                        return InkWell(
                          onTap: () {
                            setState(() {
                              _selected = s;
                            });
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? const Color(0xFF0EA5E9)
                                      .withValues(alpha: 0.12)
                                  : null,
                              border: Border(
                                left: BorderSide(
                                  color: isSelected
                                      ? const Color(0xFF0EA5E9)
                                      : Colors.transparent,
                                  width: 3,
                                ),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: dot,
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        s.name,
                                        style: TextStyle(
                                          color: isSelected
                                              ? const Color(0xFF38BDF8)
                                              : Colors.white,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13,
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      Text(
                                        s.isExpired ? 'Expired' : '${s.daysUntilExpiry}d left',
                                        style: TextStyle(
                                            color: dot, fontSize: 11),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),

            // ── Detail panel ─────────────────────────────────────────────
            Expanded(
              child: _selected == null
                  ? _emptyState()
                  : _detailPanel(_selected!),
            ),
          ],
        );
      },
    );
  }

  // ── Empty state ──────────────────────────────────────────────────────────

  Widget _emptyState() {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.school, color: Color(0xFF334155), size: 48),
          SizedBox(height: 12),
          Text(
            'Select a school to manage billing',
            style: TextStyle(color: Color(0xFF64748B), fontSize: 15),
          ),
        ],
      ),
    );
  }

  // ── Main detail panel ────────────────────────────────────────────────────

  Widget _detailPanel(School school) {
    final expiry = school.subscriptionExpiry;
    final start = school.subscriptionStartDate;
    final totalDays = expiry.difference(start).inDays;
    final elapsed =
        DateTime.now().difference(start).inDays.clamp(0, totalDays);
    final progress = totalDays > 0 ? elapsed / totalDays : 1.0;

    Color statusColor;
    String statusText;
    if (!school.isActive) {
      statusColor = const Color(0xFFEF4444);
      statusText = 'LOCKED';
    } else if (school.isExpired) {
      statusColor = const Color(0xFFEF4444);
      statusText = 'EXPIRED';
    } else if (school.isExpiringSoon) {
      statusColor = const Color(0xFFF59E0B);
      statusText = 'EXPIRING SOON';
    } else {
      statusColor = const Color(0xFF22C55E);
      statusText = 'ACTIVE';
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── School header ──────────────────────────────────────────────
          Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor:
                    const Color(0xFF0EA5E9).withValues(alpha: 0.15),
                child: Text(
                  school.name[0],
                  style: const TextStyle(
                    color: Color(0xFF38BDF8),
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      school.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      [
                        if (school.city != null && school.city!.isNotEmpty)
                          school.city!,
                        school.principalName,
                      ].join(' · '),
                      style: const TextStyle(
                          color: Color(0xFF94A3B8), fontSize: 13),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                  border:
                      Border.all(color: statusColor.withValues(alpha: 0.5)),
                ),
                child: Text(
                  statusText,
                  style: TextStyle(
                    color: statusColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // ── Subscription period ────────────────────────────────────────
          _sectionLabel('SUBSCRIPTION PERIOD'),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: _cardDecor(),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _dateChip('Start',
                        DateFormat('dd MMM yyyy').format(start),
                        const Color(0xFF38BDF8)),
                    _dateChip('Expiry',
                        DateFormat('dd MMM yyyy').format(expiry),
                        statusColor),
                  ],
                ),
                const SizedBox(height: 14),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: progress.clamp(0.0, 1.0),
                    minHeight: 8,
                    backgroundColor: const Color(0xFF334155),
                    valueColor: AlwaysStoppedAnimation<Color>(statusColor),
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '$elapsed of $totalDays days elapsed',
                      style: const TextStyle(
                          color: Color(0xFF64748B), fontSize: 12),
                    ),
                    Text(
                      school.isExpired
                          ? 'Expired'
                          : '${school.daysUntilExpiry} days remaining',
                      style: TextStyle(
                          color: statusColor,
                          fontSize: 12,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                // Extend buttons
                Row(
                  children: [
                    _extendBtn('+ 1 Month', 30, school),
                    const SizedBox(width: 8),
                    _extendBtn('+ 3 Months', 90, school),
                    const SizedBox(width: 8),
                    _extendBtn('+ 6 Months', 180, school),
                    const SizedBox(width: 8),
                    _extendBtn('+ 1 Year', 365, school),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ── Plan details ───────────────────────────────────────────────
          _sectionLabel('PLAN DETAILS'),
          const SizedBox(height: 10),
          _infoCard([
            _infoRow('Plan',
                _planLabel(school.subscriptionPlan,
                    school.customSubscriptionDays)),
            _infoRow('Monthly Fee',
                'PKR ${NumberFormat('#,##0').format(school.monthlyFee)}'),
            if (school.notes.isNotEmpty)
              _infoRow('Notes', school.notes),
          ]),

          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ── Extend subscription ──────────────────────────────────────────────────

  Widget _extendBtn(String label, int days, School school) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        foregroundColor: const Color(0xFF38BDF8),
        side: const BorderSide(color: Color(0xFF334155)),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
      onPressed: () async {
        final base = school.isExpired
            ? DateTime.now()
            : school.subscriptionExpiry;
        final newExpiry = base.add(Duration(days: days));
        await FirebaseService.setSubscription(school.id, newExpiry, true);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Extended by $days days'),
              backgroundColor: const Color(0xFF22C55E),
            ),
          );
        }
      },
      child: Text(label, style: const TextStyle(fontSize: 12)),
    );
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  BoxDecoration _cardDecor() => BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      );

  Widget _sectionLabel(String text) => Text(
        text,
        style: const TextStyle(
          color: Color(0xFF38BDF8),
          fontSize: 12,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.0,
        ),
      );

  Widget _infoCard(List<Widget> rows) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardDecor(),
      child: Column(children: rows),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(label,
                style: const TextStyle(
                    color: Color(0xFF94A3B8), fontSize: 12)),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }

  Widget _dateChip(String label, String date, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                color: Color(0xFF64748B), fontSize: 11)),
        const SizedBox(height: 2),
        Text(date,
            style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 14)),
      ],
    );
  }

  String _planLabel(String plan, int? customDays) {
    switch (plan) {
      case '1month':
        return '1 Month';
      case '3months':
        return '3 Months';
      case 'custom':
        return 'Custom (${customDays ?? '?'} days)';
      default:
        return plan;
    }
  }
}