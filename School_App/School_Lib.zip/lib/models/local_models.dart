// lib/models/local_models.dart
// Local-only data models — not synced to Firestore.

class AppSettings {
  final String activeThemeId;       // 'light' | 'dark' | custom name
  final bool autohideSidebar;
  final int autohideDelaySecs;      // 5–30
  final List<String> hiddenNavItems; // labels of hidden nav items

  const AppSettings({
    this.activeThemeId = 'light',
    this.autohideSidebar = false,
    this.autohideDelaySecs = 10,
    this.hiddenNavItems = const [],
  });

  AppSettings copyWith({
    String? activeThemeId,
    bool? autohideSidebar,
    int? autohideDelaySecs,
    List<String>? hiddenNavItems,
  }) =>
      AppSettings(
        activeThemeId: activeThemeId ?? this.activeThemeId,
        autohideSidebar: autohideSidebar ?? this.autohideSidebar,
        autohideDelaySecs: autohideDelaySecs ?? this.autohideDelaySecs,
        hiddenNavItems: hiddenNavItems ?? List.unmodifiable(this.hiddenNavItems),
      );

  Map<String, dynamic> toJson() => {
        'activeThemeId': activeThemeId,
        'autohideSidebar': autohideSidebar,
        'autohideDelaySecs': autohideDelaySecs,
        'hiddenNavItems': hiddenNavItems,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        activeThemeId: j['activeThemeId'] as String? ?? 'light',
        autohideSidebar: j['autohideSidebar'] as bool? ?? false,
        autohideDelaySecs: (j['autohideDelaySecs'] as num?)?.toInt() ?? 10,
        hiddenNavItems: List<String>.from(j['hiddenNavItems'] ?? []),
      );
}

class CustomTheme {
  final String id;
  final String name;
  final String bgColor;      // hex e.g. '#FEF6E4'
  final String cardColor;
  final String navyColor;
  final String accentColor;
  final String mutedColor;
  final String borderColor;

  const CustomTheme({
    required this.id,
    required this.name,
    required this.bgColor,
    required this.cardColor,
    required this.navyColor,
    required this.accentColor,
    required this.mutedColor,
    required this.borderColor,
  });

  CustomTheme copyWith({
    String? id,
    String? name,
    String? bgColor,
    String? cardColor,
    String? navyColor,
    String? accentColor,
    String? mutedColor,
    String? borderColor,
  }) =>
      CustomTheme(
        id: id ?? this.id,
        name: name ?? this.name,
        bgColor: bgColor ?? this.bgColor,
        cardColor: cardColor ?? this.cardColor,
        navyColor: navyColor ?? this.navyColor,
        accentColor: accentColor ?? this.accentColor,
        mutedColor: mutedColor ?? this.mutedColor,
        borderColor: borderColor ?? this.borderColor,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'bgColor': bgColor,
        'cardColor': cardColor,
        'navyColor': navyColor,
        'accentColor': accentColor,
        'mutedColor': mutedColor,
        'borderColor': borderColor,
      };

  factory CustomTheme.fromJson(Map<String, dynamic> j) => CustomTheme(
        id: j['id'] as String? ?? '',
        name: j['name'] as String? ?? '',
        bgColor: j['bgColor'] as String? ?? '#FEF6E4',
        cardColor: j['cardColor'] as String? ?? '#FFFFFF',
        navyColor: j['navyColor'] as String? ?? '#001858',
        accentColor: j['accentColor'] as String? ?? '#82F5B2',
        mutedColor: j['mutedColor'] as String? ?? '#8896AA',
        borderColor: j['borderColor'] as String? ?? '#E8EEF4',
      );
}

class LockConfig {
  final bool enabled;
  final String type;       // 'pin' | 'password'
  final String hashValue;  // SHA-256 hex

  const LockConfig({
    this.enabled = false,
    this.type = 'pin',
    this.hashValue = '',
  });

  LockConfig copyWith({bool? enabled, String? type, String? hashValue}) =>
      LockConfig(
        enabled: enabled ?? this.enabled,
        type: type ?? this.type,
        hashValue: hashValue ?? this.hashValue,
      );

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'type': type,
        'hashValue': hashValue,
      };

  factory LockConfig.fromJson(Map<String, dynamic> j) => LockConfig(
        enabled: j['enabled'] as bool? ?? false,
        type: j['type'] as String? ?? 'pin',
        hashValue: j['hashValue'] as String? ?? '',
      );
}
