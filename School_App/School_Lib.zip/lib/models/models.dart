// lib/models/models.dart
import 'package:cloud_firestore/cloud_firestore.dart';

// ── Class Model ───────────────────────────────────────────────
class SchoolClass {
  final String id;
  final String schoolId;
  final String name;
  final String grade;
  final String section;

  SchoolClass({
    required this.id, required this.schoolId, required this.name,
    required this.grade, required this.section,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'name': name,
        'grade': grade, 'section': section,
      };

  factory SchoolClass.fromMap(Map<String, dynamic> m) => SchoolClass(
        id: m['id'] ?? '', schoolId: m['schoolId'] ?? '',
        name: m['name'] ?? '', grade: m['grade'] ?? '', section: m['section'] ?? '',
      );
}

// ── Student Model ─────────────────────────────────────────────
class Student {
  final String id;
  final String schoolId;
  final String classId;
  final String name;
  final String rollNo;
  final String parentPhone;
  // Student app credentials
  final String studentLoginId;
  final String studentPassword;
  // Parent app credentials (separate)
  final String parentLoginId;
  final String parentPassword;

  Student({
    required this.id, required this.schoolId, required this.classId,
    required this.name, required this.rollNo, required this.parentPhone,
    this.studentLoginId  = '',
    this.studentPassword = '',
    this.parentLoginId   = '',
    this.parentPassword  = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'name': name, 'rollNo': rollNo, 'parentPhone': parentPhone,
        'studentLoginId':  studentLoginId,
        'studentPassword': studentPassword,
        'parentLoginId':   parentLoginId,
        'parentPassword':  parentPassword,
      };

  factory Student.fromMap(Map<String, dynamic> m) => Student(
        id:              m['id']              ?? '',
        schoolId:        m['schoolId']        ?? '',
        classId:         m['classId']         ?? '',
        name:            m['name']            ?? '',
        rollNo:          m['rollNo']          ?? '',
        parentPhone:     m['parentPhone']     ?? '',
        studentLoginId:  m['studentLoginId']  ?? '',
        studentPassword: m['studentPassword'] ?? '',
        parentLoginId:   m['parentLoginId']   ?? '',
        parentPassword:  m['parentPassword']  ?? '',
      );
}

// ── Timetable ─────────────────────────────────────────────────
class TimetableEntry {
  final String day;       // 'Monday' … 'Saturday'
  final String period;    // '1', '2', … '8'
  final String subject;
  final String classId;
  final String className;

  TimetableEntry({
    required this.day,
    required this.period,
    required this.subject,
    required this.classId,
    required this.className,
  });

  Map<String, dynamic> toMap() => {
        'day': day, 'period': period,
        'subject': subject, 'classId': classId, 'className': className,
      };

  factory TimetableEntry.fromMap(Map<String, dynamic> m) => TimetableEntry(
        day:       m['day']       ?? '',
        period:    m['period']    ?? '',
        subject:   m['subject']   ?? '',
        classId:   m['classId']   ?? '',
        className: m['className'] ?? '',
      );
}

class TeacherTimetable {
  final String             teacherId;
  final String             teacherName;
  final DateTime           updatedAt;
  final List<TimetableEntry> entries;

  TeacherTimetable({
    required this.teacherId,
    required this.teacherName,
    required this.updatedAt,
    required this.entries,
  });

  Map<String, dynamic> toMap() => {
        'teacherId':   teacherId,
        'teacherName': teacherName,
        'updatedAt':   Timestamp.fromDate(updatedAt),
        'entries':     entries.map((e) => e.toMap()).toList(),
      };

  factory TeacherTimetable.fromMap(Map<String, dynamic> m) => TeacherTimetable(
        teacherId:   m['teacherId']   ?? '',
        teacherName: m['teacherName'] ?? '',
        updatedAt:   m['updatedAt'] != null
            ? (m['updatedAt'] as Timestamp).toDate()
            : DateTime.now(),
        entries: (m['entries'] as List<dynamic>? ?? [])
            .map((e) => TimetableEntry.fromMap(e as Map<String, dynamic>))
            .toList(),
      );
}

// ── Teacher Model ─────────────────────────────────────────────
class Teacher {
  final String id;
  final String schoolId;
  final String name;
  final String phone;
  final String email;
  final String password;
  final List<String> assignedClassIds;

  /// Which classes this teacher is the CLASS TEACHER of.
  /// Class teacher = can mark attendance for that class.
  /// Other teachers can still log in and send homework.
  final List<String> classTeacherOf;

  /// Subject assigned per class: {'classId': 'Subject Name'}
  final Map<String, String> classSubjects;

  Teacher({
    required this.id, required this.schoolId, required this.name,
    required this.phone, required this.email, required this.password,
    required this.assignedClassIds,
    this.classTeacherOf = const [],
    this.classSubjects  = const {},
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'name': name,
        'phone': phone, 'email': email, 'password': password,
        'assignedClassIds': assignedClassIds,
        'classTeacherOf':   classTeacherOf,
        'classSubjects':    classSubjects,
      };

  factory Teacher.fromMap(Map<String, dynamic> m) => Teacher(
        id:               m['id']       ?? '',
        schoolId:         m['schoolId'] ?? '',
        name:             m['name']     ?? '',
        phone:            m['phone']    ?? '',
        email:            m['email']    ?? '',
        password:         m['password'] ?? '',
        assignedClassIds: List<String>.from(m['assignedClassIds'] ?? []),
        classTeacherOf:   List<String>.from(m['classTeacherOf']   ?? []),
        classSubjects:    Map<String, String>.from(m['classSubjects'] ?? {}),
      );
}

// ── Attendance Record ─────────────────────────────────────────
enum AttendanceStatus { present, absent, late }

class AttendanceRecord {
  final String id;
  final String schoolId;
  final String classId;
  final String studentId;
  final String teacherId;
  final String sessionId;
  final AttendanceStatus status;
  final DateTime date;
  final bool messageSent;
  final int? lateMinutes;

  AttendanceRecord({
    this.id = '', this.schoolId = '', this.classId = '',
    this.teacherId = '', DateTime? date,
    required this.studentId, required this.sessionId,
    required this.status,
    this.messageSent = false, this.lateMinutes,
  }) : date = date ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'studentId': studentId, 'teacherId': teacherId, 'sessionId': sessionId,
        'status': status.name, 'date': Timestamp.fromDate(date),
        'messageSent': messageSent,
        if (lateMinutes != null) 'lateMinutes': lateMinutes,
      };

  factory AttendanceRecord.fromMap(Map<String, dynamic> m) => AttendanceRecord(
        id: m['id'] ?? '', schoolId: m['schoolId'] ?? '',
        classId: m['classId'] ?? '', studentId: m['studentId'] ?? '',
        teacherId: m['teacherId'] ?? '', sessionId: m['sessionId'] ?? '',
        status: AttendanceStatus.values.firstWhere(
          (e) => e.name == m['status'],
          orElse: () => AttendanceStatus.present,
        ),
        date: m['date'] != null
            ? (m['date'] as Timestamp).toDate()
            : DateTime.now(),
        messageSent: m['messageSent'] ?? false,
        lateMinutes: (m['lateMinutes'] as num?)?.toInt(),
      );
}

// ── Test + TestResult ─────────────────────────────────────────
class SchoolTest {
  final String       id;
  final String       schoolId;
  final String       classId;
  final String       teacherId;
  final String       subject;
  final String       topic;
  final DateTime     testDate;

  SchoolTest({
    required this.id, required this.schoolId, required this.classId,
    required this.teacherId, required this.subject, required this.topic,
    required this.testDate,
  });

  factory SchoolTest.fromMap(Map<String, dynamic> m) => SchoolTest(
        id:        m['id']        ?? '',
        schoolId:  m['schoolId']  ?? '',
        classId:   m['classId']   ?? '',
        teacherId: m['teacherId'] ?? '',
        subject:   m['subject']   ?? '',
        topic:     m['topic']     ?? '',
        testDate: m['testDate'] != null
            ? (m['testDate'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

class TestResult {
  final String   id;
  final String   testId;
  final String   studentId;
  final String   studentName;
  final int      marksObtained;
  final int      marksTotal;
  final bool     wasAbsent;

  TestResult({
    required this.id, required this.testId, required this.studentId,
    required this.studentName, required this.marksObtained,
    required this.marksTotal, this.wasAbsent = false,
  });

  double get percentage =>
      marksTotal > 0 ? (marksObtained / marksTotal) * 100 : 0;

  factory TestResult.fromMap(Map<String, dynamic> m) => TestResult(
        id:            m['id']            ?? '',
        testId:        m['testId']        ?? '',
        studentId:     m['studentId']     ?? '',
        studentName:   m['studentName']   ?? '',
        marksObtained: m['marksObtained'] ?? 0,
        marksTotal:    m['marksTotal']    ?? 0,
        wasAbsent:     m['wasAbsent']     ?? false,
      );
}

// ── School Notice ─────────────────────────────────────────────
class SchoolNotice {
  final String   id;
  final String   schoolId;
  final String   sectionId;
  final String   title;
  final String   body;
  final String   targetAudience; // 'teachers' | 'parents' | 'students' | 'all'
  final String   createdBy;
  final DateTime createdAt;

  SchoolNotice({
    required this.id, required this.schoolId, required this.sectionId,
    required this.title, required this.body, required this.targetAudience,
    required this.createdBy, required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'sectionId': sectionId,
        'title': title, 'body': body, 'targetAudience': targetAudience,
        'createdBy': createdBy, 'createdAt': Timestamp.fromDate(createdAt),
      };

  factory SchoolNotice.fromMap(Map<String, dynamic> m) => SchoolNotice(
        id:             m['id']             ?? '',
        schoolId:       m['schoolId']       ?? '',
        sectionId:      m['sectionId']      ?? '',
        title:          m['title']          ?? '',
        body:           m['body']           ?? '',
        targetAudience: m['targetAudience'] ?? 'all',
        createdBy:      m['createdBy']      ?? '',
        createdAt: m['createdAt'] != null
            ? (m['createdAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

// ── Leave Request ─────────────────────────────────────────────
class LeaveRequest {
  final String   id;
  final String   studentId;
  final String   studentName;
  final String   classId;
  final String   sectionId;
  final DateTime requestedDate;
  final String   reason;
  final String   status; // 'pending' | 'approved' | 'rejected'
  final String   submittedBy; // 'student' | 'parent'
  final DateTime submittedAt;
  final String   remarks;

  LeaveRequest({
    required this.id, required this.studentId, required this.studentName,
    required this.classId, required this.sectionId,
    required this.requestedDate, required this.reason,
    required this.status, required this.submittedBy, required this.submittedAt,
    this.remarks = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'studentId': studentId, 'studentName': studentName,
        'classId': classId, 'sectionId': sectionId,
        'requestedDate': Timestamp.fromDate(requestedDate),
        'reason': reason, 'status': status, 'submittedBy': submittedBy,
        'submittedAt': Timestamp.fromDate(submittedAt), 'remarks': remarks,
      };

  factory LeaveRequest.fromMap(Map<String, dynamic> m) => LeaveRequest(
        id:            m['id']          ?? '',
        studentId:     m['studentId']   ?? '',
        studentName:   m['studentName'] ?? '',
        classId:       m['classId']     ?? '',
        sectionId:     m['sectionId']   ?? '',
        requestedDate: m['requestedDate'] != null
            ? (m['requestedDate'] as Timestamp).toDate()
            : DateTime.now(),
        reason:        m['reason']      ?? '',
        status:        m['status']      ?? 'pending',
        submittedBy:   m['submittedBy'] ?? '',
        submittedAt:   m['submittedAt'] != null
            ? (m['submittedAt'] as Timestamp).toDate()
            : DateTime.now(),
        remarks:       m['remarks']     ?? '',
      );
}

// ── Stored Document ───────────────────────────────────────────
class StoredDocument {
  final String id;
  final String name;
  final String type;        // 'CV' | 'CNIC' | 'Contract' | 'Certificate' | 'Other'
  final String fileUrl;     // base64 data URI or remote URL
  final String uploadedBy;  // uploader displayName
  final String notes;
  final DateTime uploadedAt;

  StoredDocument({
    required this.id,
    required this.name,
    required this.type,
    required this.fileUrl,
    required this.uploadedBy,
    required this.notes,
    required this.uploadedAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'type': type,
        'fileUrl': fileUrl,
        'uploadedBy': uploadedBy,
        'notes': notes,
        'uploadedAt': Timestamp.fromDate(uploadedAt),
      };

  factory StoredDocument.fromMap(Map<String, dynamic> m) => StoredDocument(
        id: m['id'] ?? '',
        name: m['name'] ?? '',
        type: m['type'] ?? 'Other',
        fileUrl: m['fileUrl'] ?? '',
        uploadedBy: m['uploadedBy'] ?? '',
        notes: m['notes'] ?? '',
        uploadedAt: m['uploadedAt'] != null
            ? (m['uploadedAt'] as Timestamp).toDate()
            : DateTime.now(),
      );
}

// ── Fee Record ────────────────────────────────────────────────
class FeeRecord {
  final String id;
  final String studentId;
  final String studentName;
  final String classId;
  final double amount;
  final double paid;
  final String month;   // 'YYYY-MM' e.g. '2025-01'
  final String status;  // 'paid' | 'partial' | 'pending'
  final DateTime? paidAt;
  final String notes;

  FeeRecord({
    required this.id,
    required this.studentId,
    required this.studentName,
    required this.classId,
    required this.amount,
    required this.paid,
    required this.month,
    required this.status,
    this.paidAt,
    this.notes = '',
  });

  double get outstanding => (amount - paid).clamp(0, double.infinity);

  Map<String, dynamic> toMap() => {
        'id': id,
        'studentId': studentId,
        'studentName': studentName,
        'classId': classId,
        'amount': amount,
        'paid': paid,
        'month': month,
        'status': status,
        if (paidAt != null) 'paidAt': Timestamp.fromDate(paidAt!),
        'notes': notes,
      };

  factory FeeRecord.fromMap(Map<String, dynamic> m) => FeeRecord(
        id: m['id'] ?? '',
        studentId: m['studentId'] ?? '',
        studentName: m['studentName'] ?? '',
        classId: m['classId'] ?? '',
        amount: (m['amount'] as num?)?.toDouble() ?? 0.0,
        paid: (m['paid'] as num?)?.toDouble() ?? 0.0,
        month: m['month'] ?? '',
        status: m['status'] ?? 'pending',
        paidAt: m['paidAt'] != null
            ? (m['paidAt'] as Timestamp).toDate()
            : null,
        notes: m['notes'] ?? '',
      );
}

// ── Attendance Session ────────────────────────────────────────
class AttendanceSession {
  final String id;
  final String schoolId;
  final String classId;
  final String teacherId;
  final DateTime date;
  final bool isSubmitted;
  final bool messagesSent;

  AttendanceSession({
    required this.id, required this.schoolId, required this.classId,
    required this.teacherId, required this.date,
    this.isSubmitted = false, this.messagesSent = false,
  });

  Map<String, dynamic> toMap() => {
        'id': id, 'schoolId': schoolId, 'classId': classId,
        'teacherId': teacherId, 'date': Timestamp.fromDate(date),
        'isSubmitted': isSubmitted, 'messagesSent': messagesSent,
      };

  factory AttendanceSession.fromMap(Map<String, dynamic> m) =>
      AttendanceSession(
        id: m['id'] ?? '', schoolId: m['schoolId'] ?? '',
        classId: m['classId'] ?? '', teacherId: m['teacherId'] ?? '',
        date: m['date'] != null
            ? (m['date'] as Timestamp).toDate()
            : DateTime.now(),
        isSubmitted: m['isSubmitted'] ?? false,
        messagesSent: m['messagesSent'] ?? false,
      );
}
