// lib/backend_image.dart
// Displays images stored on the Ubuntu backend.
// Handles three cases transparently:
//   1. Relative path  "/files/..."  → prepends kBackendBaseUrl
//   2. Full URL       "http://..."  → used as-is
//   3. Legacy         "data:image/..." base64 → decoded locally
// If the backend is unreachable the widget shows a grey placeholder
// (no crash, no error message to the user).
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'backend_config.dart';

// ── Singleton HTTP client with API-key header ─────────────────
class _ImgClient {
  _ImgClient._();
  static final instance = _ImgClient._();

  final HttpClient _c = HttpClient()
    ..connectionTimeout = const Duration(seconds: 8);

  Future<Uint8List> get(String url) async {
    final request  = await _c.getUrl(Uri.parse(url));
    request.headers.set('X-API-Key', kBackendApiKey);
    final response = await request.close();
    if (response.statusCode != 200) {
      throw Exception('HTTP ${response.statusCode}');
    }
    final chunks = <List<int>>[];
    await for (final chunk in response) {
      chunks.add(chunk);
    }
    return Uint8List.fromList(chunks.expand((e) => e).toList());
  }
}

// ── Widget ────────────────────────────────────────────────────
class BackendImage extends StatefulWidget {
  final String  url;
  final BoxFit  fit;
  final double? width;
  final double? height;

  const BackendImage(
    this.url, {
    super.key,
    this.fit    = BoxFit.cover,
    this.width,
    this.height,
  });

  @override
  State<BackendImage> createState() => _BackendImageState();
}

class _BackendImageState extends State<BackendImage> {
  Uint8List? _bytes;
  bool       _loading = true;
  bool       _error   = false;

  @override
  void initState() {
    super.initState();
    _load(widget.url);
  }

  @override
  void didUpdateWidget(BackendImage old) {
    super.didUpdateWidget(old);
    if (old.url != widget.url) {
      setState(() { _loading = true; _error = false; _bytes = null; });
      _load(widget.url);
    }
  }

  Future<void> _load(String url) async {
    if (url.isEmpty) {
      if (mounted) setState(() { _loading = false; _error = true; });
      return;
    }

    // Legacy base64 data URI
    if (url.startsWith('data:')) {
      try {
        final bytes = base64Decode(url.split(',').last);
        if (mounted) setState(() { _bytes = bytes; _loading = false; });
      } catch (_) {
        if (mounted) setState(() { _loading = false; _error = true; });
      }
      return;
    }

    // Backend URL (relative or absolute)
    final fullUrl = url.startsWith('http') ? url : '$kBackendBaseUrl$url';
    try {
      final bytes = await _ImgClient.instance.get(fullUrl);
      if (mounted) setState(() { _bytes = bytes; _loading = false; });
    } catch (_) {
      // Backend unreachable → show placeholder, don't crash
      if (mounted) setState(() { _loading = false; _error = true; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return SizedBox(
        width:  widget.width,
        height: widget.height,
        child: const Center(
            child: SizedBox(width: 20, height: 20,
                child: CircularProgressIndicator(strokeWidth: 2))),
      );
    }
    if (_error || _bytes == null) {
      return _Placeholder(width: widget.width, height: widget.height);
    }
    return Image.memory(
      _bytes!,
      fit:    widget.fit,
      width:  widget.width,
      height: widget.height,
    );
  }
}

// ── Offline placeholder ───────────────────────────────────────
class _Placeholder extends StatelessWidget {
  final double? width;
  final double? height;
  const _Placeholder({this.width, this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      width:  width,
      height: height,
      color:  Colors.grey.shade200,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cloud_off_rounded,
              color: Colors.grey.shade400, size: 28),
          const SizedBox(height: 4),
          Text('Service\nunavailable',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: Colors.grey.shade500, fontSize: 10)),
        ],
      ),
    );
  }
}
