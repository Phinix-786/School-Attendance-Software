// lib/screens/app_lock_screen.dart
// Shown on app start (or after inactivity) when app lock is enabled.
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_theme.dart';
import '../services/local_settings_service.dart';
import '../models/local_models.dart';

class AppLockScreen extends StatefulWidget {
  final LockConfig lockConfig;
  final VoidCallback onUnlocked;

  const AppLockScreen({
    super.key,
    required this.lockConfig,
    required this.onUnlocked,
  });

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen>
    with TickerProviderStateMixin {
  final _textCtrl = TextEditingController();
  final _focusNode = FocusNode();

  int _failCount = 0;
  static const int _maxFails = 5;
  bool _lockedOut = false;
  String? _error;
  bool _obscureText = true;

  // For PIN mode: collect digits
  final List<String> _pinDigits = [];

  // Animations
  late final AnimationController _shakeCtrl;
  late final Animation<double> _shakeAnim;
  late final AnimationController _fadeCtrl;
  late final Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 450));
    _shakeAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _focusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    _fadeCtrl.dispose();
    _textCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submitPin() {
    if (_lockedOut) return;
    final input = widget.lockConfig.type == 'pin'
        ? _pinDigits.join()
        : _textCtrl.text.trim();

    if (input.isEmpty) return;

    final ok = LocalSettingsService.verifyPin(input, widget.lockConfig.hashValue);
    if (ok) {
      _fadeCtrl.reverse().then((_) {
        if (mounted) widget.onUnlocked();
      });
    } else {
      _failCount++;
      if (widget.lockConfig.type == 'pin') {
        _pinDigits.clear();
        setState(() {});
      } else {
        _textCtrl.clear();
      }
      if (_failCount >= _maxFails) {
        setState(() {
          _lockedOut = true;
          _error =
              'Too many failed attempts. Close the app and try again.';
        });
      } else {
        setState(() {
          _error =
              'Incorrect ${widget.lockConfig.type == 'pin' ? 'PIN' : 'password'}. '
              '${_maxFails - _failCount} attempts remaining.';
        });
        _shakeCtrl.forward(from: 0);
      }
    }
  }

  void _onPinKey(String digit) {
    if (_lockedOut) return;
    if (_pinDigits.length >= 6) return; // hard cap at 6
    setState(() {
      _pinDigits.add(digit);
      _error = null;
    });
    // No auto-submit — user taps Unlock when ready (supports 4–6 digit PINs)
  }

  void _onBackspace() {
    if (_pinDigits.isEmpty) return;
    setState(() {
      _pinDigits.removeLast();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isPin = widget.lockConfig.type == 'pin';

    return Scaffold(
      backgroundColor: cBg(context),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Responsive card width — never wider than 400, never wider than screen
            final cardW = (constraints.maxWidth * 0.9).clamp(280.0, 400.0);
            // Use less padding on small heights
            final vPad  = constraints.maxHeight < 600 ? 20.0 : 32.0;

            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: vPad),
                    child: AnimatedBuilder(
                      animation: _shakeAnim,
                      builder: (_, child) => Transform.translate(
                          offset: Offset(_shakeAnim.value, 0), child: child!),
                      child: Container(
                        width: cardW,
                        padding: EdgeInsets.symmetric(
                            horizontal: 28, vertical: vPad),
                        decoration: BoxDecoration(
                          color:        cCard(context),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: cBorder(context), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color:      kNavy.withValues(alpha: 0.08),
                              blurRadius: 32,
                              offset:     const Offset(0, 12),
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Icon
                            Container(
                              width: 56, height: 56,
                              decoration: BoxDecoration(
                                color:        cNavy(context).withValues(alpha: 0.08),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Icon(Icons.lock_rounded,
                                  color: cNavy(context), size: 26),
                            ),
                            const SizedBox(height: 16),
                            Text('App Locked',
                                style: TextStyle(
                                    color:      cNavy(context),
                                    fontSize:   20,
                                    fontWeight: FontWeight.w800)),
                            const SizedBox(height: 4),
                            Text(
                              isPin
                                  ? 'Enter your PIN to continue'
                                  : 'Enter your password to continue',
                              style: TextStyle(
                                  color: cMuted(context), fontSize: 12.5),
                            ),
                            const SizedBox(height: 22),

                            if (isPin) ...[
                              _buildPinDots(),
                              const SizedBox(height: 18),
                              _buildNumPad(),
                              const SizedBox(height: 14),
                              _buildUnlockButton(),
                            ] else ...[
                              _buildPasswordField(),
                              const SizedBox(height: 14),
                              _buildUnlockButton(),
                            ],

                            // Error
                            if (_error != null) ...[
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color:        kError.withValues(alpha: 0.08),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      color: kError.withValues(alpha: 0.25)),
                                ),
                                child: Row(children: [
                                  Icon(Icons.error_outline_rounded,
                                      color: kError, size: 15),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(_error!,
                                        style: const TextStyle(
                                            color:      kError,
                                            fontSize:   12,
                                            fontWeight: FontWeight.w500)),
                                  ),
                                ]),
                              ),
                            ],

                            const SizedBox(height: 16),
                            GestureDetector(
                              onTap: _resetLock,
                              child: Text('Forgot PIN? Reset lock',
                                  style: TextStyle(
                                    color:      cMuted(context),
                                    fontSize:   12,
                                    decoration: TextDecoration.underline,
                                    decorationColor: cMuted(context),
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _resetLock() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(ctx),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Reset App Lock',
            style: TextStyle(
                color:      cNavy(ctx),
                fontSize:   16,
                fontWeight: FontWeight.w800)),
        content: Text(
          'This will disable the app lock and let you in. '
          'You can set a new lock from Settings → Profile.',
          style: TextStyle(color: cMuted(ctx), fontSize: 13, height: 1.5),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text('Cancel',
                  style: TextStyle(color: cMuted(ctx)))),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy,
                  foregroundColor: Colors.white,
                  elevation: 0),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Reset & Enter')),
        ],
      ),
    );
    if (confirm != true) return;
    // Wipe the lock config from disk
    await LocalSettingsService.instance.saveLockConfig(const LockConfig(
      enabled:   false,
      type:      'pin',
      hashValue: '',
    ));
    // Proceed into the app
    if (mounted) widget.onUnlocked();
  }

  Widget _buildPinDots() {
    // Show exactly as many dots as digits entered, min 4 placeholders
    // so the user sees the minimum expected length.
    final entered     = _pinDigits.length;
    final dotCount    = entered < 4 ? 4 : entered; // show at least 4
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(dotCount, (i) {
        final filled = i < entered;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width:  14,
          height: 14,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: filled ? cNavy(context) : Colors.transparent,
            border: Border.all(
              color: filled ? cNavy(context) : cBorder(context),
              width: 1.8,
            ),
          ),
        );
      }),
    );
  }

  Widget _buildNumPad() {
    const keys = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['', '0', '⌫'],
    ];
    return LayoutBuilder(
      builder: (_, c) {
        // Key size: fit 3 keys + gaps in available width
        final keyW = ((c.maxWidth - 24) / 3).clamp(56.0, 88.0);
        final keyH = (keyW * 0.75).clamp(48.0, 66.0);
        return Column(
          children: keys.map((row) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: row.map((k) {
                  if (k.isEmpty) {
                    return SizedBox(width: keyW + 8, height: keyH);
                  }
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: SizedBox(
                      width:  keyW,
                      height: keyH,
                      child: _NumKey(
                        label:      k,
                        onTap:      k == '⌫' ? _onBackspace : () => _onPinKey(k),
                        isBackspace: k == '⌫',
                        disabled:   _lockedOut,
                      ),
                    ),
                  );
                }).toList(),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  Widget _buildPasswordField() {
    return KeyboardListener(
      focusNode: FocusNode(),
      onKeyEvent: (event) {
        if (event is KeyDownEvent &&
            event.logicalKey == LogicalKeyboardKey.enter) {
          _submitPin();
        }
      },
      child: TextField(
        controller: _textCtrl,
        focusNode: _focusNode,
        obscureText: _obscureText,
        enabled: !_lockedOut,
        style: TextStyle(
            color: cNavy(context), fontSize: 14.5, fontWeight: FontWeight.w500),
        decoration: InputDecoration(
          hintText: 'Password',
          hintStyle: TextStyle(color: cMuted(context)),
          filled: true,
          fillColor: cBg(context),
          prefixIcon: Icon(Icons.lock_outline_rounded,
              color: cMuted(context), size: 19),
          suffixIcon: IconButton(
            icon: Icon(
                _obscureText
                    ? Icons.visibility_off_rounded
                    : Icons.visibility_rounded,
                color: cMuted(context),
                size: 19),
            onPressed: () =>
                setState(() => _obscureText = !_obscureText),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: BorderSide(color: cBorder(context), width: 1.4),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: BorderSide(color: cBorder(context), width: 1.4),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: BorderSide(color: cNavy(context), width: 1.8),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
        ),
        onSubmitted: (_) => _submitPin(),
        onChanged: (_) => setState(() => _error = null),
      ),
    );
  }

  Widget _buildUnlockButton() {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: _lockedOut ? kMuted : kNavy,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          elevation: 0,
        ),
        onPressed: _lockedOut ? null : _submitPin,
        child: const Text('Unlock',
            style:
                TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
      ),
    );
  }
}

// ── Number key widget ─────────────────────────────────────────
class _NumKey extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool isBackspace;
  final bool disabled;

  const _NumKey({
    required this.label,
    required this.onTap,
    this.isBackspace = false,
    this.disabled = false,
  });

  @override
  State<_NumKey> createState() => _NumKeyState();
}

class _NumKeyState extends State<_NumKey>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 120));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) => _ctrl.reverse(),
      onTapCancel: () => _ctrl.reverse(),
      onTap: widget.disabled ? null : widget.onTap,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Transform.scale(
          scale: 1.0 - _ctrl.value * 0.06,
          // Size comes from parent SizedBox in _buildNumPad
          child: Container(
            decoration: BoxDecoration(
              color: cCard(context),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: cBorder(context)),
              boxShadow: [
                BoxShadow(
                  color:      cNavy(context).withValues(alpha: 0.04),
                  blurRadius: 4,
                  offset:     const Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: widget.isBackspace
                  ? Icon(Icons.backspace_outlined,
                      color: cNavy(context), size: 20)
                  : Text(
                      widget.label,
                      style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   20,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
