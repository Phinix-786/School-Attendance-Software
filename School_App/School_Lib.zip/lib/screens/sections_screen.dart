// lib/screens/sections_screen.dart
import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../app_theme.dart';
import '../services/school_firebase_service.dart';
import '../models/models.dart';

// ─── Helpers ─────────────────────────────────────────────────────────────
String _generateId() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  final rng = Random.secure();
  return 'SEC-' + List.generate(5, (_) => chars[rng.nextInt(chars.length)]).join();
}

String _generatePassword() {
  const letters = 'abcdefghjkmnpqrstuvwxyz';
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const digits = '23456789';
  final rng = Random.secure();
  final parts = [
    upper[rng.nextInt(upper.length)],
    upper[rng.nextInt(upper.length)],
    letters[rng.nextInt(letters.length)],
    letters[rng.nextInt(letters.length)],
    digits[rng.nextInt(digits.length)],
    digits[rng.nextInt(digits.length)],
    digits[rng.nextInt(digits.length)],
  ]..shuffle(rng);
  return parts.join();
}

// ─── SectionsScreen ──────────────────────────────────────────────────────
class SectionsScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;

  const SectionsScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
  });

  @override
  State<SectionsScreen> createState() => _SectionsScreenState();
}

class _SectionsScreenState extends State<SectionsScreen> {
  final _db = FirebaseFirestore.instance;

  List<Map<String, dynamic>> _sections = [];
  List<SchoolClass> _allClasses = [];
  bool _loading = true;

  StreamSubscription? _sectionSub;
  final Map<String, StreamSubscription> _classSubs = {};
  final Map<String, List<SchoolClass>> _classesBySection = {};

  @override
  void initState() {
    super.initState();
    _subscribeSections();
  }

  void _subscribeSections() {
    _sectionSub = _db
        .collection('schools/${widget.schoolId}/sections')
        .snapshots()
        .listen((snap) {
      final sections = snap.docs.map((d) => d.data()).toList();
      setState(() {
        _sections = sections;
        _loading = false;
      });
      // Subscribe to classes of each section
      final sectionIds = sections.map((s) => s['id'] as String).toSet();
      // Cancel subs for removed sections
      for (final id in _classSubs.keys.toList()) {
        if (!sectionIds.contains(id)) {
          _classSubs[id]?.cancel();
          _classSubs.remove(id);
          _classesBySection.remove(id);
        }
      }
      for (final section in sections) {
        final sId = section['id'] as String;
        if (_classSubs.containsKey(sId)) continue;
        _classSubs[sId] = SchoolFirebaseService.classesStream(widget.schoolId, sId)
            .listen((classes) {
          if (mounted) setState(() => _classesBySection[sId] = classes);
        });
      }
    });
  }

  Future<List<SchoolClass>> _getUnassignedClasses() async {
    // Classes that have no sectionId assigned (or whose assigned section's id matches no section)
    final allSectionIds = _sections.map((s) => s['id'] as String).toSet();
    // Collect all classes from all sections
    final assignedClassIds = <String>{};
    for (final classes in _classesBySection.values) {
      for (final c in classes) assignedClassIds.add(c.id);
    }
    // We need to fetch classes that are NOT in any section
    // But in this schema classes live under sections. So "unassigned" = not yet in any section.
    // We'll just return empty here since classes only exist under sections.
    return [];
  }

  @override
  void dispose() {
    _sectionSub?.cancel();
    for (final sub in _classSubs.values) sub.cancel();
    super.dispose();
  }

  void _showAddSectionDialog({Map<String, dynamic>? existing}) {
    showDialog(
      context: context,
      builder: (_) => _SectionDialog(
        schoolId: widget.schoolId,
        existing: existing,
        onSave: (id, name, password) async {
          final data = {
            'id': id,
            'name': name,
            'password': password,
            'createdAt': FieldValue.serverTimestamp(),
          };
          await _db
              .collection('schools/${widget.schoolId}/sections')
              .doc(id)
              .set(data, SetOptions(merge: true));
        },
      ),
    );
  }

  Future<void> _deleteSection(String sectionId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        title: Text('Delete Section?', style: TextStyle(color: kNavy, fontWeight: FontWeight.w700)),
        content: Text('All classes, students, teachers and attendance under this section will be deleted. This cannot be undone.',
            style: TextStyle(color: kMuted, fontSize: 13)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: Text('Cancel', style: TextStyle(color: kMuted))),
          TextButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete', style: TextStyle(color: kError, fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (confirm != true) return;
    await _db.collection('schools/${widget.schoolId}/sections').doc(sectionId).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(children: [
              Icon(Icons.account_tree_rounded, color: cNavy(context), size: 20),
              const SizedBox(width: 9),
              Text('Sections Management',
                  style: TextStyle(color: cNavy(context), fontSize: 19, fontWeight: FontWeight.w800)),
              const Spacer(),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: cNavy(context),
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                ),
                icon: const Icon(Icons.add_rounded, size: 16),
                label: const Text('Add Section', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                onPressed: () => _showAddSectionDialog(),
              ),
            ]),
            const SizedBox(height: 6),
            Text('Manage sections and their assigned classes',
                style: TextStyle(color: cMuted(context), fontSize: 12)),
            const SizedBox(height: 20),

            if (_loading)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else if (_sections.isEmpty)
              Expanded(child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.account_tree_outlined, size: 40, color: cMuted(context).withValues(alpha: 0.3)),
                  const SizedBox(height: 12),
                  Text('No sections yet', style: TextStyle(color: cNavy(context), fontSize: 14, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text('Add a section to get started', style: TextStyle(color: cMuted(context), fontSize: 12)),
                ]),
              ))
            else
              Expanded(
                child: ListView.separated(
                  itemCount: _sections.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    final sec = _sections[i];
                    final sId = sec['id'] as String;
                    final classes = _classesBySection[sId] ?? [];
                    return _SectionCard(
                      section: sec,
                      classes: classes,
                      onEdit: () => _showAddSectionDialog(existing: sec),
                      onDelete: () => _deleteSection(sId),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── Section Card ─────────────────────────────────────────────────────────
class _SectionCard extends StatefulWidget {
  final Map<String, dynamic> section;
  final List<SchoolClass> classes;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _SectionCard({
    required this.section,
    required this.classes,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  State<_SectionCard> createState() => _SectionCardState();
}

class _SectionCardState extends State<_SectionCard> {
  bool _expanded = true;
  bool _showPass = false;

  @override
  Widget build(BuildContext context) {
    final sId   = widget.section['id'] as String? ?? '';
    final sName = widget.section['name'] as String? ?? '';
    final sPass = widget.section['password'] as String? ?? '';

    return Container(
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cBorder(context)),
        boxShadow: [BoxShadow(color: cNavy(context).withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 3))],
      ),
      child: Column(children: [
        // Header row
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 12, 14),
          child: Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(color: kTeal.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.folder_special_rounded, color: kTeal, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(sName, style: TextStyle(color: cNavy(context), fontSize: 15, fontWeight: FontWeight.w700)),
              Text('ID: $sId', style: TextStyle(color: cMuted(context), fontSize: 11)),
            ])),
            // Credentials chip
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: kNavy.withValues(alpha: 0.06),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: cBorder(context)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.lock_outline_rounded, size: 12, color: cMuted(context)),
                const SizedBox(width: 5),
                Text(
                  _showPass ? sPass : '••••••••',
                  style: TextStyle(color: cNavy(context), fontSize: 12, fontWeight: FontWeight.w600, fontFamily: 'monospace'),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onTap: () => setState(() => _showPass = !_showPass),
                  child: Icon(_showPass ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                      size: 13, color: cMuted(context)),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onTap: () => Clipboard.setData(ClipboardData(text: sPass)),
                  child: Icon(Icons.copy_rounded, size: 12, color: cMuted(context)),
                ),
              ]),
            ),
            const SizedBox(width: 8),
            Text('${widget.classes.length} classes',
                style: TextStyle(color: cMuted(context), fontSize: 11.5)),
            const SizedBox(width: 8),
            IconButton(
              icon: Icon(Icons.edit_rounded, size: 16, color: cMuted(context)),
              tooltip: 'Edit section',
              onPressed: widget.onEdit,
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline_rounded, size: 16, color: kError),
              tooltip: 'Delete section',
              onPressed: widget.onDelete,
            ),
            IconButton(
              icon: Icon(_expanded ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                  color: cMuted(context)),
              onPressed: () => setState(() => _expanded = !_expanded),
            ),
          ]),
        ),
        if (_expanded && widget.classes.isNotEmpty) ...[
          Divider(height: 1, color: cBorder(context)),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CLASSES IN THIS SECTION',
                    style: TextStyle(color: cMuted(context).withValues(alpha: 0.6), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: widget.classes.map((c) => Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: cNavy(context).withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: cBorder(context)),
                    ),
                    child: Text(c.name, style: TextStyle(color: cNavy(context), fontSize: 12, fontWeight: FontWeight.w600)),
                  )).toList(),
                ),
              ],
            ),
          ),
        ] else if (_expanded && widget.classes.isEmpty) ...[
          Divider(height: 1, color: cBorder(context)),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('No classes added yet. Add classes from the Classes screen.',
                style: TextStyle(color: cMuted(context), fontSize: 12)),
          ),
        ],
      ]),
    );
  }
}

// ─── Section Dialog ───────────────────────────────────────────────────────
class _SectionDialog extends StatefulWidget {
  final String schoolId;
  final Map<String, dynamic>? existing;
  final Future<void> Function(String id, String name, String password) onSave;

  const _SectionDialog({
    required this.schoolId,
    this.existing,
    required this.onSave,
  });

  @override
  State<_SectionDialog> createState() => _SectionDialogState();
}

class _SectionDialogState extends State<_SectionDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _idCtrl;
  late final TextEditingController _passCtrl;
  bool _loading = false;
  bool _showPass = false;

  @override
  void initState() {
    super.initState();
    final ex = widget.existing;
    _idCtrl   = TextEditingController(text: ex?['id']       ?? _generateId());
    _nameCtrl = TextEditingController(text: ex?['name']     ?? '');
    _passCtrl = TextEditingController(text: ex?['password'] ?? _generatePassword());
  }

  @override
  void dispose() {
    _idCtrl.dispose(); _nameCtrl.dispose(); _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty) return;
    setState(() => _loading = true);
    try {
      await widget.onSave(
        _idCtrl.text.trim(),
        _nameCtrl.text.trim(),
        _passCtrl.text.trim(),
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: kError));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Dialog(
      backgroundColor: kCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: SizedBox(
        width: 440,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(isEdit ? 'Edit Section' : 'Add Section',
                style: TextStyle(color: kNavy, fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(isEdit ? 'Update section credentials' : 'A login ID and password will be generated',
                style: TextStyle(color: kMuted, fontSize: 12)),
            const SizedBox(height: 20),

            // Section Name
            Text('Section Name', style: TextStyle(color: kMuted, fontSize: 12, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            _field(_nameCtrl, 'e.g. Morning Shift, Block A'),
            const SizedBox(height: 14),

            // Section ID
            Text('Section ID (login ID)', style: TextStyle(color: kMuted, fontSize: 12, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: _field(_idCtrl, 'SEC-XXXXX', monospace: true,
                  enabled: !isEdit)),
              if (!isEdit) ...[
                const SizedBox(width: 6),
                IconButton(
                  icon: Icon(Icons.refresh_rounded, color: kTeal, size: 18),
                  tooltip: 'Regenerate',
                  onPressed: () => setState(() => _idCtrl.text = _generateId()),
                ),
              ],
              const SizedBox(width: 2),
              IconButton(
                icon: Icon(Icons.copy_rounded, color: kMuted, size: 16),
                tooltip: 'Copy',
                onPressed: () => Clipboard.setData(ClipboardData(text: _idCtrl.text)),
              ),
            ]),
            const SizedBox(height: 14),

            // Password
            Text('Section Password', style: TextStyle(color: kMuted, fontSize: 12, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: _field(_passCtrl, 'Password', monospace: true, obscure: !_showPass)),
              IconButton(
                icon: Icon(_showPass ? Icons.visibility_off_rounded : Icons.visibility_rounded,
                    color: kMuted, size: 16),
                onPressed: () => setState(() => _showPass = !_showPass),
              ),
              IconButton(
                icon: Icon(Icons.refresh_rounded, color: kTeal, size: 18),
                tooltip: 'Regenerate',
                onPressed: () => setState(() => _passCtrl.text = _generatePassword()),
              ),
              IconButton(
                icon: Icon(Icons.copy_rounded, color: kMuted, size: 16),
                onPressed: () => Clipboard.setData(ClipboardData(text: _passCtrl.text)),
              ),
            ]),

            const SizedBox(height: 24),
            Row(children: [
              Expanded(child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: kMuted,
                  side: BorderSide(color: kBorder),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              )),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                onPressed: _loading ? null : _save,
                child: _loading
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : Text(isEdit ? 'Save Changes' : 'Create Section',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
              )),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String hint, {
    bool obscure = false, bool monospace = false, bool enabled = true
  }) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      enabled: enabled,
      style: TextStyle(
        color: enabled ? kNavy : kMuted,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        fontFamily: monospace ? 'monospace' : null,
      ),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: kMuted, fontSize: 13),
        filled: true,
        fillColor: enabled ? kBg : kBorder,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kBorder)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kBorder)),
        disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: kBorder.withValues(alpha: 0.5))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: kNavy, width: 1.8)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
        isDense: true,
      ),
    );
  }
}
