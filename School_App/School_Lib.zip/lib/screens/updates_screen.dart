// lib/screens/updates_screen.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import '../app_theme.dart';
import '../services/auto_updater_service.dart';

class UpdatesScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;
  final String sectionId;

  const UpdatesScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
  });

  @override
  State<UpdatesScreen> createState() => _UpdatesScreenState();
}

class _UpdatesScreenState extends State<UpdatesScreen> {
  // ── Release info ───────────────────────────────────────────────────────────
  bool   _loadingRelease = true;
  String _releaseVersion = '';
  String _releaseBody    = '';
  String _releaseDate    = '';
  String _releaseError   = '';

  // ── Suggestion form ────────────────────────────────────────────────────────
  final _suggestionCtrl = TextEditingController();
  bool   _submitting = false;
  String _submitMsg  = '';

  @override
  void initState() {
    super.initState();
    _fetchLatestRelease();
  }

  @override
  void dispose() {
    _suggestionCtrl.dispose();
    super.dispose();
  }

  // ── Fetch GitHub release notes ─────────────────────────────────────────────
  Future<void> _fetchLatestRelease() async {
    setState(() { _loadingRelease = true; _releaseError = ''; });
    try {
      final url = Uri.parse(
          'https://api.github.com/repos/$kGithubOwner/$kGithubRepo/releases/latest');
      final resp = await http
          .get(url, headers: {'Accept': 'application/vnd.github+json'})
          .timeout(const Duration(seconds: 15));

      if (resp.statusCode == 200) {
        final json      = jsonDecode(resp.body) as Map<String, dynamic>;
        final tag       = (json['tag_name'] as String? ?? '').replaceAll('v', '');
        final body      = (json['body']     as String? ?? '').trim();
        final published = json['published_at'] as String? ?? '';
        DateTime? dt;
        try { dt = DateTime.parse(published); } catch (_) {}

        setState(() {
          _releaseVersion = tag;
          _releaseBody    = body.isEmpty ? 'No release notes provided.' : body;
          _releaseDate    = dt != null
              ? '${dt.day.toString().padLeft(2, '0')} ${_month(dt.month)} ${dt.year}'
              : '';
          _loadingRelease = false;
        });
      } else {
        setState(() {
          _releaseError   = 'Could not fetch release info (${resp.statusCode}).';
          _loadingRelease = false;
        });
      }
    } catch (e) {
      setState(() {
        _releaseError   = 'Network error: $e';
        _loadingRelease = false;
      });
    }
  }

  // ── Trigger manual update check ────────────────────────────────────────────
  Future<void> _checkNow() async {
    await AutoUpdaterService.instance.forceCheck();
  }

  // ── Submit suggestion ──────────────────────────────────────────────────────
  Future<void> _submitSuggestion() async {
    final text = _suggestionCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() { _submitting = true; _submitMsg = ''; });
    try {
      await FirebaseFirestore.instance
          .collection('schools')
          .doc(widget.schoolId)
          .collection('suggested_updates')
          .add({
        'suggestion': text,
        'schoolName': widget.schoolName,
        'schoolId':   widget.schoolId,
        'createdAt':  FieldValue.serverTimestamp(),
      });
      _suggestionCtrl.clear();
      setState(() { _submitMsg = 'Thanks! Your suggestion has been sent.'; });
    } catch (e) {
      setState(() { _submitMsg = 'Error: $e'; });
    } finally {
      setState(() { _submitting = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Header ────────────────────────────────
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('App Updates',
                            style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   22,
                              fontWeight: FontWeight.w800,
                            )),
                        const SizedBox(height: 4),
                        Text('Current Version: v$kCurrentVersion',
                            style: TextStyle(
                                color: cMuted(context), fontSize: 13)),
                      ],
                    ),
                  ),
                  _CheckNowButton(onPressed: _checkNow),
                ],
              ),

              const SizedBox(height: 20),

              // ── Live updater status panel ─────────────
              _UpdateStatusPanel(),

              const SizedBox(height: 24),

              // ── Release notes card ────────────────────
              _ReleaseCard(
                loading: _loadingRelease,
                version: _releaseVersion,
                body:    _releaseBody,
                date:    _releaseDate,
                error:   _releaseError,
                onRetry: _fetchLatestRelease,
              ),

              const SizedBox(height: 24),

              // ── Suggest card ──────────────────────────
              _SuggestCard(
                controller: _suggestionCtrl,
                submitting: _submitting,
                submitMsg:  _submitMsg,
                onSubmit:   _submitSuggestion,
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  static String _month(int m) => const [
    '', 'Jan','Feb','Mar','Apr','May','Jun',
    'Jul','Aug','Sep','Oct','Nov','Dec'
  ][m];
}

// ────────────────────────────────────────────────────────────────────────────
// Live Update Status Panel — listens to AutoUpdaterService and always shows
// ────────────────────────────────────────────────────────────────────────────
class _UpdateStatusPanel extends StatelessWidget {
  const _UpdateStatusPanel();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<UpdaterState>(
      valueListenable: AutoUpdaterService.instance.state,
      builder: (context, state, _) {
        return ValueListenableBuilder<double?>(
          valueListenable: AutoUpdaterService.instance.downloadProgress,
          builder: (context, progress, _) {
            return _StatusCard(state: state, progress: progress);
          },
        );
      },
    );
  }
}

class _StatusCard extends StatelessWidget {
  final UpdaterState state;
  final double?      progress;
  const _StatusCard({required this.state, required this.progress});

  @override
  Widget build(BuildContext context) {
    final cfg = _config(state);
    final dark = isDark(context);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve:    Curves.easeOut,
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cfg.bgColor(context, dark),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cfg.borderColor(context, dark)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 10,
            offset:     const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Icon / spinner
              _StatusIcon(state: state, color: cfg.iconColor),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      cfg.title,
                      style: TextStyle(
                        color:      cfg.titleColor(context),
                        fontSize:   14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      cfg.subtitle,
                      style: TextStyle(
                        color:    cMuted(context).withValues(alpha: 0.8),
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
              // Progress % badge
              if (state == UpdaterState.downloading && progress != null)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color:        kNavy.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '${(progress! * 100).toStringAsFixed(0)}%',
                    style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
            ],
          ),
          // Progress bar for downloading state
          if (state == UpdaterState.downloading) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value:           progress,
                minHeight:       6,
                backgroundColor: cBorder(context),
                valueColor:      const AlwaysStoppedAnimation<Color>(kNavy),
              ),
            ),
          ],
          // Indeterminate bar for checking / installing
          if (state == UpdaterState.checking ||
              state == UpdaterState.installing) ...[
            const SizedBox(height: 14),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                minHeight:  6,
                backgroundColor: cBorder(context),
                valueColor: const AlwaysStoppedAnimation<Color>(kNavy),
              ),
            ),
          ],
        ],
      ),
    );
  }

  _CardConfig _config(UpdaterState s) {
    switch (s) {
      case UpdaterState.checking:
        return _CardConfig(
          title:    'Checking for updates…',
          subtitle: 'Contacting GitHub, please wait.',
          iconColor: kNavy,
          bgColor:   (ctx, dark) =>
              dark ? const Color(0xFF1E293B) : cCard(ctx),
          borderColor: (ctx, dark) =>
              dark ? const Color(0xFF334155) : cBorder(ctx),
          titleColor: (ctx) => cNavy(ctx),
        );
      case UpdaterState.upToDate:
        return _CardConfig(
          title:    'You\'re up to date!',
          subtitle: 'Version v$kCurrentVersion is the latest release.',
          iconColor: const Color(0xFF22C55E),
          bgColor:   (ctx, dark) =>
              const Color(0xFF22C55E).withValues(alpha: dark ? 0.08 : 0.07),
          borderColor: (ctx, dark) =>
              const Color(0xFF22C55E).withValues(alpha: 0.25),
          titleColor: (ctx) => const Color(0xFF15803D),
        );
      case UpdaterState.downloading:
        return _CardConfig(
          title:    'Downloading update…',
          subtitle: 'Please keep the app open while the update downloads.',
          iconColor: kNavy,
          bgColor:   (ctx, dark) =>
              dark ? const Color(0xFF1E293B) : cCard(ctx),
          borderColor: (ctx, dark) =>
              dark ? const Color(0xFF334155) : cBorder(ctx),
          titleColor: (ctx) => cNavy(ctx),
        );
      case UpdaterState.installing:
        return _CardConfig(
          title:    'Installing update…',
          subtitle: 'The app will restart automatically in a moment.',
          iconColor: const Color(0xFFF59E0B),
          bgColor:   (ctx, dark) =>
              const Color(0xFFF59E0B).withValues(alpha: dark ? 0.08 : 0.07),
          borderColor: (ctx, dark) =>
              const Color(0xFFF59E0B).withValues(alpha: 0.25),
          titleColor: (ctx) => const Color(0xFF92400E),
        );
      default: // idle
        return _CardConfig(
          title:    'Update Check',
          subtitle: 'Press "Check for Updates" to look for a new version.',
          iconColor: kNavy.withValues(alpha: 0.4),
          bgColor:   (ctx, dark) =>
              dark ? const Color(0xFF1E293B) : cCard(ctx),
          borderColor: (ctx, dark) =>
              dark ? const Color(0xFF334155) : cBorder(ctx),
          titleColor: (ctx) => cNavy(ctx).withValues(alpha: 0.7),
        );
    }
  }
}

class _CardConfig {
  final String   title;
  final String   subtitle;
  final Color    iconColor;
  final Color Function(BuildContext, bool) bgColor;
  final Color Function(BuildContext, bool) borderColor;
  final Color Function(BuildContext)       titleColor;

  const _CardConfig({
    required this.title,
    required this.subtitle,
    required this.iconColor,
    required this.bgColor,
    required this.borderColor,
    required this.titleColor,
  });
}

// Spinning icon for active states, static for others
class _StatusIcon extends StatefulWidget {
  final UpdaterState state;
  final Color        color;
  const _StatusIcon({required this.state, required this.color});

  @override
  State<_StatusIcon> createState() => _StatusIconState();
}

class _StatusIconState extends State<_StatusIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 1))..repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  bool get _spinning =>
      widget.state == UpdaterState.checking ||
      widget.state == UpdaterState.downloading ||
      widget.state == UpdaterState.installing;

  IconData get _icon {
    switch (widget.state) {
      case UpdaterState.upToDate:    return Icons.check_circle_rounded;
      case UpdaterState.downloading: return Icons.download_rounded;
      case UpdaterState.installing:  return Icons.system_update_rounded;
      default:                       return Icons.sync_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final iconWidget = Container(
      width:  42,
      height: 42,
      decoration: BoxDecoration(
        color:        widget.color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(_icon, color: widget.color, size: 20),
    );

    if (_spinning) {
      return RotationTransition(
        turns: _ctrl,
        child: iconWidget,
      );
    }
    return iconWidget;
  }
}

// ── "Check for Updates" button ───────────────────────────────────────────────
class _CheckNowButton extends StatefulWidget {
  final VoidCallback onPressed;
  const _CheckNowButton({required this.onPressed});

  @override
  State<_CheckNowButton> createState() => _CheckNowButtonState();
}

class _CheckNowButtonState extends State<_CheckNowButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Color?>   _bg;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 180));
    _bg = ColorTween(
      begin: kNavy.withValues(alpha: 0.08),
      end:   kNavy.withValues(alpha: 0.16),
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<UpdaterState>(
      valueListenable: AutoUpdaterService.instance.state,
      builder: (context, state, _) {
        final busy = state == UpdaterState.checking ||
            state == UpdaterState.downloading ||
            state == UpdaterState.installing;

        return MouseRegion(
          onEnter: (_) { if (!busy) _ctrl.forward(); },
          onExit:  (_) => _ctrl.reverse(),
          child: GestureDetector(
            onTap: busy ? null : widget.onPressed,
            child: AnimatedBuilder(
              animation: _ctrl,
              builder: (_, __) => AnimatedOpacity(
                opacity:  busy ? 0.45 : 1.0,
                duration: const Duration(milliseconds: 200),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    color:        _bg.value,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: cNavy(context).withValues(alpha: 0.18)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.system_update_rounded,
                          color: cNavy(context), size: 15),
                      const SizedBox(width: 7),
                      Text(
                        busy ? 'Checking…' : 'Check for Updates',
                        style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ── Release notes card ────────────────────────────────────────────────────────
class _ReleaseCard extends StatelessWidget {
  final bool     loading;
  final String   version;
  final String   body;
  final String   date;
  final String   error;
  final VoidCallback onRetry;

  const _ReleaseCard({
    required this.loading,
    required this.version,
    required this.body,
    required this.date,
    required this.error,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 12,
            offset:     const Offset(0, 3),
          ),
        ],
      ),
      child: loading
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          : error.isNotEmpty
              ? _ErrorState(message: error, onRetry: onRetry)
              : _ReleaseContent(version: version, body: body, date: date),
    );
  }
}

class _ReleaseContent extends StatelessWidget {
  final String version;
  final String body;
  final String date;
  const _ReleaseContent({
    required this.version,
    required this.body,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color:        kNavy.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.new_releases_rounded,
                      color: cNavy(context), size: 13),
                  const SizedBox(width: 5),
                  Text('v$version',
                      style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   12,
                        fontWeight: FontWeight.w700,
                      )),
                ],
              ),
            ),
            if (date.isNotEmpty) ...[
              const SizedBox(width: 10),
              Text(date,
                  style: TextStyle(color: cMuted(context), fontSize: 12)),
            ],
          ],
        ),
        const SizedBox(height: 14),
        Text("What's New",
            style: TextStyle(
              color:      cNavy(context),
              fontSize:   15,
              fontWeight: FontWeight.w800,
            )),
        const SizedBox(height: 10),
        ..._parseBody(context, body),
      ],
    );
  }

  List<Widget> _parseBody(BuildContext ctx, String raw) {
    final widgets = <Widget>[];
    for (final line in raw.split('\n')) {
      final t = line.trim();
      if (t.isEmpty) { widgets.add(const SizedBox(height: 6)); continue; }
      if (t.startsWith('## ')) {
        widgets.add(Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 4),
          child: Text(t.substring(3),
              style: TextStyle(color: cNavy(ctx), fontSize: 14,
                  fontWeight: FontWeight.w700)),
        )); continue;
      }
      if (t.startsWith('# ')) {
        widgets.add(Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 4),
          child: Text(t.substring(2),
              style: TextStyle(color: cNavy(ctx), fontSize: 15,
                  fontWeight: FontWeight.w800)),
        )); continue;
      }
      if (t.startsWith('- ') || t.startsWith('* ')) {
        widgets.add(Padding(
          padding: const EdgeInsets.only(bottom: 5),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 6, right: 8),
                child: Container(width: 5, height: 5,
                  decoration: BoxDecoration(
                    color: cNavy(ctx).withValues(alpha: 0.5),
                    shape: BoxShape.circle,
                  )),
              ),
              Expanded(child: Text(t.substring(2),
                  style: TextStyle(color: cMuted(ctx), fontSize: 13.5,
                      height: 1.5))),
            ],
          ),
        )); continue;
      }
      widgets.add(Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Text(t, style: TextStyle(color: cMuted(ctx), fontSize: 13.5,
            height: 1.5)),
      ));
    }
    return widgets;
  }
}

class _ErrorState extends StatelessWidget {
  final String       message;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(Icons.cloud_off_rounded,
            color: cMuted(context).withValues(alpha: 0.5), size: 36),
        const SizedBox(height: 10),
        Text(message, style: TextStyle(color: cMuted(context), fontSize: 13),
            textAlign: TextAlign.center),
        const SizedBox(height: 14),
        TextButton.icon(
          onPressed: onRetry,
          icon:  const Icon(Icons.refresh_rounded, size: 16),
          label: const Text('Retry'),
        ),
      ],
    );
  }
}

// ── Suggest update card ───────────────────────────────────────────────────────
class _SuggestCard extends StatelessWidget {
  final TextEditingController controller;
  final bool         submitting;
  final String       submitMsg;
  final VoidCallback onSubmit;

  const _SuggestCard({
    required this.controller,
    required this.submitting,
    required this.submitMsg,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    final isSuccess = submitMsg.startsWith('Thanks');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 12,
            offset:     const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(Icons.lightbulb_outline_rounded,
                color: cNavy(context), size: 17),
            const SizedBox(width: 8),
            Text('Suggest a Feature / Update',
                style: TextStyle(
                    color: cNavy(context), fontSize: 15,
                    fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 6),
          Text('Have an idea or spotted something we should fix? Let us know.',
              style: TextStyle(color: cMuted(context), fontSize: 13)),
          const SizedBox(height: 14),
          TextField(
            controller: controller,
            minLines: 3, maxLines: 6,
            style: TextStyle(color: cNavy(context), fontSize: 13.5),
            decoration: InputDecoration(
              hintText: 'Describe the feature or improvement…',
              hintStyle: TextStyle(
                  color: cMuted(context).withValues(alpha: 0.55)),
              filled:    true,
              fillColor: cBg(context),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide:   BorderSide(color: cBorder(context)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide:   BorderSide(color: cBorder(context)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                    color: cNavy(context).withValues(alpha: 0.4),
                    width: 1.5),
              ),
              contentPadding: const EdgeInsets.all(14),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: submitMsg.isNotEmpty
                    ? Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSuccess
                              ? kPink.withValues(alpha: 0.15)
                              : kError.withValues(alpha: 0.10),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(children: [
                          Icon(
                            isSuccess
                                ? Icons.check_circle_outline_rounded
                                : Icons.error_outline_rounded,
                            color: isSuccess ? kNavy : kError,
                            size: 14,
                          ),
                          const SizedBox(width: 7),
                          Expanded(
                            child: Text(
                              submitMsg,
                              style: TextStyle(
                                color: isSuccess ? cNavy(context) : kError,
                                fontSize:   12.5,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ]),
                      )
                    : const SizedBox.shrink(),
              ),
              const SizedBox(width: 10),
              _SubmitButton(submitting: submitting, onSubmit: onSubmit),
            ],
          ),
        ],
      ),
    );
  }
}

class _SubmitButton extends StatefulWidget {
  final bool         submitting;
  final VoidCallback onSubmit;
  const _SubmitButton({required this.submitting, required this.onSubmit});

  @override
  State<_SubmitButton> createState() => _SubmitButtonState();
}

class _SubmitButtonState extends State<_SubmitButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Color?>   _bg;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 160));
    _bg = ColorTween(
      begin: kNavy,
      end:   kNavy.withValues(alpha: 0.80),
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) { if (!widget.submitting) _ctrl.forward(); },
      onExit:  (_) => _ctrl.reverse(),
      child: GestureDetector(
        onTap: widget.submitting ? null : widget.onSubmit,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              color:        _bg.value,
              borderRadius: BorderRadius.circular(10),
            ),
            child: widget.submitting
                ? const SizedBox(width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation(Colors.white)))
                : const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.send_rounded, color: Colors.white, size: 14),
                      SizedBox(width: 7),
                      Text('Send Suggestion',
                          style: TextStyle(color: Colors.white, fontSize: 13,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
