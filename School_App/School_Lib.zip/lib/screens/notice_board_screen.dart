// lib/screens/notice_board_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class NoticesScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;
  final String sectionId;

  const NoticesScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
  });

  @override
  State<NoticesScreen> createState() => _NoticesScreenState();
}

class _NoticesScreenState extends State<NoticesScreen> {
  List<SchoolNotice>         _notices       = [];
  List<Map<String, dynamic>> _adminSections = [];
  String?                    _selectedSecId;
  SchoolNotice?              _selectedNotice;
  bool                       _loading       = true;
  Timer?                     _pollTimer;

  // Compose form
  final _titleCtrl = TextEditingController();
  final _bodyCtrl  = TextEditingController();
  String _audience = 'all';
  bool   _saving   = false;
  String? _error;

  static const _audiences = ['teachers', 'parents', 'students', 'all'];

  String get _effectiveSecId =>
      widget.sectionId.isEmpty
          ? (_selectedSecId ?? '')
          : widget.sectionId;

  bool get isAdmin => widget.sectionId.isEmpty;

  @override
  void initState() {
    super.initState();
    if (isAdmin) {
      _loadAdminSections();
    } else {
      _load(widget.sectionId);
    }
    _pollTimer =
        Timer.periodic(const Duration(seconds: 30), (_) => _load(_effectiveSecId));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAdminSections() async {
    final secs = await SchoolFirebaseService.getSections(widget.schoolId);
    if (!mounted) return;
    setState(() {
      _adminSections = secs;
      if (secs.isNotEmpty) _selectedSecId = secs.first['id'] as String;
    });
    if (_selectedSecId != null) _load(_selectedSecId!);
  }

  Future<void> _load(String secId) async {
    if (secId.isEmpty) return;
    setState(() => _loading = true);
    final notices =
        await SchoolFirebaseService.getNotices(widget.schoolId, secId);
    if (!mounted) return;
    setState(() { _notices = notices; _loading = false; });
  }

  Future<void> _submit() async {
    final title = _titleCtrl.text.trim();
    final body  = _bodyCtrl.text.trim();
    if (title.isEmpty) {
      setState(() => _error = 'Title is required.');
      return;
    }
    final secId = _effectiveSecId;
    if (secId.isEmpty) {
      setState(() => _error = 'No section selected.');
      return;
    }
    setState(() { _saving = true; _error = null; });

    final prefs   = await SharedPreferences.getInstance();
    final creator = prefs.getString('sectionName') ??
        prefs.getString('schoolName') ??
        'Admin';

    final notice = SchoolNotice(
      id:             const Uuid().v4(),
      schoolId:       widget.schoolId,
      sectionId:      secId,
      title:          title,
      body:           body,
      targetAudience: _audience,
      createdBy:      creator,
      createdAt:      DateTime.now(),
    );

    try {
      await SchoolFirebaseService.addNotice(widget.schoolId, secId, notice);
      _titleCtrl.clear();
      _bodyCtrl.clear();
      setState(() { _saving = false; _audience = 'all'; });
      _load(secId);
    } catch (e) {
      if (mounted) setState(() { _saving = false; _error = 'Failed to save.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(context),
            if (isAdmin && _adminSections.isNotEmpty) ...[
              const SizedBox(height: 14),
              _buildSectionChips(context),
            ],
            const SizedBox(height: 18),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Left: Notices list
                  SizedBox(
                    width: 280,
                    child: _buildNoticesList(context),
                  ),
                  const SizedBox(width: 20),
                  // Right: Compose + Detail
                  Expanded(child: _buildRightPanel(context)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        Icon(Icons.campaign_rounded, color: cNavy(context), size: 20),
        const SizedBox(width: 9),
        Text('Notice Board',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   19,
                fontWeight: FontWeight.w800)),
        const Spacer(),
        IconButton(
          icon: Icon(Icons.refresh_rounded, color: cNavy(context), size: 19),
          tooltip: 'Refresh',
          onPressed: () => _load(_effectiveSecId),
        ),
      ],
    );
  }

  Widget _buildSectionChips(BuildContext context) {
    return Row(
      children: _adminSections.map((sec) {
        final sId  = (sec['id'] as String?) ?? '';
        final name = (sec['name'] as String?) ?? sId;
        final sel  = _selectedSecId == sId;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: GestureDetector(
            onTap: () {
              if (_selectedSecId == sId) return;
              setState(() { _selectedSecId = sId; _selectedNotice = null; });
              _load(sId);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color:        sel ? cNavy(context) : cCard(context),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: sel ? cNavy(context) : cBorder(context)),
              ),
              child: Text(name,
                  style: TextStyle(
                      color:      sel ? Colors.white : cMuted(context),
                      fontSize:   12.5,
                      fontWeight: sel
                          ? FontWeight.w700
                          : FontWeight.w500)),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildNoticesList(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Text('Notices (${_notices.length})',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   13,
                    fontWeight: FontWeight.w700)),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(strokeWidth: 2))
                : _notices.isEmpty
                    ? Center(
                        child: Text('No notices yet.',
                            style: TextStyle(
                                color: cMuted(context), fontSize: 13)))
                    : ListView.builder(
                        itemCount: _notices.length,
                        itemBuilder: (_, i) {
                          final n   = _notices[i];
                          final sel = _selectedNotice?.id == n.id;
                          return GestureDetector(
                            onTap: () =>
                                setState(() => _selectedNotice = n),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: sel
                                    ? cNavy(context).withValues(alpha: 0.06)
                                    : Colors.transparent,
                                border: Border(
                                    left: BorderSide(
                                        color: sel
                                            ? cNavy(context)
                                            : Colors.transparent,
                                        width: 3)),
                              ),
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(n.title,
                                      maxLines:  1,
                                      overflow:  TextOverflow.ellipsis,
                                      style: TextStyle(
                                          color:      cNavy(context),
                                          fontSize:   13,
                                          fontWeight: FontWeight.w700)),
                                  const SizedBox(height: 3),
                                  Row(
                                    children: [
                                      _AudienceBadge(n.targetAudience),
                                      const Spacer(),
                                      Text(
                                        '${n.createdAt.day}/${n.createdAt.month}/${n.createdAt.year}',
                                        style: TextStyle(
                                            color:    cMuted(context),
                                            fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildRightPanel(BuildContext context) {
    return Column(
      children: [
        // Compose card
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color:        cCard(context),
            borderRadius: BorderRadius.circular(14),
            border:       Border.all(color: cBorder(context)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('New Notice',
                  style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   14,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              TextField(
                controller: _titleCtrl,
                style: TextStyle(color: cNavy(context), fontSize: 14),
                decoration: InputDecoration(
                  labelText:  'Title *',
                  labelStyle: TextStyle(color: cMuted(context), fontSize: 13),
                  filled:     true,
                  fillColor:  cBg(context),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _bodyCtrl,
                maxLines:   4,
                style: TextStyle(color: cNavy(context), fontSize: 13),
                decoration: InputDecoration(
                  labelText:  'Message (optional)',
                  labelStyle: TextStyle(color: cMuted(context), fontSize: 13),
                  filled:     true,
                  fillColor:  cBg(context),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text('Audience:',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w600)),
                  const SizedBox(width: 10),
                  ..._audiences.map((a) {
                    final sel = _audience == a;
                    return Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: GestureDetector(
                        onTap: () => setState(() => _audience = a),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: sel
                                ? kNavy
                                : cBg(context),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: sel
                                    ? kNavy
                                    : cBorder(context)),
                          ),
                          child: Text(
                            a[0].toUpperCase() + a.substring(1),
                            style: TextStyle(
                                color: sel
                                    ? Colors.white
                                    : cMuted(context),
                                fontSize:   11,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
              if (_error != null) ...[
                const SizedBox(height: 8),
                Text(_error!,
                    style: const TextStyle(color: kError, fontSize: 12)),
              ],
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kNavy,
                    foregroundColor: Colors.white,
                    elevation:       0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onPressed: _saving ? null : _submit,
                  child: _saving
                      ? const SizedBox(
                          width: 18, height: 18,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2))
                      : const Text('Publish Notice',
                          style: TextStyle(
                              fontSize:   13,
                              fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),

        if (_selectedNotice != null) ...[
          const SizedBox(height: 16),
          Expanded(child: _buildNoticeDetail(context, _selectedNotice!)),
        ],
      ],
    );
  }

  Widget _buildNoticeDetail(BuildContext context, SchoolNotice n) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _AudienceBadge(n.targetAudience),
              const Spacer(),
              Text(
                '${n.createdAt.day}/${n.createdAt.month}/${n.createdAt.year}',
                style: TextStyle(color: cMuted(context), fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(n.title,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   18,
                  fontWeight: FontWeight.w800)),
          if (n.body.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(n.body,
                style: TextStyle(
                    color:    cBlue(context),
                    fontSize: 13,
                    height:   1.6)),
          ],
          if (n.createdBy.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text('Posted by: ${n.createdBy}',
                style: TextStyle(color: cMuted(context), fontSize: 11)),
          ],
        ],
      ),
    );
  }
}

class _AudienceBadge extends StatelessWidget {
  final String audience;
  const _AudienceBadge(this.audience);

  Color _color() {
    switch (audience) {
      case 'teachers': return const Color(0xFF2563EB);
      case 'parents':  return const Color(0xFF16A34A);
      case 'students': return const Color(0xFFF59E0B);
      default:         return kNavy;
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _color();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color:        c.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: c.withValues(alpha: 0.35)),
      ),
      child: Text(
        audience.toUpperCase(),
        style: TextStyle(
            color:         c,
            fontSize:      9,
            fontWeight:    FontWeight.w800,
            letterSpacing: 0.4),
      ),
    );
  }
}
