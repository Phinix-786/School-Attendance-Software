// lib/screens/privacy_consent_screen.dart
// Shown once after the first successful login.
// User MUST agree to proceed. Declining closes the app.
// Agreement stored in SharedPreferences under 'pp_agreed'.
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import '../privacy_policy_content.dart';
import 'privacy_policy_screen.dart';

class PrivacyConsentScreen extends StatefulWidget {
  /// The screen to push when the user agrees.
  final Widget nextScreen;
  const PrivacyConsentScreen({super.key, required this.nextScreen});

  static const _kAgreedKey = 'pp_agreed';

  /// Returns true if the user has already agreed (skip the consent screen).
  static Future<bool> hasAgreed() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kAgreedKey) ?? false;
  }

  /// Call this to mark agreement permanently.
  static Future<void> markAgreed() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAgreedKey, true);
  }

  @override
  State<PrivacyConsentScreen> createState() => _PrivacyConsentScreenState();
}

class _PrivacyConsentScreenState extends State<PrivacyConsentScreen> {
  bool _checked = false;

  Future<void> _agree() async {
    if (!_checked) return;
    await PrivacyConsentScreen.markAgreed();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => widget.nextScreen),
      (_) => false,
    );
  }

  void _decline() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(ctx),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Cannot Proceed',
            style: TextStyle(
                color:      cNavy(ctx),
                fontSize:   16,
                fontWeight: FontWeight.w800)),
        content: Text(kPrivacyDeclineWarning,
            style: TextStyle(color: cMuted(ctx), fontSize: 13, height: 1.5)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Go Back',
                  style: TextStyle(
                      color:      cNavy(ctx),
                      fontWeight: FontWeight.w700))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: kError,
                foregroundColor: Colors.white,
                elevation: 0),
            onPressed: () => exit(0),
            child: const Text('Close App'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Logo + title
              Row(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color:        const Color(0xFFEEDFC8),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset('assets/icon.png',
                          width: 44, height: 44, fit: BoxFit.cover),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(kAppName,
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   20,
                              fontWeight: FontWeight.w900)),
                      Text(kAppRole,
                          style: TextStyle(
                              color: cMuted(context), fontSize: 12)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 32),

              Text('Privacy Policy',
                  style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   26,
                      fontWeight: FontWeight.w900,
                      height:     1.1)),
              const SizedBox(height: 8),
              Text(
                'Before you continue, please review our Privacy Policy. '
                'It explains what data is stored and how it is used.',
                style: TextStyle(
                    color:    cBlue(context),
                    fontSize: 14,
                    height:   1.6),
              ),
              const SizedBox(height: 24),

              // Key points
              _BulletPoint(
                icon:  Icons.child_care_rounded,
                color: kTeal,
                text:  'We do not collect any personal data from children under 13 or above 13 for any commercial purpose.',
              ),
              const SizedBox(height: 10),
              _BulletPoint(
                icon:  Icons.lock_outlined,
                color: kNavy,
                text:  'Your school\'s data is stored only in your school\'s own Firebase database — we cannot access it.',
              ),
              const SizedBox(height: 10),
              _BulletPoint(
                icon:  Icons.block_rounded,
                color: kError,
                text:  'We do not sell, share, or use your data for advertising.',
              ),
              const SizedBox(height: 10),
              _BulletPoint(
                icon:  Icons.email_outlined,
                color: kMuted,
                text:  'Questions? Contact us at $kContactEmail',
              ),

              const SizedBox(height: 24),

              // Read full policy
              GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(
                        builder: (_) => const PrivacyPolicyScreen())),
                child: Row(
                  children: [
                    Icon(Icons.open_in_new_rounded,
                        size: 15, color: isDark(context) ? kDarkTeal : kNavy),
                    const SizedBox(width: 6),
                    Text('Read the full Privacy Policy',
                        style: TextStyle(
                            color: isDark(context) ? kDarkTeal : kNavy,
                            fontSize:      13,
                            fontWeight:    FontWeight.w700,
                            decoration:    TextDecoration.underline,
                            decorationColor:
                                isDark(context) ? kDarkTeal : kNavy)),
                  ],
                ),
              ),

              const Spacer(),

              // Checkbox agreement
              GestureDetector(
                onTap: () => setState(() => _checked = !_checked),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      width: 22, height: 22,
                      decoration: BoxDecoration(
                        color:        _checked ? kNavy : Colors.transparent,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color: _checked ? kNavy : cBorder(context),
                            width: 2),
                      ),
                      child: _checked
                          ? const Icon(Icons.check_rounded,
                              color: Colors.white, size: 14)
                          : null,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(kPrivacyAgreementText,
                          style: TextStyle(
                              color:    cNavy(context),
                              fontSize: 13,
                              height:   1.5)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _decline,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: kError,
                        side: const BorderSide(color: kError),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding:
                            const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: const Text('Decline',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton(
                      onPressed: _checked ? _agree : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kNavy,
                        foregroundColor: Colors.white,
                        disabledBackgroundColor:
                            cBorder(context),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding:
                            const EdgeInsets.symmetric(vertical: 15),
                      ),
                      child: const Text('I Agree & Continue',
                          style: TextStyle(
                              fontSize:   15,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BulletPoint extends StatelessWidget {
  final IconData icon;
  final Color    color;
  final String   text;
  const _BulletPoint({
    required this.icon,
    required this.color,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(
            color:        color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(text,
                style: TextStyle(
                    color:    cBlue(context),
                    fontSize: 13,
                    height:   1.5)),
          ),
        ),
      ],
    );
  }
}
