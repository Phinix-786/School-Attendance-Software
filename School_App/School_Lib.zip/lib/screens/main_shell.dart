// lib/screens/main_shell.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import 'dashboard_screen.dart';
import 'students_screen.dart';
import 'teachers_screen.dart';
import 'attendance_dashboard_screen.dart';
import 'classes_screen.dart';
import 'notice_board_screen.dart';
import 'updates_screen.dart';
import 'sections_screen.dart';
import 'tests_screen.dart';
import 'leaves_screen.dart';
import 'timetable_screen.dart';
import 'settings_screen.dart';
import 'documents_screen.dart';
import 'fee_management_screen.dart';
import 'login_screen.dart';
import '../widgets/update_banner.dart';
import '../widgets/hq_banner.dart';
import '../services/auto_updater_service.dart';
import '../services/hq_message_service.dart';
import '../services/feature_service.dart';
import '../services/local_settings_service.dart';
import '../services/notification_service.dart';
import '../models/local_models.dart';

class MainShell extends StatefulWidget {
  final String schoolId;
  final String schoolName;
  final String sectionId;
  final String sectionName;
  final bool isAdmin;

  const MainShell({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
    required this.sectionName,
    this.isAdmin = false,
  });

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with TickerProviderStateMixin {
  int _selected = 0;

  // ── Live session validation ────────────────────────────────────────────────
  Timer? _sessionPollTimer;

  // ── Sidebar animations ─────────────────────────────────────────────────────
  late final AnimationController _sidebarCtrl;
  late final Animation<Offset>   _sidebarSlide;
  late final Animation<double>   _sidebarFade;

  // ── Content fade ──────────────────────────────────────────────────────────
  late final AnimationController _contentCtrl;
  late final Animation<double>   _contentFade;

  // ── Feature flags + settings state ───────────────────────────────────────
  Map<String, bool> _features = {};
  AppSettings _appSettings = const AppSettings();
  bool _settingsLoaded = false;

  // ── Sidebar autohide ──────────────────────────────────────────────────────
  bool _sidebarVisible = true;
  Timer? _autohideTimer;
  bool _sidebarHovered = false;

  // ── Notification badge ───────────────────────────────────────────────────
  int _unreadNotifs = 0;
  Timer? _notifPollTimer;

  late List<_NavSection> _sections;

  @override
  void initState() {
    super.initState();

    _sidebarCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _sidebarSlide = Tween<Offset>(
            begin: const Offset(-1, 0), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _sidebarCtrl, curve: Curves.easeOutCubic));
    _sidebarFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(
            parent: _sidebarCtrl, curve: Curves.easeOut));

    _contentCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _contentFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(
            parent: _contentCtrl, curve: Curves.easeOut));

    _sidebarCtrl.forward();
    Future.delayed(const Duration(milliseconds: 200),
        () { if (mounted) _contentCtrl.forward(); });

    HqMessageService.instance.init(widget.schoolId);
    _startSessionWatcher();

    // Load feature flags + local settings, then build nav
    _initAsync();
  }

  Future<void> _initAsync() async {
    final features = await FeatureService.instance.getAll(
        widget.schoolId, widget.sectionId);
    final settings = await LocalSettingsService.instance.loadSettings();

    // Push loaded settings into global notifier so other listeners get them
    settingsNotifier.value = settings;

    // Apply theme from settings
    if (settings.activeThemeId == 'dark') {
      themeNotifier.value = ThemeMode.dark;
    } else if (settings.activeThemeId == 'light') {
      themeNotifier.value = ThemeMode.light;
    }

    // Preload notification count
    final notifSvc = NotificationService.instance;
    notifSvc.invalidateCache();
    await notifSvc.getAll(widget.schoolId);

    if (mounted) {
      setState(() {
        _features = features;
        _appSettings = settings;
        _settingsLoaded = true;
        _unreadNotifs = notifSvc.unreadCount(widget.schoolId);
        _buildSections();
      });
    }

    // Listen for live settings changes (from SettingsScreen)
    settingsNotifier.addListener(_onSettingsChanged);

    // Poll notifications every 30s
    _notifPollTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
      if (!mounted) return;
      notifSvc.invalidateCache();
      await notifSvc.getAll(widget.schoolId);
      if (mounted) {
        setState(() => _unreadNotifs = notifSvc.unreadCount(widget.schoolId));
      }
    });
  }

  void _buildSections() {
    final f = _features;
    final hidden = _appSettings.hiddenNavItems;

    bool show(String label) => !hidden.contains(label);

    // Re-read defaults if features map is empty (first build before init)
    bool isOn(String key) {
      if (f.containsKey(key)) return f[key]!;
      return const {
        FeatureService.kAttendance: true,
        FeatureService.kClasses: true,
        FeatureService.kStudents: true,
        FeatureService.kTeachers: true,
        FeatureService.kTimetable: true,
        FeatureService.kNotices: true,
        FeatureService.kTests: true,
        FeatureService.kLeaves: true,
        FeatureService.kFeeManagement: false,
        FeatureService.kDocuments: false,
      }[key] ?? false;
    }

    _sections = [
      _NavSection(header: null, items: [
        if (show('Dashboard'))
          _NavItem(
            icon:   Icons.grid_view_rounded,
            label:  'Dashboard',
            screen: DashboardScreen(
              schoolId:         widget.schoolId,
              schoolName:       widget.schoolName,
              sectionId:        widget.sectionId,
              onAddStudent:     () => _switchToLabel('Students'),
              onViewAttendance: () => _switchToLabel('Attendance'),
            ),
          ),
      ]),

      if (isOn(FeatureService.kAttendance))
        _NavSection(header: null, items: [
          if (show('Attendance'))
            _NavItem(
              icon:  Icons.fact_check_rounded,
              label: 'Attendance',
              screen: AttendanceDashboardScreen(
                schoolId:      widget.schoolId,
                schoolName:    widget.schoolName,
                sectionId:     widget.sectionId,
                isAdmin:       widget.isAdmin,
                onGoToClasses: () => _switchToLabel('Classes'),
              ),
            ),
        ]),

      _NavSection(header: 'MANAGEMENT', items: [
        if (isOn(FeatureService.kClasses) && show('Classes'))
          _NavItem(
            icon:   Icons.class_rounded,
            label:  'Classes',
            screen: ClassesScreen(
                schoolId: widget.schoolId,
                sectionId: widget.sectionId,
                isAdmin: widget.isAdmin),
          ),
        if (isOn(FeatureService.kStudents) && show('Students'))
          _NavItem(
            icon:   Icons.people_alt_rounded,
            label:  'Students',
            screen: StudentsScreen(
                schoolId: widget.schoolId,
                sectionId: widget.sectionId,
                isAdmin: widget.isAdmin),
          ),
        if (isOn(FeatureService.kTeachers) && show('Teachers'))
          _NavItem(
            icon:   Icons.person_4_rounded,
            label:  'Teachers',
            screen: TeachersScreen(
                schoolId: widget.schoolId,
                sectionId: widget.sectionId,
                isAdmin: widget.isAdmin),
          ),
      ]),

      if (widget.isAdmin)
        _NavSection(header: 'ADMIN', items: [
          if (show('Sections'))
            _NavItem(
              icon:   Icons.account_tree_rounded,
              label:  'Sections',
              screen: SectionsScreen(
                schoolId:   widget.schoolId,
                schoolName: widget.schoolName,
              ),
            ),
          if (isOn(FeatureService.kDocuments) && show('Documents'))
            _NavItem(
              icon:   Icons.folder_rounded,
              label:  'Documents',
              screen: DocumentsScreen(
                  schoolId: widget.schoolId,
                  sectionId: widget.sectionId),
            ),
        ]),

      _NavSection(header: 'RECORDS', items: [
        if (isOn(FeatureService.kTimetable) && show('Timetable'))
          _NavItem(
            icon:   Icons.calendar_month_rounded,
            label:  'Timetable',
            screen: TimetableScreen(
              schoolId:  widget.schoolId,
              sectionId: widget.sectionId,
              isAdmin:   widget.isAdmin,
            ),
          ),
        if (isOn(FeatureService.kNotices) && show('Notices'))
          _NavItem(
            icon:   Icons.campaign_rounded,
            label:  'Notices',
            screen: NoticesScreen(
              schoolId:   widget.schoolId,
              schoolName: widget.schoolName,
              sectionId:  widget.sectionId,
            ),
          ),
        if (isOn(FeatureService.kTests) && show('Tests'))
          _NavItem(
            icon:   Icons.quiz_rounded,
            label:  'Tests',
            screen: TestsScreen(
              schoolId:   widget.schoolId,
              schoolName: widget.schoolName,
              sectionId:  widget.sectionId,
              isAdmin:    widget.isAdmin,
            ),
          ),
        if (isOn(FeatureService.kLeaves) && show('Leaves'))
          _NavItem(
            icon:   Icons.event_note_rounded,
            label:  'Leaves',
            screen: LeavesScreen(
              schoolId:  widget.schoolId,
              sectionId: widget.sectionId,
              isAdmin:   widget.isAdmin,
            ),
          ),
        if (isOn(FeatureService.kFeeManagement) && show('Fee Management'))
          _NavItem(
            icon:   Icons.account_balance_wallet_rounded,
            label:  'Fee Management',
            screen: FeeManagementScreen(
              schoolId:  widget.schoolId,
              sectionId: widget.sectionId,
              isAdmin:   widget.isAdmin,
            ),
          ),
      ]),

      _NavSection(header: null, items: [
        if (show('Settings'))
          _NavItem(
            icon:   Icons.settings_rounded,
            label:  'Settings',
            screen: SettingsScreen(
              schoolId:    widget.schoolId,
              sectionId:   widget.sectionId,
              displayName: widget.sectionName,
              isAdmin:     widget.isAdmin,
            ),
          ),
        if (show('Updates'))
          _NavItem(
            icon:   Icons.system_update_rounded,
            label:  'Updates',
            screen: UpdatesScreen(
              schoolId:   widget.schoolId,
              schoolName: widget.schoolName,
              sectionId:  widget.sectionId,
            ),
          ),
      ]),
    ];

    // Remove sections with no visible items
    _sections.removeWhere((s) => s.items.isEmpty);
  }

  @override
  void dispose() {
    settingsNotifier.removeListener(_onSettingsChanged);
    _sidebarCtrl.dispose();
    _contentCtrl.dispose();
    _sessionPollTimer?.cancel();
    _autohideTimer?.cancel();
    _notifPollTimer?.cancel();
    super.dispose();
  }

  void _onSettingsChanged() {
    if (!mounted) return;
    final s = settingsNotifier.value;
    // Apply theme change immediately
    if (s.activeThemeId == 'dark') {
      themeNotifier.value = ThemeMode.dark;
    } else if (s.activeThemeId == 'light') {
      themeNotifier.value = ThemeMode.light;
    }
    setState(() {
      // Remember the label of the currently shown screen
      final currentLabel = _selected < _allItems.length
          ? _allItems[_selected].label
          : null;

      _appSettings = s;
      _buildSections();

      // Try to keep the same screen selected after rebuilding nav
      if (currentLabel != null) {
        final idx = _allItems.indexWhere((i) => i.label == currentLabel);
        if (idx >= 0) {
          _selected = idx;
        } else {
          // The current screen was hidden — fall back to Dashboard (index 0)
          _selected = 0;
        }
      }
    });
  }

  // ── Session watcher ────────────────────────────────────────────────────────
  void _startSessionWatcher() {
    _checkSession();
    _sessionPollTimer = Timer.periodic(const Duration(seconds: 60), (_) {
      _checkSession();
    });
  }

  Future<void> _checkSession() async {
    if (!mounted) return;
    try {
      final db = FirebaseFirestore.instance;
      final schoolDoc = await db
          .collection('schools')
          .doc(widget.schoolId)
          .get();
      if (!mounted) return;
      if (!schoolDoc.exists || schoolDoc.data()?['isActive'] != true) {
        _forceLogout();
        return;
      }
      if (!widget.isAdmin && widget.sectionId.isNotEmpty) {
        final sectionDoc = await db
            .collection('schools/${widget.schoolId}/sections')
            .doc(widget.sectionId)
            .get();
        if (!mounted) return;
        if (!sectionDoc.exists) _forceLogout();
      }
    } catch (e) {
      debugPrint('[_checkSession] error: $e');
    }
  }

  Future<void> _forceLogout() async {
    _sessionPollTimer?.cancel();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('schoolId');
    await prefs.remove('schoolName');
    await prefs.remove('sectionId');
    await prefs.remove('sectionName');
    await prefs.remove('isAdmin');
    await prefs.remove('hasSeenWelcome');
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, __, ___) => const LoginScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
      (_) => false,
    );
  }

  List<_NavItem> get _allItems =>
      _sections.expand((s) => s.items).toList();

  // Switch to tab by flat index
  Future<void> _switchTab(int flatIndex) async {
    if (flatIndex == _selected) return;
    await _contentCtrl.reverse();
    if (!mounted) return;
    setState(() => _selected = flatIndex);
    _contentCtrl.forward();
    final items = _allItems;
    final updatesIdx = items.indexWhere((i) => i.label == 'Updates');
    if (flatIndex == updatesIdx && updatesIdx >= 0) {
      HqMessageService.instance.clearUpdateDot();
    }
  }

  // Switch to tab by label (for callbacks from child screens)
  void _switchToLabel(String label) {
    final items = _allItems;
    final idx = items.indexWhere((i) => i.label == label);
    if (idx >= 0) _switchTab(idx);
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(ctx),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Sign Out?',
            style: TextStyle(
                color:      cNavy(ctx),
                fontSize:   17,
                fontWeight: FontWeight.w800)),
        content: Text('Are you sure you want to sign out?',
            style: TextStyle(color: cMuted(ctx), fontSize: 13)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text('Cancel',
                  style: TextStyle(
                      color:      cMuted(ctx),
                      fontWeight: FontWeight.w600))),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kError,
                  foregroundColor: Colors.white,
                  elevation:       0),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Sign Out',
                  style: TextStyle(fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('schoolId');
    await prefs.remove('schoolName');
    await prefs.remove('sectionId');
    await prefs.remove('sectionName');
    await prefs.remove('isAdmin');
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder:        (_, __, ___) => const LoginScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
      ),
    );
  }

  // ── Sidebar hover helpers (autohide removed — toggle button only) ─────────
  void _onSidebarEnter() {}
  void _onSidebarExit()  {}
  void _onContentEnter() {}

  // ── Notifications panel ─────────────────────────────────────────────────────
  void _openNotifications() {
    showDialog(
      context: context,
      builder: (ctx) => _NotificationPanel(
        schoolId: widget.schoolId,
        onClosed: () async {
          await NotificationService.instance.markAllRead(widget.schoolId);
          if (mounted) setState(() => _unreadNotifs = 0);
        },
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (!_settingsLoaded) {
      // Show spinner while loading settings/features
      return Scaffold(
        backgroundColor: cBg(context),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final items = _allItems;
    // Guard selected index
    if (_selected >= items.length && items.isNotEmpty) {
      _selected = 0;
    }

    return Scaffold(
      backgroundColor: cBg(context),
      body: Row(
        children: [
          // ── Sidebar ─────────────────────────────────────────────
          // When hidden: collapses to 0 but a 6px hover-strip remains
          // so autohide can re-show it on mouse entry.
          Stack(
            children: [
              // Actual sidebar panel
              MouseRegion(
                onEnter: (_) => _onSidebarEnter(),
                onExit:  (_) => _onSidebarExit(),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  curve:    Curves.easeInOut,
                  width:    _sidebarVisible ? 220 : 0,
                  child: OverflowBox(
                    maxWidth:  220,
                    alignment: Alignment.centerLeft,
                    child: SizedBox(
                      width: 220,
                      child: SlideTransition(
                        position: _sidebarSlide,
                        child: FadeTransition(
                          opacity: _sidebarFade,
                          child: _buildSidebar(context, items),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

            ],
          ),

          Expanded(
            child: MouseRegion(
              onEnter: (_) => _onContentEnter(),
              child: FadeTransition(
                opacity: _contentFade,
                child: Column(
                  children: [
                    const HqBanner(),
                    _buildTopBar(context),
                    Expanded(
                      child: items.isEmpty
                          ? const SizedBox.shrink()
                          : items[_selected].screen,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Top bar (hamburger + spacer) ──────────────────────────────────────────
  Widget _buildTopBar(BuildContext context) {
    return Container(
      height: 44,
      color: cBg(context),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          // Hamburger — toggles sidebar
          Tooltip(
            message: _sidebarVisible ? 'Hide sidebar' : 'Show sidebar',
            child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () {
                _autohideTimer?.cancel();
                setState(() => _sidebarVisible = !_sidebarVisible);
              },
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color:        cNavy(context).withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  _sidebarVisible
                      ? Icons.menu_open_rounded
                      : Icons.menu_rounded,
                  color: cNavy(context).withValues(alpha: 0.7),
                  size: 18,
                ),
              ),
            ),
          ),
          // Spacer — rest of bar is empty; content starts below
          const Spacer(),
        ],
      ),
    );
  }

  // ── Sidebar ───────────────────────────────────────────────────────────────
  Widget _buildSidebar(BuildContext context, List<_NavItem> allItems) {
    int flatIdx = 0;
    final dark = isDark(context);

    return Container(
      width:  220,
      height: double.infinity,
      decoration: BoxDecoration(
        color: cCard(context),
        border: Border(right: BorderSide(color: cBorder(context))),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 20,
            offset:     const Offset(4, 0),
          ),
        ],
      ),
      child: Column(
        children: [
          // ── Logo / school header ───────────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(18, 26, 18, 20),
            child: Row(
              children: [
                Container(
                  width:  40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: dark
                        ? const Color(0xFF2C2C3A)
                        : const Color(0xFFEEDFC8),
                    borderRadius: BorderRadius.circular(12),
                    border: dark
                        ? Border.all(
                            color: Colors.white.withValues(alpha: 0.08),
                            width: 1)
                        : null,
                    boxShadow: dark
                        ? [BoxShadow(
                            color:      Colors.black.withValues(alpha: 0.25),
                            blurRadius: 6,
                            offset:     const Offset(0, 2))]
                        : null,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(
                      dark ? 'assets/inverted_icon.png' : 'assets/icon.ico',
                      width: 40, height: 40, fit: BoxFit.cover,
                    ),
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.schoolName.isNotEmpty
                            ? widget.schoolName
                            : 'Your School',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color:      cNavy(context),
                          fontWeight: FontWeight.w800,
                          fontSize:   13,
                        ),
                      ),
                      Container(
                        margin:  const EdgeInsets.only(top: 3),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color:        kPink.withValues(alpha: 0.25),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          widget.sectionName.isNotEmpty
                              ? widget.sectionName
                              : (widget.isAdmin ? 'Admin' : 'Section'),
                          style: TextStyle(
                            color:         cNavy(context),
                            fontSize:      9.5,
                            fontWeight:    FontWeight.w800,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // ── Notification bell ────────────────────────────
                GestureDetector(
                  onTap: _openNotifications,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 30, height: 30,
                        decoration: BoxDecoration(
                          color: cBg(context),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: cBorder(context)),
                        ),
                        child: Icon(Icons.notifications_outlined,
                            color: cMuted(context).withValues(alpha: 0.7),
                            size: 16),
                      ),
                      if (_unreadNotifs > 0)
                        Positioned(
                          top: -4, right: -4,
                          child: Container(
                            padding: const EdgeInsets.all(3),
                            decoration: const BoxDecoration(
                              color: kError,
                              shape: BoxShape.circle,
                            ),
                            constraints: const BoxConstraints(
                                minWidth: 16, minHeight: 16),
                            child: Text(
                              '$_unreadNotifs',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          Divider(height: 1, color: cBorder(context)),
          const UpdateBanner(),

          // ── Nav items ────────────────────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _sections.map((section) {
                  final sectionWidgets = <Widget>[];

                  if (section.header != null) {
                    sectionWidgets.add(
                      Padding(
                        padding: const EdgeInsets.fromLTRB(8, 14, 8, 6),
                        child: Text(
                          section.header!,
                          style: TextStyle(
                            color:         cMuted(context).withValues(alpha: 0.6),
                            fontSize:      10,
                            fontWeight:    FontWeight.w700,
                            letterSpacing: 0.9,
                          ),
                        ),
                      ),
                    );
                  }

                  for (final item in section.items) {
                    final idx = flatIdx++;
                    sectionWidgets.add(_navTile(context, item, idx));
                  }

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: sectionWidgets,
                  );
                }).toList(),
              ),
            ),
          ),

          // ── Bottom controls ──────────────────────────────────────
          Divider(height: 1, color: cBorder(context)),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 16),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Powered By App_Name',
                        style: TextStyle(
                          color: isDark(context)
                              ? Colors.white.withValues(alpha: 0.35)
                              : Colors.black.withValues(alpha: 0.45),
                          fontSize:      10,
                          fontWeight:    FontWeight.w600,
                          letterSpacing: 0.3,
                        ),
                      ),
                      Text(
                        '  •  v$kCurrentVersion',
                        style: TextStyle(
                          color: isDark(context)
                              ? Colors.white.withValues(alpha: 0.22)
                              : Colors.black.withValues(alpha: 0.28),
                          fontSize:   10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                _ThemeToggle(),
                const SizedBox(height: 8),
                _CheckUpdatesButton(
                  onPressed: () async {
                    _switchToLabel('Updates');
                    await AutoUpdaterService.instance.forceCheck();
                  },
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color:        cBg(context),
                    borderRadius: BorderRadius.circular(10),
                    border:       Border.all(color: cBorder(context)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.badge_outlined,
                          color: cMuted(context).withValues(alpha: 0.5),
                          size: 15),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          'ID: ${widget.schoolId}',
                          style: TextStyle(
                            color:      cMuted(context).withValues(alpha: 0.6),
                            fontSize:   11,
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                _LogoutButton(onLogout: _logout),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Nav tile ──────────────────────────────────────────────────────────────
  Widget _navTile(BuildContext context, _NavItem item, int index) {
    final selected    = _selected == index;
    final items       = _allItems;
    final updatesIdx  = items.indexWhere((i) => i.label == 'Updates');
    final isUpdateTab = index == updatesIdx && updatesIdx >= 0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve:    Curves.easeOut,
        decoration: BoxDecoration(
          color: selected
              ? cNavy(context).withValues(
                  alpha: isDark(context) ? 0.12 : 0.06)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: selected
              ? Border.all(
                  color: cNavy(context).withValues(alpha: 0.08))
              : null,
        ),
        child: ListTile(
          dense:           true,
          minLeadingWidth: 0,
          leading: AnimatedContainer(
            duration:     const Duration(milliseconds: 200),
            width: 32, height: 32,
            decoration: BoxDecoration(
              color: selected
                  ? cNavy(context).withValues(alpha: 0.10)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(
              item.icon,
              color: selected
                  ? cNavy(context)
                  : cMuted(context).withValues(alpha: 0.6),
              size: 17,
            ),
          ),
          title: Text(
            item.label,
            style: TextStyle(
              color:      selected
                  ? cNavy(context)
                  : cMuted(context).withValues(alpha: 0.75),
              fontSize:   13,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
          trailing: isUpdateTab
              ? ValueListenableBuilder<bool>(
                  valueListenable:
                      HqMessageService.instance.updateAvailable,
                  builder: (_, hasUpdate, __) {
                    if (hasUpdate) {
                      return Container(
                        width: 8, height: 8,
                        decoration: const BoxDecoration(
                            color: kError, shape: BoxShape.circle),
                      );
                    }
                    return selected
                        ? Container(
                            width: 5, height: 5,
                            decoration: BoxDecoration(
                                color: cNavy(context),
                                shape: BoxShape.circle),
                          )
                        : const SizedBox.shrink();
                  },
                )
              : (selected
                  ? Container(
                      width: 5, height: 5,
                      decoration: BoxDecoration(
                          color: cNavy(context),
                          shape: BoxShape.circle),
                    )
                  : null),
          onTap: () => _switchTab(index),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }
}

// ── Notification Panel Dialog ─────────────────────────────────
class _NotificationPanel extends StatefulWidget {
  final String schoolId;
  final VoidCallback onClosed;

  const _NotificationPanel(
      {required this.schoolId, required this.onClosed});

  @override
  State<_NotificationPanel> createState() => _NotificationPanelState();
}

class _NotificationPanelState extends State<_NotificationPanel> {
  List<AppNotification> _notifs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final notifs =
        await NotificationService.instance.getAll(widget.schoolId);
    if (mounted) {
      setState(() {
        _notifs = List.from(notifs);
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    widget.onClosed();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: cCard(context),
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: SizedBox(
        width: 400,
        height: 520,
        child: Column(children: [
          // Header
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 16, 18),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: cBorder(context))),
            ),
            child: Row(children: [
              Icon(Icons.notifications_rounded,
                  color: cNavy(context), size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text('Notifications',
                    style: TextStyle(
                        color: cNavy(context),
                        fontSize: 15,
                        fontWeight: FontWeight.w700)),
              ),
              TextButton(
                onPressed: () async {
                  await NotificationService.instance
                      .clearAll(widget.schoolId);
                  if (mounted) setState(() => _notifs = []);
                },
                child: const Text('Clear all',
                    style: TextStyle(fontSize: 12)),
              ),
              IconButton(
                icon: Icon(Icons.close_rounded,
                    color: cMuted(context), size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ]),
          ),
          // List
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _notifs.isEmpty
                    ? Center(
                        child: Text('No notifications',
                            style: TextStyle(
                                color: cMuted(context), fontSize: 13)))
                    : ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: _notifs.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final n = _notifs[i];
                          return Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: n.read
                                  ? cBg(context)
                                  : cNavy(context)
                                      .withValues(alpha: 0.05),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: n.read
                                      ? cBorder(context)
                                      : cNavy(context)
                                          .withValues(alpha: 0.15)),
                            ),
                            child: Column(
                              crossAxisAlignment:
                                  CrossAxisAlignment.start,
                              children: [
                                Row(children: [
                                  Expanded(
                                    child: Text(n.title,
                                        style: TextStyle(
                                            color: cNavy(context),
                                            fontSize: 13,
                                            fontWeight:
                                                FontWeight.w700)),
                                  ),
                                  if (!n.read)
                                    Container(
                                      width: 7, height: 7,
                                      decoration: const BoxDecoration(
                                          color: kError,
                                          shape: BoxShape.circle),
                                    ),
                                ]),
                                const SizedBox(height: 4),
                                Text(n.body,
                                    style: TextStyle(
                                        color: cMuted(context),
                                        fontSize: 12)),
                                const SizedBox(height: 6),
                                Text(
                                  _formatTime(n.timestamp),
                                  style: TextStyle(
                                      color: cMuted(context)
                                          .withValues(alpha: 0.6),
                                      fontSize: 10.5),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ]),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}

// ── Theme Toggle ─────────────────────────────────────────────
class _ThemeToggle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (ctx, mode, _) {
        final dark = mode == ThemeMode.dark;
        return GestureDetector(
          onTap: () {
            themeNotifier.value =
                dark ? ThemeMode.light : ThemeMode.dark;
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color:        cBg(ctx),
              borderRadius: BorderRadius.circular(10),
              border:       Border.all(color: cBorder(ctx)),
            ),
            child: Row(children: [
              Icon(
                dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                color: cMuted(ctx).withValues(alpha: 0.75),
                size: 14,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  dark ? 'Light Mode' : 'Dark Mode',
                  style: TextStyle(
                    color:      cMuted(ctx),
                    fontSize:   12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                width: 32, height: 18,
                decoration: BoxDecoration(
                  color:        dark ? kNavy : cBorder(ctx),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: AnimatedAlign(
                  duration:  const Duration(milliseconds: 250),
                  alignment: dark
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    width: 14, height: 14,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ),
            ]),
          ),
        );
      },
    );
  }
}

// ── Logout button ─────────────────────────────────────────────
class _LogoutButton extends StatefulWidget {
  final VoidCallback onLogout;
  const _LogoutButton({required this.onLogout});

  @override
  State<_LogoutButton> createState() => _LogoutButtonState();
}

class _LogoutButtonState extends State<_LogoutButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Color?>   _bgColor;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 180));
    _bgColor = ColorTween(
      begin: kError.withValues(alpha: 0.06),
      end:   kError.withValues(alpha: 0.14),
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => _ctrl.forward(),
      onExit:  (_) => _ctrl.reverse(),
      child: GestureDetector(
        onTap: widget.onLogout,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            decoration: BoxDecoration(
              color:        _bgColor.value,
              borderRadius: BorderRadius.circular(10),
              border:       Border.all(color: kError.withValues(alpha: 0.2)),
            ),
            child: Row(children: [
              Icon(Icons.logout_rounded, color: kError, size: 16),
              const SizedBox(width: 9),
              const Text('Sign Out',
                  style: TextStyle(
                      color:      kError,
                      fontSize:   13,
                      fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      ),
    );
  }
}

// ── Check for Updates button ──────────────────────────────────
class _CheckUpdatesButton extends StatefulWidget {
  final VoidCallback onPressed;
  const _CheckUpdatesButton({required this.onPressed});

  @override
  State<_CheckUpdatesButton> createState() => _CheckUpdatesButtonState();
}

class _CheckUpdatesButtonState extends State<_CheckUpdatesButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Color?>   _bgColor;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 180));
    _bgColor = ColorTween(
      begin: kNavy.withValues(alpha: 0.06),
      end:   kNavy.withValues(alpha: 0.13),
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => _ctrl.forward(),
      onExit:  (_) => _ctrl.reverse(),
      child: GestureDetector(
        onTap: widget.onPressed,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color:        _bgColor.value,
              borderRadius: BorderRadius.circular(10),
              border:       Border.all(
                  color: cNavy(context).withValues(alpha: 0.15)),
            ),
            child: Row(children: [
              Icon(Icons.system_update_rounded,
                  color: cNavy(context).withValues(alpha: 0.75), size: 14),
              const SizedBox(width: 8),
              Expanded(
                child: Text('Check for Updates',
                    style: TextStyle(
                        color:      cMuted(context),
                        fontSize:   12,
                        fontWeight: FontWeight.w600)),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ── Data models ───────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String   label;
  final Widget   screen;
  _NavItem({required this.icon, required this.label, required this.screen});
}

class _NavSection {
  final String?        header;
  final List<_NavItem> items;
  _NavSection({required this.header, required this.items});
}
