// lib/screens/feature_detail_screen.dart
import 'package:flutter/material.dart';

import '../app_theme.dart';
import '../services/feature_service.dart';

// ── Mini toggle (local copy) ──────────────────────────────────
class _MiniToggle extends StatelessWidget {
  final bool enabled;
  const _MiniToggle({required this.enabled});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      width: 36,
      height: 20,
      decoration: BoxDecoration(
        color: enabled ? kNavy : cBorder(context),
        borderRadius: BorderRadius.circular(10),
      ),
      child: AnimatedAlign(
        duration: const Duration(milliseconds: 220),
        alignment: enabled ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          width: 16,
          height: 16,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }
}

class FeatureDetailScreen extends StatefulWidget {
  final String featureKey;
  final FeatureMeta meta;
  final bool enabled;
  final String schoolId;
  final String sectionId;
  final bool isAdmin;
  final ValueChanged<bool> onToggle;

  const FeatureDetailScreen({
    super.key,
    required this.featureKey,
    required this.meta,
    required this.enabled,
    required this.schoolId,
    required this.sectionId,
    required this.isAdmin,
    required this.onToggle,
  });

  @override
  State<FeatureDetailScreen> createState() => _FeatureDetailScreenState();
}

class _FeatureDetailScreenState extends State<FeatureDetailScreen> {
  late bool _enabled;

  @override
  void initState() {
    super.initState();
    _enabled = widget.enabled;
  }

  // What data each feature stores (human-readable)
  static const Map<String, String> _dataStored = {
    FeatureService.kAttendance:
        'Attendance sessions and per-student attendance records for each class day.',
    FeatureService.kClasses:
        'Class names, grades, and assigned teacher lists.',
    FeatureService.kStudents:
        'Student profiles including name, roll number, parent contact, and login credentials.',
    FeatureService.kTeachers:
        'Teacher profiles, subject assignments, class lists, and login credentials.',
    FeatureService.kTimetable:
        'Per-teacher weekly timetables with subject, class, day, and period information.',
    FeatureService.kNotices:
        'School notices distributed to teachers, parents, or students via mobile apps.',
    FeatureService.kTests:
        'Test definitions and per-student results including marks and absence flags.',
    FeatureService.kLeaves:
        'Student leave requests submitted by students or parents, with approval status.',
    FeatureService.kFeeManagement:
        'Monthly fee records per student including amount, paid amount, and payment status.',
    FeatureService.kDocuments:
        'Staff and student document files (CVs, CNICs, contracts, certificates) stored as base64.',
  };

  static const Map<String, String> _whoCanUse = {
    FeatureService.kAttendance: 'Admin (school-wide) and Section Heads (own section only).',
    FeatureService.kClasses: 'Admin and Section Heads.',
    FeatureService.kStudents: 'Admin and Section Heads.',
    FeatureService.kTeachers: 'Admin and Section Heads.',
    FeatureService.kTimetable: 'Admin and Section Heads.',
    FeatureService.kNotices: 'Admin and Section Heads.',
    FeatureService.kTests: 'Admin and Section Heads. Teachers via Teacher App.',
    FeatureService.kLeaves: 'Admin and Section Heads. Students and Parents via mobile apps.',
    FeatureService.kFeeManagement: 'Admin and Section Heads (if granted access by admin).',
    FeatureService.kDocuments: 'Admin only.',
  };

  @override
  Widget build(BuildContext context) {
    final icon = IconData(widget.meta.iconCodePoint, fontFamily: 'MaterialIcons');

    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Divider(height: 1, color: cBorder(context)),
        ),
        title: Text(widget.meta.label,
            style: TextStyle(
                color: cNavy(context),
                fontSize: 16,
                fontWeight: FontWeight.w700)),
      ),
      body: Row(
        children: [
          // Mini sidebar — back button + label
          Container(
            width: 200,
            decoration: BoxDecoration(
              color:  cCard(context),
              border: Border(right: BorderSide(color: cBorder(context))),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 20, 12, 8),
                  child: TextButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: Icon(Icons.arrow_back_ios_new_rounded,
                        size: 14, color: cNavy(context)),
                    label: Text('Features',
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   13,
                            fontWeight: FontWeight.w700)),
                    style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6)),
                  ),
                ),
                Divider(height: 1, color: cBorder(context)),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
                  child: Text('FEATURE DETAILS',
                      style: TextStyle(
                          color:         cMuted(context),
                          fontSize:      10,
                          fontWeight:    FontWeight.w700,
                          letterSpacing: 0.8)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color:        cNavy(context).withValues(alpha: 0.07),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(widget.meta.label,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   13,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ),
          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: cCard(context),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: cBorder(context)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: (_enabled ? kNavy : kMuted).withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(icon,
                        color: _enabled ? kNavy : kMuted, size: 30),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Text(widget.meta.label,
                              style: TextStyle(
                                  color: cNavy(context),
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800)),
                          const SizedBox(width: 12),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: (_enabled
                                      ? Colors.green
                                      : kMuted)
                                  .withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              _enabled ? 'Enabled' : 'Disabled',
                              style: TextStyle(
                                color: _enabled ? Colors.green : kMuted,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          if (widget.meta.adminOnly) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: kTeal.withValues(alpha: 0.12),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text('Admin Only',
                                  style: TextStyle(
                                      color: kTeal,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700)),
                            ),
                          ],
                        ]),
                        const SizedBox(height: 8),
                        Text(widget.meta.description,
                            style: TextStyle(
                                color: cMuted(context), fontSize: 14)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Info cards row
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _infoCard(
                    'Data Stored',
                    Icons.storage_rounded,
                    _dataStored[widget.featureKey] ?? '',
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _infoCard(
                    'Who Can Use',
                    Icons.group_rounded,
                    _whoCanUse[widget.featureKey] ?? '',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Toggle card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: cCard(context),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: cBorder(context)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Feature Toggle',
                      style: TextStyle(
                          color: cNavy(context),
                          fontSize: 15,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  if (!_enabled)
                    Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: kError.withValues(alpha: 0.06),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color: kError.withValues(alpha: 0.2)),
                      ),
                      child: Row(children: [
                        const Icon(Icons.warning_amber_rounded,
                            color: kError, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Disabling this feature will permanently delete '
                            'all its Firestore data. This cannot be undone.',
                            style: const TextStyle(
                                color: kError,
                                fontSize: 12.5,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                      ]),
                    ),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _enabled
                                  ? 'Feature is currently enabled'
                                  : 'Feature is currently disabled',
                              style: TextStyle(
                                  color: cNavy(context),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600),
                            ),
                            Text(
                              _enabled
                                  ? 'Toggle off to disable and delete data'
                                  : 'Toggle on to re-enable (data already deleted)',
                              style: TextStyle(
                                  color: cMuted(context), fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      if (!widget.meta.adminOnly || widget.isAdmin)
                        GestureDetector(
                          onTap: () async {
                            widget.onToggle(!_enabled);
                            setState(() => _enabled = !_enabled);
                          },
                          child: _MiniToggle(enabled: _enabled),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
          ), // SingleChildScrollView
          ), // Expanded
        ],
      ), // Row body
    );
  }

  Widget _infoCard(String title, IconData icon, String body) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: cNavy(context), size: 16),
            const SizedBox(width: 8),
            Text(title,
                style: TextStyle(
                    color: cNavy(context),
                    fontSize: 13,
                    fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 10),
          Text(body,
              style: TextStyle(color: cMuted(context), fontSize: 12.5)),
        ],
      ),
    );
  }
}
