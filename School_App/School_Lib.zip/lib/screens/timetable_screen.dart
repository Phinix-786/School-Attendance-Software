// lib/screens/timetable_screen.dart
// School desktop — set/edit timetables for each teacher.
// Section head manages their own section's teachers.
// Admin can pick any section.
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class TimetableScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool   isAdmin;

  const TimetableScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
    this.isAdmin = false,
  });

  @override
  State<TimetableScreen> createState() => _TimetableScreenState();
}

class _TimetableScreenState extends State<TimetableScreen> {
  List<Map<String, dynamic>> _adminSections = [];
  String?                    _selectedSecId;

  List<Teacher>         _teachers  = [];
  List<SchoolClass>     _classes   = [];
  Teacher?              _selTeacher;
  TeacherTimetable?     _timetable;
  bool                  _loading   = false;
  bool                  _saving    = false;
  Timer?                _pollTimer;

  // Editing state: day → period → entry
  final Map<String, Map<String, _CellEntry>> _grid = {};

  static const _days    = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  static const _periods = ['1','2','3','4','5','6','7','8'];

  String get _effectiveSecId =>
      widget.isAdmin ? (_selectedSecId ?? '') : widget.sectionId;

  @override
  void initState() {
    super.initState();
    if (widget.isAdmin) {
      _loadAdminSections();
    } else {
      _loadTeachers(widget.sectionId);
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadAdminSections() async {
    final secs = await SchoolFirebaseService.getSections(widget.schoolId);
    if (!mounted) return;
    setState(() {
      _adminSections = secs;
      if (secs.isNotEmpty) _selectedSecId = secs.first['id'] as String;
    });
    if (_selectedSecId != null) _loadTeachers(_selectedSecId!);
  }

  Future<void> _loadTeachers(String secId) async {
    setState(() { _loading = true; _teachers = []; _selTeacher = null; _timetable = null; });
    final [teachers, classes] = await Future.wait([
      SchoolFirebaseService.getAllTeachers(widget.schoolId, secId),
      SchoolFirebaseService.getClasses(widget.schoolId, secId),
    ]);
    if (!mounted) return;
    setState(() {
      _teachers = teachers as List<Teacher>;
      _classes  = classes  as List<SchoolClass>;
      _loading  = false;
    });
  }

  Future<void> _selectTeacher(Teacher t) async {
    setState(() { _selTeacher = t; _loading = true; _timetable = null; });
    final tt = await SchoolFirebaseService.getTimetable(
        widget.schoolId, _effectiveSecId, t.id);
    if (!mounted) return;
    _buildGrid(tt, t);
    setState(() { _timetable = tt; _loading = false; });
  }

  void _buildGrid(TeacherTimetable? tt, Teacher t) {
    _grid.clear();
    for (final d in _days) {
      _grid[d] = {};
      for (final p in _periods) {
        _grid[d]![p] = _CellEntry(subject: '', classId: '');
      }
    }
    if (tt != null) {
      for (final e in tt.entries) {
        if (_grid.containsKey(e.day) && _grid[e.day]!.containsKey(e.period)) {
          _grid[e.day]![e.period] = _CellEntry(
              subject: e.subject, classId: e.classId);
        }
      }
    }
  }

  Future<void> _save() async {
    if (_selTeacher == null) return;
    setState(() => _saving = true);

    final entries = <TimetableEntry>[];
    for (final d in _days) {
      for (final p in _periods) {
        final cell = _grid[d]![p]!;
        if (cell.subject.isNotEmpty) {
          final cls = _classes.firstWhere(
              (c) => c.id == cell.classId,
              orElse: () => SchoolClass(
                  id: cell.classId, schoolId: widget.schoolId,
                  name: '', grade: '', section: ''));
          entries.add(TimetableEntry(
            day:       d,
            period:    p,
            subject:   cell.subject,
            classId:   cell.classId,
            className: cls.name,
          ));
        }
      }
    }

    final tt = TeacherTimetable(
      teacherId:   _selTeacher!.id,
      teacherName: _selTeacher!.name,
      updatedAt:   DateTime.now(),
      entries:     entries,
    );

    await SchoolFirebaseService.saveTimetable(
        widget.schoolId, _effectiveSecId, tt);
    if (mounted) {
      setState(() { _saving = false; _timetable = tt; });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Timetable saved! Teacher will be notified.'),
            backgroundColor: Color(0xFF16A34A)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(context),
            if (widget.isAdmin && _adminSections.isNotEmpty) ...[
              const SizedBox(height: 12),
              _buildSectionChips(context),
            ],
            const SizedBox(height: 16),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Teacher list
                  SizedBox(
                    width: 200,
                    child: _buildTeacherList(context),
                  ),
                  const SizedBox(width: 20),
                  // Grid
                  Expanded(child: _buildGrid2(context)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        Icon(Icons.calendar_month_rounded, color: cNavy(context), size: 20),
        const SizedBox(width: 9),
        Text('Timetable Management',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   19,
                fontWeight: FontWeight.w800)),
        const Spacer(),
        if (_selTeacher != null)
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: kNavy,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(
                  horizontal: 18, vertical: 11),
            ),
            icon: _saving
                ? const SizedBox(width: 14, height: 14,
                    child: CircularProgressIndicator(
                        color: Colors.white, strokeWidth: 2))
                : const Icon(Icons.save_rounded, size: 16),
            label: Text(_saving ? 'Saving…' : 'Save Timetable',
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w700)),
            onPressed: _saving ? null : _save,
          ),
      ],
    );
  }

  Widget _buildSectionChips(BuildContext context) {
    return Row(
      children: _adminSections.map((sec) {
        final sId  = (sec['id'] as String?) ?? '';
        final name = (sec['name'] as String?) ?? sId;
        final sel  = _selectedSecId == sId;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: GestureDetector(
            onTap: () {
              if (_selectedSecId == sId) return;
              setState(() { _selectedSecId = sId; });
              _loadTeachers(sId);
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color:        sel ? cNavy(context) : cCard(context),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: sel ? cNavy(context) : cBorder(context)),
              ),
              child: Text(name,
                  style: TextStyle(
                      color:      sel ? Colors.white : cMuted(context),
                      fontSize:   12.5,
                      fontWeight: sel ? FontWeight.w700 : FontWeight.w500)),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTeacherList(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Text('Teachers',
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   13,
                    fontWeight: FontWeight.w700)),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : _teachers.isEmpty
                    ? Center(
                        child: Text('No teachers.',
                            style: TextStyle(color: cMuted(context), fontSize: 13)))
                    : ListView.builder(
                        itemCount: _teachers.length,
                        itemBuilder: (_, i) {
                          final t   = _teachers[i];
                          final sel = _selTeacher?.id == t.id;
                          return GestureDetector(
                            onTap: () => _selectTeacher(t),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 10),
                              decoration: BoxDecoration(
                                color: sel
                                    ? cNavy(context).withValues(alpha: 0.07)
                                    : Colors.transparent,
                                border: Border(
                                    left: BorderSide(
                                        color: sel
                                            ? cNavy(context)
                                            : Colors.transparent,
                                        width: 3)),
                              ),
                              child: Text(t.name,
                                  style: TextStyle(
                                      color:      cNavy(context),
                                      fontSize:   13,
                                      fontWeight: sel
                                          ? FontWeight.w700
                                          : FontWeight.w500)),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildGrid2(BuildContext context) {
    if (_selTeacher == null) {
      return Container(
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(14),
          border:       Border.all(color: cBorder(context)),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('📅', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 12),
              Text('Select a teacher to view or edit their timetable.',
                  style: TextStyle(color: cMuted(context), fontSize: 14)),
            ],
          ),
        ),
      );
    }

    if (_loading) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }

    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                Text('${_selTeacher!.name} — Timetable',
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   14,
                        fontWeight: FontWeight.w800)),
                if (_timetable != null) ...[
                  const SizedBox(width: 10),
                  Text(
                    'Last saved: ${_timetable!.updatedAt.day}/${_timetable!.updatedAt.month}/${_timetable!.updatedAt.year}',
                    style: TextStyle(color: cMuted(context), fontSize: 11),
                  ),
                ],
              ],
            ),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Table(
                    defaultColumnWidth:
                        const FixedColumnWidth(140),
                    border: TableBorder.all(
                        color: cBorder(context), width: 0.5),
                    children: [
                      // Header row
                      TableRow(
                        decoration: BoxDecoration(
                            color: cNavy(context).withValues(alpha: 0.08)),
                        children: [
                          _hCell(context, 'Period'),
                          ..._days.map((d) => _hCell(context, d)),
                        ],
                      ),
                      // Data rows
                      ..._periods.map((p) => TableRow(
                        children: [
                          // Period number
                          Container(
                            padding: const EdgeInsets.all(8),
                            child: Text('P$p',
                                style: TextStyle(
                                    color:      cNavy(context),
                                    fontSize:   12,
                                    fontWeight: FontWeight.w700)),
                          ),
                          // Cells for each day
                          ..._days.map((d) {
                            final cell = _grid[d]![p]!;
                            return _TimetableCell(
                              entry:   cell,
                              classes: _classes,
                              onChanged: (sub, cid) {
                                setState(() {
                                  _grid[d]![p] =
                                      _CellEntry(subject: sub, classId: cid);
                                });
                              },
                            );
                          }),
                        ],
                      )),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _hCell(BuildContext context, String text) => Container(
        padding: const EdgeInsets.all(8),
        child: Text(text,
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   12,
                fontWeight: FontWeight.w700)),
      );
}

// ── Cell data ─────────────────────────────────────────────────
class _CellEntry {
  String subject;
  String classId;
  _CellEntry({required this.subject, required this.classId});
}

// ── Interactive timetable cell ────────────────────────────────
class _TimetableCell extends StatelessWidget {
  final _CellEntry          entry;
  final List<SchoolClass>   classes;
  final void Function(String subject, String classId) onChanged;

  const _TimetableCell({
    required this.entry,
    required this.classes,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isEmpty = entry.subject.isEmpty;
    final cls     = classes.where((c) => c.id == entry.classId).firstOrNull;

    return GestureDetector(
      onTap: () => _showEditor(context),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 52,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        color: isEmpty
            ? Colors.transparent
            : kTeal.withValues(alpha: 0.12),
        child: isEmpty
            ? Center(
                child: Icon(Icons.add_rounded,
                    color: cBorder(context), size: 18))
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(entry.subject,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   11,
                          fontWeight: FontWeight.w700)),
                  if (cls != null)
                    Text(cls.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: cMuted(context), fontSize: 10)),
                ],
              ),
      ),
    );
  }

  void _showEditor(BuildContext context) {
    final subCtrl = TextEditingController(text: entry.subject);
    String? selClassId = entry.classId.isNotEmpty ? entry.classId : null;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, ss) => AlertDialog(
          backgroundColor: cCard(ctx),
          title: Text('Edit Period',
              style: TextStyle(
                  color:      cNavy(ctx),
                  fontSize:   16,
                  fontWeight: FontWeight.w800)),
          content: SizedBox(
            width: 320,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: subCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Subject',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value:       selClassId,
                  decoration:  const InputDecoration(
                    labelText: 'Class',
                    border:    OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(
                        value: null, child: Text('— None —')),
                    ...classes.map((c) => DropdownMenuItem(
                        value: c.id, child: Text(c.name))),
                  ],
                  onChanged: (v) => ss(() => selClassId = v),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                onChanged('', '');
                Navigator.pop(ctx);
              },
              child: const Text('Clear',
                  style: TextStyle(color: kError)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy,
                  foregroundColor: Colors.white,
                  elevation: 0),
              onPressed: () {
                onChanged(subCtrl.text.trim(), selClassId ?? '');
                Navigator.pop(ctx);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
