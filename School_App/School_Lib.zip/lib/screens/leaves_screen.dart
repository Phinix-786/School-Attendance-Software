// lib/screens/leaves_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class LeavesScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool   isAdmin;

  const LeavesScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
    this.isAdmin = false,
  });

  @override
  State<LeavesScreen> createState() => _LeavesScreenState();
}

class _LeavesScreenState extends State<LeavesScreen> {
  List<LeaveRequest>         _all       = [];
  List<Map<String, dynamic>> _adminSections = [];
  String?                    _selectedSecId;
  String                     _filter    = 'all';
  bool                       _loading   = true;
  Timer?                     _pollTimer;

  static const _tabs = ['all', 'pending', 'approved', 'rejected'];

  String get _effectiveSecId =>
      widget.isAdmin ? (_selectedSecId ?? '') : widget.sectionId;

  @override
  void initState() {
    super.initState();
    if (widget.isAdmin) {
      _loadAdminSections();
    } else {
      _load(widget.sectionId);
    }
    _pollTimer = Timer.periodic(
        const Duration(seconds: 30), (_) => _load(_effectiveSecId));
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadAdminSections() async {
    final secs = await SchoolFirebaseService.getSections(widget.schoolId);
    if (!mounted) return;
    setState(() {
      _adminSections = secs;
      if (secs.isNotEmpty) {
        _selectedSecId = secs.first['id'] as String;
      }
    });
    if (_selectedSecId != null) _load(_selectedSecId!);
  }

  Future<void> _load(String secId) async {
    if (secId.isEmpty) return;
    setState(() => _loading = true);
    final leaves = await SchoolFirebaseService.getLeavesForSection(
        widget.schoolId, secId);
    if (!mounted) return;
    setState(() { _all = leaves; _loading = false; });
  }

  List<LeaveRequest> get _filtered {
    if (_filter == 'all') return _all;
    return _all.where((l) => l.status == _filter).toList();
  }

  Future<void> _approve(LeaveRequest req, String remarks) async {
    await SchoolFirebaseService.updateLeaveStatus(
        widget.schoolId, _effectiveSecId, req.id, 'approved', remarks);
    _load(_effectiveSecId);
  }

  Future<void> _reject(LeaveRequest req, String remarks) async {
    await SchoolFirebaseService.updateLeaveStatus(
        widget.schoolId, _effectiveSecId, req.id, 'rejected', remarks);
    _load(_effectiveSecId);
  }

  void _showDetail(BuildContext ctx, LeaveRequest req) {
    final remarkCtrl = TextEditingController(text: req.remarks);
    showDialog(
      context: ctx,
      builder: (_) => AlertDialog(
        backgroundColor: cCard(ctx),
        title: Text(req.studentName,
            style: TextStyle(
                color:      cNavy(ctx),
                fontSize:   17,
                fontWeight: FontWeight.w800)),
        content: SizedBox(
          width: 400,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _detailRow(ctx, 'Requested Date',
                  DateFormat('dd/MM/yyyy').format(req.requestedDate)),
              _detailRow(ctx, 'Submitted By', req.submittedBy),
              _detailRow(ctx, 'Reason', req.reason),
              _detailRow(ctx, 'Status', req.status.toUpperCase()),
              const SizedBox(height: 14),
              Text('Remarks',
                  style: TextStyle(
                      color:      cNavy(ctx),
                      fontSize:   13,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              TextField(
                controller: remarkCtrl,
                maxLines:   2,
                style: TextStyle(color: cNavy(ctx), fontSize: 13),
                decoration: InputDecoration(
                  hintText:  'Add a remark (optional)…',
                  hintStyle: TextStyle(color: cMuted(ctx), fontSize: 12),
                  filled:    true,
                  fillColor: cBg(ctx),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: cBorder(ctx))),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(color: cBorder(ctx))),
                ),
              ),
            ],
          ),
        ),
        actions: req.status == 'pending'
            ? [
                TextButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _reject(req, remarkCtrl.text.trim());
                  },
                  child: const Text('Reject',
                      style: TextStyle(color: kError)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF16A34A),
                      foregroundColor: Colors.white,
                      elevation: 0),
                  onPressed: () {
                    Navigator.pop(ctx);
                    _approve(req, remarkCtrl.text.trim());
                  },
                  child: const Text('Approve'),
                ),
              ]
            : [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text('Close',
                      style: TextStyle(color: cNavy(ctx))),
                ),
              ],
      ),
    );
  }

  Widget _detailRow(BuildContext ctx, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text('$label:',
                style: TextStyle(
                    color:      cMuted(ctx),
                    fontSize:   12,
                    fontWeight: FontWeight.w600)),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(color: cNavy(ctx), fontSize: 12)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.event_note_rounded,
                    color: cNavy(context), size: 20),
                const SizedBox(width: 9),
                Text('Leave Requests',
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   19,
                        fontWeight: FontWeight.w800)),
                const Spacer(),
                IconButton(
                  icon: Icon(Icons.refresh_rounded,
                      color: cNavy(context), size: 20),
                  tooltip: 'Refresh',
                  onPressed: () => _load(_effectiveSecId),
                ),
              ],
            ),
            if (widget.isAdmin && _adminSections.isNotEmpty) ...[
              const SizedBox(height: 12),
              Row(
                children: _adminSections.map((sec) {
                  final sId  = (sec['id'] as String?) ?? '';
                  final name = (sec['name'] as String?) ?? sId;
                  final sel  = _selectedSecId == sId;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () {
                        if (_selectedSecId == sId) return;
                        setState(() { _selectedSecId = sId; });
                        _load(sId);
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: sel ? cNavy(context) : cCard(context),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: sel
                                  ? cNavy(context)
                                  : cBorder(context)),
                        ),
                        child: Text(name,
                            style: TextStyle(
                                color: sel
                                    ? Colors.white
                                    : cMuted(context),
                                fontSize:   12.5,
                                fontWeight: sel
                                    ? FontWeight.w700
                                    : FontWeight.w500)),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
            const SizedBox(height: 14),
            // Filter tabs
            Row(
              children: _tabs.map((t) {
                final sel = _filter == t;
                final count = t == 'all'
                    ? _all.length
                    : _all.where((l) => l.status == t).length;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () => setState(() => _filter = t),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(
                        color: sel ? kNavy : cCard(context),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: sel ? kNavy : cBorder(context)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            t[0].toUpperCase() + t.substring(1),
                            style: TextStyle(
                                color: sel ? Colors.white : cMuted(context),
                                fontSize:   12.5,
                                fontWeight: sel
                                    ? FontWeight.w700
                                    : FontWeight.w500),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: sel
                                  ? Colors.white.withValues(alpha: 0.2)
                                  : cBorder(context),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text('$count',
                                style: TextStyle(
                                    color: sel
                                        ? Colors.white
                                        : cMuted(context),
                                    fontSize: 10.5,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                  : _filtered.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text('📋',
                                  style: TextStyle(fontSize: 48)),
                              const SizedBox(height: 12),
                              Text('No leave requests.',
                                  style: TextStyle(
                                      color:    cMuted(context),
                                      fontSize: 15)),
                            ],
                          ),
                        )
                      : _buildTable(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTable(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color:        cNavy(context).withValues(alpha: 0.06),
              borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(13)),
            ),
            child: Row(
              children: [
                _hCell('Student', 2),
                _hCell('Requested Date', 1.5),
                _hCell('Reason', 2),
                _hCell('Submitted By', 1),
                _hCell('Status', 1),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _filtered.length,
              itemBuilder: (_, i) {
                final req = _filtered[i];
                return GestureDetector(
                  onTap: () => _showDetail(context, req),
                  child: _LeaveRow(req: req, index: i),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _hCell(String text, double flex) => Expanded(
        flex: (flex * 10).round(),
        child: Text(text,
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   12,
                fontWeight: FontWeight.w700)),
      );
}

class _LeaveRow extends StatelessWidget {
  final LeaveRequest req;
  final int          index;
  const _LeaveRow({required this.req, required this.index});

  Color _statusColor(String s) {
    switch (s) {
      case 'approved': return const Color(0xFF16A34A);
      case 'rejected': return kError;
      default:         return const Color(0xFFF59E0B);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sc   = _statusColor(req.status);
    final date = DateFormat('dd/MM/yyyy').format(req.requestedDate);
    final bg   = index.isOdd
        ? cBg(context).withValues(alpha: 0.5)
        : Colors.transparent;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: bg,
      child: Row(
        children: [
          Expanded(
            flex: 20,
            child: Text(req.studentName,
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   13,
                    fontWeight: FontWeight.w600)),
          ),
          Expanded(
            flex: 15,
            child: Text(date,
                style: TextStyle(color: cNavy(context), fontSize: 12.5)),
          ),
          Expanded(
            flex: 20,
            child: Text(req.reason,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: cBlue(context), fontSize: 12.5)),
          ),
          Expanded(
            flex: 10,
            child: Text(req.submittedBy,
                style: TextStyle(color: cMuted(context), fontSize: 12)),
          ),
          Expanded(
            flex: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color:        sc.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: sc.withValues(alpha: 0.35)),
              ),
              child: Text(req.status.toUpperCase(),
                  style: TextStyle(
                      color:      sc,
                      fontSize:   10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3)),
            ),
          ),
        ],
      ),
    );
  }
}
