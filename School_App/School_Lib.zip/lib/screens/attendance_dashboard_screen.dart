// lib/screens/attendance_dashboard_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';
import '../services/pdf_service.dart';

// ── Combined state fed to a single setState ───────────────────
class _DashData {
  final List<SchoolClass>        classes;
  final List<AttendanceSession>  sessions;
  final Map<String, String>      teacherMap; // teacherId → name
  const _DashData({
    this.classes    = const [],
    this.sessions   = const [],
    this.teacherMap = const {},
  });
}

// ─────────────────────────────────────────────────────────────
class AttendanceDashboardScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;
  final String sectionId;
  final bool isAdmin;
  final VoidCallback? onGoToClasses;

  const AttendanceDashboardScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
    this.isAdmin = false,
    this.onGoToClasses,
  });

  @override
  State<AttendanceDashboardScreen> createState() =>
      _AttendanceDashboardScreenState();
}

class _AttendanceDashboardScreenState
    extends State<AttendanceDashboardScreen> {

  // ── combined data ─────────────────────────────────────────
  _DashData _data = const _DashData();

  // ── poll timer (replaces snapshot listeners to avoid Windows crash) ─────
  Timer? _pollTimer;

  // ── Admin: sections & selected section ────────────────────
  List<Map<String, dynamic>> _adminSections = [];
  String? _selectedAdminSectionId;

  // ── raw lists (merged in _merge) ──────────────────────────
  List<SchoolClass>       _classes    = [];
  List<AttendanceSession> _sessions   = [];
  Map<String, String>     _teacherMap = {};

  // ── UI state ──────────────────────────────────────────────
  String? _selectedClassId;
  String  _searchQuery       = '';

  int     _totalPresent      = 0;
  int     _totalAbsent       = 0;
  int     _totalLate         = 0;

  // ─────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _startPolling();
  }

  void _startPolling() {
    _doRefresh();
    _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _doRefresh());
  }

  Future<void> _doRefresh() async {
    if (widget.isAdmin) {
      await _subscribeAdminSections();
    } else {
      await _fetchAll(widget.sectionId);
    }
  }

  Future<void> _subscribeAdminSections() async {
    try {
      final snap = await FirebaseFirestore.instance
          .collection('schools/${widget.schoolId}/sections')
          .get();
      final sections = snap.docs.map((d) => d.data()).toList();
      if (!mounted) return;
      setState(() {
        _adminSections = sections;
        if (_selectedAdminSectionId == null && sections.isNotEmpty) {
          _selectedAdminSectionId = sections.first['id'] as String;
        }
      });
      if (_selectedAdminSectionId != null) {
        await _fetchAll(_selectedAdminSectionId!);
      }
    } catch (e) {
      debugPrint('[_subscribeAdminSections] error: $e');
    }
  }

  void _switchAdminSection(String sectionId) {
    if (_selectedAdminSectionId == sectionId) return;
    _classes = []; _sessions = []; _teacherMap = {};
    setState(() {
      _selectedAdminSectionId = sectionId;
      _selectedClassId = null;
      _data = const _DashData();
    });
    _fetchAll(sectionId);
  }

  Future<void> _fetchAll(String sectionId) async {
    try {
      // Use Future-based (get) methods instead of snapshot streams to avoid
      // opening/cancelling Firestore real-time listeners on every poll cycle,
      // which crashes the Firebase Windows SDK.
      final results = await Future.wait([
        SchoolFirebaseService.getClasses(widget.schoolId, sectionId),
        SchoolFirebaseService.getTodaySessions(widget.schoolId, sectionId),
        SchoolFirebaseService.getAllTeachers(widget.schoolId, sectionId),
      ]);
      if (!mounted) return;
      _classes    = results[0] as List<SchoolClass>;
      _sessions   = results[1] as List<AttendanceSession>;
      final teachers = results[2] as List<Teacher>;
      _teacherMap = {for (final t in teachers) t.id: t.name};
      setState(() {
        _data = _DashData(
          classes:    _classes,
          sessions:   _sessions,
          teacherMap: _teacherMap,
        );
      });
    } catch (e) {
      debugPrint('[_fetchAll] error: $e');
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────
  void _updateTotals(List<AttendanceRecord> records) {
    int p = 0, a = 0, l = 0;
    for (final r in records) {
      if (r.status == AttendanceStatus.present)     { p++; }
      else if (r.status == AttendanceStatus.absent) { a++; }
      else if (r.status == AttendanceStatus.late)   { l++; }
    }
    if (mounted) {
      setState(() { _totalPresent = p; _totalAbsent = a; _totalLate = l; });
    }
  }

  String get _effectiveSectionId =>
      widget.isAdmin ? (_selectedAdminSectionId ?? '') : widget.sectionId;


  // ────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final today =
        DateFormat('EEEE, dd MMM yyyy').format(DateTime.now());

    final sessionMap = <String, AttendanceSession>{
      for (final s in _data.sessions) s.classId: s
    };

    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(context, today),
            if (widget.isAdmin && _adminSections.isNotEmpty) ...[
              const SizedBox(height: 14),
              _buildAdminSectionDropdown(context),
            ],
            const SizedBox(height: 18),
            Expanded(
              child: _buildMainContent(context, sessionMap),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdminSectionDropdown(BuildContext context) {
    return Row(children: [
      Icon(Icons.account_tree_rounded, color: cMuted(context), size: 15),
      const SizedBox(width: 8),
      Text('Viewing section:', style: TextStyle(color: cMuted(context), fontSize: 12.5)),
      const SizedBox(width: 10),
      ...(_adminSections.map((sec) {
        final sId   = (sec['id'] as String?) ?? '';
        final sName = sec['name'] as String? ?? sId;
        final sel   = _selectedAdminSectionId == sId;
        return Padding(
          padding: const EdgeInsets.only(right: 8),
          child: GestureDetector(
            onTap: () => _switchAdminSection(sId),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: sel ? cNavy(context) : cCard(context),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: sel ? cNavy(context) : cBorder(context)),
              ),
              child: Text(sName,
                  style: TextStyle(
                    color: sel ? Colors.white : cMuted(context),
                    fontSize: 12.5,
                    fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                  )),
            ),
          ),
        );
      })),
    ]);
  }

  // ── HEADER ───────────────────────────────────────────────
  Widget _buildHeader(BuildContext context, String today) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(Icons.fact_check_rounded,
                  color: cNavy(context), size: 20),
              const SizedBox(width: 9),
              Text(
                'Attendance Management',
                style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   19,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ]),
            const SizedBox(height: 3),
            Padding(
              padding: const EdgeInsets.only(left: 29),
              child: Text(
                'Live class status — $today',
                style: TextStyle(
                  color:    cMuted(context).withValues(alpha: 0.75),
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        const Spacer(),

        if (widget.onGoToClasses != null) ...[
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: cNavy(context),
              side: BorderSide(color: cBorder(context), width: 1.5),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 11),
            ),
            icon: Icon(Icons.class_rounded,
                size: 15, color: cNavy(context)),
            label: Text(
              'Manage Classes',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize:   12.5,
                color:      cNavy(context),
              ),
            ),
            onPressed: widget.onGoToClasses,
          ),
          const SizedBox(width: 10),
        ],

        if (_selectedClassId != null) ...[
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: cNavy(context),
              side: BorderSide(color: cBorder(context), width: 1.5),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 11),
            ),
            icon: Icon(Icons.picture_as_pdf_rounded,
                size: 15, color: cNavy(context)),
            label: Text('Export PDF',
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize:   12.5,
                    color:      cNavy(context))),
            onPressed: () => _exportPdf(context),
          ),
        ],
      ],
    );
  }

  Future<void> _exportPdf(BuildContext context) async {
    final classId = _selectedClassId!;
    final secId   = _effectiveSectionId;
    if (secId.isEmpty) return;

    final cls = _data.classes.firstWhere(
        (c) => c.id == classId,
        orElse: () => SchoolClass(
            id: classId, schoolId: widget.schoolId,
            name: classId, grade: '', section: ''));

    // -- Step 1: ask scope (entire class or one student) --
    final scope = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(ctx),
        title: Text('Attendance PDF',
            style: TextStyle(
                color:      cNavy(ctx),
                fontSize:   16,
                fontWeight: FontWeight.w800)),
        content: Text('Generate report for the entire class or a specific student?',
            style: TextStyle(color: cMuted(ctx), fontSize: 13)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, 'class'),
              child: Text('Entire Class',
                  style: TextStyle(
                      color: cNavy(ctx), fontWeight: FontWeight.w700))),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy,
                  foregroundColor: Colors.white,
                  elevation: 0),
              onPressed: () => Navigator.pop(ctx, 'student'),
              child: const Text('Specific Student')),
        ],
      ),
    );
    if (scope == null || !context.mounted) return;

    // -- Step 2: if student, pick which one --
    Student? targetStudent;
    if (scope == 'student') {
      final students = await SchoolFirebaseService.getStudentsByClass(
          widget.schoolId, secId, classId);
      if (!context.mounted) return;
      targetStudent = await showDialog<Student>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: cCard(ctx),
          title: Text('Select Student',
              style: TextStyle(
                  color:      cNavy(ctx),
                  fontSize:   16,
                  fontWeight: FontWeight.w800)),
          content: SizedBox(
            width: 320,
            height: 360,
            child: ListView.separated(
              itemCount: students.length,
              separatorBuilder: (_, __) =>
                  Divider(height: 1, color: cBorder(ctx)),
              itemBuilder: (_, i) {
                final s = students[i];
                return ListTile(
                  title: Text(s.name,
                      style: TextStyle(
                          color:      cNavy(ctx),
                          fontSize:   13,
                          fontWeight: FontWeight.w600)),
                  subtitle: Text('Roll: ${s.rollNo}',
                      style: TextStyle(
                          color: cMuted(ctx), fontSize: 11)),
                  onTap: () => Navigator.pop(ctx, s),
                );
              },
            ),
          ),
        ),
      );
      if (targetStudent == null || !context.mounted) return;
    }

    // -- Step 3: date range picker --
    final now         = DateTime.now();
    DateTime startDate = now.subtract(const Duration(days: 30));
    DateTime endDate   = now;

    final range = await showDialog<List<DateTime>>(
      context: context,
      builder: (ctx) {
        DateTime tmpStart = startDate;
        DateTime tmpEnd   = endDate;
        return StatefulBuilder(
          builder: (ctx, ss) => AlertDialog(
            backgroundColor: cCard(ctx),
            title: Text('Select Date Range',
                style: TextStyle(
                    color:      cNavy(ctx),
                    fontSize:   16,
                    fontWeight: FontWeight.w800)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.calendar_today_outlined,
                      color: cNavy(ctx), size: 18),
                  title: Text('From: ${tmpStart.day}/${tmpStart.month}/${tmpStart.year}',
                      style: TextStyle(
                          color: cNavy(ctx), fontWeight: FontWeight.w600)),
                  trailing: Icon(Icons.edit_calendar_outlined,
                      color: cMuted(ctx), size: 16),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: tmpStart,
                      firstDate: DateTime(2020),
                      lastDate: tmpEnd,
                    );
                    if (d != null) ss(() => tmpStart = d);
                  },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.calendar_today_outlined,
                      color: cNavy(ctx), size: 18),
                  title: Text('To: ${tmpEnd.day}/${tmpEnd.month}/${tmpEnd.year}',
                      style: TextStyle(
                          color: cNavy(ctx), fontWeight: FontWeight.w600)),
                  trailing: Icon(Icons.edit_calendar_outlined,
                      color: cMuted(ctx), size: 16),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: tmpEnd,
                      firstDate: tmpStart,
                      lastDate: DateTime.now(),
                    );
                    if (d != null) ss(() => tmpEnd = d);
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: Text('Cancel',
                      style: TextStyle(color: cMuted(ctx)))),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: kNavy,
                      foregroundColor: Colors.white,
                      elevation: 0),
                  onPressed: () =>
                      Navigator.pop(ctx, [tmpStart, tmpEnd]),
                  child: const Text('Generate')),
            ],
          ),
        );
      },
    );
    if (range == null || !context.mounted) return;
    startDate = range[0];
    endDate   = range[1];

    // -- Step 4: generate and save --
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Generating PDF…'),
          duration: Duration(seconds: 2)));

    try {
      final allStudents = await SchoolFirebaseService.getStudentsByClass(
          widget.schoolId, secId, classId);
      final rows = await SchoolFirebaseService.getAttendanceForDateRange(
          widget.schoolId, secId, classId, startDate, endDate);

      // Filter to specific student if needed
      final filteredRows = targetStudent != null
          ? rows.where((r) => r.studentId == targetStudent!.id).toList()
          : rows;
      final filteredStudents = targetStudent != null
          ? allStudents
              .where((s) => s.id == targetStudent!.id)
              .toList()
          : allStudents;

      final bytes = await PdfService.generateAttendanceReport(
        schoolName:  widget.schoolName,
        sectionId:   secId,
        className:   cls.name,
        startDate:   startDate,
        endDate:     endDate,
        students:    filteredStudents,
        rows:        filteredRows,
        studentMap:  {for (final s in allStudents) s.id: s.name},
      );

      final suffix = targetStudent != null
          ? targetStudent.name.replaceAll(' ', '_')
          : cls.name.replaceAll(' ', '_');
      final filename =
          'attendance_${suffix}_${startDate.day}-${startDate.month}'
          '_to_${endDate.day}-${endDate.month}.pdf';

      final savedPath = await PdfService.saveToFile(bytes, filename);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(savedPath != null
              ? 'PDF saved to: $savedPath'
              : 'Failed to save PDF.'),
          backgroundColor: savedPath != null
              ? const Color(0xFF16A34A)
              : kError,
        ));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Export failed: $e'),
              backgroundColor: kError));
      }
    }
  }

  // ── MAIN CONTENT ─────────────────────────────────────────
  Widget _buildMainContent(
    BuildContext context,
    Map<String, AttendanceSession> sessionMap,
  ) {
    return Column(
      children: [
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildClassList(context, sessionMap),
              const SizedBox(width: 14),
              Expanded(child: _buildDetailPanel(context, sessionMap)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _buildSummaryBar(context),
      ],
    );
  }

  // ── LEFT PANEL ────────────────────────────────────────────
  Widget _buildClassList(
    BuildContext context,
    Map<String, AttendanceSession> sessionMap,
  ) {
    final classes = _data.classes;

    return Container(
      width: 270,
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 10,
            offset:     const Offset(0, 3),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 13, 16, 9),
            child: Row(
              children: [
                Icon(Icons.class_rounded,
                    size:  13,
                    color: cMuted(context).withValues(alpha: 0.6)),
                const SizedBox(width: 7),
                Text(
                  'CLASSES',
                  style: TextStyle(
                    color:         cMuted(context).withValues(alpha: 0.7),
                    fontSize:      10.5,
                    fontWeight:    FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
                const Spacer(),
                if (widget.onGoToClasses != null)
                  Tooltip(
                    message: 'Manage Classes',
                    child: InkWell(
                      borderRadius: BorderRadius.circular(6),
                      onTap:        widget.onGoToClasses,
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Icon(
                          Icons.open_in_new_rounded,
                          size:  13,
                          color: cMuted(context).withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: classes.isEmpty
                ? _EmptyClasses(onGoToClasses: widget.onGoToClasses)
                : ListView.separated(
                    padding:
                        const EdgeInsets.symmetric(vertical: 4),
                    itemCount: classes.length,
                    separatorBuilder: (_, __) =>
                        Divider(height: 1, color: cBorder(context)),
                    itemBuilder: (_, i) {
                      final c          = classes[i];
                      final session    = sessionMap[c.id];
                      final isSelected = _selectedClassId == c.id;

                      Color  dotColor;
                      String statusText;
                      if (session == null) {
                        dotColor   = kError;
                        statusText = 'Not Started';
                      } else if (session.isSubmitted) {
                        dotColor   = const Color(0xFF16A34A);
                        statusText = 'Submitted';
                      } else {
                        dotColor   = const Color(0xFFD97706);
                        statusText = 'In Progress';
                      }

                      final teacherName = session != null
                          ? (_data.teacherMap[session.teacherId] ?? '')
                          : '';

                      return InkWell(
                        onTap: () => setState(() {
                          _selectedClassId = c.id;
                          _searchQuery     = '';
                        }),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          color: isSelected
                              ? cNavy(context).withValues(alpha: 0.05)
                              : Colors.transparent,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 11),
                          child: Row(
                            children: [
                              Container(
                                width:  8,
                                height: 8,
                                decoration: BoxDecoration(
                                    color:  dotColor,
                                    shape:  BoxShape.circle),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      c.name,
                                      style: TextStyle(
                                        color:      cNavy(context),
                                        fontSize:   13,
                                        fontWeight: isSelected
                                            ? FontWeight.w700
                                            : FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 1),
                                    Text(
                                      teacherName.isNotEmpty
                                          ? '$teacherName · $statusText'
                                          : statusText,
                                      style: TextStyle(
                                        color: cMuted(context)
                                            .withValues(alpha: 0.65),
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (isSelected)
                                Icon(
                                  Icons.chevron_right_rounded,
                                  color: cNavy(context)
                                      .withValues(alpha: 0.35),
                                  size: 16,
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // ── RIGHT PANEL ───────────────────────────────────────────
  Widget _buildDetailPanel(
    BuildContext context,
    Map<String, AttendanceSession> sessionMap,
  ) {
    if (_selectedClassId == null) {
      return Container(
        decoration: BoxDecoration(
          color:        cCard(context),
          borderRadius: BorderRadius.circular(14),
          border:       Border.all(color: cBorder(context)),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.touch_app_rounded,
                  color: cMuted(context).withValues(alpha: 0.3),
                  size:  44),
              const SizedBox(height: 12),
              Text(
                'Select a class to view attendance',
                style: TextStyle(
                    color:    cMuted(context).withValues(alpha: 0.55),
                    fontSize: 13.5),
              ),
            ],
          ),
        ),
      );
    }

    final classes = _data.classes;
    if (classes.isEmpty) return const SizedBox.shrink();

    final selectedClass = classes.firstWhere(
      (c) => c.id == _selectedClassId,
      orElse: () => classes.first,
    );
    final session = sessionMap[_selectedClassId];

    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 10,
            offset:     const Offset(0, 3),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 13, 18, 11),
            child: Row(
              children: [
                Text(
                  selectedClass.name,
                  style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   15.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(width: 10),
                _StudentCountBadge(schoolId: widget.schoolId, sectionId: _effectiveSectionId, classId:   _selectedClassId!),
                const Spacer(),
                _QuickCountRow(
                  present: _totalPresent,
                  absent:  _totalAbsent,
                  late:    _totalLate,
                ),
              ],
            ),
          ),
          Divider(height: 1, color: cBorder(context)),

          Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 10),
            child: TextField(
              onChanged: (v) => setState(() => _searchQuery = v),
              style: TextStyle(fontSize: 13, color: cNavy(context)),
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search_rounded,
                    color: cMuted(context).withValues(alpha: 0.45),
                    size:  17),
                hintText:  'Search student...',
                hintStyle: TextStyle(
                    color:    cMuted(context).withValues(alpha: 0.45),
                    fontSize: 13),
                filled:    true,
                fillColor: cBg(context),
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 9),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(9),
                    borderSide:
                        BorderSide(color: cBorder(context))),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(9),
                    borderSide:
                        BorderSide(color: cBorder(context))),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(9),
                    borderSide: BorderSide(
                        color: cNavy(context), width: 1.5)),
              ),
            ),
          ),

          Expanded(
            child: session == null
                ? const _NotStartedState()
                : _StudentAttendanceList(schoolId: widget.schoolId, sectionId: _effectiveSectionId, classId:          _selectedClassId!,
                    sessionId:        session.id,
                    searchQuery:      _searchQuery,
                    isSubmitted:      session.isSubmitted,
                    onRecordsChanged: _updateTotals,
                  ),
          ),
        ],
      ),
    );
  }

  // ── SUMMARY BAR ───────────────────────────────────────────
  Widget _buildSummaryBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Row(
        children: [
          Icon(Icons.bar_chart_rounded,
              color: cNavy(context), size: 15),
          const SizedBox(width: 8),
          Text(
            'Attendance Summary — Today',
            style: TextStyle(
              color:      cNavy(context),
              fontSize:   12.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(width: 20),
          _SummaryChip(
            icon:  Icons.check_box_rounded,
            label: 'Present',
            count: _totalPresent,
            color: const Color(0xFF16A34A),
            bg:    const Color(0xFFDCFCE7),
          ),
          const SizedBox(width: 10),
          _SummaryChip(
            icon:  Icons.close_rounded,
            label: 'Absent',
            count: _totalAbsent,
            color: kError,
            bg:    const Color(0xFFFFEDF2),
          ),
          const SizedBox(width: 10),
          _SummaryChip(
            icon:  Icons.watch_later_rounded,
            label: 'Late',
            count: _totalLate,
            color: const Color(0xFFD97706),
            bg:    const Color(0xFFFEF3C7),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
class _StudentCountBadge extends StatelessWidget {
  final String schoolId;
  final String sectionId;
  final String classId;
  const _StudentCountBadge({required this.schoolId, required this.sectionId, required this.classId});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Student>>(
      future: SchoolFirebaseService.getStudentsByClass(schoolId, sectionId, classId),
      builder: (_, snap) {
        final count = snap.data?.length ?? 0;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
          decoration: BoxDecoration(
            color:        cNavy(context).withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '$count student${count == 1 ? '' : 's'}',
            style: TextStyle(
              color:      cNavy(context).withValues(alpha: 0.6),
              fontSize:   11,
              fontWeight: FontWeight.w600,
            ),
          ),
        );
      },
    );
  }
}

class _QuickCountRow extends StatelessWidget {
  final int present, absent, late;
  const _QuickCountRow(
      {required this.present, required this.absent, required this.late});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _chip(Icons.check_box_rounded,  '$present',
            const Color(0xFF16A34A), const Color(0xFFDCFCE7), context),
        const SizedBox(width: 5),
        _chip(Icons.close_rounded,       '$absent',
            kError,                 const Color(0xFFFFEDF2), context),
        const SizedBox(width: 5),
        _chip(Icons.watch_later_rounded, '$late',
            const Color(0xFFD97706), const Color(0xFFFEF3C7), context),
      ],
    );
  }

  Widget _chip(IconData icon, String val, Color color, Color bg,
      BuildContext ctx) =>
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration:
            BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 12),
            const SizedBox(width: 4),
            Text(val,
                style: TextStyle(
                    color:      color,
                    fontSize:   12,
                    fontWeight: FontWeight.w700)),
          ],
        ),
      );
}

class _StudentAttendanceList extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final String classId;
  final String sessionId;
  final String searchQuery;
  final bool   isSubmitted;
  final void Function(List<AttendanceRecord>) onRecordsChanged;

  const _StudentAttendanceList({
    required this.schoolId,
    required this.sectionId,
    required this.classId,
    required this.sessionId,
    required this.searchQuery,
    required this.isSubmitted,
    required this.onRecordsChanged,
  });

  @override
  State<_StudentAttendanceList> createState() =>
      _StudentAttendanceListState();
}

class _StudentAttendanceListState extends State<_StudentAttendanceList> {
  Map<String, AttendanceStatus> _statusMap = {};
  List<Student> _students = [];
  bool _loading = true;
  @override
  void initState() {
    super.initState();
    _loadRecords();
    _loadStudents();
  }

  @override
  void didUpdateWidget(_StudentAttendanceList old) {
    super.didUpdateWidget(old);
    if (old.sessionId  != widget.sessionId  ||
        old.classId    != widget.classId    ||
        old.sectionId  != widget.sectionId) {
      _loadRecords();
      _loadStudents();
    }
  }

  Future<void> _loadStudents() async {
    try {
      final list = await SchoolFirebaseService.getStudentsByClass(
          widget.schoolId, widget.sectionId, widget.classId);
      if (mounted) setState(() => _students = list);
    } catch (e) {
      debugPrint('[_StudentAttendanceList] loadStudents error: $e');
    }
  }

  Future<void> _loadRecords() async {
    if (mounted) setState(() => _loading = true);
    try {
      final records = await SchoolFirebaseService.getSessionRecords(
          widget.schoolId, widget.sectionId, widget.sessionId);
      final map = {for (final r in records) r.studentId: r.status};
      if (mounted) {
        setState(() { _statusMap = map; _loading = false; });
        widget.onRecordsChanged(records);
      }
    } catch (e) {
      debugPrint('[_loadRecords] error: $e');
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Center(
          child: CircularProgressIndicator(
              color: cNavy(context), strokeWidth: 2));
    }

    final q = widget.searchQuery.toLowerCase();
    final students = q.isEmpty
        ? _students
        : _students
            .where((s) =>
                s.name.toLowerCase().contains(q) ||
                s.rollNo.toLowerCase().contains(q))
            .toList();

    if (students.isEmpty) {
      return Center(
        child: Text(
          q.isEmpty ? 'No students in this class' : 'No match found',
          style: TextStyle(color: cMuted(context), fontSize: 13),
        ),
      );
    }

    return ListView.separated(
      padding:          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      itemCount:        students.length,
      separatorBuilder: (_, __) => Divider(height: 1, color: cBorder(context)),
      itemBuilder: (_, i) {
        final student = students[i];
        final status  = _statusMap[student.id] ?? AttendanceStatus.present;

        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 9),
          child: Row(
            children: [
              Container(
                width:  34,
                height: 34,
                decoration: BoxDecoration(
                  color:        cNavy(context).withValues(alpha: 0.07),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Center(
                  child: Text(
                    student.name[0].toUpperCase(),
                    style: TextStyle(
                      color:      cNavy(context).withValues(alpha: 0.65),
                      fontWeight: FontWeight.w800,
                      fontSize:   14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(student.name,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   13,
                            fontWeight: FontWeight.w600)),
                    Text(student.rollNo,
                        style: TextStyle(
                            color: cMuted(context).withValues(alpha: 0.65),
                            fontSize: 11.5)),
                  ],
                ),
              ),
              _PalButtons(
                current:  status,
                readOnly: widget.isSubmitted,
                onChanged: widget.isSubmitted
                    ? null
                    : (s) {
                        setState(() => _statusMap[student.id] = s);
                        final updated = _students
                            .map((st) => AttendanceRecord(
                                  studentId: st.id,
                                  sessionId: widget.sessionId,
                                  status: _statusMap[st.id] ??
                                      AttendanceStatus.present,
                                ))
                            .toList();
                        widget.onRecordsChanged(updated);
                      },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PalButtons extends StatelessWidget {
  final AttendanceStatus current;
  final bool readOnly;
  final void Function(AttendanceStatus)? onChanged;

  const _PalButtons(
      {required this.current, required this.readOnly, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _btn(context, AttendanceStatus.present, 'P',
            const Color(0xFF16A34A), const Color(0xFFDCFCE7)),
        const SizedBox(width: 5),
        _btn(context, AttendanceStatus.absent, 'A',
            kError, const Color(0xFFFFEDF2)),
        const SizedBox(width: 5),
        _btn(context, AttendanceStatus.late, 'L',
            const Color(0xFFD97706), const Color(0xFFFEF3C7)),
      ],
    );
  }

  Widget _btn(BuildContext context, AttendanceStatus s, String label,
      Color active, Color bg) {
    final selected = current == s;
    return GestureDetector(
      onTap: readOnly ? null : () => onChanged?.call(s),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width:  32,
        height: 28,
        decoration: BoxDecoration(
          color:        selected ? bg : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected
                ? active.withValues(alpha: 0.55)
                : cBorder(context),
            width: 1.5,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected
                  ? active
                  : cMuted(context).withValues(alpha: 0.45),
              fontSize:   11.5,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ),
    );
  }
}

class _EmptyClasses extends StatelessWidget {
  final VoidCallback? onGoToClasses;
  const _EmptyClasses({this.onGoToClasses});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.class_outlined,
              size:  36,
              color: cMuted(context).withValues(alpha: 0.3)),
          const SizedBox(height: 10),
          Text('No classes yet',
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   13,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('Create classes first to take attendance.',
              style: TextStyle(color: cMuted(context), fontSize: 12),
              textAlign: TextAlign.center),
          if (onGoToClasses != null) ...[
            const SizedBox(height: 14),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: cNavy(context),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(9)),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
              ),
              icon:  const Icon(Icons.add_rounded, size: 15),
              label: const Text('Manage Classes',
                  style: TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 12.5)),
              onPressed: onGoToClasses,
            ),
          ],
        ],
      ),
    );
  }
}

class _NotStartedState extends StatelessWidget {
  const _NotStartedState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.hourglass_top_rounded,
              color: cMuted(context).withValues(alpha: 0.3), size: 38),
          const SizedBox(height: 10),
          Text('Attendance not started yet',
              style: TextStyle(
                  color:    cMuted(context).withValues(alpha: 0.6),
                  fontSize: 13)),
          const SizedBox(height: 3),
          Text('Waiting for the teacher to begin',
              style: TextStyle(
                  color:    cMuted(context).withValues(alpha: 0.4),
                  fontSize: 12)),
        ],
      ),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final IconData icon;
  final String   label;
  final int      count;
  final Color    color;
  final Color    bg;

  const _SummaryChip({
    required this.icon,
    required this.label,
    required this.count,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
          color: bg, borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 5),
          Text(label,
              style: TextStyle(
                  color:      color,
                  fontSize:   12,
                  fontWeight: FontWeight.w600)),
          const SizedBox(width: 5),
          Text('$count',
              style: TextStyle(
                  color:      color,
                  fontSize:   14,
                  fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}