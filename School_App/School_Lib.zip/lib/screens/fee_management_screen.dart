// lib/screens/fee_management_screen.dart
// Per-student fee records. Desktop two-panel layout.
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class FeeManagementScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool isAdmin;

  const FeeManagementScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
    required this.isAdmin,
  });

  @override
  State<FeeManagementScreen> createState() => _FeeManagementScreenState();
}

class _FeeManagementScreenState extends State<FeeManagementScreen> {
  List<SchoolClass> _classes = [];
  SchoolClass? _selectedClass;
  List<Student> _students = [];
  Student? _selectedStudent;
  List<FeeRecord> _feeRecords = [];

  bool _loadingClasses = true;
  bool _loadingStudents = false;
  bool _loadingFees = false;

  @override
  void initState() {
    super.initState();
    _loadClasses();
  }

  Future<void> _loadClasses() async {
    final classes = await SchoolFirebaseService.getClasses(
        widget.schoolId, widget.sectionId);
    if (mounted) {
      setState(() {
        _classes = classes;
        _loadingClasses = false;
      });
    }
  }

  Future<void> _selectClass(SchoolClass c) async {
    setState(() {
      _selectedClass = c;
      _selectedStudent = null;
      _feeRecords = [];
      _students = [];
      _loadingStudents = true;
    });
    final students = await SchoolFirebaseService.getStudentsByClass(
        widget.schoolId, widget.sectionId, c.id);
    if (mounted) {
      setState(() {
        _students = students;
        _loadingStudents = false;
      });
    }
  }

  Future<void> _selectStudent(Student s) async {
    setState(() {
      _selectedStudent = s;
      _loadingFees = true;
      _feeRecords = [];
    });
    final fees = await SchoolFirebaseService.getFeeRecordsForStudent(
        widget.schoolId, widget.sectionId, s.id);
    if (mounted) {
      setState(() {
        _feeRecords = fees;
        _loadingFees = false;
      });
    }
  }

  Future<void> _refreshFees() async {
    if (_selectedStudent == null) return;
    setState(() => _loadingFees = true);
    final fees = await SchoolFirebaseService.getFeeRecordsForStudent(
        widget.schoolId, widget.sectionId, _selectedStudent!.id);
    if (mounted) {
      setState(() {
        _feeRecords = fees;
        _loadingFees = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Column(
        children: [
          // Header
          Container(
            color: cCard(context),
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Fee Management',
                    style: TextStyle(
                        color: cNavy(context),
                        fontSize: 22,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('Track per-student fee records and payment status.',
                    style: TextStyle(
                        color: cMuted(context), fontSize: 13)),
              ],
            ),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: Row(
              children: [
                // Class sidebar
                _buildClassSidebar(),
                VerticalDivider(width: 1, color: cBorder(context)),
                // Student sidebar
                _buildStudentSidebar(),
                VerticalDivider(width: 1, color: cBorder(context)),
                // Fee records panel
                Expanded(child: _buildFeePanel()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClassSidebar() {
    return Container(
      width: 180,
      color: cCard(context),
      child: _loadingClasses
          ? const Center(child: CircularProgressIndicator())
          : _classes.isEmpty
              ? Center(
                  child: Text('No classes',
                      style: TextStyle(color: cMuted(context))))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  itemCount: _classes.length,
                  itemBuilder: (_, i) {
                    final c = _classes[i];
                    final sel = _selectedClass?.id == c.id;
                    return ListTile(
                      dense: true,
                      selected: sel,
                      selectedTileColor:
                          cNavy(context).withValues(alpha: 0.07),
                      leading: Icon(Icons.class_rounded,
                          color: sel
                              ? cNavy(context)
                              : cMuted(context).withValues(alpha: 0.5),
                          size: 16),
                      title: Text(c.name,
                          style: TextStyle(
                              color: cNavy(context),
                              fontSize: 13,
                              fontWeight:
                                  sel ? FontWeight.w700 : FontWeight.w500),
                          overflow: TextOverflow.ellipsis),
                      onTap: () => _selectClass(c),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    );
                  },
                ),
    );
  }

  Widget _buildStudentSidebar() {
    return Container(
      width: 200,
      color: cCard(context),
      child: _selectedClass == null
          ? Center(
              child: Text('Select a class',
                  style: TextStyle(color: cMuted(context), fontSize: 12)))
          : _loadingStudents
              ? const Center(child: CircularProgressIndicator())
              : _students.isEmpty
                  ? Center(
                      child: Text('No students',
                          style: TextStyle(color: cMuted(context))))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      itemCount: _students.length,
                      itemBuilder: (_, i) {
                        final s = _students[i];
                        final sel = _selectedStudent?.id == s.id;
                        return ListTile(
                          dense: true,
                          selected: sel,
                          selectedTileColor:
                              cNavy(context).withValues(alpha: 0.07),
                          title: Text(s.name,
                              style: TextStyle(
                                  color: cNavy(context),
                                  fontSize: 12.5,
                                  fontWeight: sel
                                      ? FontWeight.w700
                                      : FontWeight.w500),
                              overflow: TextOverflow.ellipsis),
                          subtitle: Text('Roll: ${s.rollNo}',
                              style: TextStyle(
                                  color: cMuted(context), fontSize: 10.5)),
                          onTap: () => _selectStudent(s),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                        );
                      },
                    ),
    );
  }

  Widget _buildFeePanel() {
    if (_selectedStudent == null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.account_balance_wallet_outlined,
              color: cMuted(context).withValues(alpha: 0.4), size: 48),
          const SizedBox(height: 12),
          Text('Select a student to view fee records',
              style: TextStyle(color: cMuted(context), fontSize: 14)),
        ]),
      );
    }

    // Calculate summary
    final totalAmount =
        _feeRecords.fold<double>(0, (s, r) => s + r.amount);
    final totalPaid =
        _feeRecords.fold<double>(0, (s, r) => s + r.paid);
    final outstanding = totalAmount - totalPaid;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Panel header
        Container(
          color: cCard(context),
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
          child: Row(children: [
            Expanded(
              child: Text('${_selectedStudent!.name} — Fees',
                  style: TextStyle(
                      color: cNavy(context),
                      fontSize: 15,
                      fontWeight: FontWeight.w700)),
            ),
            ElevatedButton.icon(
              icon: const Icon(Icons.add_rounded, size: 16),
              label: const Text('Add Fee Entry'),
              style: ElevatedButton.styleFrom(
                backgroundColor: kNavy.withValues(alpha: 0.88),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 10),
              ),
              onPressed: () => _showAddFeeDialog(),
            ),
          ]),
        ),
        Divider(height: 1, color: cBorder(context)),

        // Summary row
        if (_feeRecords.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(children: [
              _summaryChip('Total Billed',
                  'Rs ${totalAmount.toStringAsFixed(0)}', kNavy),
              const SizedBox(width: 12),
              _summaryChip('Total Paid',
                  'Rs ${totalPaid.toStringAsFixed(0)}', Colors.green),
              const SizedBox(width: 12),
              _summaryChip('Outstanding',
                  'Rs ${outstanding.toStringAsFixed(0)}',
                  outstanding > 0 ? kError : Colors.green),
            ]),
          ),

        Expanded(
          child: _loadingFees
              ? const Center(child: CircularProgressIndicator())
              : _feeRecords.isEmpty
                  ? Center(
                      child: Text('No fee records for this student.',
                          style: TextStyle(color: cMuted(context))))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: _feeRecords.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 10),
                      itemBuilder: (_, i) => _FeeTile(
                        record: _feeRecords[i],
                        onUpdateStatus: _updateStatus,
                        onDelete: _deleteRecord,
                      ),
                    ),
        ),
      ],
    );
  }

  Widget _summaryChip(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(children: [
        Text(value,
            style: TextStyle(
                color: color, fontSize: 16, fontWeight: FontWeight.w800)),
        Text(label,
            style: TextStyle(
                color: cMuted(context), fontSize: 11.5)),
      ]),
    );
  }

  Future<void> _showAddFeeDialog() async {
    if (_selectedStudent == null) return;
    final result = await showDialog<FeeRecord>(
      context: context,
      builder: (ctx) => _AddFeeDialog(
        studentId: _selectedStudent!.id,
        studentName: _selectedStudent!.name,
        classId: _selectedStudent!.classId,
      ),
    );
    if (result == null) return;
    await SchoolFirebaseService.addFeeRecord(
        widget.schoolId, widget.sectionId, result);
    await _refreshFees();
  }

  Future<void> _updateStatus(FeeRecord record, String newStatus) async {
    final updated = FeeRecord(
      id: record.id,
      studentId: record.studentId,
      studentName: record.studentName,
      classId: record.classId,
      amount: record.amount,
      paid: newStatus == 'paid'
          ? record.amount
          : newStatus == 'pending'
              ? 0
              : record.paid,
      month: record.month,
      status: newStatus,
      paidAt: newStatus == 'paid' ? DateTime.now() : record.paidAt,
      notes: record.notes,
    );
    await SchoolFirebaseService.updateFeeRecord(
        widget.schoolId, widget.sectionId, updated);
    await _refreshFees();
  }

  Future<void> _deleteRecord(FeeRecord record) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(context),
        title: const Text('Delete Fee Record',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Text(
            'Delete fee record for ${record.month}? This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: kError, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (result != true) return;
    await SchoolFirebaseService.deleteFeeRecord(
        widget.schoolId, widget.sectionId, record.id);
    await _refreshFees();
  }
}

// ── Fee tile ─────────────────────────────────────────────────

class _FeeTile extends StatelessWidget {
  final FeeRecord record;
  final Future<void> Function(FeeRecord, String) onUpdateStatus;
  final Future<void> Function(FeeRecord) onDelete;

  const _FeeTile({
    required this.record,
    required this.onUpdateStatus,
    required this.onDelete,
  });

  static const Map<String, Color> _statusColors = {
    'paid': Colors.green,
    'partial': Colors.orange,
    'pending': kError,
  };

  @override
  Widget build(BuildContext context) {
    final statusColor = _statusColors[record.status] ?? kMuted;
    final outstanding = record.amount - record.paid;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Text(record.month,
                style: TextStyle(
                    color: cNavy(context),
                    fontSize: 14,
                    fontWeight: FontWeight.w700)),
            const SizedBox(width: 10),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                record.status[0].toUpperCase() +
                    record.status.substring(1),
                style: TextStyle(
                    color: statusColor,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700),
              ),
            ),
            const Spacer(),
            // Status actions
            _statusButton(context, 'Paid', 'paid', statusColor),
            const SizedBox(width: 6),
            _statusButton(context, 'Partial', 'partial', statusColor),
            const SizedBox(width: 6),
            _statusButton(context, 'Pending', 'pending', statusColor),
            const SizedBox(width: 8),
            IconButton(
              icon:
                  Icon(Icons.delete_outline_rounded, color: kError, size: 16),
              onPressed: () => onDelete(record),
              tooltip: 'Delete',
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
            ),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            _amountChip('Billed',
                'Rs ${record.amount.toStringAsFixed(0)}', cNavy(context)),
            const SizedBox(width: 10),
            _amountChip(
                'Paid', 'Rs ${record.paid.toStringAsFixed(0)}', Colors.green),
            const SizedBox(width: 10),
            if (outstanding > 0)
              _amountChip('Due',
                  'Rs ${outstanding.toStringAsFixed(0)}', kError),
            if (record.paidAt != null) ...[
              const SizedBox(width: 10),
              Text(
                'Paid: ${DateFormat('dd MMM yyyy').format(record.paidAt!)}',
                style: TextStyle(color: cMuted(context), fontSize: 11.5),
              ),
            ],
          ]),
          if (record.notes.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text('Note: ${record.notes}',
                style: TextStyle(color: cMuted(context), fontSize: 11.5)),
          ],
        ],
      ),
    );
  }

  Widget _statusButton(BuildContext context, String label, String status,
      Color currentColor) {
    final active = record.status == status;
    return GestureDetector(
      onTap: active ? null : () => onUpdateStatus(record, status),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: active
              ? (_statusColors[status] ?? kMuted).withValues(alpha: 0.15)
              : cBg(context),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: active
                ? (_statusColors[status] ?? kMuted).withValues(alpha: 0.4)
                : cBorder(context),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active
                ? (_statusColors[status] ?? kMuted)
                : cMuted(context),
            fontSize: 11,
            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _amountChip(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(color: kMuted, fontSize: 10, fontWeight: FontWeight.w600)),
        Text(value,
            style: TextStyle(
                color: color, fontSize: 13, fontWeight: FontWeight.w700)),
      ],
    );
  }
}

// ── Add Fee Dialog ────────────────────────────────────────────

class _AddFeeDialog extends StatefulWidget {
  final String studentId;
  final String studentName;
  final String classId;

  const _AddFeeDialog({
    required this.studentId,
    required this.studentName,
    required this.classId,
  });

  @override
  State<_AddFeeDialog> createState() => _AddFeeDialogState();
}

class _AddFeeDialogState extends State<_AddFeeDialog> {
  final _amountCtrl = TextEditingController();
  final _paidCtrl = TextEditingController(text: '0');
  final _notesCtrl = TextEditingController();
  String _status = 'pending';
  late String _month;

  @override
  void initState() {
    super.initState();
    _month = DateFormat('yyyy-MM').format(DateTime.now());
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _paidCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: cCard(context),
      title: Row(children: [
        Icon(Icons.add_circle_outline_rounded,
            color: kNavy, size: 20),
        const SizedBox(width: 8),
        Text('Add Fee Entry',
            style: TextStyle(
                color: cNavy(context), fontWeight: FontWeight.w800)),
      ]),
      content: SizedBox(
        width: 360,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Student: ${widget.studentName}',
                style: TextStyle(
                    color: cNavy(context), fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            _label(context, 'Month (YYYY-MM)'),
            const SizedBox(height: 6),
            TextField(
              controller: TextEditingController(text: _month),
              style: TextStyle(color: cNavy(context)),
              decoration: _inputDecoration(context, 'e.g. 2025-01'),
              onChanged: (v) => _month = v,
            ),
            const SizedBox(height: 12),
            _label(context, 'Fee Amount (Rs)'),
            const SizedBox(height: 6),
            TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              style: TextStyle(color: cNavy(context)),
              decoration: _inputDecoration(context, '0'),
            ),
            const SizedBox(height: 12),
            _label(context, 'Amount Paid (Rs)'),
            const SizedBox(height: 6),
            TextField(
              controller: _paidCtrl,
              keyboardType: TextInputType.number,
              style: TextStyle(color: cNavy(context)),
              decoration: _inputDecoration(context, '0'),
              onChanged: (v) {
                final paid = double.tryParse(v) ?? 0;
                final amount = double.tryParse(_amountCtrl.text) ?? 0;
                if (paid >= amount && amount > 0) {
                  setState(() => _status = 'paid');
                } else if (paid > 0) {
                  setState(() => _status = 'partial');
                } else {
                  setState(() => _status = 'pending');
                }
              },
            ),
            const SizedBox(height: 12),
            _label(context, 'Status'),
            const SizedBox(height: 6),
            DropdownButtonFormField<String>(
              value: _status,
              dropdownColor: cCard(context),
              decoration: _inputDecoration(context, ''),
              items: ['paid', 'partial', 'pending'].map((s) {
                return DropdownMenuItem(
                    value: s,
                    child: Text(s[0].toUpperCase() + s.substring(1),
                        style: TextStyle(color: cNavy(context))));
              }).toList(),
              onChanged: (v) => setState(() => _status = v ?? 'pending'),
            ),
            const SizedBox(height: 12),
            _label(context, 'Notes (optional)'),
            const SizedBox(height: 6),
            TextField(
              controller: _notesCtrl,
              style: TextStyle(color: cNavy(context)),
              decoration: _inputDecoration(context, 'Optional note'),
              maxLines: 2,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel')),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: kNavy,
            foregroundColor: Colors.white,
          ),
          onPressed: () {
            final amount = double.tryParse(_amountCtrl.text) ?? 0;
            final paid = double.tryParse(_paidCtrl.text) ?? 0;
            if (amount <= 0) return;
            const uuid = Uuid();
            final record = FeeRecord(
              id: uuid.v4(),
              studentId: widget.studentId,
              studentName: widget.studentName,
              classId: widget.classId,
              amount: amount,
              paid: paid,
              month: _month,
              status: _status,
              paidAt: _status == 'paid' ? DateTime.now() : null,
              notes: _notesCtrl.text.trim(),
            );
            Navigator.pop(context, record);
          },
          child: const Text('Save'),
        ),
      ],
    );
  }

  Widget _label(BuildContext context, String text) {
    return Text(text,
        style: TextStyle(
            color: cMuted(context),
            fontSize: 11.5,
            fontWeight: FontWeight.w600));
  }

  InputDecoration _inputDecoration(BuildContext context, String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: cMuted(context)),
      filled: true,
      fillColor: cBg(context),
      border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: cBorder(context))),
      enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: cBorder(context))),
      focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: kNavy, width: 1.6)),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    );
  }
}
