// lib/screens/classes_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class ClassesScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool   isAdmin;
  const ClassesScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
    this.isAdmin = false,
  });

  @override
  State<ClassesScreen> createState() => _ClassesScreenState();
}

class _ClassesScreenState extends State<ClassesScreen> {
  final _gradeCtrl   = TextEditingController();
  final _sectionCtrl = TextEditingController();
  bool _saving = false;

  // For admin: list of sections and currently selected one
  List<Map<String, dynamic>> _sections        = [];
  String                     _activeSectionId = '';
  bool                       _sectionsLoading = false;

  // Polled classes list (replaces StreamBuilder to avoid Windows thread crash)
  List<SchoolClass> _classes        = [];
  bool              _classesLoading = false;
  Timer?            _pollTimer;

  @override
  void initState() {
    super.initState();
    if (widget.isAdmin && widget.sectionId.isEmpty) {
      _loadSections();
    } else {
      _activeSectionId = widget.sectionId;
      _loadClasses();
      _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadClasses());
    }
  }

  Future<void> _loadClasses() async {
    if (_activeSectionId.isEmpty) return;
    if (!_classesLoading) setState(() => _classesLoading = true);
    final classes = await SchoolFirebaseService.getClasses(
        widget.schoolId, _activeSectionId);
    if (mounted) setState(() { _classes = classes; _classesLoading = false; });
  }

  Future<void> _loadSections() async {
    setState(() => _sectionsLoading = true);
    final list = await SchoolFirebaseService.getSections(widget.schoolId);
    if (mounted) {
      setState(() {
        _sections        = list;
        _activeSectionId = list.isNotEmpty ? (list.first['id'] as String? ?? '') : '';
        _sectionsLoading = false;
      });
      _loadClasses();
      _pollTimer?.cancel();
      _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadClasses());
    }
  }

  void _switchSection(String sectionId) {
    if (_activeSectionId == sectionId) return;
    _pollTimer?.cancel();
    setState(() { _activeSectionId = sectionId; _classes = []; });
    _loadClasses();
    _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadClasses());
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _gradeCtrl.dispose();
    _sectionCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isNarrow = constraints.maxWidth < 700;
          final padding  = constraints.maxWidth < 500 ? 14.0 : 28.0;

          return Padding(
            padding: EdgeInsets.all(padding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildPageHeader(context),
                if (widget.isAdmin && widget.sectionId.isEmpty) ...[
                  const SizedBox(height: 16),
                  _buildSectionPicker(context),
                ],
                const SizedBox(height: 24),
                Expanded(
                  child: _activeSectionId.isEmpty
                      ? _buildNoSectionPlaceholder(context)
                      : isNarrow
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SingleChildScrollView(child: _buildAddForm(context)),
                                const SizedBox(height: 16),
                                Expanded(child: _buildClassGrid(context)),
                              ],
                            )
                          : Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: constraints.maxWidth < 900 ? 220 : 288,
                                  child: SingleChildScrollView(child: _buildAddForm(context)),
                                ),
                                const SizedBox(width: 24),
                                Expanded(child: _buildClassGrid(context)),
                              ],
                            ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ── Section picker (admin only) ───────────────────────────
  Widget _buildSectionPicker(BuildContext context) {
    if (_sectionsLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          SizedBox(
            width: 16, height: 16,
            child: CircularProgressIndicator(strokeWidth: 2, color: cNavy(context)),
          ),
          const SizedBox(width: 10),
          Text('Loading sections…', style: TextStyle(color: cMuted(context), fontSize: 13)),
        ]),
      );
    }
    if (_sections.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.orange.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
        ),
        child: Row(children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 16),
          const SizedBox(width: 8),
          Text('No sections found. Create a section first.',
              style: TextStyle(color: cNavy(context), fontSize: 13)),
        ]),
      );
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: cBorder(context)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_special_rounded, size: 15, color: cMuted(context)),
          const SizedBox(width: 8),
          Text('Section:', style: TextStyle(color: cMuted(context), fontSize: 13)),
          const SizedBox(width: 8),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _activeSectionId.isNotEmpty ? _activeSectionId : null,
              isDense: true,
              style: TextStyle(color: cNavy(context), fontSize: 13, fontWeight: FontWeight.w600),
              dropdownColor: cCard(context),
              onChanged: (v) { if (v != null) setState(() => _activeSectionId = v); },
              items: _sections.map((s) {
                final id   = s['id']   as String? ?? s['sectionId'] as String? ?? '';
                final name = s['name'] as String? ?? id;
                return DropdownMenuItem(value: id, child: Text(name));
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoSectionPlaceholder(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_open_rounded, size: 52, color: cMuted(context).withValues(alpha: 0.35)),
          const SizedBox(height: 14),
          Text('Select a section above to manage classes',
              style: TextStyle(color: cNavy(context), fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  // ── Page header ───────────────────────────────────────────
  Widget _buildPageHeader(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width:  40, height: 40,
          decoration: BoxDecoration(
            color:        cNavy(context).withValues(alpha: isDark(context) ? 0.15 : 0.07),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(Icons.class_rounded, color: cNavy(context), size: 20),
        ),
        const SizedBox(width: 14),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Classes',
                  style: TextStyle(
                    color: cNavy(context), fontSize: 22,
                    fontWeight: FontWeight.w800, letterSpacing: -0.3,
                  )),
              Text('Manage your school classes and sections',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: cMuted(context), fontSize: 13)),
            ],
          ),
        ),
      ],
    );
  }

  // ── Add class form ────────────────────────────────────────
  Widget _buildAddForm(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(color: cNavy(context).withValues(alpha: 0.04), blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(color: kPink.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(9)),
              child: const Icon(Icons.add_rounded, color: kNavy, size: 16),
            ),
            const SizedBox(width: 10),
            Text('New Class',
                style: TextStyle(color: cNavy(context), fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
          Divider(height: 28, color: cBorder(context)),
          _fieldLabel(context, 'Grade'),
          const SizedBox(height: 6),
          _buildTextField(context, controller: _gradeCtrl, hint: 'e.g. 10th, 2nd Year', icon: Icons.school_rounded),
          const SizedBox(height: 16),
          _fieldLabel(context, 'Section'),
          const SizedBox(height: 6),
          _buildTextField(context, controller: _sectionCtrl, hint: 'e.g. A, B, C', icon: Icons.segment_rounded),
          const SizedBox(height: 22),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: ElevatedButton(
              onPressed: _saving ? null : _addClass,
              style: ElevatedButton.styleFrom(
                backgroundColor: cNavy(context),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: _saving
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_rounded, size: 16),
                        SizedBox(width: 6),
                        Text('Create Class', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Class grid (polled — avoids Windows Firestore thread crash) ──────────
  Widget _buildClassGrid(BuildContext context) {
    if (_classesLoading && _classes.isEmpty) {
      return Center(child: CircularProgressIndicator(
          color: cNavy(context), strokeWidth: 2));
    }

    if (_classes.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.class_outlined, size: 52,
                color: cMuted(context).withValues(alpha: 0.35)),
            const SizedBox(height: 14),
            Text('No classes yet',
                style: TextStyle(color: cNavy(context),
                    fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text('Create your first class using the form on the left.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Text('All Classes',
              style: TextStyle(color: cNavy(context),
                  fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
            decoration: BoxDecoration(
              color: cNavy(context).withValues(
                  alpha: isDark(context) ? 0.15 : 0.07),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text('${_classes.length}',
                style: TextStyle(color: cNavy(context),
                    fontSize: 11, fontWeight: FontWeight.w800)),
          ),
        ]),
        const SizedBox(height: 14),
        Expanded(
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 260, childAspectRatio: 2.1,
              crossAxisSpacing: 12, mainAxisSpacing: 12,
            ),
            itemCount: _classes.length,
            itemBuilder: (_, i) => _ClassCard(
              schoolClass: _classes[i],
              sectionId:   _activeSectionId,
              onDelete:    () => _deleteClass(_classes[i]),
            ),
          ),
        ),
      ],
    );
  }

  // ── Helpers ───────────────────────────────────────────────
  Widget _fieldLabel(BuildContext context, String text) => Text(
        text,
        style: TextStyle(color: cNavy(context), fontSize: 12, fontWeight: FontWeight.w600),
      );

  Widget _buildTextField(BuildContext context, {
    required TextEditingController controller,
    required String hint,
    required IconData icon,
  }) =>
      TextField(
        controller: controller,
        style: TextStyle(color: cNavy(context), fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: cMuted(context), fontSize: 13),
          prefixIcon: Icon(icon, color: cMuted(context), size: 16),
          prefixIconConstraints: const BoxConstraints(minWidth: 38, minHeight: 38),
          filled: true,
          fillColor: cBg(context),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: cBorder(context))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: cBorder(context))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: cNavy(context), width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        ),
      );

  // ── Actions ───────────────────────────────────────────────
  Future<void> _addClass() async {
    final grade   = _gradeCtrl.text.trim();
    final section = _sectionCtrl.text.trim();
    if (grade.isEmpty || section.isEmpty) return;
    if (_activeSectionId.isEmpty) return;

    final name = '$grade-$section';

    final existing = await SchoolFirebaseService.classExistsWithName(widget.schoolId, _activeSectionId, name);
    if (existing != null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Class "$name" already exists.'), backgroundColor: Colors.orange),
        );
      }
      return;
    }

    setState(() => _saving = true);
    try {
      final c = SchoolClass(
        id: name, schoolId: widget.schoolId,
        name: name, grade: grade, section: section,
      );
      await SchoolFirebaseService.addClass(c, _activeSectionId);
      _gradeCtrl.clear();
      _sectionCtrl.clear();
      _loadClasses(); // refresh grid
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteClass(SchoolClass c) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => _DeleteDialog(className: c.name),
    );
    if (confirm == true) {
      await SchoolFirebaseService.deleteClass(widget.schoolId, _activeSectionId, c.id);
      _loadClasses(); // refresh grid
    }
  }
}

// ── Class card ────────────────────────────────────────────────
class _ClassCard extends StatefulWidget {
  final SchoolClass schoolClass;
  final VoidCallback onDelete;
  final String sectionId;
  const _ClassCard({required this.schoolClass, required this.onDelete, required this.sectionId});

  @override
  State<_ClassCard> createState() => _ClassCardState();
}

class _ClassCardState extends State<_ClassCard> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final c = widget.schoolClass;

    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit:  (_) => setState(() => _hovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve:    Curves.easeOut,
        padding:  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: cCard(context),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(
            color: _hovered ? cNavy(context).withValues(alpha: 0.20) : cBorder(context),
          ),
          boxShadow: _hovered
              ? [BoxShadow(color: cNavy(context).withValues(alpha: 0.08), blurRadius: 14, offset: const Offset(0, 4))]
              : [BoxShadow(color: cNavy(context).withValues(alpha: 0.03), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Row(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(color: kTeal.withValues(alpha: 0.18), borderRadius: BorderRadius.circular(10)),
              child: Icon(Icons.class_rounded, color: kNavy, size: 17),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment:  MainAxisAlignment.center,
                children: [
                  Text(c.name,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: cNavy(context), fontWeight: FontWeight.w700, fontSize: 13)),
                  const SizedBox(height: 2),
                  Text('Grade ${c.grade}  •  Section ${c.section}',
                      style: TextStyle(color: cMuted(context), fontSize: 11)),
                  const SizedBox(height: 4),
                  Row(children: [
                    StreamBuilder<List<Student>>(
                      stream: SchoolFirebaseService.studentsForClassStream(c.schoolId, widget.sectionId, c.id),
                      builder: (_, snap) => _CountBadge(
                          icon: Icons.people_alt_rounded, label: '${snap.data?.length ?? 0}', color: kTeal),
                    ),
                    const SizedBox(width: 6),
                    StreamBuilder<List<Teacher>>(
                      stream: SchoolFirebaseService.teachersForClassStream(c.schoolId, widget.sectionId, c.id),
                      builder: (_, snap) => _CountBadge(
                          icon: Icons.school_rounded, label: '${snap.data?.length ?? 0}', color: kPink),
                    ),
                  ]),
                ],
              ),
            ),
            AnimatedOpacity(
              opacity:  _hovered ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 150),
              child: IconButton(
                tooltip: 'Delete class',
                icon: Icon(Icons.delete_outline_rounded, color: kError, size: 17),
                onPressed: widget.onDelete,
                visualDensity: VisualDensity.compact,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CountBadge extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color    color;
  const _CountBadge({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: color),
          const SizedBox(width: 3),
          Text(label, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _DeleteDialog extends StatelessWidget {
  final String className;
  const _DeleteDialog({required this.className});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: cCard(context),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(color: kError.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(9)),
          child: Icon(Icons.delete_outline_rounded, color: kError, size: 17),
        ),
        const SizedBox(width: 10),
        Text('Delete Class',
            style: TextStyle(color: cNavy(context), fontSize: 16, fontWeight: FontWeight.w700)),
      ]),
      content: Text(
        'Delete "$className"? Students assigned to this class will not be deleted.',
        style: TextStyle(color: cMuted(context), fontSize: 13, height: 1.5),
      ),
      actionsPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      actions: [
        OutlinedButton(
          onPressed: () => Navigator.pop(context, false),
          style: OutlinedButton.styleFrom(
            foregroundColor: cNavy(context),
            side: BorderSide(color: cBorder(context)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
          ),
          child: const Text('Cancel'),
        ),
        const SizedBox(width: 8),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(
            backgroundColor: kError, foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
          ),
          child: const Text('Delete', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}
