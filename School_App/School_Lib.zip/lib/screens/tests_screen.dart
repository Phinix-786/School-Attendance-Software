// lib/screens/tests_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';
import '../services/pdf_service.dart';

class TestsScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;
  final String sectionId;
  final bool   isAdmin;

  const TestsScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
    this.isAdmin = false,
  });

  @override
  State<TestsScreen> createState() => _TestsScreenState();
}

class _TestsScreenState extends State<TestsScreen> {
  // Admin sections
  List<Map<String, dynamic>> _adminSections   = [];
  String?                    _selectedSecId;

  // Classes / students
  List<SchoolClass> _classes  = [];
  List<Student>     _students = [];
  SchoolClass?      _selectedClass;
  Student?          _selectedStudent;

  // Tests + results
  List<SchoolTest>   _tests   = [];
  Map<String, TestResult?> _resultMap = {}; // testId → result (null = not submitted)

  bool _loadingClasses   = false;
  bool _loadingStudents  = false;
  bool _loadingTests     = false;

  Timer? _pollTimer;

  String get _effectiveSecId =>
      widget.isAdmin ? (_selectedSecId ?? '') : widget.sectionId;

  @override
  void initState() {
    super.initState();
    if (widget.isAdmin) {
      _loadAdminSections();
    } else {
      _loadClasses(widget.sectionId);
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadAdminSections() async {
    final secs = await SchoolFirebaseService.getSections(widget.schoolId);
    if (!mounted) return;
    setState(() {
      _adminSections = secs;
      if (secs.isNotEmpty) {
        _selectedSecId = secs.first['id'] as String;
        _loadClasses(_selectedSecId!);
      }
    });
  }

  Future<void> _loadClasses(String secId) async {
    setState(() { _loadingClasses = true; _classes = []; _selectedClass = null; _students = []; _selectedStudent = null; });
    final cls = await SchoolFirebaseService.getClasses(widget.schoolId, secId);
    if (!mounted) return;
    setState(() { _classes = cls; _loadingClasses = false; });
  }

  Future<void> _loadStudents(SchoolClass cls) async {
    setState(() {
      _selectedClass = cls;
      _loadingStudents = true;
      _students = [];
      _selectedStudent = null;
      _tests = [];
      _resultMap = {};
    });
    final students = await SchoolFirebaseService.getStudentsByClass(
        widget.schoolId, _effectiveSecId, cls.id);
    if (!mounted) return;
    setState(() { _students = students; _loadingStudents = false; });
  }

  Future<void> _loadTestResults(Student student) async {
    setState(() {
      _selectedStudent = student;
      _loadingTests    = true;
      _tests           = [];
      _resultMap       = {};
    });

    final tests = await SchoolFirebaseService.getTests(
        widget.schoolId, _effectiveSecId, _selectedClass!.id);
    if (!mounted) return;

    // Fetch results in parallel
    final resultFutures = tests.map((t) =>
        SchoolFirebaseService.getTestResultsForStudent(
            widget.schoolId, _effectiveSecId, _selectedClass!.id,
            t.id, student.id));
    final resultLists = await Future.wait(resultFutures);
    if (!mounted) return;

    final map = <String, TestResult?>{};
    for (int i = 0; i < tests.length; i++) {
      map[tests[i].id] =
          resultLists[i].isNotEmpty ? resultLists[i].first : null;
    }

    setState(() { _tests = tests; _resultMap = map; _loadingTests = false; });
  }

  // ── Export: student report ─────────────────────────────────
  Future<void> _exportStudentPdf(BuildContext context) async {
    if (_selectedStudent == null || _selectedClass == null) return;
    _showSnack(context, 'Generating PDF…');
    try {
      final bytes = await PdfService.generateStudentTestReport(
        schoolName:  widget.schoolName,
        sectionId:   _effectiveSecId,
        className:   _selectedClass!.name,
        student:     _selectedStudent!,
        tests:       _tests,
        resultMap:   _resultMap,
      );
      final name =
          'test_results_${_selectedStudent!.name.replaceAll(' ', '_')}'
          '_${_selectedClass!.name}.pdf';
      final savedPath = await PdfService.saveToFile(bytes, name);
      if (context.mounted) {
        _showSnack(context,
            savedPath != null ? 'Saved to: $savedPath' : 'Failed to save.',
            error: savedPath == null);
      }
    } catch (e) {
      if (context.mounted) _showSnack(context, 'Export failed: $e', error: true);
    }
  }

  // ── Export: class report (all students × all tests) ────────
  Future<void> _exportClassPdf(BuildContext context) async {
    if (_selectedClass == null || _students.isEmpty || _tests.isEmpty) return;
    _showSnack(context, 'Generating class report…');
    try {
      // Fetch results for every test × every student in parallel
      final Map<String, Map<String, TestResult?>> studentResultMap = {};
      for (final student in _students) {
        studentResultMap[student.id] = {};
      }

      final futures = _tests.map((t) =>
          SchoolFirebaseService.getTestResultsForTest(
              widget.schoolId, _effectiveSecId, _selectedClass!.id, t.id));
      final allResults = await Future.wait(futures);

      for (int i = 0; i < _tests.length; i++) {
        for (final r in allResults[i]) {
          studentResultMap[r.studentId] ??= {};
          studentResultMap[r.studentId]![_tests[i].id] = r;
        }
      }

      final bytes = await PdfService.generateClassTestReport(
        schoolName:       widget.schoolName,
        sectionId:        _effectiveSecId,
        className:        _selectedClass!.name,
        tests:            _tests,
        students:         _students,
        studentResultMap: studentResultMap,
      );
      final name =
          'test_results_class_${_selectedClass!.name.replaceAll(' ', '_')}.pdf';
      final savedPath = await PdfService.saveToFile(bytes, name);
      if (context.mounted) {
        _showSnack(context,
            savedPath != null ? 'Saved to: $savedPath' : 'Failed to save.',
            error: savedPath == null);
      }
    } catch (e) {
      if (context.mounted) _showSnack(context, 'Export failed: $e', error: true);
    }
  }

  void _showSnack(BuildContext context, String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? kError : const Color(0xFF16A34A),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildPageHeader(context),
            if (widget.isAdmin && _adminSections.isNotEmpty) ...[
              const SizedBox(height: 14),
              _buildSectionChips(context),
            ],
            const SizedBox(height: 18),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Left: Class + Student list ──
                  SizedBox(
                    width: 220,
                    child: Column(
                      children: [
                        Expanded(flex: 1, child: _buildClassPanel(context)),
                        const SizedBox(height: 12),
                        Expanded(flex: 2, child: _buildStudentPanel(context)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 20),
                  // ── Right: Test results ──
                  Expanded(child: _buildResultsPanel(context)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPageHeader(BuildContext context) {
    return Row(
      children: [
        Icon(Icons.quiz_rounded, color: cNavy(context), size: 20),
        const SizedBox(width: 9),
        Text('Test Results',
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   19,
                fontWeight: FontWeight.w800)),
        const Spacer(),
        // Class report — only when a class with students+tests is loaded
        if (_selectedClass != null &&
            _students.isNotEmpty &&
            _tests.isNotEmpty)
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: cNavy(context),
              side: BorderSide(color: cBorder(context), width: 1.5),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 11),
            ),
            icon: Icon(Icons.picture_as_pdf_rounded,
                size: 15, color: cNavy(context)),
            label: Text('Export Class Report',
                style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize:   12.5,
                    color:      cNavy(context))),
            onPressed: () => _exportClassPdf(context),
          ),
      ],
    );
  }

  Widget _buildSectionChips(BuildContext context) {
    return Row(
      children: [
        Icon(Icons.account_tree_rounded, color: cMuted(context), size: 15),
        const SizedBox(width: 8),
        Text('Section:', style: TextStyle(color: cMuted(context), fontSize: 12.5)),
        const SizedBox(width: 10),
        ..._adminSections.map((sec) {
          final sId  = (sec['id'] as String?) ?? '';
          final name = (sec['name'] as String?) ?? sId;
          final sel  = _selectedSecId == sId;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                if (_selectedSecId == sId) return;
                setState(() { _selectedSecId = sId; });
                _loadClasses(sId);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: sel ? cNavy(context) : cCard(context),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: sel ? cNavy(context) : cBorder(context)),
                ),
                child: Text(name,
                    style: TextStyle(
                        color:      sel ? Colors.white : cMuted(context),
                        fontSize:   12.5,
                        fontWeight: sel ? FontWeight.w700 : FontWeight.w500)),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildClassPanel(BuildContext context) {
    return _Panel(
      title: 'Classes',
      child: _loadingClasses
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _classes.isEmpty
              ? Center(
                  child: Text('No classes.',
                      style: TextStyle(color: cMuted(context), fontSize: 13)))
              : ListView.builder(
                  itemCount: _classes.length,
                  itemBuilder: (_, i) {
                    final cls = _classes[i];
                    final sel = _selectedClass?.id == cls.id;
                    return _ListTile(
                      label:    cls.name,
                      selected: sel,
                      onTap:    () => _loadStudents(cls),
                    );
                  },
                ),
    );
  }

  Widget _buildStudentPanel(BuildContext context) {
    return _Panel(
      title: 'Students',
      child: _selectedClass == null
          ? Center(
              child: Text('Select a class.',
                  style: TextStyle(color: cMuted(context), fontSize: 13)))
          : _loadingStudents
              ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
              : _students.isEmpty
                  ? Center(
                      child: Text('No students.',
                          style: TextStyle(color: cMuted(context), fontSize: 13)))
                  : ListView.builder(
                      itemCount: _students.length,
                      itemBuilder: (_, i) {
                        final s   = _students[i];
                        final sel = _selectedStudent?.id == s.id;
                        return _ListTile(
                          label:    s.name,
                          sublabel: 'Roll: ${s.rollNo}',
                          selected: sel,
                          onTap:    () => _loadTestResults(s),
                        );
                      },
                    ),
    );
  }

  Widget _buildResultsPanel(BuildContext context) {
    if (_selectedStudent == null) {
      return _Panel(
        title: 'Test Results',
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('📝', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 12),
              Text('Select a student to view test results.',
                  style: TextStyle(color: cMuted(context), fontSize: 14)),
            ],
          ),
        ),
      );
    }

    return _PanelWithAction(
      title:  'Tests — ${_selectedStudent!.name}',
      action: _tests.isNotEmpty
          ? OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: cNavy(context),
                side: BorderSide(color: cBorder(context), width: 1),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 7),
              ),
              icon: Icon(Icons.picture_as_pdf_rounded,
                  size: 13, color: cNavy(context)),
              label: Text('Save PDF',
                  style: TextStyle(
                      fontSize:   11.5,
                      fontWeight: FontWeight.w600,
                      color:      cNavy(context))),
              onPressed: () => _exportStudentPdf(context),
            )
          : null,
      child: _loadingTests
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : _tests.isEmpty
              ? Center(
                  child: Text('No tests found for this class.',
                      style: TextStyle(color: cMuted(context), fontSize: 14)))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _tests.length,
                  itemBuilder: (_, i) {
                    final test   = _tests[i];
                    final result = _resultMap[test.id];
                    return _TestResultRow(test: test, result: result);
                  },
                ),
    );
  }
}

class _Panel extends StatelessWidget {
  final String title;
  final Widget child;
  const _Panel({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: Text(title,
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   13,
                    fontWeight: FontWeight.w700)),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(child: child),
        ],
      ),
    );
  }
}

// Panel with an optional action widget in the header row
class _PanelWithAction extends StatelessWidget {
  final String  title;
  final Widget  child;
  final Widget? action;
  const _PanelWithAction({
    required this.title,
    required this.child,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 10, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(title,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w700)),
                ),
                if (action != null) action!,
              ],
            ),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(child: child),
        ],
      ),
    );
  }
}

class _ListTile extends StatelessWidget {
  final String   label;
  final String?  sublabel;
  final bool     selected;
  final VoidCallback onTap;
  const _ListTile({
    required this.label,
    this.sublabel,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected
              ? cNavy(context).withValues(alpha: 0.07)
              : Colors.transparent,
          border: Border(
              left: BorderSide(
                  color: selected ? cNavy(context) : Colors.transparent,
                  width: 3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   13,
                    fontWeight:
                        selected ? FontWeight.w700 : FontWeight.w500)),
            if (sublabel != null)
              Text(sublabel!,
                  style: TextStyle(color: cMuted(context), fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _TestResultRow extends StatelessWidget {
  final SchoolTest  test;
  final TestResult? result;
  const _TestResultRow({required this.test, required this.result});

  @override
  Widget build(BuildContext context) {
    final date  = '${test.testDate.day}/${test.testDate.month}/${test.testDate.year}';

    Widget statusWidget;
    if (result == null) {
      statusWidget = Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color:        cBorder(context),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text('Not submitted',
            style: TextStyle(color: cMuted(context), fontSize: 11)),
      );
    } else if (result!.wasAbsent) {
      statusWidget = Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color:        const Color(0xFFF59E0B).withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
              color: const Color(0xFFF59E0B).withValues(alpha: 0.4)),
        ),
        child: const Text('Absent',
            style: TextStyle(
                color:      Color(0xFFF59E0B),
                fontSize:   11,
                fontWeight: FontWeight.w700)),
      );
    } else {
      final pct   = result!.percentage;
      final color = pct >= 80
          ? const Color(0xFF16A34A)
          : pct >= 50
              ? const Color(0xFFF59E0B)
              : kError;
      statusWidget = Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text('${result!.marksObtained} / ${result!.marksTotal}',
              style: TextStyle(
                  color:      color,
                  fontSize:   14,
                  fontWeight: FontWeight.w800)),
          Text('${pct.toStringAsFixed(1)}%',
              style: TextStyle(color: color, fontSize: 10)),
        ],
      );
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color:        cBg(context),
        borderRadius: BorderRadius.circular(10),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(test.topic,
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   13,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color:        kTeal.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(test.subject,
                          style: TextStyle(
                              color: cNavy(context), fontSize: 9)),
                    ),
                    const SizedBox(width: 8),
                    Text(date,
                        style: TextStyle(
                            color: cMuted(context), fontSize: 11)),
                  ],
                ),
              ],
            ),
          ),
          statusWidget,
        ],
      ),
    );
  }
}
