// lib/screens/students_screen.dart  (UPDATED)
// Changes:
//   • Auto-generates studentLoginId (e.g. S-school-0001) and studentPassword
//     when a student is created for the first time.
//   • Shows those credentials in the table with a copy button.
//   • Edit dialog also shows / lets admin regenerate credentials.
//   • All other logic preserved exactly.
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

String _normalizePhone(String raw) {
  String p = raw.trim().replaceAll(RegExp(r'[\s\-()]'), '');
  if (p.startsWith('+')) p = p.substring(1);
  if (p.startsWith('0')) p = '92${p.substring(1)}';
  return p;
}

// ── Credential generators ─────────────────────────────────────
String _genStudentLoginId(String schoolId, int index) =>
    'S-${schoolId.toUpperCase()}-${index.toString().padLeft(4, '0')}';

String _genParentLoginId(String schoolId, int index) =>
    'P-${schoolId.toUpperCase()}-${index.toString().padLeft(4, '0')}';

String _genPassword() {
  final rand  = Random();
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  return List.generate(6, (_) => chars[rand.nextInt(chars.length)]).join();
}
// keep old name as alias
String _genStudentPassword() => _genPassword();

class StudentsScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool   isAdmin;
  const StudentsScreen(
      {super.key,
      required this.schoolId,
      required this.sectionId,
      this.isAdmin = false});

  @override
  State<StudentsScreen> createState() => _StudentsScreenState();
}

class _StudentsScreenState extends State<StudentsScreen> {
  String? _filterClassId;
  String? _filterSection;
  String  _searchQuery = '';

  List<Map<String, dynamic>> _sections        = [];
  String                     _activeSectionId = '';
  bool                       _sectionsLoading = false;

  // Polled data (replaces StreamBuilders)
  List<Student>     _students    = [];
  List<SchoolClass> _classes     = [];
  bool              _dataLoading = false;
  Timer?            _pollTimer;

  @override
  void initState() {
    super.initState();
    if (widget.isAdmin && widget.sectionId.isEmpty) {
      _loadSections();
    } else {
      _activeSectionId = widget.sectionId;
      _loadData();
      _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadData());
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadData() async {
    if (_activeSectionId.isEmpty) return;
    setState(() => _dataLoading = true);
    final results = await Future.wait([
      SchoolFirebaseService.getAllStudents(widget.schoolId, _activeSectionId),
      SchoolFirebaseService.getClasses(widget.schoolId, _activeSectionId),
    ]);
    if (mounted) {
      setState(() {
        _students    = results[0] as List<Student>;
        _classes     = results[1] as List<SchoolClass>;
        _dataLoading = false;
      });
    }
  }

  Future<void> _loadSections() async {
    setState(() => _sectionsLoading = true);
    final list =
        await SchoolFirebaseService.getSections(widget.schoolId);
    if (mounted) {
      setState(() {
        _sections        = list;
        _activeSectionId =
            list.isNotEmpty ? (list.first['id'] as String? ?? '') : '';
        _sectionsLoading = false;
      });
      _loadData();
      _pollTimer?.cancel();
      _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadData());
    }
  }

  // ── Section picker (same as before) ──────────────────────────
  Widget _buildSectionPicker(BuildContext context) {
    if (_sectionsLoading) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(children: [
          SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: cNavy(context))),
          const SizedBox(width: 10),
          Text('Loading sections…',
              style: TextStyle(color: cMuted(context), fontSize: 13)),
        ]),
      );
    }
    if (_sections.isEmpty) {
      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color:        Colors.orange.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
              color: Colors.orange.withValues(alpha: 0.3)),
        ),
        child: Row(children: [
          const Icon(Icons.warning_amber_rounded,
              color: Colors.orange, size: 16),
          const SizedBox(width: 8),
          Text('No sections found. Create a section first.',
              style: TextStyle(color: cNavy(context), fontSize: 13)),
        ]),
      );
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(10),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_special_rounded,
              size: 15, color: cMuted(context)),
          const SizedBox(width: 8),
          Text('Section:',
              style: TextStyle(color: cMuted(context), fontSize: 13)),
          const SizedBox(width: 8),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: _activeSectionId.isNotEmpty
                  ? _activeSectionId
                  : null,
              isDense:       true,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   13,
                  fontWeight: FontWeight.w600),
              dropdownColor: cCard(context),
              onChanged: (v) {
                if (v != null) setState(() => _activeSectionId = v);
              },
              items: _sections.map((s) {
                final id   = s['id']   as String? ??
                    s['sectionId'] as String? ?? '';
                final name = s['name'] as String? ?? id;
                return DropdownMenuItem(
                    value: id, child: Text(name));
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  // ── Filters ───────────────────────────────────────────────────
  List<Student> _applyFilters(
      List<Student> all, Map<String, SchoolClass> classById) {
    return all.where((s) {
      if (_filterClassId != null && s.classId != _filterClassId)
        return false;
      if (_filterSection != null) {
        final cn    = classById[s.classId]?.name ?? '';
        final parts = cn.trim().split(' ');
        if (parts.isEmpty || parts.last != _filterSection) return false;
      }
      if (_searchQuery.isNotEmpty) {
        final q  = _searchQuery.toLowerCase();
        final cn = classById[s.classId]?.name.toLowerCase() ?? '';
        if (!s.name.toLowerCase().contains(q) &&
            !s.rollNo.toLowerCase().contains(q) &&
            !cn.contains(q) &&
            !s.studentLoginId.toLowerCase().contains(q)) {
          return false;
        }
      }
      return true;
    }).toList();
  }

  // ── Show add/edit dialog ──────────────────────────────────────
  Future<void> _showAddDialog({Student? student}) async {
    final existingStudents = await SchoolFirebaseService
        .getAllStudents(widget.schoolId, _activeSectionId);
    final nextIndex = existingStudents.length + 1;

    final classes = await SchoolFirebaseService
        .getClasses(widget.schoolId, _activeSectionId);
    if (!mounted) return;

    await showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.4),
      builder: (_) => _StudentDialog(
        student:    student,
        classes:    classes,
        schoolId:   widget.schoolId,
        sectionId:  _activeSectionId,
        nextIndex:  nextIndex,
      ),
    );
    _loadData(); // refresh table after add/edit
  }

  // ── Copy credentials ──────────────────────────────────────────
  void _copyCreds(Student s) {
    final text =
        'Student: ${s.name}\n'
        '--- Student App ---\n'
        'Student ID: ${s.studentLoginId}\nPassword: ${s.studentPassword}\n'
        '--- Parent App ---\n'
        'Parent ID: ${s.parentLoginId}\nPassword: ${s.parentPassword}\n'
        'School: ${s.schoolId}';
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content:         Text('Credentials copied to clipboard!'),
      backgroundColor: Color(0xFF16A34A),
      duration:        Duration(seconds: 2),
    ));
  }

  // ── Confirm delete ────────────────────────────────────────────
  void _confirmDelete(Student s) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(ctx),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14)),
        title: Text('Delete Student?',
            style: TextStyle(
                color:      cNavy(ctx),
                fontSize:   16,
                fontWeight: FontWeight.w800)),
        content: Text('Remove ${s.name} from the system?',
            style:
                TextStyle(color: cMuted(ctx), fontSize: 13.5)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Cancel',
                  style: TextStyle(color: cMuted(ctx)))),
          TextButton(
              onPressed: () {
                Navigator.pop(ctx);
                SchoolFirebaseService.deleteStudent(
                    widget.schoolId,
                    _activeSectionId,
                    s.classId,
                    s.id).then((_) => _loadData());
              },
              child: const Text('Delete',
                  style: TextStyle(
                      color:      kError,
                      fontWeight: FontWeight.w700))),
        ],
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Builder(builder: (context) {
          final classes   = _classes;
          final classById = <String, SchoolClass>{
            for (final c in classes) c.id: c
          };
          final sections = classes
              .map((c) => c.name.trim().split(' ').last)
              .toSet()
              .toList()
            ..sort();
          final filtered = _applyFilters(_students, classById);

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context),
              const SizedBox(height: 16),
              if (widget.isAdmin && widget.sectionId.isEmpty)
                _buildSectionPicker(context),
              if (_activeSectionId.isEmpty)
                const Expanded(
                    child: Center(
                        child: Text(
                            'Select a section above to view students')))
              else if (_dataLoading && _students.isEmpty)
                const Expanded(
                    child: Center(
                        child: CircularProgressIndicator(strokeWidth: 2)))
              else ...[
                _buildSearchBar(context, classes, sections),
                const SizedBox(height: 14),
                Expanded(
                    child: _buildTable(context, filtered, classById)),
              ],
            ],
          );
        }),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Text('🎓', style: TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text('Student Management',
                  style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   19,
                      fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 3),
            Padding(
              padding: const EdgeInsets.only(left: 28),
              child: Text(
                'Add, edit students · auto-generates parent app login credentials.',
                style: TextStyle(
                    color:    cMuted(context).withValues(alpha: 0.8),
                    fontSize: 12),
              ),
            ),
          ],
        ),
        const Spacer(),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: kNavy,
            foregroundColor: Colors.white,
            elevation:       0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 12),
          ),
          onPressed: () => _showAddDialog(),
          child: const Text('+ Add Student',
              style: TextStyle(
                  fontWeight: FontWeight.w700, fontSize: 13)),
        ),
      ],
    );
  }

  Widget _buildSearchBar(BuildContext context,
      List<SchoolClass> classes, List<String> sections) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            onChanged: (v) => setState(() => _searchQuery = v),
            style:
                TextStyle(fontSize: 13, color: cNavy(context)),
            decoration: InputDecoration(
              prefixIcon: Icon(Icons.search_rounded,
                  color: cMuted(context).withValues(alpha: 0.45),
                  size: 17),
              hintText:  'Name, CID, Student ID, or class...',
              hintStyle: TextStyle(
                  color:    cMuted(context).withValues(alpha: 0.45),
                  fontSize: 13),
              filled:    true,
              fillColor: cCard(context),
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 11),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: BorderSide(color: cBorder(context))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: BorderSide(color: cBorder(context))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide:
                      const BorderSide(color: kTeal, width: 1.5)),
            ),
          ),
        ),
        const SizedBox(width: 10),
        _FilterDropdown<String?>(
          value: _filterClassId,
          hint:  'All Classes',
          items: [
            DropdownMenuItem(
                value: null,
                child: Text('All Classes',
                    style:
                        TextStyle(color: cNavy(context)))),
            ...classes.map((c) => DropdownMenuItem(
                value: c.id,
                child: Text(c.name,
                    style: TextStyle(color: cNavy(context))))),
          ],
          onChanged: (v) =>
              setState(() => _filterClassId = v),
        ),
        const SizedBox(width: 8),
        _FilterDropdown<String?>(
          value: _filterSection,
          hint:  'All Sections',
          items: [
            DropdownMenuItem(
                value: null,
                child: Text('All Sections',
                    style:
                        TextStyle(color: cNavy(context)))),
            ...sections.map((s) => DropdownMenuItem(
                value: s,
                child: Text('Section $s',
                    style:
                        TextStyle(color: cNavy(context))))),
          ],
          onChanged: (v) =>
              setState(() => _filterSection = v),
        ),
      ],
    );
  }

  Widget _buildTable(BuildContext context, List<Student> students,
      Map<String, SchoolClass> classById) {
    if (students.isEmpty) {
      return Container(
        decoration: BoxDecoration(
            color:        cCard(context),
            borderRadius: BorderRadius.circular(14),
            border:       Border.all(color: cBorder(context))),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.people_outline_rounded,
                  color: cMuted(context).withValues(alpha: 0.3),
                  size: 44),
              const SizedBox(height: 12),
              Text('No students found',
                  style: TextStyle(
                      color:    cMuted(context).withValues(alpha: 0.65),
                      fontSize: 14)),
            ],
          ),
        ),
      );
    }

    const cols = [
      _ColDef('CID',            0.06),
      _ColDef('STUDENT NAME',   0.13),
      _ColDef('WHATSAPP',       0.11),
      _ColDef('CLASS',          0.09),
      _ColDef('STUDENT ID',     0.11),
      _ColDef('STU. PASS',      0.09),
      _ColDef('PARENT ID',      0.11),
      _ColDef('PAR. PASS',      0.09),
      _ColDef('ACTIONS',        0.13),
    ];

    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
              color:      cNavy(context).withValues(alpha: 0.04),
              blurRadius: 10,
              offset:     const Offset(0, 3)),
        ],
      ),
      child: Column(
        children: [
          // Header
          Container(
            decoration: BoxDecoration(
              color: cBorder(context).withValues(alpha: 0.5),
              borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(13)),
            ),
            child: _TableRow(
                cols:     cols,
                isHeader: true,
                cells:    cols
                    .map((c) => _headerCell(context, c.label))
                    .toList()),
          ),
          Expanded(
            child: ListView.separated(
              padding:      EdgeInsets.zero,
              itemCount:    students.length,
              separatorBuilder: (_, __) =>
                  Divider(height: 1, color: cBorder(context)),
              itemBuilder: (_, i) {
                final s  = students[i];
                final cn = classById[s.classId]?.name ?? '';
                final hasCredentials = s.studentLoginId.isNotEmpty;

                Widget _credCell(String val) => val.isNotEmpty
                    ? Text(val,
                        style: TextStyle(
                            color:      cNavy(context).withValues(alpha: 0.85),
                            fontSize:   11.5,
                            fontFamily: 'monospace',
                            fontWeight: FontWeight.w600))
                    : Text('—', style: TextStyle(color: cMuted(context), fontSize: 12));

                return _TableRow(cols: cols, cells: [
                  Text(s.rollNo,
                      style: TextStyle(
                          color:    cMuted(context).withValues(alpha: 0.75),
                          fontSize: 12.5)),
                  Text(s.name,
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   13,
                          fontWeight: FontWeight.w700)),
                  Text(s.parentPhone,
                      style: TextStyle(
                          color:    cBlue(context).withValues(alpha: 0.75),
                          fontSize: 12.5)),
                  _ClassChip(label: cn),
                  _credCell(s.studentLoginId),
                  _credCell(s.studentPassword),
                  _credCell(s.parentLoginId),
                  _credCell(s.parentPassword),
                  // Actions
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    _ActionBtn(
                        icon:  Icons.edit_outlined,
                        label: 'Edit',
                        color: cNavy(context),
                        onTap: () => _showAddDialog(student: s)),
                    const SizedBox(width: 6),
                    if (hasCredentials)
                      _ActionBtn(
                          icon:  Icons.copy_outlined,
                          label: 'Copy',
                          color: kTeal,
                          onTap: () => _copyCreds(s)),
                    const SizedBox(width: 6),
                    _DeleteIconBtn(
                        onTap: () => _confirmDelete(s)),
                  ]),
                ]);
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ── Student Dialog ────────────────────────────────────────────
class _StudentDialog extends StatefulWidget {
  final Student?          student;
  final List<SchoolClass> classes;
  final String            schoolId;
  final String            sectionId;
  final int               nextIndex;

  const _StudentDialog({
    required this.student,
    required this.classes,
    required this.schoolId,
    required this.sectionId,
    required this.nextIndex,
  });

  @override
  State<_StudentDialog> createState() => _StudentDialogState();
}

class _StudentDialogState extends State<_StudentDialog> {
  late final TextEditingController _cidCtrl;
  late final TextEditingController _nameCtrl;
  late final TextEditingController _phoneCtrl;
  // Student app credentials
  late final TextEditingController _stuIdCtrl;
  late final TextEditingController _stuPassCtrl;
  // Parent app credentials
  late final TextEditingController _parIdCtrl;
  late final TextEditingController _parPassCtrl;
  String? _selClassId;
  bool    _saving = false;

  @override
  void initState() {
    super.initState();
    final s = widget.student;

    _cidCtrl   = TextEditingController(text: s?.rollNo      ?? '');
    _nameCtrl  = TextEditingController(text: s?.name        ?? '');
    _phoneCtrl = TextEditingController(text: s?.parentPhone ?? '');

    // Student app creds
    final stuId   = s?.studentLoginId.isNotEmpty == true
        ? s!.studentLoginId
        : _genStudentLoginId(widget.schoolId, widget.nextIndex);
    final stuPass = s?.studentPassword.isNotEmpty == true
        ? s!.studentPassword
        : _genPassword();

    // Parent app creds (separate)
    final parId   = s?.parentLoginId.isNotEmpty == true
        ? s!.parentLoginId
        : _genParentLoginId(widget.schoolId, widget.nextIndex);
    final parPass = s?.parentPassword.isNotEmpty == true
        ? s!.parentPassword
        : _genPassword();

    _stuIdCtrl   = TextEditingController(text: stuId);
    _stuPassCtrl = TextEditingController(text: stuPass);
    _parIdCtrl   = TextEditingController(text: parId);
    _parPassCtrl = TextEditingController(text: parPass);

    _selClassId = s?.classId ??
        (widget.classes.isNotEmpty ? widget.classes.first.id : null);
  }

  @override
  void dispose() {
    _cidCtrl.dispose();
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _stuIdCtrl.dispose();
    _stuPassCtrl.dispose();
    _parIdCtrl.dispose();
    _parPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final cidVal = _cidCtrl.text.trim();
    if (_nameCtrl.text.trim().isEmpty ||
        _phoneCtrl.text.trim().isEmpty ||
        cidVal.isEmpty ||
        _selClassId == null) return;
    if (_saving) return;
    setState(() => _saving = true);

    final s = Student(
      id: widget.student?.id ??
          '${_nameCtrl.text.trim()}_$cidVal'
              .replaceAll(RegExp(r'[^\w\-]'), '_'),
      schoolId:        widget.schoolId,
      classId:         _selClassId!,
      name:            _nameCtrl.text.trim(),
      rollNo:          cidVal,
      parentPhone:     _normalizePhone(_phoneCtrl.text.trim()),
      studentLoginId:  _stuIdCtrl.text.trim(),
      studentPassword: _stuPassCtrl.text.trim(),
      parentLoginId:   _parIdCtrl.text.trim(),
      parentPassword:  _parPassCtrl.text.trim(),
    );

    try {
      if (widget.student == null) {
        await SchoolFirebaseService.addStudent(s, widget.sectionId);
      } else {
        await SchoolFirebaseService.updateStudent(
            s, widget.sectionId);
      }
    } catch (e) {
      if (mounted) setState(() => _saving = false);
      return;
    }

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: cCard(context),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.symmetric(
          horizontal: 380, vertical: 60),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(28, 24, 28, 28),
        child: Column(
          mainAxisSize:        MainAxisSize.min,
          crossAxisAlignment:  CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Text(
                  widget.student == null
                      ? '+ Add New Student'
                      : 'Edit Student',
                  style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   16,
                      fontWeight: FontWeight.w800),
                ),
                const Spacer(),
                _CloseButton(
                    onTap: () => Navigator.pop(context)),
              ],
            ),
            const SizedBox(height: 22),

            // Row 1: CID + Name
            Row(
              children: [
                Expanded(
                  child: _DlgField(
                      label:      'CID / ROLL NO',
                      controller: _cidCtrl,
                      hint:       'e.g. C-1001'),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: _DlgField(
                      label:      'FULL NAME',
                      controller: _nameCtrl,
                      hint:       'Ahmed Raza'),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Row 2: Phone + Class
            Row(
              children: [
                Expanded(
                  child: _DlgField(
                    label:        "FATHER'S PHONE",
                    controller:   _phoneCtrl,
                    hint:         '923001234567',
                    keyboardType: TextInputType.phone,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _FieldLabel(label: 'CLASS'),
                      const SizedBox(height: 6),
                      Container(
                        height: 42,
                        decoration: BoxDecoration(
                          color: cBg(context),
                          border: Border.all(
                              color: cBorder(context)),
                          borderRadius:
                              BorderRadius.circular(9),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value:         _selClassId,
                            dropdownColor: cCard(context),
                            isExpanded:    true,
                            style: TextStyle(
                                color:    cNavy(context),
                                fontSize: 13),
                            icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: cMuted(context)
                                    .withValues(alpha: 0.6),
                                size: 18),
                            items: widget.classes
                                .map((c) => DropdownMenuItem(
                                      value: c.id,
                                      child: Text(c.name,
                                          style: TextStyle(
                                              color: cNavy(
                                                  context))),
                                    ))
                                .toList(),
                            onChanged: (v) =>
                                setState(() => _selClassId = v),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // ── Parent App Credentials ────────────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:        kPink.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
                border:       Border.all(
                    color: kPink.withValues(alpha: 0.25)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Student App creds ──────────────────
                  Row(
                    children: [
                      const Text('🎓', style: TextStyle(fontSize: 13)),
                      const SizedBox(width: 6),
                      Text('Student App Login',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   12,
                              fontWeight: FontWeight.w800)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => setState(
                            () => _stuPassCtrl.text = _genPassword()),
                        child: _RegenBtn(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text('Only for the Student App — child uses this.',
                      style: TextStyle(color: cMuted(context), fontSize: 11)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: _DlgField(
                          label: 'STUDENT ID',
                          controller: _stuIdCtrl,
                          hint: 'S-SCHOOL-0001')),
                      const SizedBox(width: 10),
                      Expanded(child: _DlgField(
                          label: 'PASSWORD',
                          controller: _stuPassCtrl,
                          hint: 'auto-generated')),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // ── Parent App creds ───────────────────
                  Row(
                    children: [
                      const Text('👨‍👩‍👧', style: TextStyle(fontSize: 13)),
                      const SizedBox(width: 6),
                      Text('Parent App Login',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   12,
                              fontWeight: FontWeight.w800)),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => setState(
                            () => _parPassCtrl.text = _genPassword()),
                        child: _RegenBtn(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text('Only for the Parent App — parent uses this.',
                      style: TextStyle(color: cMuted(context), fontSize: 11)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: _DlgField(
                          label: 'PARENT ID',
                          controller: _parIdCtrl,
                          hint: 'P-SCHOOL-0001')),
                      const SizedBox(width: 10),
                      Expanded(child: _DlgField(
                          label: 'PASSWORD',
                          controller: _parPassCtrl,
                          hint: 'auto-generated')),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),

            // Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                _CancelBtn(
                    onTap: () => Navigator.pop(context)),
                const SizedBox(width: 10),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kNavy,
                    foregroundColor: Colors.white,
                    elevation:       0,
                    shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(9)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 12),
                  ),
                  icon: _saving
                      ? const SizedBox(
                          width:  13,
                          height: 13,
                          child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color:       Colors.white))
                      : const Text('🎓',
                          style: TextStyle(fontSize: 13)),
                  label: Text(
                    widget.student == null
                        ? 'Add Student'
                        : 'Update Student',
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize:   13),
                  ),
                  onPressed: _saving ? null : _save,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Shared small widgets ──────────────────────────────────────
class _ColDef {
  final String label;
  final double flex;
  const _ColDef(this.label, this.flex);
}

class _TableRow extends StatelessWidget {
  final List<_ColDef> cols;
  final List<Widget>  cells;
  final bool          isHeader;
  const _TableRow(
      {required this.cols,
      required this.cells,
      this.isHeader = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
          horizontal: 20, vertical: 12),
      child: LayoutBuilder(builder: (_, bc) {
        return Row(
          children: List.generate(
              cols.length,
              (i) => SizedBox(
                  width: bc.maxWidth * cols[i].flex,
                  child: cells[i])),
        );
      }),
    );
  }
}

Widget _headerCell(BuildContext context, String label) =>
    Text(label,
        style: TextStyle(
            color:         cMuted(context).withValues(alpha: 0.75),
            fontSize:      10.5,
            fontWeight:    FontWeight.w700,
            letterSpacing: 0.7));

class _FieldLabel extends StatelessWidget {
  final String label;
  const _FieldLabel({required this.label});
  @override
  Widget build(BuildContext context) => Text(label,
      style: TextStyle(
          color:         cNavy(context).withValues(alpha: 0.7),
          fontSize:      10.5,
          fontWeight:    FontWeight.w700,
          letterSpacing: 0.8));
}

class _DlgField extends StatelessWidget {
  final String                label;
  final TextEditingController controller;
  final String?               hint;
  final TextInputType?        keyboardType;

  const _DlgField({
    required this.label,
    required this.controller,
    this.hint,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _FieldLabel(label: label),
          const SizedBox(height: 6),
          TextField(
            controller:   controller,
            keyboardType: keyboardType,
            style: TextStyle(
                fontSize: 13, color: cNavy(context)),
            decoration: InputDecoration(
              hintText:  hint,
              hintStyle: TextStyle(
                  color:    cMuted(context).withValues(alpha: 0.5),
                  fontSize: 13),
              filled:    true,
              fillColor: cBg(context),
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 11),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide:
                      BorderSide(color: cBorder(context))),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide:
                      BorderSide(color: cBorder(context))),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(
                      color: kTeal, width: 1.5)),
            ),
          ),
        ]);
  }
}

class _FilterDropdown<T> extends StatelessWidget {
  final T                         value;
  final String                    hint;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?>          onChanged;

  const _FilterDropdown({
    required this.value,
    required this.hint,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
          color:        cCard(context),
          border:       Border.all(color: cBorder(context)),
          borderRadius: BorderRadius.circular(9)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          value:         value,
          dropdownColor: cCard(context),
          style: TextStyle(
              color: cNavy(context), fontSize: 13),
          icon: Icon(Icons.keyboard_arrow_down_rounded,
              color: cMuted(context).withValues(alpha: 0.6),
              size: 18),
          items:     items,
          onChanged: onChanged,
        ),
      ),
    );
  }
}

class _ClassChip extends StatelessWidget {
  final String label;
  const _ClassChip({required this.label});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
          color: cNavy(context).withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(20)),
      child: Text(label,
          style: TextStyle(
              color:      cNavy(context),
              fontSize:   11.5,
              fontWeight: FontWeight.w600)),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData     icon;
  final String       label;
  final Color        color;
  final VoidCallback onTap;
  const _ActionBtn({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child:
          Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon,
            color: color.withValues(alpha: 0.8), size: 14),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(
                color:      color,
                fontSize:   12,
                fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _DeleteIconBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _DeleteIconBtn({required this.onTap});
  @override
  State<_DeleteIconBtn> createState() => _DeleteIconBtnState();
}

class _DeleteIconBtnState extends State<_DeleteIconBtn> {
  bool _hovered = false;
  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit:  (_) => setState(() => _hovered = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          width: 30, height: 28,
          decoration: BoxDecoration(
              color: kError.withValues(
                  alpha: _hovered ? 0.15 : 0.08),
              borderRadius: BorderRadius.circular(7)),
          child: Icon(Icons.delete_outline_rounded,
              color: kError.withValues(
                  alpha: _hovered ? 0.9 : 0.55),
              size: 15),
        ),
      ),
    );
  }
}

class _CloseButton extends StatelessWidget {
  final VoidCallback onTap;
  const _CloseButton({required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28, height: 28,
        decoration: BoxDecoration(
            color:        cBorder(context),
            borderRadius: BorderRadius.circular(8)),
        child: Icon(Icons.close_rounded,
            size:  15,
            color: cMuted(context).withValues(alpha: 0.7)),
      ),
    );
  }
}

class _CancelBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _CancelBtn({required this.onTap});
  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        foregroundColor: cMuted(context),
        side: BorderSide(color: cBorder(context), width: 1.5),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(9)),
        padding: const EdgeInsets.symmetric(
            horizontal: 18, vertical: 12),
      ),
      onPressed: onTap,
      child: Text('Cancel',
          style: TextStyle(
              color:      cMuted(context),
              fontSize:   13,
              fontWeight: FontWeight.w600)),
    );
  }
}

// Small "Regen" button used in credential sections
Widget _RegenBtn(BuildContext context) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(6),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.refresh_rounded, size: 12, color: cMuted(context)),
          const SizedBox(width: 4),
          Text('Regen',
              style: TextStyle(
                  color:      cMuted(context),
                  fontSize:   11,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
