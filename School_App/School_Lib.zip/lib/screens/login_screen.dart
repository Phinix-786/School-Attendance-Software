// lib/screens/login_screen.dart
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import '../services/local_settings_service.dart';
import 'welcome_screen.dart';
import 'app_lock_screen.dart';

// ─── RateLimiter ──────────────────────────────────────────────────────────
class _RateLimiter {
  static const _kAttemptTimestamps = 'rl_attempt_timestamps';
  static const _kTotalFailed       = 'rl_total_failed';
  static const _kBanned            = 'rl_banned';

  static Future<String?> checkAndRecord(SharedPreferences prefs) async {
    if (prefs.getBool(_kBanned) ?? false) {
      return 'Your account has been permanently banned due to too many failed '
          'login attempts. Please contact support.';
    }
    final now        = DateTime.now().millisecondsSinceEpoch;
    final rawList    = prefs.getStringList(_kAttemptTimestamps) ?? [];
    final timestamps = rawList.map(int.parse).toList();
    final in15Min = timestamps.where((t) => now - t <= 15 * 60 * 1000).length;
    final in1Hr   = timestamps.where((t) => now - t <= 60 * 60 * 1000).length;
    final in24Hr  = timestamps.where((t) => now - t <= 24 * 60 * 60 * 1000).length;
    if (in15Min >= 5) return 'Too many attempts. You can try again in 15 minutes.';
    if (in1Hr >= 10)  return 'Too many attempts. Please wait 1 hour before trying again.';
    if (in24Hr >= 20) return 'Daily limit reached. Please try again after 24 hours.';
    timestamps.add(now);
    final pruned = timestamps.where((t) => now - t <= 24 * 60 * 60 * 1000).toList();
    await prefs.setStringList(_kAttemptTimestamps, pruned.map((t) => t.toString()).toList());
    final total = (prefs.getInt(_kTotalFailed) ?? 0) + 1;
    await prefs.setInt(_kTotalFailed, total);
    if (total >= 30) {
      await prefs.setBool(_kBanned, true);
      return 'Your account has been permanently banned due to too many failed '
          'login attempts. Please contact support.';
    }
    return null;
  }

  static Future<void> onSuccess(SharedPreferences prefs) async {
    await prefs.remove(_kAttemptTimestamps);
    final current = prefs.getInt(_kTotalFailed) ?? 0;
    if (current > 0) await prefs.setInt(_kTotalFailed, current - 1);
  }
}

// ─── Login mode ───────────────────────────────────────────────────────────
enum _LoginMode { choose, admin, section }

// Section login sub-steps
enum _SectionStep { schoolId, sectionId, password }

// ─── LoginScreen ─────────────────────────────────────────────────────────
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with TickerProviderStateMixin {
  // ── Admin fields ──
  final _adminSchoolIdCtrl = TextEditingController();
  final _adminPassCtrl     = TextEditingController();

  // ── Section fields ──
  final _secSchoolIdCtrl = TextEditingController();
  final _secSectionIdCtrl = TextEditingController();
  final _secPassCtrl     = TextEditingController();

  _LoginMode    _mode       = _LoginMode.choose;
  _SectionStep  _secStep    = _SectionStep.schoolId;
  bool          _loading    = false;
  bool          _obscure    = true;
  bool          _secObscure = true;
  String?       _error;
  bool          _blocked    = false;

  // Data
  String _verifiedSchoolId   = '';
  String _verifiedSchoolName = '';
  String _verifiedSectionId  = '';
  Map<String, dynamic>? _sectionData;

  // ── Animations ──────────────────────────────────────────────────────
  late final AnimationController _entranceCtrl;
  late final AnimationController _pulseCtrl;
  late final AnimationController _shakeCtrl;
  late final AnimationController _bgOrbitCtrl;
  late final AnimationController _logoCtrl;
  late final AnimationController _stepCtrl;

  late final Animation<double> _fadeAnim;
  late final Animation<Offset> _cardSlideAnim;
  late final Animation<double> _cardScaleAnim;
  late final Animation<Offset> _logoSlideAnim;
  late final Animation<double> _logoFadeAnim;
  late final Animation<Offset> _field1SlideAnim;
  late final Animation<double> _field1FadeAnim;
  late final Animation<Offset> _field2SlideAnim;
  late final Animation<double> _field2FadeAnim;
  late final Animation<Offset> _btnSlideAnim;
  late final Animation<double> _btnFadeAnim;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _bgOrbitAnim;
  late final Animation<double> _shakeAnim;
  late final Animation<double> _logoScaleAnim;
  late final Animation<double> _stepFade;
  late final Animation<Offset> _stepSlide;

  @override
  void initState() {
    super.initState();

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));
    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.0, 0.4, curve: Curves.easeOut)));
    _cardSlideAnim = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.0, 0.55, curve: Curves.easeOutCubic)));
    _cardScaleAnim = Tween<double>(begin: 0.93, end: 1.0).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.0, 0.55, curve: Curves.easeOutBack)));
    _logoSlideAnim = Tween<Offset>(begin: const Offset(0, -0.3), end: Offset.zero).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.1, 0.5, curve: Curves.easeOutBack)));
    _logoFadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.1, 0.45, curve: Curves.easeOut)));
    _field1SlideAnim = Tween<Offset>(begin: const Offset(0.12, 0), end: Offset.zero).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.3, 0.65, curve: Curves.easeOutCubic)));
    _field1FadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.3, 0.6, curve: Curves.easeOut)));
    _field2SlideAnim = Tween<Offset>(begin: const Offset(0.12, 0), end: Offset.zero).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.42, 0.75, curve: Curves.easeOutCubic)));
    _field2FadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.42, 0.72, curve: Curves.easeOut)));
    _btnSlideAnim = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.58, 0.9, curve: Curves.easeOutCubic)));
    _btnFadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _entranceCtrl, curve: const Interval(0.58, 0.88, curve: Curves.easeOut)));

    _logoCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _logoScaleAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _logoCtrl, curve: Curves.elasticOut));

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.97, end: 1.03).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _bgOrbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 9))..repeat();
    _bgOrbitAnim = CurvedAnimation(parent: _bgOrbitCtrl, curve: Curves.linear);

    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _shakeAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -10.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10.0, end: 10.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10.0, end: -8.0),  weight: 2),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0),   weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: 0.0),    weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _stepCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _stepFade = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _stepCtrl, curve: Curves.easeOut));
    _stepSlide = Tween<Offset>(begin: const Offset(0.06, 0), end: Offset.zero).animate(
        CurvedAnimation(parent: _stepCtrl, curve: Curves.easeOutCubic));

    Future.delayed(const Duration(milliseconds: 80), () {
      if (mounted) { _entranceCtrl.forward(); _logoCtrl.forward(); }
    });
    _checkBanOnStartup();
  }

  Future<void> _checkBanOnStartup() async {
    final prefs  = await SharedPreferences.getInstance();
    final banned = prefs.getBool('rl_banned') ?? false;
    if (banned && mounted) {
      setState(() {
        _blocked = true;
        _error   = 'Your account has been permanently banned. Please contact support.';
      });
    }
  }

  @override
  void dispose() {
    _adminSchoolIdCtrl.dispose(); _adminPassCtrl.dispose();
    _secSchoolIdCtrl.dispose(); _secSectionIdCtrl.dispose(); _secPassCtrl.dispose();
    _entranceCtrl.dispose(); _pulseCtrl.dispose(); _shakeCtrl.dispose();
    _bgOrbitCtrl.dispose(); _logoCtrl.dispose(); _stepCtrl.dispose();
    super.dispose();
  }

  Future<void> _switchMode(_LoginMode mode) async {
    await _stepCtrl.reverse();
    setState(() { _mode = mode; _error = null; });
    _stepCtrl.forward(from: 0);
  }

  // ── Admin Login ───────────────────────────────────────────────────────────
  Future<void> _loginAdmin() async {
    final schoolId = _adminSchoolIdCtrl.text.trim();
    final password = _adminPassCtrl.text.trim();
    if (schoolId.isEmpty || password.isEmpty) {
      _triggerError('Please enter School ID and Password.');
      return;
    }
    setState(() { _loading = true; _error = null; });

    try {
      final prefs       = await SharedPreferences.getInstance();
      final blockReason = await _RateLimiter.checkAndRecord(prefs);
      if (!mounted) return;
      if (blockReason != null) {
        setState(() { _blocked = blockReason.contains('permanently'); _error = blockReason; _loading = false; });
        _shakeCtrl.forward(from: 0);
        return;
      }
    } catch (e) {
      if (mounted) _triggerError('Error: $e');
      return;
    }

    try {
      final doc = await FirebaseFirestore.instance.collection('schools').doc(schoolId).get();
      if (!mounted) return;
      if (!doc.exists) { _triggerError('School ID not found.'); return; }
      final data       = doc.data()!;
      final storedPass = data['adminPassword'] ?? '';
      if (storedPass != password) { _triggerError('Incorrect password.'); return; }
      if (data['isActive'] != true) {
        _triggerError('School account is locked. Contact support.');
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      await _RateLimiter.onSuccess(prefs);
      await prefs.setString('schoolId',   schoolId);
      await prefs.setString('schoolName', data['name'] ?? '');
      await prefs.setBool('isAdmin', true);
      await prefs.remove('sectionId');
      await prefs.remove('sectionName');

      // Admin username: prompt if not set yet
      final adminName = data['adminName'] as String?;

      if (!mounted) return;

      if (adminName == null || adminName.trim().isEmpty) {
        // First login — ask for a display name
        final entered = await _showAdminNameDialog(context, schoolId);
        if (!mounted) return;
        final resolvedName = (entered?.trim().isNotEmpty == true)
            ? entered!.trim()
            : 'Admin';
        await prefs.setString('adminName', resolvedName);
      } else {
        await prefs.setString('adminName', adminName);
      }

      final resolvedAdmin = prefs.getString('adminName') ?? 'Admin';

      await _navigateAfterLogin(
        context,
        schoolId:    schoolId,
        schoolName:  data['name'] ?? '',
        sectionId:   '',
        sectionName: resolvedAdmin,
        isAdmin:     true,
      );
    } catch (e) {
      if (mounted) _triggerError('Error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── Section Login: Step 1 — verify school + sectionId ────────────────────
  Future<void> _verifySectionSchool() async {
    final schoolId  = _secSchoolIdCtrl.text.trim();
    final sectionId = _secSectionIdCtrl.text.trim();
    if (schoolId.isEmpty || sectionId.isEmpty) {
      _triggerError('Please enter School ID and Section ID.');
      return;
    }
    setState(() { _loading = true; _error = null; });

    try {
      final prefs       = await SharedPreferences.getInstance();
      final blockReason = await _RateLimiter.checkAndRecord(prefs);
      if (!mounted) return;
      if (blockReason != null) {
        setState(() { _blocked = blockReason.contains('permanently'); _error = blockReason; _loading = false; });
        _shakeCtrl.forward(from: 0);
        return;
      }
    } catch (e) {
      if (mounted) _triggerError('Error: $e');
      return;
    }

    try {
      final schoolDoc = await FirebaseFirestore.instance.collection('schools').doc(schoolId).get();
      if (!mounted) return;
      if (!schoolDoc.exists) { _triggerError('School ID not found.'); return; }
      final schoolData = schoolDoc.data()!;
      if (schoolData['isActive'] != true) { _triggerError('School account is locked.'); return; }

      final sectionDoc = await FirebaseFirestore.instance
          .collection('schools/$schoolId/sections').doc(sectionId).get();
      if (!mounted) return;
      if (!sectionDoc.exists) { _triggerError('Section ID not found.'); return; }

      final prefs = await SharedPreferences.getInstance();
      await _RateLimiter.onSuccess(prefs);

      _verifiedSchoolId   = schoolId;
      _verifiedSchoolName = schoolData['name'] ?? '';
      _verifiedSectionId  = sectionId;
      _sectionData        = sectionDoc.data();
      _secPassCtrl.clear();

      await _stepCtrl.reverse();
      setState(() { _secStep = _SectionStep.password; _error = null; _loading = false; });
      _stepCtrl.forward(from: 0);
    } catch (e) {
      if (mounted) _triggerError('Error: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── Section Login: Step 2 — verify password ───────────────────────────────
  Future<void> _loginSection() async {
    if (_sectionData == null) return;
    final entered  = _secPassCtrl.text.trim();
    final expected = _sectionData!['password'] ?? '';
    if (entered.isEmpty) { _triggerError('Please enter section password.'); return; }

    setState(() { _loading = true; _error = null; });

    if (entered != expected) {
      await Future.delayed(const Duration(milliseconds: 400));
      _triggerError('Incorrect section password.');
      return;
    }

    final sectionName = _sectionData!['name'] as String? ?? '';

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('schoolId',     _verifiedSchoolId);
    await prefs.setString('schoolName',   _verifiedSchoolName);
    await prefs.setString('sectionId',   _verifiedSectionId);
    await prefs.setString('sectionName', sectionName);
    await prefs.setBool('isAdmin', false);

    if (!mounted) return;
    await _navigateAfterLogin(
      context,
      schoolId:    _verifiedSchoolId,
      schoolName:  _verifiedSchoolName,
      sectionId:   _verifiedSectionId,
      sectionName: sectionName,
      isAdmin:     false,
    );
  }

  // ── App lock check + navigate ─────────────────────────────────────────────
  static Future<void> _navigateAfterLogin(
    BuildContext context, {
    required String schoolId,
    required String schoolName,
    required String sectionId,
    required String sectionName,
    required bool isAdmin,
  }) async {
    final lockConfig = await LocalSettingsService.instance.loadLockConfig();

    if (!context.mounted) return;

    final welcomeScreen = WelcomeScreen(
      schoolId:    schoolId,
      schoolName:  schoolName,
      sectionId:   sectionId,
      sectionName: sectionName,
      isAdmin:     isAdmin,
    );

    // No privacy consent screen for the school desktop app.
    Widget destination = welcomeScreen;

    if (lockConfig.enabled && lockConfig.hashValue.isNotEmpty) {
      // App lock first → on unlock → privacy consent (if needed) → welcome
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 400),
          pageBuilder: (_, __, ___) => AppLockScreen(
            lockConfig: lockConfig,
            onUnlocked: () {
              Navigator.pushReplacement(
                context,
                PageRouteBuilder(
                  transitionDuration: const Duration(milliseconds: 600),
                  pageBuilder: (_, __, ___) => destination,
                  transitionsBuilder: (_, anim, __, child) =>
                      FadeTransition(opacity: anim, child: child),
                ),
              );
            },
          ),
          transitionsBuilder: (_, anim, __, child) =>
              FadeTransition(opacity: anim, child: child),
        ),
      );
    } else {
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, animation, __) => destination,
          transitionsBuilder: (_, animation, __, child) => FadeTransition(
            opacity: CurvedAnimation(
                parent: animation, curve: Curves.easeOut),
            child: child,
          ),
        ),
      );
    }
  }

  void _triggerError(String msg) {
    setState(() { _error = msg; _loading = false; });
    _shakeCtrl.forward(from: 0);
  }

  // ── Admin username dialog (shown on first login) ────────────────────────
  static Future<String?> _showAdminNameDialog(
      BuildContext context, String schoolId) async {
    final ctrl = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: Theme.of(ctx).cardColor,
        title: const Text('Welcome, Admin!',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enter your name or username. This is shown in the sidebar '
              'and stored with your school account.',
              style: TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 14),
            TextField(
              controller:     ctrl,
              autofocus:      true,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Your Name / Username',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (_) => Navigator.pop(ctx, ctrl.text),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    // Persist to Firestore so subsequent logins don't ask again
    if (result != null && result.trim().isNotEmpty) {
      try {
        await FirebaseFirestore.instance
            .collection('schools')
            .doc(schoolId)
            .update({'adminName': result.trim()});
      } catch (_) {}
    }
    ctrl.dispose();
    return result;
  }

  // ── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(children: [
        AnimatedBuilder(
          animation: _bgOrbitAnim,
          builder: (_, __) {
            final t = _bgOrbitAnim.value * 2 * math.pi;
            return Stack(children: [
              Container(color: kBg),
              Positioned(right: -80 + math.sin(t) * 30, top: -60 + math.cos(t * 0.7) * 25,
                  child: _blob(280, kTeal.withValues(alpha: 0.20))),
              Positioned(left: -100 + math.cos(t * 0.6) * 20, bottom: -80 + math.sin(t * 0.9) * 20,
                  child: _blob(320, kPink.withValues(alpha: 0.16))),
              Positioned(right: 50 + math.sin(t * 1.1) * 15, bottom: 150 + math.cos(t * 0.8) * 20,
                  child: _blob(160, kNavy.withValues(alpha: 0.05))),
            ]);
          },
        ),
        Center(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SlideTransition(
              position: _cardSlideAnim,
              child: ScaleTransition(
                scale: _cardScaleAnim,
                child: AnimatedBuilder(
                  animation: _shakeAnim,
                  builder: (_, child) => Transform.translate(
                    offset: Offset(_shakeAnim.value, 0), child: child),
                  child: Container(
                    width: 460,
                    padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 36),
                    decoration: BoxDecoration(
                      color: kCard,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: kBorder, width: 1.5),
                      boxShadow: [
                        BoxShadow(color: kNavy.withValues(alpha: 0.08), blurRadius: 40, offset: const Offset(0, 16)),
                        BoxShadow(color: kTeal.withValues(alpha: 0.10), blurRadius: 20, offset: const Offset(-6, 6)),
                      ],
                    ),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      // ── Logo ──
                      SlideTransition(position: _logoSlideAnim,
                        child: FadeTransition(opacity: _logoFadeAnim,
                          child: ScaleTransition(scale: _logoScaleAnim,
                            child: Container(
                              width: 64, height: 64,
                              decoration: BoxDecoration(
                                color: kNavy, borderRadius: BorderRadius.circular(16),
                                boxShadow: [BoxShadow(color: kNavy.withValues(alpha: 0.30), blurRadius: 18, offset: const Offset(0, 8))],
                              ),
                              child: ClipRRect(borderRadius: BorderRadius.circular(16),
                                child: Image.asset('assets/inverted_icon.png', width: 64, height: 64, fit: BoxFit.cover)),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      FadeTransition(opacity: _logoFadeAnim,
                        child: const Column(children: [
                          Text('App_Name', style: TextStyle(color: kNavy, fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -0.4)),
                          SizedBox(height: 4),
                          Text('Attendance Portal', style: TextStyle(color: kMuted, fontSize: 13, fontWeight: FontWeight.w500)),
                        ]),
                      ),
                      const SizedBox(height: 24),

                      // ── Step content ──
                      AnimatedSize(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOut,
                        child: _buildCurrentStep(),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildCurrentStep() {
    switch (_mode) {
      case _LoginMode.choose:
        return _buildChooseStep();
      case _LoginMode.admin:
        return _buildAdminStep();
      case _LoginMode.section:
        return _buildSectionStep();
    }
  }

  // ── Choose Step ──────────────────────────────────────────────────────────
  Widget _buildChooseStep() {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      _divider('SELECT LOGIN TYPE'),
      const SizedBox(height: 16),
      Text(
        'How would you like to sign in?',
        style: TextStyle(color: kMuted, fontSize: 13),
      ),
      const SizedBox(height: 16),
      _loginTypeCard(
        icon: Icons.admin_panel_settings_rounded,
        title: 'Admin Login',
        subtitle: 'Full school management access',
        color: kNavy,
        onTap: () => _switchMode(_LoginMode.admin),
      ),
      const SizedBox(height: 10),
      _loginTypeCard(
        icon: Icons.folder_special_rounded,
        title: 'Section Login',
        subtitle: 'Access your assigned section only',
        color: kTeal,
        onTap: () => _switchMode(_LoginMode.section),
      ),
      const SizedBox(height: 16),
      Text('Contact your administrator for credentials',
          style: TextStyle(color: kMuted, fontSize: 11.5)),
    ]);
  }

  Widget _loginTypeCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return _HoverCard(
      onTap: onTap,
      color: color,
      child: Row(children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: kNavy, fontSize: 15, fontWeight: FontWeight.w700)),
          Text(subtitle, style: TextStyle(color: kMuted, fontSize: 12)),
        ])),
        Icon(Icons.arrow_forward_ios_rounded, color: kMuted.withValues(alpha: 0.5), size: 14),
      ]),
    );
  }

  // ── Admin Step ────────────────────────────────────────────────────────────
  Widget _buildAdminStep() {
    return FadeTransition(
      opacity: _stepFade,
      child: SlideTransition(position: _stepSlide,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _divider('ADMIN LOGIN'),
          const SizedBox(height: 16),
          SlideTransition(position: _field1SlideAnim,
            child: FadeTransition(opacity: _field1FadeAnim,
              child: _buildField('School ID', _adminSchoolIdCtrl,
                  prefixIcon: Icons.badge_rounded, enabled: !_blocked))),
          const SizedBox(height: 14),
          SlideTransition(position: _field2SlideAnim,
            child: FadeTransition(opacity: _field2FadeAnim,
              child: _buildField('Admin Password', _adminPassCtrl,
                  obscure: _obscure, prefixIcon: Icons.lock_rounded, enabled: !_blocked,
                  suffix: IconButton(
                    icon: Icon(_obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: kMuted, size: 19),
                    onPressed: _blocked ? null : () => setState(() => _obscure = !_obscure),
                  )))),
          _errorWidget(),
          const SizedBox(height: 20),
          SlideTransition(position: _btnSlideAnim,
            child: FadeTransition(opacity: _btnFadeAnim,
              child: _loginButton(_loginAdmin, label: 'Admin Login'))),
          const SizedBox(height: 14),
          _backButton(() => _switchMode(_LoginMode.choose)),
        ]),
      ),
    );
  }

  // ── Section Step ──────────────────────────────────────────────────────────
  Widget _buildSectionStep() {
    return FadeTransition(
      opacity: _stepFade,
      child: SlideTransition(position: _stepSlide,
        child: _secStep == _SectionStep.password
            ? _buildSectionPasswordStep()
            : _buildSectionIdStep(),
      ),
    );
  }

  Widget _buildSectionIdStep() {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      _divider('SECTION LOGIN'),
      const SizedBox(height: 16),
      _buildField('School ID', _secSchoolIdCtrl, prefixIcon: Icons.badge_rounded, enabled: !_blocked),
      const SizedBox(height: 14),
      _buildField('Section ID', _secSectionIdCtrl, prefixIcon: Icons.folder_special_rounded, enabled: !_blocked),
      _errorWidget(),
      const SizedBox(height: 20),
      _loginButton(_verifySectionSchool, label: 'Continue'),
      const SizedBox(height: 14),
      _backButton(() => _switchMode(_LoginMode.choose)),
    ]);
  }

  Widget _buildSectionPasswordStep() {
    final secName = _sectionData?['name'] ?? 'Section';
    return Column(mainAxisSize: MainAxisSize.min, children: [
      _divider('SECTION ACCESS'),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: kTeal.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(10),
          border: Border.all(color: kTeal.withValues(alpha: 0.25))),
        child: Row(children: [
          Icon(Icons.folder_special_rounded, color: kTeal, size: 16),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Section', style: TextStyle(color: kMuted, fontSize: 10.5, fontWeight: FontWeight.w600)),
            Text(secName, style: const TextStyle(color: kNavy, fontSize: 14, fontWeight: FontWeight.w700)),
          ])),
        ]),
      ),
      const SizedBox(height: 14),
      _buildField('Section Password', _secPassCtrl,
          obscure: _secObscure, prefixIcon: Icons.lock_outline_rounded,
          suffix: IconButton(
            icon: Icon(_secObscure ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: kMuted, size: 19),
            onPressed: () => setState(() => _secObscure = !_secObscure),
          )),
      _errorWidget(),
      const SizedBox(height: 20),
      _loginButton(_loginSection, label: 'Enter Section'),
      const SizedBox(height: 14),
      _backButton(() async {
        await _stepCtrl.reverse();
        setState(() { _secStep = _SectionStep.schoolId; _error = null; });
        _stepCtrl.forward(from: 0);
      }),
    ]);
  }

  // ── Helpers ──────────────────────────────────────────────────────────────
  Widget _backButton(VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.arrow_back_rounded, color: kMuted, size: 15),
        const SizedBox(width: 5),
        Text('Go back', style: TextStyle(color: kMuted, fontSize: 12.5)),
      ]),
    );
  }

  Widget _divider(String label) {
    return Row(children: [
      const Expanded(child: Divider(color: kBorder, thickness: 1.2)),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(label, style: TextStyle(color: kMuted, fontSize: 10.5, fontWeight: FontWeight.w700, letterSpacing: 1.2))),
      const Expanded(child: Divider(color: kBorder, thickness: 1.2)),
    ]);
  }

  Widget _errorWidget() {
    return AnimatedSize(
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOut,
      child: _error != null
          ? Padding(padding: const EdgeInsets.only(top: 12),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: kError.withValues(alpha: 0.07), borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: kError.withValues(alpha: 0.25))),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(_blocked ? Icons.block_rounded : Icons.error_outline_rounded, color: kError, size: 15),
                  const SizedBox(width: 6),
                  Expanded(child: Text(_error!, style: const TextStyle(color: kError, fontSize: 12.5, fontWeight: FontWeight.w500))),
                ]),
              ))
          : const SizedBox.shrink(),
    );
  }

  Widget _loginButton(VoidCallback onPressed, {String label = 'Login'}) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, child) => Transform.scale(
        scale: _loading ? 1.0 : _pulseAnim.value, child: child),
      child: SizedBox(width: double.infinity, height: 50,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            gradient: _loading ? null : const LinearGradient(
              colors: [Color(0xFF001858), Color(0xFF172C66)],
              begin: Alignment.topLeft, end: Alignment.bottomRight),
            color: _loading ? kMuted : null,
            borderRadius: BorderRadius.circular(12),
            boxShadow: _loading ? [] : [BoxShadow(color: kNavy.withValues(alpha: 0.28), blurRadius: 16, offset: const Offset(0, 6))],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
              foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: _loading ? null : onPressed,
            child: _loading
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
                    const SizedBox(width: 8),
                    const Icon(Icons.arrow_forward_rounded, size: 18),
                  ]),
          ),
        ),
      ),
    );
  }

  Widget _buildField(String hint, TextEditingController ctrl,
      {bool obscure = false, bool enabled = true, IconData? prefixIcon, Widget? suffix}) {
    return TextField(
      controller: ctrl, obscureText: obscure, enabled: enabled,
      style: TextStyle(color: enabled ? kNavy : kMuted, fontSize: 14.5, fontWeight: FontWeight.w500),
      decoration: InputDecoration(
        hintText: hint, hintStyle: const TextStyle(color: kMuted, fontSize: 14),
        filled: true, fillColor: enabled ? kBg : kBorder,
        prefixIcon: prefixIcon != null ? Icon(prefixIcon, color: kMuted, size: 19) : null,
        suffixIcon: suffix,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: const BorderSide(color: kBorder, width: 1.4)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: const BorderSide(color: kBorder, width: 1.4)),
        disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: BorderSide(color: kBorder.withValues(alpha: 0.5), width: 1.4)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(11), borderSide: const BorderSide(color: kNavy, width: 1.8)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
      ),
    );
  }

  Widget _blob(double size, Color color) =>
      Container(width: size, height: size, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
}

// ── Hover Card ──────────────────────────────────────────────────────────────
class _HoverCard extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  final Color color;
  const _HoverCard({required this.child, required this.onTap, required this.color});
  @override
  State<_HoverCard> createState() => _HoverCardState();
}

class _HoverCardState extends State<_HoverCard> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  bool _hover = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 150));
    _scale = Tween<double>(begin: 1, end: 1.02).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) { setState(() => _hover = true); _ctrl.forward(); },
      onExit: (_) { setState(() => _hover = false); _ctrl.reverse(); },
      child: GestureDetector(
        onTap: widget.onTap,
        child: ScaleTransition(scale: _scale,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: _hover ? widget.color.withValues(alpha: 0.05) : kBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _hover ? widget.color.withValues(alpha: 0.3) : kBorder, width: 1.5),
              boxShadow: _hover ? [BoxShadow(color: widget.color.withValues(alpha: 0.06), blurRadius: 12, offset: const Offset(0, 4))] : [],
            ),
            child: widget.child,
          ),
        ),
      ),
    );
  }
}
