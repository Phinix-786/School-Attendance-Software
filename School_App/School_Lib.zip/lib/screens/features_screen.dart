// lib/screens/features_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../app_theme.dart';
import '../services/feature_service.dart';
import '../services/notification_service.dart';
import 'feature_detail_screen.dart';

class FeaturesScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool isAdmin;

  const FeaturesScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
    required this.isAdmin,
  });

  @override
  State<FeaturesScreen> createState() => _FeaturesScreenState();
}

class _FeaturesScreenState extends State<FeaturesScreen> {
  Map<String, bool> _features = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final map = await FeatureService.instance.getAll(
        widget.schoolId, widget.sectionId);
    if (mounted) {
      setState(() {
        _features = map;
        _loading = false;
      });
    }
  }

  bool _canSeeFeature(String key) {
    if (key == FeatureService.kDocuments) return widget.isAdmin;
    return true;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    final keys = FeatureService.allFeatureKeys
        .where(_canSeeFeature)
        .toList();

    return Scaffold(
      backgroundColor: cBg(context),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Features',
                style: TextStyle(
                    color: cNavy(context),
                    fontSize: 22,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text('Enable or disable app features. Disabling a feature permanently deletes its data.',
                style: TextStyle(color: cMuted(context), fontSize: 13)),
            const SizedBox(height: 24),

            // Vertical list
            ...keys.map((key) {
              final meta    = FeatureService.metadata[key]!;
              final enabled = _features[key] ?? true;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _FeatureCard(
                  featureKey: key,
                  meta: meta,
                  enabled: enabled,
                  isAdmin: widget.isAdmin,
                  onToggle: (v) => _handleToggle(key, v),
                  onRequestAccess: (!widget.isAdmin && !enabled &&
                          key == FeatureService.kFeeManagement)
                      ? () => _requestAccess(key, meta)
                      : null,
                  onTap: () => _openDetail(key, meta, enabled),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _openDetail(String key, FeatureMeta meta, bool enabled) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FeatureDetailScreen(
        featureKey: key,
        meta: meta,
        enabled: enabled,
        schoolId: widget.schoolId,
        sectionId: widget.sectionId,
        isAdmin: widget.isAdmin,
        onToggle: (v) => _handleToggle(key, v),
      ),
    ));
  }

  Future<void> _handleToggle(String key, bool enabled) async {
    if (!enabled) {
      if (widget.isAdmin) {
        // Admin disabling: only hides the feature from UI — no data deletion.
        // Show a simpler confirmation dialog (no DELETE typing required).
        final confirmed = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            backgroundColor: cCard(context),
            title: Row(children: [
              const Icon(Icons.visibility_off_rounded, size: 20),
              const SizedBox(width: 10),
              const Text('Hide Feature',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ]),
            content: Text(
              'This will hide the feature from the sidebar. No data will be deleted. '
              'You can re-enable it at any time.',
              style: TextStyle(color: cMuted(context), fontSize: 13),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Cancel')),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: kNavy,
                      foregroundColor: Colors.white,
                      elevation: 0),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('Hide')),
            ],
          ),
        );
        if (confirmed != true) return;
        // Admin: no Firestore delete
      } else {
        // Section head disabling: deletes only their section's data
        final confirmed = await _showDeleteConfirmDialog(key);
        if (!confirmed) return;
        await FeatureService.instance.deleteFeatureData(
            widget.schoolId, widget.sectionId, key,
            isAdmin: false);
      }
    }
    await FeatureService.instance.setEnabled(
        widget.schoolId, widget.sectionId, key, enabled);
    if (mounted) {
      setState(() => _features = {..._features, key: enabled});
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(SnackBar(
          content: Text(enabled
              ? '${FeatureService.metadata[key]!.label} enabled.'
              : '${FeatureService.metadata[key]!.label} disabled and data deleted.'),
          duration: const Duration(seconds: 3),
        ));
    }
  }

  Future<bool> _showDeleteConfirmDialog(String key) async {
    final meta = FeatureService.metadata[key]!;
    final ctrl = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        bool canConfirm = false;
        return StatefulBuilder(builder: (ctx, setSt) {
          return AlertDialog(
            backgroundColor: cCard(context),
            title: Row(children: [
              Icon(Icons.warning_amber_rounded, color: kError, size: 22),
              const SizedBox(width: 10),
              const Text('Disable Feature',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ]),
            content: SizedBox(
              width: 400,
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Disabling "${meta.label}" will permanently delete all data for your section from Firestore. This action cannot be undone and the data cannot be recovered.',
                    style: TextStyle(color: cMuted(context), fontSize: 13)),
                const SizedBox(height: 16),
                Text('Type DELETE to confirm:',
                    style: TextStyle(color: cNavy(context), fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(
                  controller: ctrl,
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: 'DELETE',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                  onChanged: (v) => setSt(() => canConfirm = v.trim() == 'DELETE'),
                ),
              ]),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kError,
                  foregroundColor: Colors.white,
                ),
                onPressed: canConfirm
                    ? () => Navigator.pop(ctx, true)
                    : null,
                child: const Text('Disable & Delete'),
              ),
            ],
          );
        });
      },
    );
    ctrl.dispose();
    return result ?? false;
  }

  Future<void> _requestAccess(String featureKey, FeatureMeta meta) async {
    const uuid = Uuid();
    final notif = AppNotification(
      id: uuid.v4(),
      title: 'Feature Access Request',
      body:
          'Section "${widget.sectionId}" has requested access to ${meta.label}.',
      timestamp: DateTime.now(),
      actionType: 'feature_request',
      metadata: {
        'featureKey': featureKey,
        'requesterId': widget.sectionId,
      },
    );
    await NotificationService.instance
        .addNotification(widget.schoolId, notif);
    if (mounted) {
      ScaffoldMessenger.of(context)
        ..clearSnackBars()
        ..showSnackBar(const SnackBar(
          content: Text('Request sent to admin.'),
          duration: Duration(seconds: 2),
        ));
    }
  }
}

// ── Feature card ─────────────────────────────────────────────
class _FeatureCard extends StatefulWidget {
  final String featureKey;
  final FeatureMeta meta;
  final bool enabled;
  final bool isAdmin;
  final ValueChanged<bool> onToggle;
  final VoidCallback? onRequestAccess;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.featureKey,
    required this.meta,
    required this.enabled,
    required this.isAdmin,
    required this.onToggle,
    required this.onTap,
    this.onRequestAccess,
  });

  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    final icon = IconData(widget.meta.iconCodePoint, fontFamily: 'MaterialIcons');
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit:  (_) => setState(() => _hover = false),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          decoration: BoxDecoration(
            color: cCard(context),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
                color: _hover
                    ? cNavy(context).withValues(alpha: 0.25)
                    : cBorder(context)),
            boxShadow: _hover
                ? [BoxShadow(
                    color:      cNavy(context).withValues(alpha: 0.06),
                    blurRadius: 10,
                    offset:     const Offset(0, 3))]
                : [],
          ),
          child: Row(
            children: [
              // Icon
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color:        (widget.enabled ? kNavy : kMuted)
                      .withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon,
                    color: widget.enabled ? kNavy : kMuted, size: 18),
              ),
              const SizedBox(width: 14),

              // Label + description
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.meta.label,
                        style: TextStyle(
                            color:      cNavy(context),
                            fontSize:   14,
                            fontWeight: FontWeight.w700)),
                    const SizedBox(height: 2),
                    Text(widget.meta.description,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: cMuted(context), fontSize: 12)),
                  ],
                ),
              ),
              const SizedBox(width: 12),

              // Admin-only badge / request access / toggle
              if (widget.meta.adminOnly && !widget.isAdmin)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color:        kMuted.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text('Admin only',
                      style: TextStyle(
                          color:      kMuted,
                          fontSize:   9.5,
                          fontWeight: FontWeight.w600)),
                )
              else if (widget.onRequestAccess != null)
                GestureDetector(
                  onTap: widget.onRequestAccess,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color:        kTeal.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: kTeal.withValues(alpha: 0.3)),
                    ),
                    child: const Text('Request',
                        style: TextStyle(
                            color:      kTeal,
                            fontSize:   11,
                            fontWeight: FontWeight.w600)),
                  ),
                )
              else
                GestureDetector(
                  onTap: () => widget.onToggle(!widget.enabled),
                  child: _MiniToggle(enabled: widget.enabled),
                ),

              const SizedBox(width: 6),
              Icon(Icons.chevron_right_rounded,
                  color: cMuted(context), size: 16),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniToggle extends StatelessWidget {
  final bool enabled;
  const _MiniToggle({required this.enabled});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      width: 36,
      height: 20,
      decoration: BoxDecoration(
        color: enabled ? kNavy : cBorder(context),
        borderRadius: BorderRadius.circular(10),
      ),
      child: AnimatedAlign(
        duration: const Duration(milliseconds: 220),
        alignment:
            enabled ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          width: 16,
          height: 16,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
          ),
        ),
      ),
    );
  }
}
