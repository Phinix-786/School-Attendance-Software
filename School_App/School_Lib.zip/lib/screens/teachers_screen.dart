// lib/screens/teachers_screen.dart  (UPDATED)
// Changes:
//   • Per-class subject assignment field
//   • "Class Teacher" toggle per class (only class teacher can mark attendance)
//   • Table shows SUBJECT and CLASS TEACHER badge columns
//   • Student login credentials auto-generated when adding students
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class TeachersScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final bool   isAdmin;
  const TeachersScreen(
      {super.key,
      required this.schoolId,
      required this.sectionId,
      this.isAdmin = false});

  @override
  State<TeachersScreen> createState() => _TeachersScreenState();
}

class _TeachersScreenState extends State<TeachersScreen> {
  List<Map<String, dynamic>> _sections        = [];
  String                     _activeSectionId = '';
  bool                       _sectionsLoading = false;

  // Polled data (replaces StreamBuilders)
  List<Teacher>     _teachers    = [];
  List<SchoolClass> _classes     = [];
  bool              _dataLoading = false;
  Timer?            _pollTimer;

  @override
  void initState() {
    super.initState();
    if (widget.isAdmin && widget.sectionId.isEmpty) {
      _loadSections();
    } else {
      _activeSectionId = widget.sectionId;
      _loadData();
      _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadData());
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadData() async {
    if (_activeSectionId.isEmpty) return;
    setState(() => _dataLoading = true);
    final results = await Future.wait([
      SchoolFirebaseService.getAllTeachers(widget.schoolId, _activeSectionId),
      SchoolFirebaseService.getClasses(widget.schoolId, _activeSectionId),
    ]);
    if (mounted) {
      setState(() {
        _teachers    = results[0] as List<Teacher>;
        _classes     = results[1] as List<SchoolClass>;
        _dataLoading = false;
      });
    }
  }

  Future<void> _loadSections() async {
    setState(() => _sectionsLoading = true);
    final list = await SchoolFirebaseService.getSections(widget.schoolId);
    if (mounted) {
      setState(() {
        _sections        = list;
        _activeSectionId =
            list.isNotEmpty ? (list.first['id'] as String? ?? '') : '';
        _sectionsLoading = false;
      });
      _loadData();
      _pollTimer?.cancel();
      _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _loadData());
    }
  }

  Widget _buildSectionPicker(BuildContext context) {
    if (_sectionsLoading) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(children: [
          SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: cNavy(context))),
          const SizedBox(width: 10),
          Text('Loading sections…',
              style: TextStyle(color: cMuted(context), fontSize: 13)),
        ]),
      );
    }
    if (_sections.isEmpty) {
      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color:        Colors.orange.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
          border:       Border.all(color: Colors.orange.withValues(alpha: 0.3)),
        ),
        child: Row(children: [
          const Icon(Icons.warning_amber_rounded,
              color: Colors.orange, size: 16),
          const SizedBox(width: 8),
          Text('No sections found.',
              style: TextStyle(color: cNavy(context), fontSize: 13)),
        ]),
      );
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(10),
        border:       Border.all(color: cBorder(context)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_special_rounded, size: 15, color: cMuted(context)),
          const SizedBox(width: 8),
          Text('Section:', style: TextStyle(color: cMuted(context), fontSize: 13)),
          const SizedBox(width: 8),
          DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value:        _activeSectionId.isNotEmpty ? _activeSectionId : null,
              isDense:      true,
              style:        TextStyle(
                  color:      cNavy(context),
                  fontSize:   13,
                  fontWeight: FontWeight.w600),
              dropdownColor: cCard(context),
              onChanged: (v) {
                if (v != null) setState(() => _activeSectionId = v);
              },
              items: _sections.map((s) {
                final id   = s['id']   as String? ?? s['sectionId'] as String? ?? '';
                final name = s['name'] as String? ?? id;
                return DropdownMenuItem(value: id, child: Text(name));
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Future<String> _nextTeacherId() async {
    final all = await SchoolFirebaseService.getAllTeachers(
        widget.schoolId, _activeSectionId);
    return 'TCH-${(all.length + 1).toString().padLeft(2, '0')}';
  }

  String _genPassword() {
    final rand = Random();
    return 'tch${rand.nextInt(900) + 100}';
  }

  void _copyCreds(Teacher t) {
    final sb = StringBuffer();
    sb.writeln('Teacher: ${t.name}');
    sb.writeln('Teacher ID: ${t.id}');
    sb.writeln('Password: ${t.password}');
    if (t.classSubjects.isNotEmpty) {
      sb.writeln('Subjects:');
      t.classSubjects.forEach((cid, sub) => sb.writeln('  Class $cid → $sub'));
    }
    if (t.classTeacherOf.isNotEmpty) {
      sb.writeln('Class Teacher of: ${t.classTeacherOf.join(', ')}');
    }
    Clipboard.setData(ClipboardData(text: sb.toString()));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Credentials copied to clipboard!'),
      backgroundColor: Color(0xFF16A34A),
      duration: Duration(seconds: 2),
    ));
  }

  Future<void> _showDialog({Teacher? teacher}) async {
    final classes = await SchoolFirebaseService.getClasses(
        widget.schoolId, _activeSectionId);
    final teacherId = teacher == null
        ? await _nextTeacherId()
        : teacher.id;
    final autoPass  = teacher?.password.isNotEmpty == true
        ? teacher!.password
        : _genPassword();

    if (!mounted) return;

    final teacherIdCtrl = TextEditingController(text: teacherId);
    final nameCtrl      = TextEditingController(text: teacher?.name ?? '');
    final emailCtrl     = TextEditingController(text: teacher?.email ?? '');
    final passCtrl      = TextEditingController(text: autoPass);
    final messenger     = ScaffoldMessenger.of(context);

    await showDialog<void>(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.4),
      builder: (dialogCtx) => _TeacherDialog(
        teacher:       teacher,
        classes:       classes,
        teacherIdCtrl: teacherIdCtrl,
        nameCtrl:      nameCtrl,
        emailCtrl:     emailCtrl,
        passCtrl:      passCtrl,
        schoolId:      widget.schoolId,
        sectionId:     _activeSectionId,
        messenger:     messenger,
      ),
    );

    teacherIdCtrl.dispose();
    nameCtrl.dispose();
    emailCtrl.dispose();
    passCtrl.dispose();
    _loadData(); // reload after dialog closes (add or edit)
  }

  void _confirmDelete(Teacher t) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: cCard(ctx),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
          title: Text('Remove Teacher?',
              style: TextStyle(
                  color:      cNavy(ctx),
                  fontSize:   16,
                  fontWeight: FontWeight.w800)),
          content: Text('Remove ${t.name} from the system?',
              style: TextStyle(color: cMuted(ctx), fontSize: 13.5)),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text('Cancel',
                    style: TextStyle(color: cMuted(ctx)))),
            TextButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  SchoolFirebaseService.deleteTeacher(
                      widget.schoolId, _activeSectionId, t.id)
                    .then((_) => _loadData());
                },
                child: const Text('Remove',
                    style: TextStyle(
                        color: kError, fontWeight: FontWeight.w700))),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(context),
            const SizedBox(height: 18),
            if (widget.isAdmin && widget.sectionId.isEmpty)
              _buildSectionPicker(context),
            if (_activeSectionId.isEmpty)
              const Expanded(
                  child: Center(
                      child: Text(
                          'Select a section above to view teachers')))
            else
              Expanded(child: _buildTable(context)),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Text('🏫', style: TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
              Text('Teacher & Class Management',
                  style: TextStyle(
                      color:      cNavy(context),
                      fontSize:   19,
                      fontWeight: FontWeight.w800)),
            ]),
            const SizedBox(height: 3),
            Padding(
              padding: const EdgeInsets.only(left: 28),
              child: Text(
                'Assign classes, subjects, and set Class Teacher per class.',
                style: TextStyle(
                    color:    cMuted(context).withValues(alpha: 0.8),
                    fontSize: 12),
              ),
            ),
          ],
        ),
        const Spacer(),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: cNavy(context),
            foregroundColor: isDark(context) ? kDarkBg : Colors.white,
            elevation:       0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 12),
          ),
          onPressed: () => _showDialog(),
          child: const Text('+ Add Teacher',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
        ),
      ],
    );
  }

  Widget _buildTable(BuildContext context) {
    if (_dataLoading && _teachers.isEmpty) {
      return Center(child: CircularProgressIndicator(
          color: cNavy(context), strokeWidth: 2));
    }
    // Use polled _teachers and _classes
    {
      final teachers = _teachers;
      {
        final classMap = <String, String>{
          for (final c in _classes) c.id: c.name,
        };

            if (teachers.isEmpty) {
              return Container(
                decoration: BoxDecoration(
                  color:        cCard(context),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: cBorder(context)),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.person_outline_rounded,
                          color: cMuted(context).withValues(alpha: 0.3),
                          size: 44),
                      const SizedBox(height: 12),
                      Text('No teachers yet',
                          style: TextStyle(
                              color: cMuted(context).withValues(alpha: 0.65),
                              fontSize: 14)),
                    ],
                  ),
                ),
              );
            }

            const cols = [
              _ColDef('ID',              0.09),
              _ColDef('NAME',            0.16),
              _ColDef('CLASSES',         0.16),
              _ColDef('SUBJECTS',        0.16),
              _ColDef('CLASS TEACHER OF',0.14),
              _ColDef('PASSWORD',        0.10),
              _ColDef('ACTIONS',         0.19),
            ];

            return Container(
              decoration: BoxDecoration(
                color:        cCard(context),
                borderRadius: BorderRadius.circular(14),
                border:       Border.all(color: cBorder(context)),
                boxShadow: [
                  BoxShadow(
                      color:      cNavy(context).withValues(alpha: 0.04),
                      blurRadius: 10,
                      offset:     const Offset(0, 3)),
                ],
              ),
              child: Column(
                children: [
                  // Header row
                  Container(
                    decoration: BoxDecoration(
                      color: cBorder(context).withValues(alpha: 0.5),
                      borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(13)),
                    ),
                    child: _TableRow(
                      cols:     cols,
                      isHeader: true,
                      cells: cols
                          .map((c) => _headerCell(cMuted(context), c.label))
                          .toList(),
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      padding:      EdgeInsets.zero,
                      itemCount:    teachers.length,
                      separatorBuilder: (_, __) =>
                          Divider(height: 1, color: cBorder(context)),
                      itemBuilder: (_, i) {
                        final t          = teachers[i];
                        final classNames = t.assignedClassIds
                            .map((id) => classMap[id] ?? id)
                            .toList();
                        // Build subject chip list
                        final subjectChips = t.classSubjects.entries
                            .where((e) =>
                                t.assignedClassIds.contains(e.key))
                            .map((e) =>
                                '${classMap[e.key] ?? e.key}: ${e.value}')
                            .toList();
                        // Build class-teacher chip list
                        final ctChips = t.classTeacherOf
                            .map((id) => classMap[id] ?? id)
                            .toList();

                        return _TableRow(
                          cols: cols,
                          cells: [
                            Text(t.id,
                                style: TextStyle(
                                    color:    cMuted(context).withValues(alpha: 0.75),
                                    fontSize: 12)),
                            Text(t.name,
                                style: TextStyle(
                                    color:      cNavy(context),
                                    fontSize:   13,
                                    fontWeight: FontWeight.w700)),
                            Wrap(
                              spacing: 5, runSpacing: 5,
                              children: classNames
                                  .map((cn) => _Chip(label: cn, color: kNavy))
                                  .toList(),
                            ),
                            Wrap(
                              spacing: 5, runSpacing: 5,
                              children: subjectChips
                                  .map((s) => _Chip(
                                      label: s, color: kTeal, small: true))
                                  .toList(),
                            ),
                            Wrap(
                              spacing: 5, runSpacing: 5,
                              children: ctChips.isEmpty
                                  ? [
                                      Text('—',
                                          style: TextStyle(
                                              color: cMuted(context),
                                              fontSize: 12))
                                    ]
                                  : ctChips
                                      .map((cn) => _Chip(
                                          label: '★ $cn',
                                          color: const Color(0xFFF59E0B)))
                                      .toList(),
                            ),
                            Text(t.password,
                                style: TextStyle(
                                    color:      cBlue(context)
                                        .withValues(alpha: 0.75),
                                    fontSize:   12,
                                    fontFamily: 'monospace')),
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _ActionBtn(
                                  icon:  Icons.edit_outlined,
                                  label: 'Edit',
                                  color: cNavy(context),
                                  onTap: () => _showDialog(teacher: t),
                                ),
                                const SizedBox(width: 8),
                                _ActionBtn(
                                  icon:  Icons.copy_outlined,
                                  label: 'Copy',
                                  color: cBlue(context),
                                  onTap: () => _copyCreds(t),
                                ),
                                const SizedBox(width: 8),
                                _ActionBtn(
                                  icon:  Icons.delete_outline_rounded,
                                  label: 'Remove',
                                  color: kError,
                                  onTap: () => _confirmDelete(t),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
      }
    }
  }
}

// ── Teacher Dialog ────────────────────────────────────────────
class _TeacherDialog extends StatefulWidget {
  final Teacher?              teacher;
  final List<SchoolClass>     classes;
  final TextEditingController teacherIdCtrl;
  final TextEditingController nameCtrl;
  final TextEditingController emailCtrl;
  final TextEditingController passCtrl;
  final String                schoolId;
  final String                sectionId;
  final ScaffoldMessengerState messenger;

  const _TeacherDialog({
    required this.teacher, required this.classes,
    required this.teacherIdCtrl, required this.nameCtrl,
    required this.emailCtrl, required this.passCtrl,
    required this.schoolId, required this.sectionId,
    required this.messenger,
  });

  @override
  State<_TeacherDialog> createState() => _TeacherDialogState();
}

class _TeacherDialogState extends State<_TeacherDialog> {
  late Set<String>            _selected;    // assigned class ids
  late Set<String>            _ctOf;        // class teacher of
  late Map<String, TextEditingController> _subjCtrls; // classId → subject ctrl
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _selected  = Set<String>.from(widget.teacher?.assignedClassIds ?? []);
    _ctOf      = Set<String>.from(widget.teacher?.classTeacherOf   ?? []);
    _subjCtrls = {
      for (final c in widget.classes)
        c.id: TextEditingController(
            text: widget.teacher?.classSubjects[c.id] ?? '')
    };
  }

  @override
  void dispose() {
    for (final ctrl in _subjCtrls.values) ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (widget.nameCtrl.text.trim().isEmpty) return;
    if (widget.teacherIdCtrl.text.trim().isEmpty) return;
    if (_saving) return;
    setState(() => _saving = true);

    final subjects = <String, String>{};
    for (final classId in _selected) {
      final sub = _subjCtrls[classId]?.text.trim() ?? '';
      if (sub.isNotEmpty) subjects[classId] = sub;
    }

    final t = Teacher(
      id:               widget.teacher?.id ?? widget.teacherIdCtrl.text.trim(),
      schoolId:         widget.schoolId,
      name:             widget.nameCtrl.text.trim(),
      phone:            widget.teacher?.phone ?? '',
      email:            widget.emailCtrl.text.trim(),
      password:         widget.passCtrl.text.trim(),
      assignedClassIds: _selected.toList(),
      classTeacherOf:   _ctOf.toList(),
      classSubjects:    subjects,
    );

    try {
      if (widget.teacher == null) {
        await SchoolFirebaseService.addTeacher(t, widget.sectionId);
      } else {
        await SchoolFirebaseService.updateTeacher(t, widget.sectionId);
      }
    } catch (_) {
      if (mounted) setState(() => _saving = false);
      return;
    }

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final cardCol   = cCard(context);
    final navyCol   = cNavy(context);
    final bgCol     = cBg(context);
    final borderCol = cBorder(context);
    final dark      = isDark(context);

    return Dialog(
      backgroundColor: cardCol,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 380, vertical: 60),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(28, 24, 28, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  widget.teacher == null
                      ? '+ Add New Teacher'
                      : 'Edit Teacher',
                  style: TextStyle(
                      color:      navyCol,
                      fontSize:   16,
                      fontWeight: FontWeight.w800),
                ),
                const Spacer(),
                _CloseButton(onTap: () => Navigator.pop(context)),
              ],
            ),
            const SizedBox(height: 20),

            // ID + Name
            Row(
              children: [
                Expanded(
                  child: _DlgField(
                    label: 'TEACHER ID',
                    controller: widget.teacherIdCtrl,
                    hint: 'e.g. TCH-01',
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: _DlgField(
                    label: 'FULL NAME',
                    controller: widget.nameCtrl,
                    hint: "Sir / Ma'am Name",
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Password
            _DlgField(
              label:      'AUTO-GENERATED PASSWORD',
              controller: widget.passCtrl,
            ),
            const SizedBox(height: 16),

            // ── Class assignment with subject + class-teacher toggle ──
            const _FieldLabel(
                label:
                    'ASSIGN CLASSES  ·  SET SUBJECT  ·  TOGGLE CLASS TEACHER'),
            const SizedBox(height: 6),
            Container(
              height: 220,
              decoration: BoxDecoration(
                color:        bgCol,
                border:       Border.all(color: borderCol),
                borderRadius: BorderRadius.circular(9),
              ),
              child: widget.classes.isEmpty
                  ? Center(
                      child: Text('No classes in this section.',
                          style: TextStyle(
                              color:    cMuted(context), fontSize: 13)))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      itemCount: widget.classes.length,
                      itemBuilder: (_, i) {
                        final c      = widget.classes[i];
                        final isSel  = _selected.contains(c.id);
                        final isCT   = _ctOf.contains(c.id);

                        return Column(
                          children: [
                            InkWell(
                              onTap: () => setState(() {
                                if (isSel) {
                                  _selected.remove(c.id);
                                  _ctOf.remove(c.id);
                                } else {
                                  _selected.add(c.id);
                                }
                              }),
                              child: Container(
                                color: isSel
                                    ? navyCol.withValues(
                                        alpha: dark ? 0.2 : 0.07)
                                    : Colors.transparent,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 9),
                                child: Row(
                                  children: [
                                    // Checkbox-style icon
                                    Icon(
                                      isSel
                                          ? Icons.check_box_rounded
                                          : Icons
                                              .check_box_outline_blank_rounded,
                                      size:  18,
                                      color: isSel
                                          ? navyCol
                                          : cMuted(context),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(c.name,
                                          style: TextStyle(
                                              color: isSel
                                                  ? navyCol
                                                  : cBlue(context),
                                              fontSize:   13,
                                              fontWeight: isSel
                                                  ? FontWeight.w700
                                                  : FontWeight.w500)),
                                    ),
                                    if (isSel) ...[
                                      // Subject field (compact)
                                      SizedBox(
                                        width: 140,
                                        height: 30,
                                        child: TextField(
                                          controller: _subjCtrls[c.id],
                                          style: TextStyle(
                                              color:    navyCol,
                                              fontSize: 12),
                                          decoration: InputDecoration(
                                            hintText:  'Subject name',
                                            hintStyle: TextStyle(
                                                color:    cMuted(context),
                                                fontSize: 11),
                                            isDense:   true,
                                            contentPadding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical:   6),
                                            border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(6),
                                                borderSide: BorderSide(
                                                    color: borderCol)),
                                            enabledBorder:
                                                OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            6),
                                                    borderSide: BorderSide(
                                                        color: borderCol)),
                                          ),
                                          onTap: () {},
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      // Class teacher toggle
                                      GestureDetector(
                                        onTap: () => setState(() {
                                          if (isCT) {
                                            _ctOf.remove(c.id);
                                          } else {
                                            _ctOf.add(c.id);
                                          }
                                        }),
                                        child: Tooltip(
                                          message: isCT
                                              ? 'Class Teacher (can mark attendance)'
                                              : 'Not class teacher – tap to set',
                                          child: Container(
                                            padding:
                                                const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical:   5),
                                            decoration: BoxDecoration(
                                              color: isCT
                                                  ? const Color(0xFFF59E0B)
                                                      .withValues(alpha: 0.15)
                                                  : Colors.transparent,
                                              borderRadius:
                                                  BorderRadius.circular(6),
                                              border: Border.all(
                                                  color: isCT
                                                      ? const Color(
                                                          0xFFF59E0B)
                                                      : borderCol),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(
                                                  isCT
                                                      ? Icons.star_rounded
                                                      : Icons.star_outline_rounded,
                                                  size:  13,
                                                  color: isCT
                                                      ? const Color(
                                                          0xFFF59E0B)
                                                      : cMuted(context),
                                                ),
                                                const SizedBox(width: 4),
                                                Text(
                                                  'Class Teacher',
                                                  style: TextStyle(
                                                      color: isCT
                                                          ? const Color(
                                                              0xFFF59E0B)
                                                          : cMuted(context),
                                                      fontSize:   10,
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ),
                            if (i < widget.classes.length - 1)
                              Divider(height: 1, color: borderCol),
                          ],
                        );
                      },
                    ),
            ),
            const SizedBox(height: 6),
            Text(
              '★ = Class Teacher (can mark attendance).  Other teachers can still log in and send homework.',
              style: TextStyle(
                  color:    cMuted(context),
                  fontSize: 10.5,
                  fontStyle: FontStyle.italic),
            ),
            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                _CancelBtn(onTap: () => Navigator.pop(context)),
                const SizedBox(width: 10),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: navyCol,
                    foregroundColor: dark ? kDarkBg : Colors.white,
                    elevation:       0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(9)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 12),
                  ),
                  icon: _saving
                      ? const SizedBox(
                          width:  13,
                          height: 13,
                          child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color:       Colors.white))
                      : const Text('🏫',
                          style: TextStyle(fontSize: 13)),
                  label: Text(
                    widget.teacher == null ? 'Add & Sync' : 'Update',
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 13),
                  ),
                  onPressed: _saving ? null : _save,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Shared small widgets ──────────────────────────────────────
class _ColDef {
  final String label;
  final double flex;
  const _ColDef(this.label, this.flex);
}

class _TableRow extends StatelessWidget {
  final List<_ColDef> cols;
  final List<Widget>  cells;
  final bool          isHeader;
  const _TableRow(
      {required this.cols, required this.cells, this.isHeader = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: LayoutBuilder(builder: (_, bc) {
        return Row(
          children: List.generate(cols.length, (i) {
            return SizedBox(
                width: bc.maxWidth * cols[i].flex, child: cells[i]);
          }),
        );
      }),
    );
  }
}

Widget _headerCell(Color mutedCol, String label) => Text(
      label,
      style: TextStyle(
          color:         mutedCol.withValues(alpha: 0.75),
          fontSize:      10.5,
          fontWeight:    FontWeight.w700,
          letterSpacing: 0.7),
    );

class _FieldLabel extends StatelessWidget {
  final String label;
  const _FieldLabel({required this.label});

  @override
  Widget build(BuildContext context) => Text(label,
      style: TextStyle(
          color:         cNavy(context).withValues(alpha: 0.7),
          fontSize:      10.5,
          fontWeight:    FontWeight.w700,
          letterSpacing: 0.8));
}

class _DlgField extends StatelessWidget {
  final String                label;
  final TextEditingController controller;
  final String?               hint;
  final bool                  readOnly;

  const _DlgField({
    required this.label,
    required this.controller,
    this.hint,
    this.readOnly = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _FieldLabel(label: label),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          readOnly:   readOnly,
          style: TextStyle(fontSize: 13, color: cNavy(context)),
          decoration: InputDecoration(
            hintText:  hint,
            hintStyle: TextStyle(
                color:    cMuted(context).withValues(alpha: 0.5),
                fontSize: 13),
            filled:    true,
            fillColor: cBg(context),
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 11),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(9),
                borderSide: BorderSide(color: cBorder(context))),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(9),
                borderSide: BorderSide(color: cBorder(context))),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(9),
                borderSide: BorderSide(
                    color: isDark(context) ? kDarkTeal : kTeal,
                    width: 1.5)),
          ),
        ),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color  color;
  final bool   small;
  const _Chip({required this.label, required this.color, this.small = false});

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: small ? 7 : 9, vertical: small ? 3 : 4),
      decoration: BoxDecoration(
        color:        color.withValues(alpha: dark ? 0.18 : 0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: TextStyle(
              color:      color,
              fontSize:   small ? 10.5 : 11.5,
              fontWeight: FontWeight.w600)),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData     icon;
  final String       label;
  final Color        color;
  final VoidCallback onTap;
  const _ActionBtn(
      {required this.icon,
      required this.label,
      required this.color,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color.withValues(alpha: 0.8), size: 14),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  color:      color,
                  fontSize:   12,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _CloseButton extends StatelessWidget {
  final VoidCallback onTap;
  const _CloseButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28, height: 28,
        decoration: BoxDecoration(
            color:        cBorder(context),
            borderRadius: BorderRadius.circular(8)),
        child: Icon(Icons.close_rounded,
            size: 15, color: cMuted(context).withValues(alpha: 0.7)),
      ),
    );
  }
}

class _CancelBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _CancelBtn({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        foregroundColor: cMuted(context),
        side: BorderSide(color: cBorder(context), width: 1.5),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(9)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      ),
      onPressed: onTap,
      child: const Text('Cancel',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
    );
  }
}
