// lib/screens/documents_screen.dart
// Admin-only. Two tabs: Staff Documents | Student Documents.
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class DocumentsScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;

  const DocumentsScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
  });

  @override
  State<DocumentsScreen> createState() => _DocumentsScreenState();
}

class _DocumentsScreenState extends State<DocumentsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Column(
        children: [
          // Tab bar header
          Container(
            color: cCard(context),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Document Storage',
                          style: TextStyle(
                              color: cNavy(context),
                              fontSize: 22,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('Store and manage staff and student documents.',
                          style: TextStyle(
                              color: cMuted(context), fontSize: 13)),
                      const SizedBox(height: 14),
                    ],
                  ),
                ),
                TabBar(
                  controller: _tabCtrl,
                  labelColor: kNavy,
                  unselectedLabelColor: kMuted,
                  indicatorColor: kNavy,
                  indicatorWeight: 2.5,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  tabs: const [
                    Tab(text: 'Staff Documents'),
                    Tab(text: 'Student Documents'),
                  ],
                ),
                Divider(height: 1, color: cBorder(context)),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _StaffDocumentsTab(
                    schoolId: widget.schoolId,
                    sectionId: widget.sectionId),
                _StudentDocumentsTab(
                    schoolId: widget.schoolId,
                    sectionId: widget.sectionId),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Staff Documents Tab ───────────────────────────────────────

class _StaffDocumentsTab extends StatefulWidget {
  final String schoolId;
  final String sectionId;

  const _StaffDocumentsTab(
      {required this.schoolId, required this.sectionId});

  @override
  State<_StaffDocumentsTab> createState() => _StaffDocumentsTabState();
}

class _StaffDocumentsTabState extends State<_StaffDocumentsTab> {
  List<Teacher> _teachers = [];
  Teacher? _selected;
  List<StoredDocument> _docs = [];
  bool _loadingTeachers = true;
  bool _loadingDocs = false;

  @override
  void initState() {
    super.initState();
    _loadTeachers();
  }

  Future<void> _loadTeachers() async {
    final teachers = await SchoolFirebaseService.getAllTeachers(
        widget.schoolId, widget.sectionId);
    if (mounted) {
      setState(() {
        _teachers = teachers;
        _loadingTeachers = false;
      });
    }
  }

  Future<void> _selectTeacher(Teacher t) async {
    setState(() {
      _selected = t;
      _loadingDocs = true;
      _docs = [];
    });
    final docs = await SchoolFirebaseService.getTeacherDocuments(
        widget.schoolId, widget.sectionId, t.id);
    if (mounted) {
      setState(() {
        _docs = docs;
        _loadingDocs = false;
      });
    }
  }

  Future<void> _upload() async {
    if (_selected == null) return;
    final result = await FilePicker.pickFiles(withData: true);
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    if (file.bytes == null && file.path == null) return;

    final bytes = file.bytes ?? await File(file.path!).readAsBytes();
    final b64 = 'data:application/octet-stream;base64,${base64Encode(bytes)}';

    final typeResult = await _showDocTypeDialog();
    if (!mounted || typeResult == null) return;

    const uuid = Uuid();
    final doc = StoredDocument(
      id: uuid.v4(),
      name: file.name,
      type: typeResult,
      fileUrl: b64,
      uploadedBy: 'Admin',
      notes: '',
      uploadedAt: DateTime.now(),
    );
    await SchoolFirebaseService.addTeacherDocument(
        widget.schoolId, widget.sectionId, _selected!.id, doc);
    await _selectTeacher(_selected!);
  }

  Future<void> _deleteDoc(StoredDocument doc) async {
    final ok = await _confirmDelete(doc.name);
    if (!ok) return;
    await SchoolFirebaseService.deleteTeacherDocument(
        widget.schoolId, widget.sectionId, _selected!.id, doc.id);
    await _selectTeacher(_selected!);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Sidebar: teacher list
        _buildTeacherSidebar(),
        VerticalDivider(width: 1, color: cBorder(context)),
        // Right panel: documents
        Expanded(child: _buildDocPanel()),
      ],
    );
  }

  Widget _buildTeacherSidebar() {
    return Container(
      width: 220,
      color: cCard(context),
      child: _loadingTeachers
          ? const Center(child: CircularProgressIndicator())
          : _teachers.isEmpty
              ? Center(
                  child: Text('No teachers',
                      style: TextStyle(color: cMuted(context))))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  itemCount: _teachers.length,
                  itemBuilder: (_, i) {
                    final t = _teachers[i];
                    final sel = _selected?.id == t.id;
                    return ListTile(
                      dense: true,
                      selected: sel,
                      selectedTileColor:
                          cNavy(context).withValues(alpha: 0.07),
                      leading: CircleAvatar(
                        radius: 16,
                        backgroundColor:
                            cNavy(context).withValues(alpha: 0.10),
                        child: Text(
                          t.name.isNotEmpty
                              ? t.name[0].toUpperCase()
                              : '?',
                          style: TextStyle(
                              color: cNavy(context),
                              fontSize: 12,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                      title: Text(t.name,
                          style: TextStyle(
                              color: cNavy(context),
                              fontSize: 13,
                              fontWeight: sel
                                  ? FontWeight.w700
                                  : FontWeight.w500),
                          overflow: TextOverflow.ellipsis),
                      onTap: () => _selectTeacher(t),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    );
                  },
                ),
    );
  }

  Widget _buildDocPanel() {
    if (_selected == null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.folder_open_rounded,
              color: cMuted(context).withValues(alpha: 0.4), size: 48),
          const SizedBox(height: 12),
          Text('Select a teacher to view documents',
              style: TextStyle(color: cMuted(context), fontSize: 14)),
        ]),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Container(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          color: cCard(context),
          child: Row(children: [
            Expanded(
              child: Text('${_selected!.name} — Documents',
                  style: TextStyle(
                      color: cNavy(context),
                      fontSize: 15,
                      fontWeight: FontWeight.w700)),
            ),
            _UploadButton(onTap: _upload),
          ]),
        ),
        Divider(height: 1, color: cBorder(context)),
        Expanded(
          child: _loadingDocs
              ? const Center(child: CircularProgressIndicator())
              : _docs.isEmpty
                  ? Center(
                      child: Text('No documents uploaded.',
                          style: TextStyle(color: cMuted(context))))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: _docs.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 10),
                      itemBuilder: (_, i) =>
                          _DocTile(doc: _docs[i], onDelete: _deleteDoc),
                    ),
        ),
      ],
    );
  }

  Future<String?> _showDocTypeDialog() {
    const types = ['CV', 'CNIC', 'Contract', 'Certificate', 'Other'];
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(context),
        title: Text('Document Type',
            style: TextStyle(
                color: cNavy(context), fontWeight: FontWeight.w700)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: types.map((t) {
            return ListTile(
              title: Text(t, style: TextStyle(color: cNavy(context))),
              dense: true,
              onTap: () => Navigator.pop(ctx, t),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(String name) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(context),
        title: const Text('Delete Document',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Text('Delete "$name"? This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: kError, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}

// ── Student Documents Tab ────────────────────────────────────

class _StudentDocumentsTab extends StatefulWidget {
  final String schoolId;
  final String sectionId;

  const _StudentDocumentsTab(
      {required this.schoolId, required this.sectionId});

  @override
  State<_StudentDocumentsTab> createState() => _StudentDocumentsTabState();
}

class _StudentDocumentsTabState extends State<_StudentDocumentsTab> {
  List<SchoolClass> _classes = [];
  SchoolClass? _selectedClass;
  List<Student> _students = [];
  Student? _selectedStudent;
  List<StoredDocument> _docs = [];
  bool _loadingClasses = true;
  bool _loadingStudents = false;
  bool _loadingDocs = false;

  @override
  void initState() {
    super.initState();
    _loadClasses();
  }

  Future<void> _loadClasses() async {
    final classes = await SchoolFirebaseService.getClasses(
        widget.schoolId, widget.sectionId);
    if (mounted) {
      setState(() {
        _classes = classes;
        _loadingClasses = false;
      });
    }
  }

  Future<void> _selectClass(SchoolClass c) async {
    setState(() {
      _selectedClass = c;
      _selectedStudent = null;
      _docs = [];
      _loadingStudents = true;
    });
    final students = await SchoolFirebaseService.getStudentsByClass(
        widget.schoolId, widget.sectionId, c.id);
    if (mounted) {
      setState(() {
        _students = students;
        _loadingStudents = false;
      });
    }
  }

  Future<void> _selectStudent(Student s) async {
    setState(() {
      _selectedStudent = s;
      _loadingDocs = true;
      _docs = [];
    });
    final docs = await SchoolFirebaseService.getStudentDocuments(
        widget.schoolId, widget.sectionId, s.id);
    if (mounted) {
      setState(() {
        _docs = docs;
        _loadingDocs = false;
      });
    }
  }

  Future<void> _upload() async {
    if (_selectedStudent == null) return;
    final result = await FilePicker.pickFiles(withData: true);
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    if (file.bytes == null && file.path == null) return;

    final bytes = file.bytes ?? await File(file.path!).readAsBytes();
    final b64 = 'data:application/octet-stream;base64,${base64Encode(bytes)}';

    final typeResult = await _showDocTypeDialog();
    if (!mounted || typeResult == null) return;

    const uuid = Uuid();
    final doc = StoredDocument(
      id: uuid.v4(),
      name: file.name,
      type: typeResult,
      fileUrl: b64,
      uploadedBy: 'Admin',
      notes: '',
      uploadedAt: DateTime.now(),
    );
    await SchoolFirebaseService.addStudentDocument(
        widget.schoolId, widget.sectionId, _selectedStudent!.id, doc);
    await _selectStudent(_selectedStudent!);
  }

  Future<void> _deleteDoc(StoredDocument doc) async {
    final ok = await _confirmDelete(doc.name);
    if (!ok) return;
    await SchoolFirebaseService.deleteStudentDocument(
        widget.schoolId, widget.sectionId, _selectedStudent!.id, doc.id);
    await _selectStudent(_selectedStudent!);
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Class sidebar
        Container(
          width: 180,
          color: cCard(context),
          child: _loadingClasses
              ? const Center(child: CircularProgressIndicator())
              : _classes.isEmpty
                  ? Center(
                      child: Text('No classes',
                          style: TextStyle(color: cMuted(context))))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      itemCount: _classes.length,
                      itemBuilder: (_, i) {
                        final c = _classes[i];
                        final sel = _selectedClass?.id == c.id;
                        return ListTile(
                          dense: true,
                          selected: sel,
                          selectedTileColor:
                              cNavy(context).withValues(alpha: 0.07),
                          title: Text(c.name,
                              style: TextStyle(
                                  color: cNavy(context),
                                  fontSize: 13,
                                  fontWeight: sel
                                      ? FontWeight.w700
                                      : FontWeight.w500),
                              overflow: TextOverflow.ellipsis),
                          onTap: () => _selectClass(c),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8)),
                        );
                      },
                    ),
        ),
        VerticalDivider(width: 1, color: cBorder(context)),
        // Student sidebar
        Container(
          width: 180,
          color: cCard(context),
          child: _selectedClass == null
              ? Center(
                  child: Text('Select a class',
                      style: TextStyle(
                          color: cMuted(context), fontSize: 12)))
              : _loadingStudents
                  ? const Center(child: CircularProgressIndicator())
                  : _students.isEmpty
                      ? Center(
                          child: Text('No students',
                              style: TextStyle(color: cMuted(context))))
                      : ListView.builder(
                          padding:
                              const EdgeInsets.symmetric(vertical: 10),
                          itemCount: _students.length,
                          itemBuilder: (_, i) {
                            final s = _students[i];
                            final sel = _selectedStudent?.id == s.id;
                            return ListTile(
                              dense: true,
                              selected: sel,
                              selectedTileColor:
                                  cNavy(context).withValues(alpha: 0.07),
                              title: Text(s.name,
                                  style: TextStyle(
                                      color: cNavy(context),
                                      fontSize: 12.5,
                                      fontWeight: sel
                                          ? FontWeight.w700
                                          : FontWeight.w500),
                                  overflow: TextOverflow.ellipsis),
                              subtitle: Text('Roll: ${s.rollNo}',
                                  style: TextStyle(
                                      color: cMuted(context),
                                      fontSize: 10.5)),
                              onTap: () => _selectStudent(s),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                            );
                          },
                        ),
        ),
        VerticalDivider(width: 1, color: cBorder(context)),
        // Document panel
        Expanded(child: _buildDocPanel()),
      ],
    );
  }

  Widget _buildDocPanel() {
    if (_selectedStudent == null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.folder_open_rounded,
              color: cMuted(context).withValues(alpha: 0.4), size: 48),
          const SizedBox(height: 12),
          Text('Select a student to view documents',
              style: TextStyle(color: cMuted(context), fontSize: 14)),
        ]),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
          color: cCard(context),
          child: Row(children: [
            Expanded(
              child: Text('${_selectedStudent!.name} — Documents',
                  style: TextStyle(
                      color: cNavy(context),
                      fontSize: 15,
                      fontWeight: FontWeight.w700)),
            ),
            _UploadButton(onTap: _upload),
          ]),
        ),
        Divider(height: 1, color: cBorder(context)),
        Expanded(
          child: _loadingDocs
              ? const Center(child: CircularProgressIndicator())
              : _docs.isEmpty
                  ? Center(
                      child: Text('No documents uploaded.',
                          style: TextStyle(color: cMuted(context))))
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: _docs.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 10),
                      itemBuilder: (_, i) =>
                          _DocTile(doc: _docs[i], onDelete: _deleteDoc),
                    ),
        ),
      ],
    );
  }

  Future<String?> _showDocTypeDialog() {
    const types = ['CV', 'CNIC', 'Contract', 'Certificate', 'Other'];
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(context),
        title: Text('Document Type',
            style: TextStyle(
                color: cNavy(context), fontWeight: FontWeight.w700)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: types.map((t) {
            return ListTile(
              title: Text(t, style: TextStyle(color: cNavy(context))),
              dense: true,
              onTap: () => Navigator.pop(ctx, t),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(String name) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cCard(context),
        title: const Text('Delete Document',
            style: TextStyle(fontWeight: FontWeight.w800)),
        content: Text('Delete "$name"? This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: kError, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}

// ── Shared: DocTile ───────────────────────────────────────────

class _DocTile extends StatelessWidget {
  final StoredDocument doc;
  final Future<void> Function(StoredDocument) onDelete;

  const _DocTile({required this.doc, required this.onDelete});

  static const Map<String, Color> _typeBadgeColors = {
    'CV': kTeal,
    'CNIC': kNavy,
    'Contract': kPink,
    'Certificate': Colors.orange,
    'Other': kMuted,
  };

  @override
  Widget build(BuildContext context) {
    final badgeColor = _typeBadgeColors[doc.type] ?? kMuted;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cBorder(context)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: badgeColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.insert_drive_file_rounded,
                color: badgeColor, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(doc.name,
                    style: TextStyle(
                        color: cNavy(context),
                        fontSize: 13,
                        fontWeight: FontWeight.w600),
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: badgeColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(doc.type,
                        style: TextStyle(
                            color: badgeColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    DateFormat('dd MMM yyyy').format(doc.uploadedAt),
                    style: TextStyle(
                        color: cMuted(context), fontSize: 11),
                  ),
                ]),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline_rounded, color: kError, size: 18),
            onPressed: () => onDelete(doc),
            tooltip: 'Delete',
          ),
        ],
      ),
    );
  }
}

// ── Upload button ────────────────────────────────────────────

class _UploadButton extends StatefulWidget {
  final VoidCallback onTap;
  const _UploadButton({required this.onTap});

  @override
  State<_UploadButton> createState() => _UploadButtonState();
}

class _UploadButtonState extends State<_UploadButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 150));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => _ctrl.forward(),
      onExit: (_) => _ctrl.reverse(),
      child: GestureDetector(
        onTap: widget.onTap,
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
            decoration: BoxDecoration(
              color: kNavy
                  .withValues(alpha: 0.06 + _ctrl.value * 0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: kNavy.withValues(alpha: 0.15)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.upload_rounded,
                  color: cNavy(context).withValues(alpha: 0.8),
                  size: 16),
              const SizedBox(width: 7),
              Text('Upload Document',
                  style: TextStyle(
                      color: cNavy(context),
                      fontSize: 12.5,
                      fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
      ),
    );
  }
}
