// lib/screens/dashboard_screen.dart
import 'dart:ui' as ui;
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../app_theme.dart';
import '../models/models.dart';
import '../services/school_firebase_service.dart';

class _DayData {
  final String dayLabel;
  final int    present;
  final int    absent;
  const _DayData(this.dayLabel, this.present, this.absent);
}

class DashboardScreen extends StatefulWidget {
  final String        schoolId;
  final String        schoolName;
  final String        sectionId;
  final VoidCallback? onAddStudent;
  final VoidCallback? onViewAttendance;
  final VoidCallback? onToggleTheme;

  const DashboardScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
    this.onAddStudent,
    this.onViewAttendance,
    this.onToggleTheme,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int    _totalStudents  = 0;
  int    _totalTeachers  = 0;
  int    _todayPresent   = 0;
  int    _todayAbsent    = 0;
  int    _submittedCount = 0;
  bool   _loading        = true;
  List<AttendanceSession> _todaySessions = [];
  List<_DayData>          _weekData      = [];
  List<String>            _resolvedSectionIds = [];
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  /// For admin (empty sectionId) resolves all section IDs; for teachers returns their own.
  Future<List<String>> _resolveSectionIds() async {
    if (widget.sectionId.isNotEmpty) return [widget.sectionId];
    final sections = await SchoolFirebaseService.getSections(widget.schoolId);
    return sections
        .map((s) => s['id'] as String? ?? '')
        .where((id) => id.isNotEmpty)
        .toList();
  }

  Future<void> _load() async {
    try {
      final sectionIds = await _resolveSectionIds();
      if (sectionIds.isEmpty) {
        if (mounted) setState(() => _loading = false);
        return;
      }

      // Aggregate students, teachers and sessions across all relevant sections
      // Use get()-based helpers to avoid opening snapshot listeners on Windows
      final studentLists = await Future.wait(
        sectionIds.map((sid) => SchoolFirebaseService.getAllStudents(widget.schoolId, sid)),
      );
      final teacherLists = await Future.wait(
        sectionIds.map((sid) => SchoolFirebaseService.getAllTeachers(widget.schoolId, sid)),
      );
      final sessionLists = await Future.wait(
        sectionIds.map((sid) => SchoolFirebaseService.getTodaySessions(widget.schoolId, sid)),
      );

      final allStudents = studentLists.expand((l) => l).toList();
      final allTeachers = teacherLists.expand((l) => l).toList();
      final allSessions = sessionLists.expand((l) => l).toList();

      // Fetch attendance records per section
      final recordLists = <List<AttendanceRecord>>[];
      for (int i = 0; i < sectionIds.length; i++) {
        final sid      = sectionIds[i];
        final sessions = sessionLists[i];
        final recs = await Future.wait(
          sessions.map((s) => SchoolFirebaseService.getSessionRecords(widget.schoolId, sid, s.id)),
        );
        recordLists.addAll(recs);
      }
      final flat     = recordLists.expand((r) => r).toList();
      final weekData = await _loadWeeklyData(sectionIds);

      if (!mounted) return;
      setState(() {
        _resolvedSectionIds = sectionIds;
        _totalStudents  = allStudents.length;
        _totalTeachers  = allTeachers.length;
        _todayPresent   = flat.where((r) => r.status == AttendanceStatus.present).length;
        _todayAbsent    = flat.where((r) =>
            r.status == AttendanceStatus.absent ||
            r.status == AttendanceStatus.late).length;
        _submittedCount = allSessions.where((s) => s.isSubmitted).length;
        _todaySessions  = allSessions;
        _weekData       = weekData;
        _loading        = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<List<_DayData>> _loadWeeklyData(List<String> sectionIds) async {
    final db    = FirebaseFirestore.instance;
    final today = DateTime.now();
    const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    final futures = List.generate(5, (i) async {
      final day   = today.subtract(Duration(days: 4 - i));
      final start = DateTime(day.year, day.month, day.day);
      final end   = start.add(const Duration(days: 1));

      // Query sessions across every section for this day
      final allRecs = <AttendanceRecord>[];
      for (final sid in sectionIds) {
        final snap = await db
            .collection('schools/${widget.schoolId}/sections/$sid/attendance_sessions')
            .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
            .where('date', isLessThan: Timestamp.fromDate(end))
            .get();
        if (snap.docs.isEmpty) continue;
        final recs = await Future.wait(
          snap.docs.map((d) => SchoolFirebaseService.getSessionRecords(widget.schoolId, sid, d.id)),
        );
        allRecs.addAll(recs.expand((r) => r));
      }

      if (allRecs.isEmpty) return _DayData(labels[day.weekday - 1], 0, 0);
      return _DayData(
        labels[day.weekday - 1],
        allRecs.where((r) => r.status == AttendanceStatus.present).length,
        allRecs.where((r) =>
            r.status == AttendanceStatus.absent ||
            r.status == AttendanceStatus.late).length,
      );
    });

    return Future.wait(futures);
  }

  String get _greeting {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('EEEE, d MMMM yyyy').format(DateTime.now());

    return Scaffold(
      backgroundColor: cBg(context),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: cNavy(context), strokeWidth: 2))
          : Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(context, dateStr),
                  const SizedBox(height: 20),
                  _buildStatCards(context),
                  const SizedBox(height: 16),
                  Expanded(child: _buildBottomSection(context)),
                ],
              ),
            ),
    );
  }

  // ── HEADER ───────────────────────────────────────────────
  Widget _buildHeader(BuildContext context, String dateStr) {
    final dark = isDark(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Text(
                '$_greeting, Admin',
                style: TextStyle(
                    color: cNavy(context), fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(width: 8),
              const Text('👋', style: TextStyle(fontSize: 20)),
            ]),
            const SizedBox(height: 3),
            Text(dateStr, style: TextStyle(color: cMuted(context), fontSize: 12.5)),
          ],
        ),
        const Spacer(),

        Tooltip(
          message: dark ? 'Switch to Light Mode' : 'Switch to Dark Mode',
          child: InkWell(
            onTap: () =>
                themeNotifier.value = dark ? ThemeMode.light : ThemeMode.dark,
            borderRadius: BorderRadius.circular(10),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 44, height: 38,
              decoration: BoxDecoration(
                color: cCard(context),
                border: Border.all(color: cBorder(context), width: 1.5),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
                color: cNavy(context), size: 18,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),

        OutlinedButton(
          style: OutlinedButton.styleFrom(
            foregroundColor: cNavy(context),
            side: BorderSide(color: cBorder(context), width: 1.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          ),
          onPressed: widget.onAddStudent,
          child: Text(
            '+ Add Student',
            style: TextStyle(
                color: cNavy(context), fontWeight: FontWeight.w600, fontSize: 12.5),
          ),
        ),
        const SizedBox(width: 10),

        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: kNavy,
            foregroundColor: Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          icon: const Text('🎓', style: TextStyle(fontSize: 13)),
          label: const Text(
            "Today's Attendance",
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          ),
          onPressed: widget.onViewAttendance,
        ),
      ],
    );
  }

  // ── STAT CARDS ───────────────────────────────────────────
  Widget _buildStatCards(BuildContext context) {
  return IntrinsicHeight(
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: _StatCard(
            label:  'TOTAL STUDENTS',
            value:  '$_totalStudents',
            sub:    'Enrolled this year',
            icon:   Icons.people_alt_rounded,
            accent: const Color(0xFF3B82F6),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _StatCard(
            label:  'TODAY PRESENT',
            value:  '$_todayPresent',
            sub:    'Across all classes',
            icon:   Icons.check_box_rounded,
            accent: const Color(0xFF16A34A),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _StatCard(
            label:  'TODAY ABSENT',
            value:  '$_todayAbsent',
            sub:    'SMS alerts pending',
            icon:   Icons.close_rounded,
            accent: kError,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _StatCard(
            label:  'TEACHERS',
            value:  '$_totalTeachers',
            sub:    '$_submittedCount submitted attendance',
            icon:   Icons.school_rounded,
            accent: const Color(0xFFD97706),
          ),
        ),
      ],
    ),
  );
}

  // ── BOTTOM SECTION ───────────────────────────────────────
  Widget _buildBottomSection(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(flex: 13, child: _buildWeeklyChart(context)),
        const SizedBox(width: 14),
        Expanded(flex: 7, child: _buildTodaysClasses(context)),
      ],
    );
  }

  Widget _buildWeeklyChart(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 10,
            offset:     const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
            child: Row(children: [
              const Text('📊', style: TextStyle(fontSize: 15)),
              const SizedBox(width: 8),
              Text(
                'Attendance This Week',
                style: TextStyle(
                    color: cNavy(context), fontSize: 14, fontWeight: FontWeight.w800),
              ),
              const Spacer(),
              _LegendChip(color: const Color(0xFF16A34A), label: 'Present'),
              const SizedBox(width: 12),
              _LegendChip(color: kError, label: 'Absent'),
              const SizedBox(width: 10),
              Text(
                'Live · 30s',
                style: TextStyle(
                    color: cMuted(context).withValues(alpha: 0.5), fontSize: 10.5),
              ),
            ]),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 12, 16, 8),
              child: _weekData.isEmpty
                  ? Center(
                      child: Text(
                        'No attendance data yet',
                        style: TextStyle(
                            color: cMuted(context).withValues(alpha: 0.5),
                            fontSize: 13),
                      ),
                    )
                  : CustomPaint(
                      painter: _WeeklyChartPainter(
                        data:       _weekData,
                        gridColor:  cBorder(context).withValues(alpha: 0.8),
                        labelColor: cMuted(context),
                        dotFill:    cCard(context),
                      ),
                      child: const SizedBox.expand(),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTodaysClasses(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        cCard(context),
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: cBorder(context)),
        boxShadow: [
          BoxShadow(
            color:      cNavy(context).withValues(alpha: 0.04),
            blurRadius: 10,
            offset:     const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            child: Row(children: [
              const Text('🎯', style: TextStyle(fontSize: 14)),
              const SizedBox(width: 8),
              Text(
                "Today's Classes",
                style: TextStyle(
                    color: cNavy(context), fontSize: 14, fontWeight: FontWeight.w800),
              ),
            ]),
          ),
          Divider(height: 1, color: cBorder(context)),
          Expanded(
            child: FutureBuilder<List<SchoolClass>>(
              future: SchoolFirebaseService.getClasses(widget.schoolId, _resolvedSectionIds.isNotEmpty ? _resolvedSectionIds.first : widget.sectionId),
              builder: (_, classSnap) {
                final classes = classSnap.data ?? [];
                if (classes.isEmpty) {
                  return Center(
                    child: Text(
                      'No classes yet',
                      style: TextStyle(
                          color: cMuted(context).withValues(alpha: 0.5),
                          fontSize: 13),
                    ),
                  );
                }
                final sessionMap = <String, AttendanceSession>{
                  for (final s in _todaySessions) s.classId: s,
                };
                return ListView.separated(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  itemCount: classes.length,
                  separatorBuilder: (_, __) =>
                      Divider(height: 1, color: cBorder(context)),
                  itemBuilder: (_, i) {
                    final c       = classes[i];
                    final session = sessionMap[c.id];
                    Color  dotColor;
                    String statusText;
                    if (session == null) {
                      dotColor   = kError;
                      statusText = 'Not Started';
                    } else if (session.isSubmitted) {
                      dotColor   = const Color(0xFF16A34A);
                      statusText = 'Submitted';
                    } else {
                      dotColor   = const Color(0xFFD97706);
                      statusText = 'In Progress';
                    }
                    return Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 11),
                      child: Row(children: [
                        Container(
                          width:  8, height: 8,
                          decoration: BoxDecoration(
                              color: dotColor, shape: BoxShape.circle),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            c.name,
                            style: TextStyle(
                                color:      cNavy(context),
                                fontSize:   13,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color:        dotColor.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            statusText,
                            style: TextStyle(
                                color:      dotColor,
                                fontSize:   10.5,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                      ]),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ── Stat Card ─────────────────────────────────────────────────
// Uses a Stack so the coloured top bar is a separate layer —
// this avoids the "borderRadius with non-uniform border colors" crash.
class _StatCard extends StatelessWidget {
  final String   label;
  final String   value;
  final String   sub;
  final IconData icon;
  final Color    accent;

  const _StatCard({
    required this.label,
    required this.value,
    required this.sub,
    required this.icon,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Stack(
        children: [
          // ── Card body ──────────────────────────────────
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color:        cCard(context),
              borderRadius: BorderRadius.circular(14),
              border:       Border.all(color: cBorder(context)),
              boxShadow: [
                BoxShadow(
                  color:      cNavy(context).withValues(alpha: 0.04),
                  blurRadius: 10,
                  offset:     const Offset(0, 3),
                ),
              ],
            ),
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,   // ← shrink to content
              children: [
                // top bar spacer (the accent bar is Positioned at top: 0)
                const SizedBox(height: 3),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        label,
                        style: TextStyle(
                          color:         cMuted(context),
                          fontSize:      10,
                          fontWeight:    FontWeight.w700,
                          letterSpacing: 0.6,
                        ),
                      ),
                    ),
                    Icon(icon, color: accent.withValues(alpha: 0.25), size: 18),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  value,
                  style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   28,
                    fontWeight: FontWeight.w800,
                    height:     1,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  sub,
                  style: TextStyle(
                    color:    cMuted(context).withValues(alpha: 0.7),
                    fontSize: 11,
                  ),
                  maxLines:  1,
                  overflow:  TextOverflow.ellipsis,
                ),
              ],
            ),
          ),

          // ── Coloured top accent bar ─────────────────────
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(height: 3, color: accent),
          ),
        ],
      ),
    );
  }
}

// ── Legend chip ───────────────────────────────────────────────
class _LegendChip extends StatelessWidget {
  final Color  color;
  final String label;
  const _LegendChip({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width:  10, height: 10,
        decoration: BoxDecoration(
          color:        color.withValues(alpha: 0.2),
          border:       Border.all(color: color, width: 1.5),
          borderRadius: BorderRadius.circular(3),
        ),
      ),
      const SizedBox(width: 5),
      Text(
        label,
        style: TextStyle(
            color: cMuted(context), fontSize: 11.5, fontWeight: FontWeight.w600),
      ),
    ]);
  }
}

// ── Weekly Chart Painter ──────────────────────────────────────
class _WeeklyChartPainter extends CustomPainter {
  final List<_DayData> data;
  final Color          gridColor;
  final Color          labelColor;
  final Color          dotFill;

  static const _green = Color(0xFF16A34A);
  static const _red   = Color(0xFFE53E6B);
  static const double _padLeft = 50, _padRight = 12, _padTop = 10, _padBottom = 30;

  const _WeeklyChartPainter({
    required this.data,
    required this.gridColor,
    required this.labelColor,
    required this.dotFill,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width  - _padLeft - _padRight;
    final h = size.height - _padTop  - _padBottom;
    if (data.isEmpty || w <= 0 || h <= 0) return;

    final n = data.length;
    int maxVal = 1;
    for (final d in data) {
      if (d.present > maxVal) maxVal = d.present;
      if (d.absent  > maxVal) maxVal = d.absent;
    }

    Offset pt(int i, int val) => Offset(
      _padLeft + (n <= 1 ? w / 2 : i * w / (n - 1)),
      _padTop  + h * (1.0 - val / maxVal),
    );

    const kLines   = 4;
    final gridPaint = Paint()..color = gridColor..strokeWidth = 0.8;
    for (int g = 0; g <= kLines; g++) {
      final y = _padTop + h * g / kLines;
      canvas.drawLine(
          Offset(_padLeft, y), Offset(size.width - _padRight, y), gridPaint);
      _label(canvas, '${(maxVal * (kLines - g) / kLines).round()}',
          Offset(0, y - 7), 10);
    }

    void drawSeries(int Function(_DayData) getValue, Color color) {
      if (n == 0) return;
      final points = [for (int i = 0; i < n; i++) pt(i, getValue(data[i]))];
      final fill = Path()
        ..moveTo(points.first.dx, _padTop + h)
        ..lineTo(points.first.dx, points.first.dy);
      final line = Path()..moveTo(points.first.dx, points.first.dy);

      for (int i = 1; i < n; i++) {
        final a  = points[i - 1];
        final b  = points[i];
        final dx = (b.dx - a.dx) * 0.45;
        fill.cubicTo(a.dx + dx, a.dy, b.dx - dx, b.dy, b.dx, b.dy);
        line.cubicTo(a.dx + dx, a.dy, b.dx - dx, b.dy, b.dx, b.dy);
      }
      fill
        ..lineTo(points.last.dx, _padTop + h)
        ..close();

      canvas.drawPath(
        fill,
        Paint()
          ..color = color.withValues(alpha: 0.12)
          ..style = PaintingStyle.fill,
      );
      canvas.drawPath(
        line,
        Paint()
          ..color      = color
          ..strokeWidth = 2.5
          ..style      = PaintingStyle.stroke
          ..strokeCap  = StrokeCap.round
          ..strokeJoin = StrokeJoin.round,
      );

      for (final p in points) {
        canvas.drawCircle(
            p, 4.5, Paint()..color = dotFill..style = PaintingStyle.fill);
        canvas.drawCircle(
            p,
            4.5,
            Paint()
              ..color       = color
              ..strokeWidth = 2
              ..style       = PaintingStyle.stroke);
      }
    }

    drawSeries((d) => d.absent,  _red);
    drawSeries((d) => d.present, _green);

    for (int i = 0; i < n; i++) {
      final x = _padLeft + (n <= 1 ? w / 2 : i * w / (n - 1));
      _label(canvas, data[i].dayLabel,
          Offset(x - 12, size.height - _padBottom + 9), 10.5);
    }
  }

  void _label(Canvas canvas, String text, Offset pos, double fontSize) {
    final tp = TextPainter(
      text: TextSpan(
        text:  text,
        style: TextStyle(
          color:      labelColor,
          fontSize:   fontSize,
          fontWeight: FontWeight.w500,
        ),
      ),
      textDirection: ui.TextDirection.ltr,
    )..layout(maxWidth: 60);
    tp.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(_WeeklyChartPainter old) =>
      old.data       != data       ||
      old.gridColor  != gridColor  ||
      old.dotFill    != dotFill;
}