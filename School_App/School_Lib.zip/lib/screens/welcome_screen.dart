// lib/screens/welcome_screen.dart
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_theme.dart';
import 'main_shell.dart';
import 'login_screen.dart';

// ─────────────────────────────────────────────────────────
// Call this in main.dart BEFORE runApp to check first-launch
// Returns true if this is the first time the app ever opened.
// ─────────────────────────────────────────────────────────
Future<bool> isFirstLaunch() async {
  final prefs = await SharedPreferences.getInstance();
  final seen = prefs.getBool('hasSeenWelcome') ?? false;
  return !seen;
}

Future<void> markWelcomeSeen() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool('hasSeenWelcome', true);
}

// ─────────────────────────────────────────────────────────
// Onboarding step data
// ─────────────────────────────────────────────────────────
class _Step {
  final Color color;
  final String emoji;
  final String title;
  final String sub;
  final String body;
  const _Step({
    required this.color,
    required this.emoji,
    required this.title,
    required this.sub,
    required this.body,
  });
}

const _steps = [
  _Step(
    color: kTeal,
    emoji: '📚',
    title: 'Set Up Classes',
    sub: 'Step 1 of 3',
    body:
        'Start by creating your school\'s class structure. Add each grade or section '
        '(e.g. Class 1-A, Class 5-B). This is the foundation everything else builds on.',
  ),
  _Step(
    color: kPink,
    emoji: '👩‍🏫',
    title: 'Add Teachers & Students',
    sub: 'Step 2 of 3',
    body:
        'Register your teachers first, then enroll students into their respective classes. '
        'Make sure to add each student\'s parent phone number for attendance alerts.',
  ),
  _Step(
    color: Color(0xFFFFB347),
    emoji: '✅',
    title: 'Track Attendance Daily',
    sub: 'Step 3 of 3',
    body:
        'Teachers mark attendance from the HQ app. You\'ll see a live feed here '
        'and can send instant SMS alerts to parents of absent students.',
  ),
];

// ─────────────────────────────────────────────────────────
// Phase enum
// ─────────────────────────────────────────────────────────
enum _Phase { lottie, onboarding }

// ─────────────────────────────────────────────────────────
// WelcomeScreen
// ─────────────────────────────────────────────────────────
class WelcomeScreen extends StatefulWidget {
  final String schoolId;
  final String schoolName;
  final String sectionId;
  final String sectionName;
  final bool isAdmin;

  const WelcomeScreen({
    super.key,
    required this.schoolId,
    required this.schoolName,
    required this.sectionId,
    required this.sectionName,
    this.isAdmin = false,
  });

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen>
    with TickerProviderStateMixin {
  _Phase _phase = _Phase.lottie;
  int _step = 0;

  // ── Lottie phase ──────────────────────────────────────
  // Fades in, then fades out once Lottie completes
  late final AnimationController _lottieEnterCtrl;
  late final Animation<double> _lottieFadeIn;

  late final AnimationController _lottieExitCtrl;
  late final Animation<double> _lottieFadeOut;

  // ── Onboarding card animations ────────────────────────
  late final AnimationController _cardCtrl;
  late final Animation<double> _cardFade;
  late final Animation<Offset> _cardSlide;

  late final AnimationController _bounceCtrl;
  late final Animation<double> _bounce;

  // ── Global exit (→ MainShell) ─────────────────────────
  late final AnimationController _exitCtrl;
  late final Animation<double> _exitFade;

  // ── Lottie controller (to detect completion) ──────────
  late final AnimationController _lottieAnimCtrl;

  @override
  void initState() {
    super.initState();

    // Lottie phase: fade IN
    _lottieEnterCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _lottieFadeIn = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _lottieEnterCtrl, curve: Curves.easeOut));

    // Lottie phase: fade OUT
    _lottieExitCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _lottieFadeOut = Tween<double>(begin: 1, end: 0).animate(
        CurvedAnimation(parent: _lottieExitCtrl, curve: Curves.easeIn));

    // Card enter
    _cardCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _cardFade = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOut));
    _cardSlide = Tween<Offset>(
            begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _cardCtrl, curve: Curves.easeOutCubic));

    // Icon bounce
    _bounceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 650));
    _bounce = Tween<double>(begin: -28, end: 0).animate(
        CurvedAnimation(parent: _bounceCtrl, curve: Curves.elasticOut));

    // Global exit
    _exitCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 450));
    _exitFade = Tween<double>(begin: 1, end: 0).animate(
        CurvedAnimation(parent: _exitCtrl, curve: Curves.easeIn));

    // Lottie playback controller — play once then transition
    _lottieAnimCtrl = AnimationController(vsync: this);
    _lottieAnimCtrl.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _afterLottieFinished();
      }
    });

    // Kick off lottie fade-in
    _lottieEnterCtrl.forward();
  }

  @override
  void dispose() {
    _lottieEnterCtrl.dispose();
    _lottieExitCtrl.dispose();
    _cardCtrl.dispose();
    _bounceCtrl.dispose();
    _exitCtrl.dispose();
    _lottieAnimCtrl.dispose();
    super.dispose();
  }

  // ── After Lottie finishes playing ─────────────────────
  Future<void> _afterLottieFinished() async {
    // Short pause so the last frame stays visible
    await Future.delayed(const Duration(milliseconds: 300));
    if (!mounted) return;
    // Fade out the lottie
    await _lottieExitCtrl.forward();
    if (!mounted) return;
    // Switch to onboarding
    setState(() { _phase = _Phase.onboarding; _step = 0; });
    _cardCtrl.forward(from: 0);
    _bounceCtrl.forward(from: 0);
  }

  // ── Card navigation ───────────────────────────────────
  Future<void> _nextStep() async {
    if (_step == _steps.length - 1) { _goToApp(); return; }
    await _cardCtrl.reverse();
    if (!mounted) return;
    setState(() => _step++);
    _cardCtrl.forward(from: 0);
    _bounceCtrl.forward(from: 0);
  }

  Future<void> _prevStep() async {
    if (_step == 0) return;
    await _cardCtrl.reverse();
    if (!mounted) return;
    setState(() => _step--);
    _cardCtrl.forward(from: 0);
    _bounceCtrl.forward(from: 0);
  }

  Future<void> _skipAll() async {
    _goToApp();
  }

  // ── Navigate to the app ───────────────────────────────
  Future<void> _goToApp() async {
    // Mark welcome as seen so it never shows again
    await markWelcomeSeen();
    await _exitCtrl.forward();
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (_, __, ___) =>
            MainShell(schoolId: widget.schoolId, schoolName: widget.schoolName, sectionId: widget.sectionId, sectionName: widget.sectionName, isAdmin: widget.isAdmin),
        transitionsBuilder: (_, anim, __, child) {
          final c = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
          return FadeTransition(
            opacity: c,
            child: ScaleTransition(
                scale: Tween<double>(begin: 0.96, end: 1).animate(c),
                child: child),
          );
        },
      ),
    );
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('schoolId');
    await prefs.remove('schoolName');
    await prefs.remove('sectionId');
    await prefs.remove('sectionName');
    if (!mounted) return;
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  // ── Build ─────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          const _Blobs(),
          AnimatedBuilder(
            animation: _exitCtrl,
            builder: (_, child) =>
                Opacity(opacity: _exitFade.value, child: child),
            child: _phase == _Phase.lottie
                ? _buildLottiePhase()
                : _buildOnboarding(),
          ),
        ],
      ),
    );
  }

  // ── LOTTIE PHASE ──────────────────────────────────────
  Widget _buildLottiePhase() {
    return AnimatedBuilder(
      animation: Listenable.merge([_lottieEnterCtrl, _lottieExitCtrl]),
      builder: (_, child) => Opacity(
        opacity: _lottieFadeIn.value * _lottieFadeOut.value,
        child: child,
      ),
      child: Center(
        child: Lottie.asset(
          'assets/animations/welcome.json',
          controller: _lottieAnimCtrl,
          width: 320,
          height: 320,
          fit: BoxFit.contain,
          onLoaded: (composition) {
            // Set duration from composition and play once
            _lottieAnimCtrl
              ..duration = composition.duration
              ..forward();
          },
          errorBuilder: (_, __, ___) {
            // If asset missing, auto-advance after 2 s
            Future.delayed(const Duration(seconds: 2), _afterLottieFinished);
            return const _FallbackLottie();
          },
        ),
      ),
    );
  }

  // ── ONBOARDING ────────────────────────────────────────
  Widget _buildOnboarding() {
    final step = _steps[_step];

    return Center(
      child: SizedBox(
        width: 600,
        child: FadeTransition(
          opacity: _cardFade,
          child: SlideTransition(
            position: _cardSlide,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // ── School badge ──────────────────────
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 7),
                  decoration: BoxDecoration(
                    color: kNavy.withValues(alpha: 0.07),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.school_rounded,
                          color: kNavy.withValues(alpha: 0.5), size: 15),
                      const SizedBox(width: 7),
                      Text(
                        widget.schoolName.isNotEmpty
                            ? widget.schoolName
                            : 'Your School',
                        style: TextStyle(
                          color: kNavy.withValues(alpha: 0.6),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 10),

                // ── Welcome heading ───────────────────
                Text(
                  'Welcome aboard!',
                  style: TextStyle(
                    color: kNavy.withValues(alpha: 0.35),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.2,
                  ),
                ),

                const SizedBox(height: 28),

                // ── Step card ─────────────────────────
                AnimatedBuilder(
                  animation: _bounceCtrl,
                  builder: (_, __) => _StepCard(
                    step: step,
                    iconOffset: _bounce.value,
                  ),
                ),

                const SizedBox(height: 28),

                // ── Navigation row ────────────────────
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Back arrow
                    _ArrowBtn(
                      icon: Icons.arrow_back_rounded,
                      onTap: _step > 0 ? _prevStep : null,
                    ),

                    const SizedBox(width: 20),

                    // Dot indicators
                    Row(
                      children: List.generate(_steps.length, (i) {
                        final active = i == _step;
                        return AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut,
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: active ? 24 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: active
                                ? step.color
                                : step.color.withValues(alpha: 0.25),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        );
                      }),
                    ),

                    const SizedBox(width: 20),

                    // Next / Done arrow
                    _ArrowBtn(
                      icon: _step == _steps.length - 1
                          ? Icons.check_rounded
                          : Icons.arrow_forward_rounded,
                      onTap: _nextStep,
                      filled: true,
                      color: step.color,
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // ── Skip ──────────────────────────────
                if (_step < _steps.length - 1)
                  GestureDetector(
                    onTap: _skipAll,
                    child: Text(
                      'Skip setup guide',
                      style: TextStyle(
                        color: kMuted.withValues(alpha: 0.6),
                        fontSize: 12.5,
                        decoration: TextDecoration.underline,
                        decorationColor: kMuted.withValues(alpha: 0.4),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Step card ─────────────────────────────────────────────
class _StepCard extends StatelessWidget {
  final _Step step;
  final double iconOffset;

  const _StepCard({required this.step, required this.iconOffset});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(36),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: kNavy.withValues(alpha: 0.08),
            blurRadius: 50,
            offset: const Offset(0, 18),
          ),
          BoxShadow(
            color: step.color.withValues(alpha: 0.10),
            blurRadius: 28,
            spreadRadius: -4,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Transform.translate(
            offset: Offset(0, iconOffset),
            child: Column(
              children: [
                Container(
                  width: 84,
                  height: 84,
                  decoration: BoxDecoration(
                    color: step.color.withValues(alpha: 0.11),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                        color: step.color.withValues(alpha: 0.25), width: 1.5),
                  ),
                  child: Center(
                    child: Text(step.emoji,
                        style: const TextStyle(fontSize: 40)),
                  ),
                ),
                const SizedBox(height: 14),
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                      color: step.color, shape: BoxShape.circle),
                ),
              ],
            ),
          ),
          const SizedBox(width: 30),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  step.sub.toUpperCase(),
                  style: TextStyle(
                    color: step.color,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  step.title,
                  style: const TextStyle(
                    color: kNavy,
                    fontSize: 27,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.6,
                    height: 1.1,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  step.body,
                  style: const TextStyle(
                    color: kBlue,
                    fontSize: 15,
                    height: 1.7,
                  ),
                ),
                const SizedBox(height: 22),
                Row(
                  children: List.generate(
                    5,
                    (i) => Container(
                      margin: const EdgeInsets.only(right: 5),
                      width: i == 0 ? 28 : 9,
                      height: 3.5,
                      decoration: BoxDecoration(
                        color: i == 0
                            ? step.color
                            : step.color.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Arrow button ──────────────────────────────────────────
class _ArrowBtn extends StatefulWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final bool filled;
  final Color? color;

  const _ArrowBtn({
    required this.icon,
    this.onTap,
    this.filled = false,
    this.color,
  });

  @override
  State<_ArrowBtn> createState() => _ArrowBtnState();
}

class _ArrowBtnState extends State<_ArrowBtn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 130));
    _scale = Tween<double>(begin: 1, end: 1.12)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final disabled = widget.onTap == null;
    return MouseRegion(
      onEnter: (_) { if (!disabled) _ctrl.forward(); },
      onExit: (_) => _ctrl.reverse(),
      child: GestureDetector(
        onTap: widget.onTap,
        child: ScaleTransition(
          scale: _scale,
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: widget.filled
                  ? (widget.color ?? kNavy)
                  : disabled
                      ? kBg
                      : kCard,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                  color: disabled
                      ? kBorder.withValues(alpha: 0.4)
                      : widget.filled
                          ? Colors.transparent
                          : kBorder),
              boxShadow: disabled
                  ? null
                  : [
                      BoxShadow(
                        color: kNavy.withValues(alpha: 0.07),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
            ),
            child: Icon(
              widget.icon,
              color: widget.filled
                  ? Colors.white
                  : disabled
                      ? kMuted.withValues(alpha: 0.3)
                      : kNavy,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }
}

// ── Fallback animated icon (when asset is missing) ─────────
class _FallbackLottie extends StatefulWidget {
  const _FallbackLottie();
  @override
  State<_FallbackLottie> createState() => _FallbackLottieState();
}

class _FallbackLottieState extends State<_FallbackLottie>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _scale = Tween<double>(begin: 0.92, end: 1.05)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Transform.scale(
        scale: _scale.value,
        child: Container(
          width: 180,
          height: 180,
          decoration: BoxDecoration(
            color: kNavy,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: kTeal.withValues(alpha: 0.45),
                blurRadius: 40,
                spreadRadius: 4,
              ),
            ],
          ),
          child: const Icon(Icons.school_rounded, color: kTeal, size: 90),
        ),
      ),
    );
  }
}

// ── Background blobs ──────────────────────────────────────
class _Blobs extends StatelessWidget {
  const _Blobs();

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned(top: -70, right: -60, child: _b(300, kTeal, 0.18)),
      Positioned(bottom: -90, left: -90, child: _b(380, kPink, 0.16)),
      Positioned(bottom: 180, right: 120, child: _b(100, kTeal, 0.14)),
      Positioned(top: 140, left: 100, child: _b(60, kNavy, 0.06)),
    ]);
  }

  Widget _b(double s, Color c, double o) => Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
            color: c.withValues(alpha: o), shape: BoxShape.circle),
      );
}