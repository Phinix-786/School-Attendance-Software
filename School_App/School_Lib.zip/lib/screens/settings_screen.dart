// lib/screens/settings_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app_theme.dart';
import '../models/local_models.dart';
import '../services/local_settings_service.dart';
import '../services/school_firebase_service.dart';
import '../services/auto_updater_service.dart';
import 'features_screen.dart';
import 'privacy_policy_screen.dart';

class SettingsScreen extends StatefulWidget {
  final String schoolId;
  final String sectionId;
  final String displayName; // adminName for admin, sectionName for section head
  final bool isAdmin;

  const SettingsScreen({
    super.key,
    required this.schoolId,
    required this.sectionId,
    required this.displayName,
    required this.isAdmin,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // Section index: 0=Profile, 1=Personalisation, 2=Features, 3=About
  int _section = 0;

  // Profile
  final _nameCtrl = TextEditingController();
  final _oldPassCtrl = TextEditingController();
  final _newPassCtrl = TextEditingController();
  final _confPassCtrl = TextEditingController();
  bool _savingName = false;
  bool _savingPass = false;
  String? _nameMsg;
  String? _passMsg;
  bool _nameMsgOk = false;
  bool _passMsgOk = false;

  // Personalisation
  AppSettings _settings = const AppSettings();
  List<CustomTheme> _customThemes = [];
  bool _loadingSettings = true;

  // Lock
  LockConfig _lockConfig = const LockConfig();
  final _pinCtrl = TextEditingController();
  final _pinConfCtrl = TextEditingController();
  bool _savingLock = false;
  String? _lockMsg;
  bool _lockMsgOk = false;

  // Theme editor
  bool _showThemeEditor = false;
  final _themeNameCtrl = TextEditingController();
  CustomTheme _editingTheme = const CustomTheme(
    id: '',
    name: '',
    bgColor: '#FEF6E4',
    cardColor: '#FFFFFF',
    navyColor: '#001858',
    accentColor: '#82F5B2',
    mutedColor: '#8896AA',
    borderColor: '#E8EEF4',
  );

  static const List<String> _allNavItems = [
    'Dashboard',
    'Attendance',
    'Classes',
    'Students',
    'Teachers',
    'Sections',
    'Timetable',
    'Notices',
    'Tests',
    'Leaves',
    'Fee Management',
    'Documents',
    'Settings',
    'Updates',
  ];

  @override
  void initState() {
    super.initState();
    _nameCtrl.text = widget.displayName;
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await LocalSettingsService.instance.loadSettings();
    final themes = await LocalSettingsService.instance.loadThemes();
    final lock = await LocalSettingsService.instance.loadLockConfig();
    if (mounted) {
      setState(() {
        _settings = settings;
        _customThemes = themes;
        _lockConfig = lock;
        _loadingSettings = false;
      });
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _oldPassCtrl.dispose();
    _newPassCtrl.dispose();
    _confPassCtrl.dispose();
    _pinCtrl.dispose();
    _pinConfCtrl.dispose();
    _themeNameCtrl.dispose();
    super.dispose();
  }

  // ── Profile actions ───────────────────────────────────────────────────────

  Future<void> _saveName() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      setState(() { _nameMsg = 'Name cannot be empty.'; _nameMsgOk = false; });
      return;
    }
    setState(() { _savingName = true; _nameMsg = null; });
    try {
      if (widget.isAdmin) {
        await SchoolFirebaseService.setAdminName(widget.schoolId, name);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('adminName', name);
      } else {
        // Section head: update sectionName in prefs only (no Firestore field)
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('sectionName', name);
      }
      if (mounted) {
        setState(() {
          _nameMsg = 'Name updated.';
          _nameMsgOk = true;
          _savingName = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _nameMsg = 'Error: $e';
          _nameMsgOk = false;
          _savingName = false;
        });
      }
    }
  }

  Future<void> _changePassword() async {
    final oldPass = _oldPassCtrl.text.trim();
    final newPass = _newPassCtrl.text.trim();
    final confPass = _confPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confPass.isEmpty) {
      setState(() { _passMsg = 'All password fields are required.'; _passMsgOk = false; });
      return;
    }
    if (newPass != confPass) {
      setState(() { _passMsg = 'New passwords do not match.'; _passMsgOk = false; });
      return;
    }
    if (newPass.length < 6) {
      setState(() { _passMsg = 'Password must be at least 6 characters.'; _passMsgOk = false; });
      return;
    }

    setState(() { _savingPass = true; _passMsg = null; });
    try {
      // Verify old password first
      if (widget.isAdmin) {
        final config = await SchoolFirebaseService.getSchoolConfig(widget.schoolId);
        final storedPass = config?['adminPassword'] ?? '';
        if (oldPass != storedPass) {
          setState(() { _passMsg = 'Current password is incorrect.'; _passMsgOk = false; _savingPass = false; });
          return;
        }
        await SchoolFirebaseService.updateAdminPassword(widget.schoolId, newPass);
      } else {
        final sectionDocs = await SchoolFirebaseService.getSections(widget.schoolId);
        final secData = sectionDocs.firstWhere(
          (s) => s['id'] == widget.sectionId || (s['id'] ?? '') == widget.sectionId,
          orElse: () => {},
        );
        final storedPass = secData['password'] ?? '';
        if (oldPass != storedPass) {
          setState(() { _passMsg = 'Current password is incorrect.'; _passMsgOk = false; _savingPass = false; });
          return;
        }
        await SchoolFirebaseService.updateSectionPassword(
            widget.schoolId, widget.sectionId, newPass);
      }
      _oldPassCtrl.clear();
      _newPassCtrl.clear();
      _confPassCtrl.clear();
      if (mounted) {
        setState(() {
          _passMsg = 'Password updated successfully.';
          _passMsgOk = true;
          _savingPass = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _passMsg = 'Error: $e';
          _passMsgOk = false;
          _savingPass = false;
        });
      }
    }
  }

  Future<void> _saveLock() async {
    final isPin = _lockConfig.type == 'pin';
    final input = _pinCtrl.text.trim();
    final conf = _pinConfCtrl.text.trim();

    if (_lockConfig.enabled) {
      if (input.isEmpty) {
        setState(() { _lockMsg = 'Enter a ${isPin ? 'PIN' : 'password'}.'; _lockMsgOk = false; });
        return;
      }
      if (isPin && (input.length < 4 || input.length > 6)) {
        setState(() { _lockMsg = 'PIN must be 4–6 digits.'; _lockMsgOk = false; });
        return;
      }
      if (input != conf) {
        setState(() { _lockMsg = 'Values do not match.'; _lockMsgOk = false; });
        return;
      }
    }

    setState(() { _savingLock = true; _lockMsg = null; });
    try {
      final newConfig = _lockConfig.enabled
          ? _lockConfig.copyWith(
              hashValue: LocalSettingsService.hashPin(input))
          : _lockConfig.copyWith(hashValue: '');
      await LocalSettingsService.instance.saveLockConfig(newConfig);
      _pinCtrl.clear();
      _pinConfCtrl.clear();
      if (mounted) {
        setState(() {
          _lockConfig  = newConfig;
          _lockMsg     = null; // no message needed — status chip shows
          _lockMsgOk   = true;
          _savingLock  = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _lockMsg = 'Error: $e';
          _lockMsgOk = false;
          _savingLock = false;
        });
      }
    }
  }

  Future<void> _savePersonalisation() async {
    await LocalSettingsService.instance.saveSettings(_settings);
    // no snackbar — changes are silent/live
  }

  /// Update settings state + immediately persist + notify main shell.
  void _updateSettings(AppSettings updated) {
    setState(() => _settings = updated);
    _savePersonalisation();
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(
          SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      body: Row(
        children: [
          _buildSettingsSidebar(),
          Expanded(child: _buildContent()),
        ],
      ),
    );
  }

  Widget _buildSettingsSidebar() {
    const items = [
      (Icons.person_rounded, 'Profile'),
      (Icons.palette_rounded, 'Personalisation'),
      (Icons.extension_rounded, 'Features'),
      (Icons.info_outline_rounded, 'About'),
    ];
    return Container(
      width: 200,
      decoration: BoxDecoration(
        color: cCard(context),
        border: Border(right: BorderSide(color: cBorder(context))),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 24, 18, 16),
            child: Text('Settings',
                style: TextStyle(
                  color: cNavy(context),
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                )),
          ),
          Divider(height: 1, color: cBorder(context)),
          const SizedBox(height: 8),
          ...items.asMap().entries.map((e) {
            final idx = e.key;
            final (icon, label) = e.value;
            final selected = _section == idx;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
              child: ListTile(
                dense: true,
                leading: Icon(icon,
                    color: selected
                        ? cNavy(context)
                        : cMuted(context).withValues(alpha: 0.6),
                    size: 18),
                title: Text(label,
                    style: TextStyle(
                      color: selected
                          ? cNavy(context)
                          : cMuted(context).withValues(alpha: 0.75),
                      fontSize: 13,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.w500,
                    )),
                selected: selected,
                selectedTileColor:
                    cNavy(context).withValues(alpha: 0.06),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                onTap: () => setState(() => _section = idx),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_loadingSettings && _section != 2 && _section != 3) {
      return const Center(child: CircularProgressIndicator());
    }
    switch (_section) {
      case 0:
        return _buildProfileSection();
      case 1:
        return _buildPersonalisationSection();
      case 2:
        return FeaturesScreen(
          schoolId: widget.schoolId,
          sectionId: widget.sectionId,
          isAdmin: widget.isAdmin,
        );
      case 3:
        return _buildAboutSection();
      default:
        return const SizedBox.shrink();
    }
  }

  // ── Profile section ───────────────────────────────────────────────────────

  Widget _buildProfileSection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionHeader('Profile', 'Manage your display name, password, and app lock.'),
          const SizedBox(height: 28),

          _card(
            title: 'Display Name',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _label('Name'),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _field('Display name', _nameCtrl,
                          prefixIcon: Icons.person_rounded),
                    ),
                    const SizedBox(width: 12),
                    _actionButton('Save', _savingName ? null : _saveName),
                  ],
                ),
                if (_nameMsg != null) ...[
                  const SizedBox(height: 8),
                  _msgWidget(_nameMsg!, _nameMsgOk),
                ],
              ],
            ),
          ),

          const SizedBox(height: 20),
          _card(
            title: 'Change Password',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _label('Current Password'),
                const SizedBox(height: 8),
                _field('Current password', _oldPassCtrl,
                    obscure: true, prefixIcon: Icons.lock_outline_rounded),
                const SizedBox(height: 12),
                _label('New Password'),
                const SizedBox(height: 8),
                _field('New password', _newPassCtrl,
                    obscure: true, prefixIcon: Icons.lock_rounded),
                const SizedBox(height: 12),
                _label('Confirm New Password'),
                const SizedBox(height: 8),
                _field('Confirm new password', _confPassCtrl,
                    obscure: true, prefixIcon: Icons.lock_rounded),
                const SizedBox(height: 16),
                if (_passMsg != null) ...[
                  _msgWidget(_passMsg!, _passMsgOk),
                  const SizedBox(height: 12),
                ],
                _actionButton(
                    'Update Password', _savingPass ? null : _changePassword,
                    fullWidth: true),
              ],
            ),
          ),

          const SizedBox(height: 20),
          _card(
            title: 'App Lock',
            child: _buildLockCard(),
          ),
        ],
      ),
    );
  }

  // ── Personalisation section ───────────────────────────────────────────────

  // ── App Lock card — three states ─────────────────────────────────────────
  //   1. Disabled            → just the toggle
  //   2. Enabled + hash set  → status chip + Change / Disable buttons
  //   3. Enabling (no hash)  → type selector + PIN fields + Save button
  Widget _buildLockCard() {
    final isActive  = _lockConfig.enabled && _lockConfig.hashValue.isNotEmpty;
    final isSetting = _lockConfig.enabled && _lockConfig.hashValue.isEmpty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Toggle row
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Enable App Lock',
                      style: TextStyle(
                          color:      cNavy(context),
                          fontSize:   14,
                          fontWeight: FontWeight.w600)),
                  Text('Require PIN or password on every launch',
                      style: TextStyle(color: cMuted(context), fontSize: 12)),
                ],
              ),
            ),
            Switch(
              value: _lockConfig.enabled,
              activeColor: kNavy,
              onChanged: (v) {
                if (!v) {
                  // Disabling immediately — wipe hash
                  _saveLockDisable();
                } else {
                  setState(() {
                    _lockConfig = _lockConfig.copyWith(enabled: true, hashValue: '');
                    _lockMsg   = null;
                    _pinCtrl.clear();
                    _pinConfCtrl.clear();
                  });
                }
              },
            ),
          ],
        ),

        // ── State 2: lock is active ─────────────────────────────────────
        if (isActive) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color:        const Color(0xFF16A34A).withValues(alpha: 0.07),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: const Color(0xFF16A34A).withValues(alpha: 0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.lock_rounded,
                    color: Color(0xFF16A34A), size: 16),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'App lock is active (${_lockConfig.type == 'pin' ? 'PIN' : 'Password'})',
                    style: const TextStyle(
                        color:      Color(0xFF16A34A),
                        fontSize:   13,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _actionButton('Change ${_lockConfig.type == 'pin' ? 'PIN' : 'Password'}',
                () => setState(() {
                  // Enter setup mode to set a new hash
                  _lockConfig = _lockConfig.copyWith(hashValue: '');
                  _pinCtrl.clear();
                  _pinConfCtrl.clear();
                  _lockMsg = null;
                }),
                secondary: true,
              ),
              const SizedBox(width: 10),
              _actionButton('Disable Lock', _savingLock ? null : _saveLockDisable,
                  secondary: false),
            ],
          ),
        ],

        // ── State 3: enabling / changing — show input fields ────────────
        if (isSetting) ...[
          const SizedBox(height: 16),
          _label('Lock Type'),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'pin',      label: Text('PIN (4–6 digits)')),
              ButtonSegment(value: 'password', label: Text('Password')),
            ],
            selected: {_lockConfig.type},
            onSelectionChanged: (v) => setState(
                () => _lockConfig = _lockConfig.copyWith(type: v.first)),
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.resolveWith((s) =>
                  s.contains(WidgetState.selected)
                      ? kNavy.withValues(alpha: 0.12)
                      : null),
            ),
          ),
          const SizedBox(height: 16),
          _label(_lockConfig.type == 'pin' ? 'New PIN' : 'New Password'),
          const SizedBox(height: 8),
          _field(_lockConfig.type == 'pin' ? 'PIN' : 'Password', _pinCtrl,
              obscure: true,
              prefixIcon: Icons.pin_rounded,
              inputFormatters: _lockConfig.type == 'pin'
                  ? [FilteringTextInputFormatter.digitsOnly,
                     LengthLimitingTextInputFormatter(6)]
                  : null),
          const SizedBox(height: 12),
          _label(_lockConfig.type == 'pin' ? 'Confirm PIN' : 'Confirm Password'),
          const SizedBox(height: 8),
          _field(_lockConfig.type == 'pin' ? 'Confirm PIN' : 'Confirm Password',
              _pinConfCtrl,
              obscure: true,
              prefixIcon: Icons.pin_rounded,
              inputFormatters: _lockConfig.type == 'pin'
                  ? [FilteringTextInputFormatter.digitsOnly,
                     LengthLimitingTextInputFormatter(6)]
                  : null),
          if (_lockMsg != null) ...[
            const SizedBox(height: 10),
            _msgWidget(_lockMsg!, _lockMsgOk),
          ],
          const SizedBox(height: 16),
          _actionButton('Save Lock', _savingLock ? null : _saveLock,
              fullWidth: true),
        ],
      ],
    );
  }

  Future<void> _saveLockDisable() async {
    setState(() { _savingLock = true; _lockMsg = null; });
    try {
      const disabled = LockConfig(enabled: false, type: 'pin', hashValue: '');
      await LocalSettingsService.instance.saveLockConfig(disabled);
      if (mounted) setState(() { _lockConfig = disabled; _savingLock = false; });
    } catch (e) {
      if (mounted) setState(() { _savingLock = false; });
    }
  }

  Widget _buildPersonalisationSection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionHeader('Personalisation', 'Themes and visible navigation items.'),
          const SizedBox(height: 28),

          // Theme selector — auto-saves on tap
          _card(
            title: 'Active Theme',
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _themeChip('light', 'Light', const Color(0xFFFEF6E4), const Color(0xFF001858)),
                _themeChip('dark', 'Dark', const Color(0xFF0D1117), const Color(0xFFE6EDF3)),
                ..._customThemes.map((t) => _themeChip(
                    t.id, t.name,
                    _hexColor(t.bgColor),
                    _hexColor(t.navyColor))),
                _addThemeChip(),
              ],
            ),
          ),

          if (_showThemeEditor) ...[
            const SizedBox(height: 20),
            _buildThemeEditor(),
          ],

          const SizedBox(height: 20),
          // Navigation items — auto-saves on each toggle
          _card(
            title: 'Navigation Items',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Toggle which items appear in the sidebar.',
                    style: TextStyle(color: cMuted(context), fontSize: 12.5)),
                const SizedBox(height: 8),
                ..._allNavItems.map((label) {
                  final hidden = _settings.hiddenNavItems.contains(label);
                  return CheckboxListTile(
                    dense: true,
                    title: Text(label,
                        style: TextStyle(
                            color: cNavy(context), fontSize: 13)),
                    value: !hidden,
                    activeColor: kNavy,
                    onChanged: (v) {
                      final updated = List<String>.from(
                          _settings.hiddenNavItems);
                      if (v == false) {
                        updated.add(label);
                      } else {
                        updated.remove(label);
                      }
                      _updateSettings(
                          _settings.copyWith(hiddenNavItems: updated));
                    },
                  );
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _themeChip(
      String id, String name, Color bg, Color text) {
    final selected = _settings.activeThemeId == id;
    return GestureDetector(
      onTap: () => _updateSettings(_settings.copyWith(activeThemeId: id)),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? kNavy : cBorder(context),
            width: selected ? 2 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                      color: kNavy.withValues(alpha: 0.12),
                      blurRadius: 8,
                      offset: const Offset(0, 2))
                ]
              : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (selected)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: Icon(Icons.check_circle_rounded,
                    color: text, size: 14),
              ),
            Text(name,
                style: TextStyle(
                    color: text,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _addThemeChip() {
    return GestureDetector(
      onTap: () {
        setState(() {
          _showThemeEditor = !_showThemeEditor;
          if (_showThemeEditor) {
            _editingTheme = const CustomTheme(
              id: '',
              name: '',
              bgColor: '#FEF6E4',
              cardColor: '#FFFFFF',
              navyColor: '#001858',
              accentColor: '#82F5B2',
              mutedColor: '#8896AA',
              borderColor: '#E8EEF4',
            );
          }
        });
        if (_showThemeEditor) {
          // Reset controller to empty so user types fresh, no reversed text
          _themeNameCtrl.clear();
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: cBg(context),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: cBorder(context)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.add_rounded, color: cMuted(context), size: 15),
          const SizedBox(width: 4),
          Text('Custom',
              style:
                  TextStyle(color: cMuted(context), fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }

  Widget _buildThemeEditor() {
    final fields = [
      ('Background', 'bgColor', _editingTheme.bgColor),
      ('Card', 'cardColor', _editingTheme.cardColor),
      ('Navy/Text', 'navyColor', _editingTheme.navyColor),
      ('Accent', 'accentColor', _editingTheme.accentColor),
      ('Muted', 'mutedColor', _editingTheme.mutedColor),
      ('Border', 'borderColor', _editingTheme.borderColor),
    ];

    return _card(
      title: 'Custom Theme Editor',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label('Theme Name'),
          const SizedBox(height: 8),
          TextField(
            decoration: InputDecoration(
              hintText: 'My Theme',
              hintStyle: TextStyle(color: cMuted(context)),
              filled: true,
              fillColor: cBg(context),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: cBorder(context))),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            ),
            controller: _themeNameCtrl,
            onChanged: (v) => setState(
                () => _editingTheme = _editingTheme.copyWith(name: v)),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: fields.map((f) {
              final (label, field, value) = f;
              final currentColor = _hexColor(value);
              return SizedBox(
                width: 160,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _label(label),
                    const SizedBox(height: 6),
                    GestureDetector(
                      onTap: () async {
                        Color picked = currentColor;
                        await showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            backgroundColor: cCard(ctx),
                            title: Text(label,
                                style: TextStyle(
                                    color:      cNavy(ctx),
                                    fontSize:   15,
                                    fontWeight: FontWeight.w700)),
                            content: SingleChildScrollView(
                              child: ColorPicker(
                                pickerColor:         currentColor,
                                onColorChanged:      (c) => picked = c,
                                enableAlpha:         false,
                                hexInputBar:         true,
                                pickerAreaHeightPercent: 0.7,
                              ),
                            ),
                            actions: [
                              TextButton(
                                  onPressed: () => Navigator.pop(ctx),
                                  child: const Text('Cancel')),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: kNavy,
                                    foregroundColor: Colors.white,
                                    elevation: 0),
                                onPressed: () => Navigator.pop(ctx),
                                child: const Text('Select'),
                              ),
                            ],
                          ),
                        );
                        // Convert picked color back to hex
                        final hex =
                            '#${picked.value.toRadixString(16).substring(2).toUpperCase()}';
                        setState(() {
                          switch (field) {
                            case 'bgColor':
                              _editingTheme = _editingTheme.copyWith(bgColor: hex);
                            case 'cardColor':
                              _editingTheme = _editingTheme.copyWith(cardColor: hex);
                            case 'navyColor':
                              _editingTheme = _editingTheme.copyWith(navyColor: hex);
                            case 'accentColor':
                              _editingTheme = _editingTheme.copyWith(accentColor: hex);
                            case 'mutedColor':
                              _editingTheme = _editingTheme.copyWith(mutedColor: hex);
                            case 'borderColor':
                              _editingTheme = _editingTheme.copyWith(borderColor: hex);
                          }
                        });
                      },
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          color:        currentColor,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: cBorder(context), width: 1.5),
                          boxShadow: [
                            BoxShadow(
                                color:      Colors.black.withValues(alpha: 0.08),
                                blurRadius: 4,
                                offset:     const Offset(0, 2)),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            value.toUpperCase(),
                            style: TextStyle(
                              color: currentColor.computeLuminance() > 0.5
                                  ? Colors.black54
                                  : Colors.white70,
                              fontSize:   11,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          Row(children: [
            _actionButton('Save Theme', () async {
              if (_editingTheme.name.trim().isEmpty) {
                _showSnack('Enter a theme name.');
                return;
              }
              final id = _editingTheme.name.trim().toLowerCase().replaceAll(RegExp(r'\s+'), '_');
              final theme = _editingTheme.copyWith(id: id);
              await LocalSettingsService.instance.saveTheme(theme);
              final themes = await LocalSettingsService.instance.loadThemes();
              if (mounted) {
                setState(() {
                  _customThemes = themes;
                  _showThemeEditor = false;
                });
                _updateSettings(_settings.copyWith(activeThemeId: id));
              }
            }),
            const SizedBox(width: 10),
            _actionButton('Cancel', () => setState(() => _showThemeEditor = false),
                secondary: true),
          ]),
        ],
      ),
    );
  }

  // ── About section ─────────────────────────────────────────────────────────

  Widget _buildAboutSection() {
    return Align(
      alignment: Alignment.topLeft,
      child: SingleChildScrollView(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          _sectionHeader('About', 'Application information.'),
          const SizedBox(height: 28),
          _card(
            title: 'App_Name School Desktop',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _infoRow('Version', kCurrentVersion),
                _infoRow('Platform', 'Windows Desktop'),
                const SizedBox(height: 16),
                Text(
                  'Powered by App_Name',
                  style: TextStyle(color: cMuted(context), fontSize: 12),
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(
                          builder: (_) => const PrivacyPolicyScreen())),
                  child: Row(
                    children: [
                      Icon(Icons.privacy_tip_outlined,
                          color: cNavy(context), size: 16),
                      const SizedBox(width: 8),
                      Text('View Privacy Policy',
                          style: TextStyle(
                              color:      cNavy(context),
                              fontSize:   13,
                              fontWeight: FontWeight.w700,
                              decoration: TextDecoration.underline,
                              decorationColor: cNavy(context))),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      ), // SingleChildScrollView
    ); // Align
  }

  // ── Shared UI helpers ─────────────────────────────────────────────────────

  Widget _sectionHeader(String title, String subtitle) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title,
          style: TextStyle(
              color: cNavy(context), fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 4),
      Text(subtitle,
          style: TextStyle(color: cMuted(context), fontSize: 13)),
    ]);
  }

  Widget _card({required String title, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cCard(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cBorder(context)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title,
            style: TextStyle(
                color: cNavy(context),
                fontSize: 14,
                fontWeight: FontWeight.w700)),
        Divider(height: 20, color: cBorder(context)),
        child,
      ]),
    );
  }

  Widget _label(String text) {
    return Text(text,
        style: TextStyle(
            color: cMuted(context),
            fontSize: 11.5,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.3));
  }

  Widget _field(String hint, TextEditingController ctrl,
      {bool obscure = false,
      IconData? prefixIcon,
      List<TextInputFormatter>? inputFormatters}) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      inputFormatters: inputFormatters,
      style:
          TextStyle(color: cNavy(context), fontSize: 14, fontWeight: FontWeight.w500),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: cMuted(context), fontSize: 13.5),
        filled: true,
        fillColor: cBg(context),
        prefixIcon: prefixIcon != null
            ? Icon(prefixIcon, color: cMuted(context), size: 18)
            : null,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: cBorder(context), width: 1.3)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: cBorder(context), width: 1.3)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: cNavy(context), width: 1.8)),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
      ),
    );
  }

  Widget _actionButton(String label, VoidCallback? onTap,
      {bool fullWidth = false, bool secondary = false}) {
    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: 42,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: secondary
              ? cBg(context)
              : kNavy.withValues(alpha: 0.88),
          foregroundColor: secondary ? cNavy(context) : Colors.white,
          elevation: 0,
          side: secondary ? BorderSide(color: cBorder(context)) : null,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 0),
        ),
        onPressed: onTap,
        child: onTap == null
            ? const SizedBox(
                width: 18,
                height: 18,
                child:
                    CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
            : Text(label,
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600)),
      ),
    );
  }

  Widget _msgWidget(String msg, bool isOk) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: (isOk ? Colors.green : kError).withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
            color: (isOk ? Colors.green : kError).withValues(alpha: 0.25)),
      ),
      child: Row(children: [
        Icon(
            isOk
                ? Icons.check_circle_outline_rounded
                : Icons.error_outline_rounded,
            color: isOk ? Colors.green : kError,
            size: 14),
        const SizedBox(width: 8),
        Expanded(
          child: Text(msg,
              style: TextStyle(
                  color: isOk ? Colors.green : kError,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500)),
        ),
      ]),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        SizedBox(
          width: 120,
          child: Text(label,
              style: TextStyle(
                  color: cMuted(context),
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600)),
        ),
        Expanded(
          child: Text(value,
              style: TextStyle(
                  color: cNavy(context),
                  fontSize: 13,
                  fontWeight: FontWeight.w500)),
        ),
      ]),
    );
  }

  Color _hexColor(String hex) {
    try {
      final cleaned = hex.replaceAll('#', '');
      if (cleaned.length == 6) {
        return Color(int.parse('FF$cleaned', radix: 16));
      }
    } catch (_) {}
    return Colors.grey;
  }
}
