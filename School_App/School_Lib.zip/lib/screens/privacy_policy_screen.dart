// lib/screens/privacy_policy_screen.dart
import 'package:flutter/material.dart';
import '../app_theme.dart';
import '../privacy_policy_content.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cBg(context),
      appBar: AppBar(
        backgroundColor: cCard(context),
        foregroundColor: cNavy(context),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: cNavy(context), size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(kPrivacyPolicyTitle,
            style: TextStyle(
                color:      cNavy(context),
                fontSize:   17,
                fontWeight: FontWeight.w800)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 60),
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color:        kNavy.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(14),
              border:       Border.all(color: kNavy.withValues(alpha: 0.1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$kAppName — $kAppRole',
                    style: TextStyle(
                        color:      cNavy(context),
                        fontSize:   16,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text('Last updated: $kLastUpdated',
                    style: TextStyle(color: cMuted(context), fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(height: 24),

          _Section(kPrivacyIntro, isIntro: true),

          _SectionBlock(kPrivacyDataCollectedTitle, kPrivacyDataCollected),
          _SectionBlock(kPrivacyChildrenTitle, kPrivacyChildren,
              highlight: true),
          _SectionBlock(kPrivacyDataUseTitle, kPrivacyDataUse),
          _SectionBlock(kPrivacySharingTitle, kPrivacySharing),
          _SectionBlock(kPrivacySecurityTitle, kPrivacySecurity),
          _SectionBlock(kPrivacyContactTitle, kPrivacyContact),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String text;
  final bool   isIntro;
  const _Section(this.text, {this.isIntro = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Text(text.trim(),
          style: TextStyle(
              color:    cBlue(context),
              fontSize: isIntro ? 14 : 13,
              height:   1.6)),
    );
  }
}

class _SectionBlock extends StatelessWidget {
  final String title;
  final String body;
  final bool   highlight;
  const _SectionBlock(this.title, this.body, {this.highlight = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        highlight
            ? kTeal.withValues(alpha: 0.07)
            : cCard(context),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: highlight
                ? kTeal.withValues(alpha: 0.3)
                : cBorder(context)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: TextStyle(
                  color:      cNavy(context),
                  fontSize:   14,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(body.trim(),
              style: TextStyle(
                  color:    cBlue(context),
                  fontSize: 13,
                  height:   1.6)),
        ],
      ),
    );
  }
}
