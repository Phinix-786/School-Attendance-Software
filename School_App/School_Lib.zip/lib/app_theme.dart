// lib/app_theme.dart
import 'package:flutter/material.dart';

// ── Light Theme (Happy Hues Palette) ────────────────────────
const kBg    = Color(0xFFFEF6E4); // warm cream background
const kNavy  = Color(0xFF001858); // headline / dark text
const kBlue  = Color(0xFF172C66); // paragraph text
const kPink  = Color.fromARGB(255, 130, 245, 178); // primary accent
const kTeal  = Color(0xFF8BD3DD); // secondary accent
const kCard  = Color(0xFFFFFFFF); // card surfaces
const kMuted = Color(0xFF8896AA); // muted / hint text
const kBorder= Color(0xFFE8EEF4); // input borders
const kError = Color(0xFFE53E6B); // error red-pink

// ── Dark Theme ───────────────────────────────────────────────
const kDarkBg    = Color(0xFF0D1117); // GitHub-style deep background
const kDarkCard  = Color(0xFF161B22); // elevated surface
const kDarkNavy  = Color(0xFFE6EDF3); // primary text (light on dark)
const kDarkBlue  = Color(0xFFC9D1D9); // secondary text
const kDarkMuted = Color(0xFF8B949E); // muted / hint text
const kDarkBorder= Color(0xFF30363D); // dividers / borders
const kDarkPink  = Color(0xFF56D364); // accent green (brighter)
const kDarkTeal  = Color(0xFF79C0FF); // teal / highlight blue

// ── Global Theme Notifier ────────────────────────────────────
/// Toggle this to switch the entire app between light and dark.
final themeNotifier = ValueNotifier<ThemeMode>(ThemeMode.light);

// ── Convenience boolean ──────────────────────────────────────
bool isDark(BuildContext ctx) =>
    Theme.of(ctx).brightness == Brightness.dark;

// ── Adaptive color helpers (use inside build methods) ────────
Color cBg(BuildContext c)     => isDark(c) ? kDarkBg     : kBg;
Color cCard(BuildContext c)   => isDark(c) ? kDarkCard   : kCard;
Color cNavy(BuildContext c)   => isDark(c) ? kDarkNavy   : kNavy;
Color cBlue(BuildContext c)   => isDark(c) ? kDarkBlue   : kBlue;
Color cMuted(BuildContext c)  => isDark(c) ? kDarkMuted  : kMuted;
Color cBorder(BuildContext c) => isDark(c) ? kDarkBorder : kBorder;
Color cError(BuildContext c)  => kError;   // stays the same in both

// ── Light ThemeData ──────────────────────────────────────────
final lightThemeData = ThemeData(
  brightness:             Brightness.light,
  scaffoldBackgroundColor: kBg,
  colorScheme: const ColorScheme.light(
    primary:   kNavy,
    secondary: kTeal,
    surface:   kBg,
  ),
  textTheme: const TextTheme(
    bodyMedium: TextStyle(color: kBlue),
  ),
  dividerColor: kBorder,
);

// ── Dark ThemeData ───────────────────────────────────────────
final darkThemeData = ThemeData(
  brightness:             Brightness.dark,
  scaffoldBackgroundColor: kDarkBg,
  colorScheme: const ColorScheme.dark(
    primary:   kDarkTeal,
    secondary: kDarkPink,
    surface:   kDarkCard,
  ),
  textTheme: const TextTheme(
    bodyMedium: TextStyle(color: kDarkBlue),
  ),
  dividerColor: kDarkBorder,
);