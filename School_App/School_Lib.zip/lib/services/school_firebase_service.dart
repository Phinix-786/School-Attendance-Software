// lib/services/school_firebase_service.dart
// Section-scoped version. All data lives under:
//   schools/{schoolId}/sections/{sectionId}/...
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/models.dart';

class SchoolFirebaseService {
  static final _db = FirebaseFirestore.instance;

  /// Returns true when sectionId is empty (admin with no section selected).
  static bool _noSection(String sectionId) => sectionId.trim().isEmpty;

  static String _base(String schoolId, String sectionId) =>
      'schools/$schoolId/sections/$sectionId';

  static CollectionReference<Map<String, dynamic>> _classesCol(
          String sid, String secId) =>
      _db.collection('${_base(sid, secId)}/classes');

  static CollectionReference<Map<String, dynamic>> _studentsCol(
          String sid, String secId, String cid) =>
      _db.collection('${_base(sid, secId)}/classes/$cid/students');

  static CollectionReference<Map<String, dynamic>> _classTeachersCol(
          String sid, String secId, String cid) =>
      _db.collection('${_base(sid, secId)}/classes/$cid/teachers');

  static CollectionReference<Map<String, dynamic>> _globalTeachersCol(
          String sid, String secId) =>
      _db.collection('${_base(sid, secId)}/teachers');

  static CollectionReference<Map<String, dynamic>> _attendanceCol(
          String sid, String secId) =>
      _db.collection('${_base(sid, secId)}/attendance_sessions');

  // -- Sections -------------------------------------------------------------
  static Future<List<Map<String, dynamic>>> getSections(String schoolId) async {
    final snap = await _db.collection('schools/$schoolId/sections').get();
    return snap.docs.map((d) => d.data()).toList();
  }

  // -- Classes --------------------------------------------------------------
  static Future<void> addClass(SchoolClass c, String sectionId) async {
    if (_noSection(sectionId)) return;
    await _classesCol(c.schoolId, sectionId).doc(c.id).set(c.toMap());
  }

  static Future<void> updateClass(SchoolClass c, String sectionId) async {
    if (_noSection(sectionId)) return;
    await _classesCol(c.schoolId, sectionId).doc(c.id).update(c.toMap());
  }

  static Future<void> deleteClass(
      String schoolId, String sectionId, String classId) async {
    if (_noSection(sectionId)) return;
    final stuSnap = await _studentsCol(schoolId, sectionId, classId).get();
    if (stuSnap.docs.isNotEmpty) {
      final b = _db.batch();
      for (final d in stuSnap.docs) b.delete(d.reference);
      await b.commit();
    }
    final tchSnap = await _classTeachersCol(schoolId, sectionId, classId).get();
    if (tchSnap.docs.isNotEmpty) {
      final b = _db.batch();
      for (final d in tchSnap.docs) b.delete(d.reference);
      await b.commit();
    }
    await _classesCol(schoolId, sectionId).doc(classId).delete();
  }

  static Stream<List<SchoolClass>> classesStream(
      String schoolId, String sectionId) {
    if (_noSection(sectionId)) return Stream.value([]);
    return _classesCol(schoolId, sectionId)
        .snapshots()
        .map((s) => s.docs.map((d) => SchoolClass.fromMap(d.data())).toList());
  }

  // -- Students -------------------------------------------------------------
  static String _studentDocId(Student s) =>
      '${s.name}_${s.rollNo}'.replaceAll(RegExp(r'[^\w\-]'), '_');

  static Future<void> addStudent(Student s, String sectionId) async {
    if (_noSection(sectionId)) return;
    final docId = _studentDocId(s);
    await _studentsCol(s.schoolId, sectionId, s.classId).doc(docId).set(s.toMap());
  }

  static Future<void> updateStudent(Student s, String sectionId) async {
    if (_noSection(sectionId)) return;
    final classes = await _classesCol(s.schoolId, sectionId).get();
    final batch = _db.batch();
    for (final classDoc in classes.docs) {
      final cid = classDoc.id;
      if (cid == s.classId) continue;
      final oldRef = _studentsCol(s.schoolId, sectionId, cid).doc(s.id);
      final oldSnap = await oldRef.get();
      if (oldSnap.exists) batch.delete(oldRef);
    }
    final docId = _studentDocId(s);
    batch.set(_studentsCol(s.schoolId, sectionId, s.classId).doc(docId), s.toMap());
    await batch.commit();
  }

  static Future<void> deleteStudent(
      String schoolId, String sectionId, String classId, String studentId) async {
    if (_noSection(sectionId)) return;
    await _studentsCol(schoolId, sectionId, classId).doc(studentId).delete();
  }

  static Stream<List<Student>> studentsStream(
      String schoolId, String sectionId, {String? classId}) {
    if (_noSection(sectionId)) return Stream.value([]);

    if (classId != null) {
      return _studentsCol(schoolId, sectionId, classId)
          .snapshots()
          .map((s) => s.docs.map((d) => Student.fromMap(d.data())).toList());
    }

    // Use a single get()-based fetch to avoid spawning N+1 concurrent Firestore
    // snapshot listeners (one per class), which crashes the Firebase C++ Windows SDK.
    return Stream.fromFuture(_fetchAllStudents(schoolId, sectionId));
  }

  static Stream<List<Student>> studentsForClassStream(
      String schoolId, String sectionId, String classId) {
    if (_noSection(sectionId)) return Stream.value([]);
    return _studentsCol(schoolId, sectionId, classId)
        .snapshots()
        .map((s) => s.docs.map((d) => Student.fromMap(d.data())).toList());
  }

  static Future<List<Student>> getStudentsByClass(
      String schoolId, String sectionId, String classId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _studentsCol(schoolId, sectionId, classId).get();
    return snap.docs.map((d) => Student.fromMap(d.data())).toList();
  }

  static Future<List<Student>> getStudentsByIds(
      String schoolId, String sectionId, List<String> ids) async {
    if (_noSection(sectionId) || ids.isEmpty) return [];
    final classSnap = await _classesCol(schoolId, sectionId).get();
    final result = <Student>[];
    final remaining = Set<String>.from(ids);
    for (final classDoc in classSnap.docs) {
      if (remaining.isEmpty) break;
      final idList = remaining.toList();
      for (int i = 0; i < idList.length; i += 30) {
        final chunk = idList.sublist(i, (i + 30).clamp(0, idList.length));
        final snap = await _studentsCol(schoolId, sectionId, classDoc.id)
            .where(FieldPath.documentId, whereIn: chunk).get();
        for (final d in snap.docs) {
          result.add(Student.fromMap(d.data()));
          remaining.remove(d.id);
        }
      }
    }
    return result;
  }

  // -- Teachers -------------------------------------------------------------
  static Future<void> addTeacher(Teacher t, String sectionId) async {
    if (_noSection(sectionId)) return;
    await _globalTeachersCol(t.schoolId, sectionId).doc(t.id).set(t.toMap());
    await _syncTeacherToClasses(t, sectionId);
  }

  static Future<void> updateTeacher(Teacher t, String sectionId) async {
    if (_noSection(sectionId)) return;
    await _globalTeachersCol(t.schoolId, sectionId).doc(t.id).set(t.toMap());
    final classSnap = await _classesCol(t.schoolId, sectionId).get();
    final batch = _db.batch();
    for (final classDoc in classSnap.docs) {
      final mirrorRef = _classTeachersCol(t.schoolId, sectionId, classDoc.id).doc(t.id);
      final mirrorSnap = await mirrorRef.get();
      if (mirrorSnap.exists) batch.delete(mirrorRef);
    }
    await batch.commit();
    await _syncTeacherToClasses(t, sectionId);
  }

  static Future<void> deleteTeacher(
      String schoolId, String sectionId, String teacherId) async {
    if (_noSection(sectionId)) return;
    final classSnap = await _classesCol(schoolId, sectionId).get();
    final batch = _db.batch();
    for (final classDoc in classSnap.docs) {
      final mirrorRef =
          _classTeachersCol(schoolId, sectionId, classDoc.id).doc(teacherId);
      final mirrorSnap = await mirrorRef.get();
      if (mirrorSnap.exists) batch.delete(mirrorRef);
    }
    await batch.commit();
    await _globalTeachersCol(schoolId, sectionId).doc(teacherId).delete();
  }

  static Stream<List<Teacher>> teachersStream(
      String schoolId, String sectionId) {
    if (_noSection(sectionId)) return Stream.value([]);
    return _globalTeachersCol(schoolId, sectionId)
        .snapshots()
        .map((s) => s.docs.map((d) => Teacher.fromMap(d.data())).toList());
  }

  static Stream<List<Teacher>> teachersForClassStream(
      String schoolId, String sectionId, String classId) {
    if (_noSection(sectionId)) return Stream.value([]);
    return _classTeachersCol(schoolId, sectionId, classId)
        .snapshots()
        .map((s) => s.docs.map((d) => Teacher.fromMap(d.data())).toList());
  }

  static Future<void> _syncTeacherToClasses(Teacher t, String sectionId) async {
    if (_noSection(sectionId)) return;
    for (final classId in t.assignedClassIds) {
      await _classTeachersCol(t.schoolId, sectionId, classId).doc(t.id).set(t.toMap());
    }
  }

  // -- Attendance Sessions --------------------------------------------------
  static Future<void> createSession(
      AttendanceSession session, String sectionId) async {
    if (_noSection(sectionId)) return;
    await _attendanceCol(session.schoolId, sectionId)
        .doc(session.id)
        .set(session.toMap());
  }

  static Future<void> updateSession(
      AttendanceSession session, String sectionId) async {
    if (_noSection(sectionId)) return;
    await _attendanceCol(session.schoolId, sectionId)
        .doc(session.id)
        .update(session.toMap());
  }

  static Stream<List<AttendanceSession>> todaySessionsStream(
      String schoolId, String sectionId) {
    if (_noSection(sectionId)) return Stream.value([]);
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final end = start.add(const Duration(days: 1));
    return _attendanceCol(schoolId, sectionId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .snapshots()
        .map((s) => s.docs.map((d) => AttendanceSession.fromMap(d.data())).toList());
  }

  // -- Attendance Records ---------------------------------------------------
  static Future<void> saveAttendanceRecords(String schoolId, String sectionId,
      String sessionId, List<AttendanceRecord> records) async {
    if (_noSection(sectionId)) return;
    final batch = _db.batch();
    for (final r in records) {
      final ref = _db
          .collection('${_base(schoolId, sectionId)}/attendance_sessions/$sessionId/records')
          .doc(r.id);
      batch.set(ref, r.toMap());
    }
    await batch.commit();
  }

  static Future<List<AttendanceRecord>> getSessionRecords(
      String schoolId, String sectionId, String sessionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection(
            '${_base(schoolId, sectionId)}/attendance_sessions/$sessionId/records')
        .get();
    for (final doc in snap.docs) {
      debugPrint('[getSessionRecords] studentId=${doc.data()['studentId']} '
          'rawStatus="${doc.data()['status']}"');
    }
    return snap.docs.map((d) => AttendanceRecord.fromMap(d.data())).toList();
  }

  // -- School Config --------------------------------------------------------
  static Future<Map<String, dynamic>?> getSchoolConfig(String schoolId) async {
    final doc = await _db.collection('schools').doc(schoolId).get();
    return doc.data();
  }

  static Future<Object?> classExistsWithName(
      String schoolId, String sectionId, String name) async {}
  static Future<List<Student>> _fetchAllStudents(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final classSnap = await _classesCol(schoolId, sectionId).get();
    final results = await Future.wait(
      classSnap.docs.map((d) => _studentsCol(schoolId, sectionId, d.id).get()),
    );
    return results
        .expand((snap) => snap.docs.map((d) => Student.fromMap(d.data())))
        .toList();
  }


  // -- get()-based helpers (no persistent listeners, safe for Windows) ------

  static Future<List<Student>> getAllStudents(
      String schoolId, String sectionId) async {
    return _fetchAllStudents(schoolId, sectionId);
  }

  static Future<List<Teacher>> getAllTeachers(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _globalTeachersCol(schoolId, sectionId).get();
    return snap.docs.map((d) => Teacher.fromMap(d.data())).toList();
  }

  static Future<List<AttendanceSession>> getTodaySessions(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final end   = start.add(const Duration(days: 1));
    final snap  = await _attendanceCol(schoolId, sectionId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .get();
    return snap.docs.map((d) => AttendanceSession.fromMap(d.data())).toList();
  }

  static Future<List<SchoolClass>> getClasses(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _classesCol(schoolId, sectionId).get();
    return snap.docs.map((d) => SchoolClass.fromMap(d.data())).toList();
  }

  // -- Tests (read-only) ----------------------------------------------------
  static Future<List<SchoolTest>> getTests(
      String schoolId, String sectionId, String classId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection('${_base(schoolId, sectionId)}/classes/$classId/tests')
        .orderBy('testDate', descending: true)
        .get();
    return snap.docs.map((d) => SchoolTest.fromMap(d.data())).toList();
  }

  // -- All results for every student for one test (for class report) ----------
  static Future<List<TestResult>> getTestResultsForTest(
      String schoolId, String sectionId, String classId,
      String testId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection(
            '${_base(schoolId, sectionId)}/classes/$classId/tests/$testId/results')
        .get();
    return snap.docs.map((d) => TestResult.fromMap(d.data())).toList();
  }

  static Future<List<TestResult>> getTestResultsForStudent(
      String schoolId, String sectionId, String classId,
      String testId, String studentId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection(
            '${_base(schoolId, sectionId)}/classes/$classId/tests/$testId/results')
        .where('studentId', isEqualTo: studentId)
        .limit(1)
        .get();
    return snap.docs.map((d) => TestResult.fromMap(d.data())).toList();
  }

  // -- Notices ---------------------------------------------------------------
  static Future<void> addNotice(
      String schoolId, String sectionId, SchoolNotice notice) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('${_base(schoolId, sectionId)}/notices')
        .doc(notice.id)
        .set(notice.toMap());
  }

  static Future<List<SchoolNotice>> getNotices(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection('${_base(schoolId, sectionId)}/notices')
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => SchoolNotice.fromMap(d.data())).toList();
  }

  // -- Leaves ----------------------------------------------------------------
  static Future<List<LeaveRequest>> getLeavesForSection(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection('${_base(schoolId, sectionId)}/leaves')
        .orderBy('submittedAt', descending: true)
        .get();
    return snap.docs.map((d) => LeaveRequest.fromMap(d.data())).toList();
  }

  static Future<void> updateLeaveStatus(
      String schoolId, String sectionId, String leaveId,
      String status, String remarks) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('${_base(schoolId, sectionId)}/leaves')
        .doc(leaveId)
        .update({'status': status, 'remarks': remarks});
  }

  // -- Timetables -----------------------------------------------------------
  static Future<void> saveTimetable(
      String schoolId, String sectionId, TeacherTimetable tt) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('${_base(schoolId, sectionId)}/timetables')
        .doc(tt.teacherId)
        .set(tt.toMap());
  }

  static Future<TeacherTimetable?> getTimetable(
      String schoolId, String sectionId, String teacherId) async {
    if (_noSection(sectionId)) return null;
    final doc = await _db
        .collection('${_base(schoolId, sectionId)}/timetables')
        .doc(teacherId)
        .get();
    if (!doc.exists) return null;
    return TeacherTimetable.fromMap(doc.data()!);
  }

  static Future<List<TeacherTimetable>> getAllTimetables(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection('${_base(schoolId, sectionId)}/timetables')
        .get();
    return snap.docs.map((d) => TeacherTimetable.fromMap(d.data())).toList();
  }

  // -- Admin username -------------------------------------------------------
  static Future<String?> getAdminName(String schoolId) async {
    final doc = await _db.collection('schools').doc(schoolId).get();
    return doc.data()?['adminName'] as String?;
  }

  static Future<void> setAdminName(String schoolId, String name) async {
    await _db.collection('schools').doc(schoolId).update({'adminName': name});
  }

  // -- Credential management (admin change any ID/pass) --------------------
  static Future<void> updateStudentCredentials(
      String schoolId, String sectionId, String studentDocId,
      String classId, {
      String? studentLoginId, String? studentPassword,
      String? parentLoginId, String? parentPassword}) async {
    if (_noSection(sectionId)) return;
    final updates = <String, dynamic>{};
    if (studentLoginId != null) updates['studentLoginId'] = studentLoginId;
    if (studentPassword != null) updates['studentPassword'] = studentPassword;
    if (parentLoginId  != null) updates['parentLoginId']   = parentLoginId;
    if (parentPassword != null) updates['parentPassword']  = parentPassword;
    if (updates.isEmpty) return;
    await _studentsCol(schoolId, sectionId, classId)
        .doc(studentDocId)
        .update(updates);
  }

  static Future<void> updateTeacherCredentials(
      String schoolId, String sectionId, String teacherId,
      {String? password}) async {
    if (_noSection(sectionId) || password == null) return;
    await _globalTeachersCol(schoolId, sectionId)
        .doc(teacherId)
        .update({'password': password});
  }

  // -- Attendance for date range (for PDF export) ---------------------------
  static Future<List<AttendanceExportRow>> getAttendanceForDateRange(
      String schoolId, String sectionId, String classId,
      DateTime startDate, DateTime endDate) async {
    if (_noSection(sectionId)) return [];
    final start = DateTime(startDate.year, startDate.month, startDate.day);
    final end   = DateTime(endDate.year, endDate.month, endDate.day)
        .add(const Duration(days: 1));
    final sessSnap = await _attendanceCol(schoolId, sectionId)
        .where('classId', isEqualTo: classId)
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThan: Timestamp.fromDate(end))
        .get();

    final rows = <AttendanceExportRow>[];
    for (final sessDoc in sessSnap.docs) {
      final session = AttendanceSession.fromMap(sessDoc.data());
      final recSnap = await _db
          .collection(
              '${_base(schoolId, sectionId)}/attendance_sessions/${session.id}/records')
          .get();
      for (final recDoc in recSnap.docs) {
        final rec = AttendanceRecord.fromMap(recDoc.data());
        rows.add(AttendanceExportRow(
          studentId:  rec.studentId,
          date:       session.date,
          status:     rec.status,
        ));
      }
    }
    return rows;
  }

  // -- Documents (admin-only) -----------------------------------------------

  static Future<void> addTeacherDocument(
      String schoolId, String sectionId, String teacherId,
      StoredDocument doc) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection(
            '${_base(schoolId, sectionId)}/teacher_documents/$teacherId/files')
        .doc(doc.id)
        .set(doc.toMap());
  }

  static Future<List<StoredDocument>> getTeacherDocuments(
      String schoolId, String sectionId, String teacherId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection(
            '${_base(schoolId, sectionId)}/teacher_documents/$teacherId/files')
        .orderBy('uploadedAt', descending: true)
        .get();
    return snap.docs.map((d) => StoredDocument.fromMap(d.data())).toList();
  }

  static Future<void> deleteTeacherDocument(
      String schoolId, String sectionId, String teacherId,
      String docId) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection(
            '${_base(schoolId, sectionId)}/teacher_documents/$teacherId/files')
        .doc(docId)
        .delete();
  }

  static Future<void> addStudentDocument(
      String schoolId, String sectionId, String studentId,
      StoredDocument doc) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection(
            '${_base(schoolId, sectionId)}/student_documents/$studentId/files')
        .doc(doc.id)
        .set(doc.toMap());
  }

  static Future<List<StoredDocument>> getStudentDocuments(
      String schoolId, String sectionId, String studentId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection(
            '${_base(schoolId, sectionId)}/student_documents/$studentId/files')
        .orderBy('uploadedAt', descending: true)
        .get();
    return snap.docs.map((d) => StoredDocument.fromMap(d.data())).toList();
  }

  static Future<void> deleteStudentDocument(
      String schoolId, String sectionId, String studentId,
      String docId) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection(
            '${_base(schoolId, sectionId)}/student_documents/$studentId/files')
        .doc(docId)
        .delete();
  }

  // -- Fee Management --------------------------------------------------------

  static Future<void> addFeeRecord(
      String schoolId, String sectionId, FeeRecord record) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('${_base(schoolId, sectionId)}/fees')
        .doc(record.id)
        .set(record.toMap());
  }

  static Future<void> updateFeeRecord(
      String schoolId, String sectionId, FeeRecord record) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('${_base(schoolId, sectionId)}/fees')
        .doc(record.id)
        .set(record.toMap());
  }

  static Future<void> deleteFeeRecord(
      String schoolId, String sectionId, String feeId) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('${_base(schoolId, sectionId)}/fees')
        .doc(feeId)
        .delete();
  }

  static Future<List<FeeRecord>> getFeeRecordsForStudent(
      String schoolId, String sectionId, String studentId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection('${_base(schoolId, sectionId)}/fees')
        .where('studentId', isEqualTo: studentId)
        .orderBy('month', descending: true)
        .get();
    return snap.docs.map((d) => FeeRecord.fromMap(d.data())).toList();
  }

  static Future<List<FeeRecord>> getAllFeeRecords(
      String schoolId, String sectionId) async {
    if (_noSection(sectionId)) return [];
    final snap = await _db
        .collection('${_base(schoolId, sectionId)}/fees')
        .orderBy('month', descending: true)
        .get();
    return snap.docs.map((d) => FeeRecord.fromMap(d.data())).toList();
  }

  // -- Section password update -----------------------------------------------

  static Future<void> updateSectionPassword(
      String schoolId, String sectionId, String newPassword) async {
    if (_noSection(sectionId)) return;
    await _db
        .collection('schools/$schoolId/sections')
        .doc(sectionId)
        .update({'password': newPassword});
  }

  static Future<void> updateAdminPassword(
      String schoolId, String newPassword) async {
    await _db
        .collection('schools')
        .doc(schoolId)
        .update({'adminPassword': newPassword});
  }
}

class AttendanceExportRow {
  final String           studentId;
  final DateTime         date;
  final AttendanceStatus status;
  AttendanceExportRow({
    required this.studentId,
    required this.date,
    required this.status,
  });
}