// lib/services/auto_updater_service.dart

import 'dart:async';
import 'dart:convert';
import 'dart:ffi';
import 'dart:io';

import 'package:ffi/ffi.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── Windows ShellExecute via FFI (needed to launch elevated .exe) ──────────
typedef _ShellExecuteW = Int32 Function(
  IntPtr hwnd,
  Pointer<Utf16> lpOperation,
  Pointer<Utf16> lpFile,
  Pointer<Utf16> lpParameters,
  Pointer<Utf16> lpDirectory,
  Int32 nShowCmd,
);
typedef _ShellExecuteDart = int Function(
  int hwnd,
  Pointer<Utf16> lpOperation,
  Pointer<Utf16> lpFile,
  Pointer<Utf16> lpParameters,
  Pointer<Utf16> lpDirectory,
  int nShowCmd,
);

void _shellExecuteElevated(String exePath, String args) {
  final shell32 = DynamicLibrary.open('shell32.dll');
  final shellExecuteW = shell32.lookupFunction<_ShellExecuteW, _ShellExecuteDart>(
    'ShellExecuteW',
  );

  final operation  = 'runas'.toNativeUtf16();
  final file       = exePath.toNativeUtf16();
  final parameters = args.toNativeUtf16();
  final directory  = nullptr.cast<Utf16>();
  const swShownormal = 1;

  shellExecuteW(0, operation, file, parameters, directory, swShownormal);

  calloc.free(operation);
  calloc.free(file);
  calloc.free(parameters);
}

// ── CONFIG ─────────────────────────────────────────────────────────────────
const kGithubOwner   = 'App_Name-sas';
const kGithubRepo    = 'app_updates';
const kCurrentVersion = '1.0.8';
// ──────────────────────────────────────────────────────────────────────────

class AutoUpdaterService {
  AutoUpdaterService._();
  static final AutoUpdaterService instance = AutoUpdaterService._();

  final ValueNotifier<double?> downloadProgress = ValueNotifier(null);
  final ValueNotifier<UpdaterState> state = ValueNotifier(UpdaterState.idle);

  void dispose() {
    downloadProgress.dispose();
    state.dispose();
  }

  /// Call once from main(). Checks for update on every app start.
  Future<void> init() async {
    if (!Platform.isWindows) return;
    final prefs = await SharedPreferences.getInstance();
    await _checkAndUpdate(prefs);
  }

  /// Force an immediate update check (e.g. from a settings button).
  Future<void> forceCheck() async {
    if (!Platform.isWindows) return;
    final prefs = await SharedPreferences.getInstance();
    await _checkAndUpdate(prefs);
  }

  Future<void> _checkAndUpdate(SharedPreferences prefs) async {
    debugPrint('[Updater] Checking for updates…');
    state.value = UpdaterState.checking;

    try {
      // ── 1. Fetch latest release from GitHub API ──────────────────────────
      final apiUrl = Uri.parse(
          'https://api.github.com/repos/$kGithubOwner/$kGithubRepo/releases/latest');

      final resp = await http
          .get(apiUrl, headers: {'Accept': 'application/vnd.github+json'})
          .timeout(const Duration(seconds: 15));

      if (resp.statusCode != 200) {
        debugPrint('[Updater] GitHub API returned ${resp.statusCode}');
        state.value = UpdaterState.idle;
        return;
      }

      // ── 2. Parse version tag ─────────────────────────────────────────────
      final json      = jsonDecode(resp.body) as Map<String, dynamic>;
      final remoteTag = (json['tag_name'] as String? ?? '').replaceAll('v', '');
      final assets    = (json['assets']   as List?  ) ?? [];

      debugPrint('[Updater] Remote: $remoteTag  Local: $kCurrentVersion');

      if (!_isNewer(remoteTag, kCurrentVersion)) {
        debugPrint('[Updater] Already up to date.');
        state.value = UpdaterState.upToDate;
        Future.delayed(const Duration(seconds: 4), () {
          if (state.value == UpdaterState.upToDate) {
            state.value = UpdaterState.idle;
          }
        });
        return;
      }

      // ── 3. Find the .exe asset ───────────────────────────────────────────
      final exeAsset = assets.firstWhere(
        (a) => (a['name'] as String).endsWith('.exe'),
        orElse: () => null,
      );

      if (exeAsset == null) {
        debugPrint('[Updater] No .exe asset found in release.');
        state.value = UpdaterState.idle;
        return;
      }

      final downloadUrl = exeAsset['browser_download_url'] as String;
      final assetName   = exeAsset['name']                 as String;

      debugPrint('[Updater] Downloading $assetName from $downloadUrl');
      state.value = UpdaterState.downloading;

      // ── 4. Download to temp dir ──────────────────────────────────────────
      final exeDir   = p.dirname(Platform.resolvedExecutable);
      final tmpDir   = await getTemporaryDirectory();
      final savePath = p.join(tmpDir.path, assetName);
      final saveFile = File(savePath);

      final dlResp = await http.Client().send(http.Request('GET', Uri.parse(downloadUrl)));
      final total  = dlResp.contentLength ?? 0;
      int received = 0;

      final sink = saveFile.openWrite();
      await for (final chunk in dlResp.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) downloadProgress.value = received / total;
      }
      await sink.flush();
      await sink.close();

      downloadProgress.value = 1.0;
      debugPrint('[Updater] Download complete → $savePath');
      state.value = UpdaterState.installing;

      // ── 5. Run installer silently ─────────────────────────────────────────
      final installArgs =
          '/VERYSILENT /SUPPRESSMSGBOXES "/DIR=\\"$exeDir\\"" /NORESTART';
      _shellExecuteElevated(savePath, installArgs);

      debugPrint('[Updater] Installer launched — exiting app…');

      // ── 6. Exit so the installer can overwrite the exe ───────────────────
      await Future.delayed(const Duration(seconds: 2));
      exit(0);

    } catch (e, st) {
      debugPrint('[Updater] Error: $e\n$st');
      state.value            = UpdaterState.idle;
      downloadProgress.value = null;
    }
  }

  static bool _isNewer(String remote, String local) {
    try {
      final r = _parse(remote);
      final l = _parse(local);
      for (int i = 0; i < 3; i++) {
        if (r[i] > l[i]) return true;
        if (r[i] < l[i]) return false;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  static List<int> _parse(String v) {
    final parts = v.split('.').map((s) => int.tryParse(s) ?? 0).toList();
    while (parts.length < 3) parts.add(0);
    return parts;
  }
}

enum UpdaterState { idle, checking, upToDate, downloading, installing }