// lib/services/feature_service.dart
// Feature flag management stored in SharedPreferences, keyed by schoolId+sectionId.
// On disable, relevant Firestore data is permanently deleted.
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FeatureService {
  FeatureService._();
  static final FeatureService instance = FeatureService._();

  // ── Feature keys ─────────────────────────────────────────────────────────
  static const String kAttendance    = 'FEATURE_ATTENDANCE';
  static const String kClasses       = 'FEATURE_CLASSES';
  static const String kStudents      = 'FEATURE_STUDENTS';
  static const String kTeachers      = 'FEATURE_TEACHERS';
  static const String kTimetable     = 'FEATURE_TIMETABLE';
  static const String kNotices       = 'FEATURE_NOTICES';
  static const String kTests         = 'FEATURE_TESTS';
  static const String kLeaves        = 'FEATURE_LEAVES';
  static const String kFeeManagement = 'FEATURE_FEE_MANAGEMENT';
  static const String kDocuments     = 'FEATURE_DOCUMENTS';

  // Ordered list for UI display
  static const List<String> allFeatureKeys = [
    kAttendance,
    kClasses,
    kStudents,
    kTeachers,
    kTimetable,
    kNotices,
    kTests,
    kLeaves,
    kFeeManagement,
    kDocuments,
  ];

  // ── Default values ───────────────────────────────────────────────────────
  static const Map<String, bool> _defaults = {
    kAttendance:    true,
    kClasses:       true,
    kStudents:      true,
    kTeachers:      true,
    kTimetable:     true,
    kNotices:       true,
    kTests:         true,
    kLeaves:        true,
    kFeeManagement: false,
    kDocuments:     false,
  };

  // ── Feature metadata (name, description, icon codepoint) ────────────────
  static const Map<String, FeatureMeta> metadata = {
    kAttendance: FeatureMeta(
      label: 'Attendance',
      description: 'Track daily student attendance by class and generate session reports.',
      iconCodePoint: 0xe3fc, // Icons.fact_check_rounded
      adminOnly: false,
    ),
    kClasses: FeatureMeta(
      label: 'Classes',
      description: 'Manage class groups within your section, assign teachers, and enrol students.',
      iconCodePoint: 0xe21a, // Icons.class_rounded
      adminOnly: false,
    ),
    kStudents: FeatureMeta(
      label: 'Students',
      description: 'Maintain a complete student directory with credentials, contact info, and class assignments.',
      iconCodePoint: 0xe614, // Icons.people_alt_rounded
      adminOnly: false,
    ),
    kTeachers: FeatureMeta(
      label: 'Teachers',
      description: 'Manage teacher profiles, assigned classes, subjects, and login credentials.',
      iconCodePoint: 0xf02a3, // Icons.person_4_rounded
      adminOnly: false,
    ),
    kTimetable: FeatureMeta(
      label: 'Timetable',
      description: 'Build and view per-teacher timetables showing subjects, days, and class periods.',
      iconCodePoint: 0xe225, // Icons.calendar_month_rounded
      adminOnly: false,
    ),
    kNotices: FeatureMeta(
      label: 'Notices',
      description: 'Post notices to teachers, students, or parents — broadcasts through the mobile apps.',
      iconCodePoint: 0xe142, // Icons.campaign_rounded
      adminOnly: false,
    ),
    kTests: FeatureMeta(
      label: 'Tests',
      description: 'Record test results per student, view class performance, and export grade reports.',
      iconCodePoint: 0xe4c3, // Icons.quiz_rounded
      adminOnly: false,
    ),
    kLeaves: FeatureMeta(
      label: 'Leave Requests',
      description: 'Review and approve student leave requests submitted by students or parents.',
      iconCodePoint: 0xe23c, // Icons.event_note_rounded
      adminOnly: false,
    ),
    kFeeManagement: FeatureMeta(
      label: 'Fee Management',
      description: 'Track per-student fee records, mark payments, view outstanding balances, and generate monthly summaries.',
      iconCodePoint: 0xe263, // Icons.account_balance_wallet_rounded
      adminOnly: false,
    ),
    kDocuments: FeatureMeta(
      label: 'Document Storage',
      description: 'Store and manage staff and student documents including CVs, CNICs, contracts, and certificates.',
      iconCodePoint: 0xe1c0, // Icons.folder_rounded
      adminOnly: true,
    ),
  };

  // ── SharedPreferences key ─────────────────────────────────────────────────
  String _key(String schoolId, String sectionId, String featureKey) =>
      'feature_${schoolId}_${sectionId}_$featureKey';

  // ── Public API ────────────────────────────────────────────────────────────

  Future<bool> isEnabled(
      String schoolId, String sectionId, String featureKey) async {
    final prefs = await SharedPreferences.getInstance();
    final key = _key(schoolId, sectionId, featureKey);
    if (!prefs.containsKey(key)) {
      return _defaults[featureKey] ?? false;
    }
    return prefs.getBool(key) ?? (_defaults[featureKey] ?? false);
  }

  Future<void> setEnabled(
      String schoolId, String sectionId, String featureKey, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_key(schoolId, sectionId, featureKey), value);
  }

  Future<Map<String, bool>> getAll(
      String schoolId, String sectionId) async {
    final prefs = await SharedPreferences.getInstance();
    final result = <String, bool>{};
    for (final key in allFeatureKeys) {
      final prefKey = _key(schoolId, sectionId, key);
      result[key] = prefs.containsKey(prefKey)
          ? (prefs.getBool(prefKey) ?? (_defaults[key] ?? false))
          : (_defaults[key] ?? false);
    }
    return result;
  }

  // ── Firestore deletion on feature disable ─────────────────────────────────
  // Call this AFTER confirming with the user and receiving the "DELETE" confirmation.

  Future<void> deleteFeatureData(
      String schoolId, String sectionId, String featureKey,
      {bool isAdmin = false}) async {
    final db = FirebaseFirestore.instance;
    final base = 'schools/$schoolId/sections/$sectionId';

    switch (featureKey) {
      case kAttendance:
        await _deleteCollection(db, '$base/attendance_sessions');
        break;

      case kTimetable:
        await _deleteCollection(db, '$base/timetables');
        break;

      case kNotices:
        await _deleteCollection(db, '$base/notices');
        break;

      case kTests:
        // Loop all classes and delete their tests + results
        final classSnap =
            await db.collection('$base/classes').get();
        for (final classDoc in classSnap.docs) {
          final testsSnap = await db
              .collection('$base/classes/${classDoc.id}/tests')
              .get();
          for (final testDoc in testsSnap.docs) {
            await _deleteCollection(
                db, '$base/classes/${classDoc.id}/tests/${testDoc.id}/results');
            await testDoc.reference.delete();
          }
        }
        break;

      case kLeaves:
        await _deleteCollection(db, '$base/leaves');
        break;

      case kFeeManagement:
        await _deleteCollection(db, '$base/fees');
        break;

      case kDocuments:
        if (isAdmin) {
          await _deleteCollection(db, '$base/teacher_documents');
          await _deleteCollection(db, '$base/student_documents');
        }
        break;

      default:
        // Classes / Students / Teachers: structural data — no bulk delete here;
        // these are core data, disabling hides them from the UI only.
        break;
    }
  }

  // ── Batch-delete a collection (Firestore max 500/batch) ──────────────────
  Future<void> _deleteCollection(
      FirebaseFirestore db, String path) async {
    const int batchSize = 400;
    QuerySnapshot snap;
    do {
      snap = await db.collection(path).limit(batchSize).get();
      if (snap.docs.isEmpty) break;
      final batch = db.batch();
      for (final doc in snap.docs) {
        batch.delete(doc.reference);
      }
      await batch.commit();
    } while (snap.docs.length >= batchSize);
  }
}

// ── Feature metadata container ────────────────────────────────────────────
class FeatureMeta {
  final String label;
  final String description;
  final int iconCodePoint;
  final bool adminOnly;

  const FeatureMeta({
    required this.label,
    required this.description,
    required this.iconCodePoint,
    required this.adminOnly,
  });
}
