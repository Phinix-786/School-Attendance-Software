// lib/services/notification_service.dart
// In-memory + SharedPreferences notification list per school session.
// Admin notifications are keyed under `notifs_{schoolId}`.
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class AppNotification {
  final String id;
  final String title;
  final String body;
  final DateTime timestamp;
  final bool read;
  final String? actionType; // 'feature_request' | 'general'
  final Map<String, String> metadata; // e.g. {'featureKey': '...', 'requesterId': sectionId}

  const AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.timestamp,
    this.read = false,
    this.actionType,
    this.metadata = const {},
  });

  AppNotification copyWith({bool? read}) => AppNotification(
        id: id,
        title: title,
        body: body,
        timestamp: timestamp,
        read: read ?? this.read,
        actionType: actionType,
        metadata: metadata,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'timestamp': timestamp.millisecondsSinceEpoch,
        'read': read,
        'actionType': actionType,
        'metadata': metadata,
      };

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        id: j['id'] as String? ?? '',
        title: j['title'] as String? ?? '',
        body: j['body'] as String? ?? '',
        timestamp: j['timestamp'] != null
            ? DateTime.fromMillisecondsSinceEpoch(j['timestamp'] as int)
            : DateTime.now(),
        read: j['read'] as bool? ?? false,
        actionType: j['actionType'] as String?,
        metadata: Map<String, String>.from(j['metadata'] ?? {}),
      );
}

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  // In-memory cache — populated on first load
  final List<AppNotification> _notifs = [];
  bool _loaded = false;

  String _prefsKey(String schoolId) => 'notifs_$schoolId';

  // ── Load from SharedPreferences ──────────────────────────────────────────

  Future<void> _ensureLoaded(String schoolId) async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_prefsKey(schoolId)) ?? [];
    _notifs.clear();
    for (final s in raw) {
      try {
        _notifs.add(AppNotification.fromJson(
            jsonDecode(s) as Map<String, dynamic>));
      } catch (_) {
        // skip malformed entries
      }
    }
    _loaded = true;
  }

  Future<void> _persist(String schoolId) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = _notifs.map((n) => jsonEncode(n.toJson())).toList();
    await prefs.setStringList(_prefsKey(schoolId), encoded);
  }

  // ── Public API ────────────────────────────────────────────────────────────

  /// Reload from disk (call when switching sessions or when admin wants fresh data).
  void invalidateCache() => _loaded = false;

  Future<void> addNotification(
      String schoolId, AppNotification notification) async {
    await _ensureLoaded(schoolId);
    // Prepend so newest shows first
    _notifs.insert(0, notification);
    // Cap at 100 entries to keep pref file manageable
    if (_notifs.length > 100) _notifs.removeRange(100, _notifs.length);
    await _persist(schoolId);
  }

  Future<List<AppNotification>> getAll(String schoolId) async {
    await _ensureLoaded(schoolId);
    return List.unmodifiable(_notifs);
  }

  Future<void> markRead(String schoolId, String id) async {
    await _ensureLoaded(schoolId);
    final idx = _notifs.indexWhere((n) => n.id == id);
    if (idx == -1) return;
    _notifs[idx] = _notifs[idx].copyWith(read: true);
    await _persist(schoolId);
  }

  Future<void> markAllRead(String schoolId) async {
    await _ensureLoaded(schoolId);
    for (int i = 0; i < _notifs.length; i++) {
      _notifs[i] = _notifs[i].copyWith(read: true);
    }
    await _persist(schoolId);
  }

  Future<void> clearAll(String schoolId) async {
    _notifs.clear();
    _loaded = true;
    await _persist(schoolId);
  }

  int unreadCount(String schoolId) =>
      _notifs.where((n) => !n.read).length;
}
