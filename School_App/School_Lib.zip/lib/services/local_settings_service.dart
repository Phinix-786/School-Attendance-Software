// lib/services/local_settings_service.dart
// Stores personalisation + security config locally in:
//   %LOCALAPPDATA%\SchoolAttendance\Personalisation\settings.json
//   %LOCALAPPDATA%\SchoolAttendance\Personalisation\themes\{name}.json
//   %LOCALAPPDATA%\SchoolAttendance\Security\lock.json
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import '../models/local_models.dart';

/// Global notifier — any widget can listen for settings changes without
/// needing to reload from disk. Updated by [LocalSettingsService.saveSettings].
final settingsNotifier = ValueNotifier<AppSettings>(const AppSettings());

class LocalSettingsService {
  LocalSettingsService._();
  static final LocalSettingsService instance = LocalSettingsService._();

  // ── Directory resolution ─────────────────────────────────────────────────

  Directory _baseDir() {
    final localAppData = Platform.environment['LOCALAPPDATA'];
    if (localAppData != null && localAppData.isNotEmpty) {
      return Directory('$localAppData\\SchoolAttendance');
    }
    // Fallback for non-Windows / missing env
    final home = Platform.environment['HOME'] ??
        Platform.environment['USERPROFILE'] ??
        '.';
    return Directory('$home/.SchoolAttendance');
  }

  Directory _personalisationDir() =>
      Directory('${_baseDir().path}\\Personalisation');

  Directory _themesDir() =>
      Directory('${_personalisationDir().path}\\themes');

  Directory _securityDir() => Directory('${_baseDir().path}\\Security');

  File _settingsFile() =>
      File('${_personalisationDir().path}\\settings.json');

  File _lockFile() => File('${_securityDir().path}\\lock.json');

  File _themeFile(String name) =>
      File('${_themesDir().path}\\${_sanitize(name)}.json');

  String _sanitize(String name) =>
      name.replaceAll(RegExp(r'[^\w\-]'), '_');

  Future<void> _ensureDirs() async {
    await _personalisationDir().create(recursive: true);
    await _themesDir().create(recursive: true);
    await _securityDir().create(recursive: true);
  }

  // ── AppSettings ──────────────────────────────────────────────────────────

  Future<AppSettings> loadSettings() async {
    try {
      final file = _settingsFile();
      if (!await file.exists()) return const AppSettings();
      final raw = await file.readAsString();
      final json = jsonDecode(raw) as Map<String, dynamic>;
      return AppSettings.fromJson(json);
    } catch (_) {
      return const AppSettings();
    }
  }

  Future<void> saveSettings(AppSettings settings) async {
    await _ensureDirs();
    await _settingsFile()
        .writeAsString(const JsonEncoder.withIndent('  ').convert(settings.toJson()));
    // Notify all listeners immediately so the shell reacts without a restart.
    settingsNotifier.value = settings;
  }

  // ── CustomThemes ─────────────────────────────────────────────────────────

  Future<List<CustomTheme>> loadThemes() async {
    try {
      final dir = _themesDir();
      if (!await dir.exists()) return [];
      final files = dir.listSync().whereType<File>().where(
            (f) => f.path.endsWith('.json'),
          );
      final themes = <CustomTheme>[];
      for (final f in files) {
        try {
          final raw = await f.readAsString();
          final json = jsonDecode(raw) as Map<String, dynamic>;
          themes.add(CustomTheme.fromJson(json));
        } catch (_) {
          // skip corrupt theme file
        }
      }
      return themes;
    } catch (_) {
      return [];
    }
  }

  Future<void> saveTheme(CustomTheme theme) async {
    await _ensureDirs();
    await _themeFile(theme.name)
        .writeAsString(const JsonEncoder.withIndent('  ').convert(theme.toJson()));
  }

  Future<void> deleteTheme(String name) async {
    final file = _themeFile(name);
    if (await file.exists()) await file.delete();
  }

  // ── LockConfig ───────────────────────────────────────────────────────────

  Future<LockConfig> loadLockConfig() async {
    try {
      final file = _lockFile();
      if (!await file.exists()) return const LockConfig();
      final raw = await file.readAsString();
      final json = jsonDecode(raw) as Map<String, dynamic>;
      return LockConfig.fromJson(json);
    } catch (_) {
      return const LockConfig();
    }
  }

  Future<void> saveLockConfig(LockConfig config) async {
    await _ensureDirs();
    await _lockFile()
        .writeAsString(const JsonEncoder.withIndent('  ').convert(config.toJson()));
  }

  // ── SHA-256 helper (dart:convert only — no crypto package) ──────────────
  // Uses base64(utf8(value)) as a simple local-only hash.
  static String hashPin(String value) {
    // We use a simple deterministic digest acceptable for local lock only.
    // Algorithm: UTF-8 encode → multiple SHA-like rounds via base64 chaining.
    // For stronger security on a real device, replace with pointycastle.
    final bytes = utf8.encode(value);
    // Two rounds of base64 encoding interleaved with length mixing
    final round1 = base64Encode(bytes);
    final round2 = base64Encode(utf8.encode('ELV_LOCK_$round1${bytes.length}'));
    return round2;
  }

  static bool verifyPin(String input, String storedHash) =>
      hashPin(input) == storedHash;
}
