// lib/services/hq_message_service.dart  (School app)
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:local_notifier/local_notifier.dart';

class HqMessage {
  final String  id;
  final String  type;
  final String  message;
  final String? version;

  const HqMessage({
    required this.id,
    required this.type,
    required this.message,
    this.version,
  });

  factory HqMessage.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data()!;
    return HqMessage(
      id:      doc.id,
      type:    d['type']    as String? ?? 'notice',
      message: d['message'] as String? ?? '',
      version: d['version'] as String?,
    );
  }
}

class HqMessageService {
  HqMessageService._();
  static final HqMessageService instance = HqMessageService._();

  final ValueNotifier<HqMessage?> activeBanner    = ValueNotifier(null);
  final ValueNotifier<bool>       updateAvailable = ValueNotifier(false);

  String? _schoolId;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _sub;
  Timer?  _bannerTimer;
  final   _noticeQueue        = <HqMessage>[];
  bool    _updateBannerActive = false;

  void init(String schoolId) {
    _schoolId = schoolId;
    _sub?.cancel();
    _sub = FirebaseFirestore.instance
        .collection('schools/$schoolId/hq_messages')
        .orderBy('createdAt')
        .snapshots()
        .listen(_onSnapshot,
            onError: (e) => debugPrint('[HQ] stream error $e'));
  }

  void dispose() {
    _sub?.cancel();
    _bannerTimer?.cancel();
    activeBanner.dispose();
    updateAvailable.dispose();
  }

  void _onSnapshot(QuerySnapshot<Map<String, dynamic>> snap) {
    for (final change in snap.docChanges) {
      if (change.type == DocumentChangeType.added) {
        _handle(HqMessage.fromDoc(change.doc));
      }
    }
  }

  void _handle(HqMessage msg) {
    switch (msg.type) {
      case 'update':
        _showUpdateBanner(msg);
        break;
      case 'notice':
        if (_updateBannerActive) {
          _noticeQueue.add(msg);
        } else {
          _showNoticeBanner(msg);
        }
        break;
      case 'notification':
        _showWindowsNotification(msg);
        break;
    }
  }

  // ── Real Windows notification panel toast ─────────────────
  Future<void> _showWindowsNotification(HqMessage msg) async {
    final notif = LocalNotification(
      identifier: msg.id,
      title:      'Message from HQ',
      body:       msg.message,
    );
    await notif.show();
    _deleteMessage(msg.id);
  }

  // ── Update banner — 1 min auto-dismiss ───────────────────
  void _showUpdateBanner(HqMessage msg) {
    _bannerTimer?.cancel();
    _updateBannerActive   = true;
    updateAvailable.value = true;
    activeBanner.value    = msg;
    _bannerTimer = Timer(const Duration(minutes: 1),
        () => _dismissBanner(msg, autoExpired: true));
  }

  // ── Notice banner — 2 min auto-dismiss ───────────────────
  void _showNoticeBanner(HqMessage msg) {
    _bannerTimer?.cancel();
    activeBanner.value = msg;
    _bannerTimer = Timer(const Duration(minutes: 2),
        () => _dismissBanner(msg, autoExpired: true));
  }

  void dismissBanner() {
    final current = activeBanner.value;
    if (current != null) _dismissBanner(current, autoExpired: false);
  }

  void _dismissBanner(HqMessage msg, {required bool autoExpired}) {
    _bannerTimer?.cancel();
    activeBanner.value = null;
    if (msg.type == 'update') _updateBannerActive = false;
    _deleteMessage(msg.id);
    if (_noticeQueue.isNotEmpty) {
      _showNoticeBanner(_noticeQueue.removeAt(0));
    }
  }

  void clearUpdateDot() => updateAvailable.value = false;

  void _deleteMessage(String messageId) {
    if (_schoolId == null) return;
    FirebaseFirestore.instance
        .collection('schools/$_schoolId/hq_messages')
        .doc(messageId)
        .delete()
        .catchError((e) => debugPrint('[HQ] delete error $e'));
  }
}