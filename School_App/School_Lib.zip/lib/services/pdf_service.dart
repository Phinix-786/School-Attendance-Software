// lib/services/pdf_service.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/models.dart';
import 'school_firebase_service.dart';

class PdfService {
  static Future<Uint8List> generateAttendanceReport({
    required String            schoolName,
    required String            sectionId,
    required String            className,
    required DateTime          startDate,
    required DateTime          endDate,
    required List<Student>     students,
    required List<AttendanceExportRow> rows,
    required Map<String, String> studentMap,
  }) async {
    final doc = pw.Document();

    final headerColor = PdfColor.fromHex('#001858');
    final altRow      = PdfColor.fromHex('#F8F9FB');
    final presentCol  = PdfColor.fromHex('#16A34A');
    final absentCol   = PdfColor.fromHex('#E53E6B');
    final lateCol     = PdfColor.fromHex('#F59E0B');

    // Sort rows by date then by studentId
    final sorted = [...rows]
      ..sort((a, b) {
        final dc = a.date.compareTo(b.date);
        return dc != 0 ? dc : a.studentId.compareTo(b.studentId);
      });

    String fmt(DateTime d) => '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year}';
    String statusLabel(AttendanceStatus s) {
      switch (s) {
        case AttendanceStatus.present: return 'Present';
        case AttendanceStatus.absent:  return 'Absent';
        case AttendanceStatus.late:    return 'Late';
      }
    }

    PdfColor statusColor(AttendanceStatus s) {
      switch (s) {
        case AttendanceStatus.present: return presentCol;
        case AttendanceStatus.absent:  return absentCol;
        case AttendanceStatus.late:    return lateCol;
      }
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin:     const pw.EdgeInsets.all(32),
        build: (context) {
          return [
            // ── Header ──
            pw.Container(
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(
                color:        headerColor,
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Row(
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          schoolName,
                          style: pw.TextStyle(
                              color:      PdfColors.white,
                              fontSize:   18,
                              fontWeight: pw.FontWeight.bold),
                        ),
                        pw.SizedBox(height: 4),
                        pw.Text(
                          'Attendance Report — $className',
                          style: pw.TextStyle(
                              color: PdfColors.white, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Text(
                        '${fmt(startDate)} – ${fmt(endDate)}',
                        style: pw.TextStyle(
                            color: PdfColors.white, fontSize: 11),
                      ),
                      pw.SizedBox(height: 2),
                      pw.Text(
                        'Section: $sectionId',
                        style: pw.TextStyle(
                            color: PdfColors.white, fontSize: 10),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            pw.SizedBox(height: 16),

            // ── Summary row ──
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              children: [
                _summaryChip('Total Records', '${sorted.length}',
                    PdfColor.fromHex('#6366F1')),
                pw.SizedBox(width: 12),
                _summaryChip('Students', '${students.length}', headerColor),
                pw.SizedBox(width: 12),
                _summaryChip('Present',
                    '${sorted.where((r) => r.status == AttendanceStatus.present).length}',
                    presentCol),
                pw.SizedBox(width: 12),
                _summaryChip('Absent',
                    '${sorted.where((r) => r.status == AttendanceStatus.absent).length}',
                    absentCol),
                pw.SizedBox(width: 12),
                _summaryChip('Late',
                    '${sorted.where((r) => r.status == AttendanceStatus.late).length}',
                    lateCol),
              ],
            ),

            pw.SizedBox(height: 16),

            // ── Table ──
            pw.Table(
              border:          pw.TableBorder.all(
                  color: PdfColor.fromHex('#E8EEF4'), width: 0.5),
              columnWidths: const {
                0: pw.FlexColumnWidth(2.8),
                1: pw.FlexColumnWidth(1.5),
                2: pw.FlexColumnWidth(1.2),
              },
              children: [
                // Header row
                pw.TableRow(
                  decoration: pw.BoxDecoration(color: headerColor),
                  children: [
                    _hCell('Student Name'),
                    _hCell('Date'),
                    _hCell('Status'),
                  ],
                ),
                // Data rows
                ...sorted.asMap().entries.map((entry) {
                  final idx = entry.key;
                  final row = entry.value;
                  final name = studentMap[row.studentId] ?? row.studentId;
                  final bg   = idx.isOdd ? altRow : PdfColors.white;
                  final sc   = statusColor(row.status);
                  return pw.TableRow(
                    decoration: pw.BoxDecoration(color: bg),
                    children: [
                      _dCell(name),
                      _dCell(fmt(row.date)),
                      pw.Padding(
                        padding: const pw.EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6),
                        child: pw.Container(
                          padding: const pw.EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: pw.BoxDecoration(
                            color:        PdfColor(sc.red, sc.green, sc.blue, 0.12),
                            borderRadius: pw.BorderRadius.circular(4),
                          ),
                          child: pw.Text(
                            statusLabel(row.status),
                            style: pw.TextStyle(
                                color:      sc,
                                fontSize:   9,
                                fontWeight: pw.FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  );
                }),
              ],
            ),

            pw.SizedBox(height: 16),
            pw.Text(
              'Generated by App_Name School Management System',
              style: pw.TextStyle(
                  color: PdfColor.fromHex('#8896AA'), fontSize: 9),
            ),
          ];
        },
      ),
    );

    return doc.save();
  }

  static pw.Widget _summaryChip(String label, String value, PdfColor color) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: pw.BoxDecoration(
        color:        PdfColor(color.red, color.green, color.blue, 0.1),
        borderRadius: pw.BorderRadius.circular(6),
        border: pw.Border.all(
            color: PdfColor(color.red, color.green, color.blue, 0.3),
            width: 0.5),
      ),
      child: pw.Column(
        children: [
          pw.Text(value,
              style: pw.TextStyle(
                  color: color, fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.Text(label,
              style: pw.TextStyle(
                  color: PdfColor.fromHex('#8896AA'), fontSize: 8)),
        ],
      ),
    );
  }

  static pw.Widget _hCell(String text) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        child: pw.Text(text,
            style: pw.TextStyle(
                color:      PdfColors.white,
                fontSize:   10,
                fontWeight: pw.FontWeight.bold)),
      );

  static pw.Widget _dCell(String text) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: pw.Text(text,
            style: pw.TextStyle(
                color: PdfColor.fromHex('#001858'), fontSize: 9.5)),
      );

  // ── Save bytes to file ────────────────────────────────────
  /// Saves the PDF to the user's Documents folder (or Downloads on
  /// Windows if Documents is unavailable). Returns the saved path on
  /// success, or null if the write failed.
  ///
  /// Uses path_provider — no file picker dialog needed; the file is
  /// saved silently and the caller shows the path in a snackbar.
  static Future<String?> saveToFile(
      Uint8List bytes, String suggestedName) async {
    try {
      // Try Documents first, fall back to app support dir
      Directory dir;
      if (Platform.isWindows) {
        final home = Platform.environment['USERPROFILE'] ?? '';
        final docs = Directory('$home\\Documents');
        dir = docs.existsSync() ? docs : await getApplicationSupportDirectory();
      } else {
        dir = await getApplicationDocumentsDirectory();
      }

      final name = suggestedName.endsWith('.pdf')
          ? suggestedName
          : '$suggestedName.pdf';
      final file = File(p.join(dir.path, name));
      await file.writeAsBytes(bytes);
      return file.path;
    } catch (_) {
      return null;
    }
  }

  // ── Test Results PDF — single student ─────────────────────
  static Future<Uint8List> generateStudentTestReport({
    required String          schoolName,
    required String          sectionId,
    required String          className,
    required Student         student,
    required List<SchoolTest>  tests,
    required Map<String, TestResult?> resultMap,
  }) async {
    final doc         = pw.Document();
    final headerColor = PdfColor.fromHex('#001858');
    final altRow      = PdfColor.fromHex('#F8F9FB');
    final passCol     = PdfColor.fromHex('#16A34A');
    final failCol     = PdfColor.fromHex('#E53E6B');
    final midCol      = PdfColor.fromHex('#F59E0B');
    final absentCol   = PdfColor.fromHex('#F59E0B');

    String fmt(DateTime d) =>
        '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

    int totalTests    = tests.length;
    int attempted     = 0;
    int absentCount   = 0;
    double totalPct   = 0;

    for (final t in tests) {
      final r = resultMap[t.id];
      if (r != null) {
        if (r.wasAbsent) { absentCount++; }
        else { attempted++; totalPct += r.percentage; }
      }
    }
    final avgPct = attempted > 0 ? totalPct / attempted : 0.0;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin:     const pw.EdgeInsets.all(32),
        build: (ctx) => [
          // Header
          pw.Container(
            padding: const pw.EdgeInsets.all(16),
            decoration: pw.BoxDecoration(
                color: headerColor,
                borderRadius: pw.BorderRadius.circular(8)),
            child: pw.Row(
              children: [
                pw.Expanded(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(schoolName,
                          style: pw.TextStyle(
                              color: PdfColors.white,
                              fontSize: 18,
                              fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 4),
                      pw.Text('Test Results Report — $className',
                          style: pw.TextStyle(
                              color: PdfColors.white, fontSize: 12)),
                    ],
                  ),
                ),
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text(student.name,
                        style: pw.TextStyle(
                            color: PdfColors.white,
                            fontSize: 13,
                            fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 2),
                    pw.Text('Roll: ${student.rollNo}',
                        style: pw.TextStyle(
                            color: PdfColors.white, fontSize: 10)),
                    pw.Text('Section: $sectionId',
                        style: pw.TextStyle(
                            color: PdfColors.white, fontSize: 10)),
                  ],
                ),
              ],
            ),
          ),
          pw.SizedBox(height: 14),

          // Summary chips
          pw.Row(
            children: [
              _summaryChip('Total Tests',  '$totalTests',  headerColor),
              pw.SizedBox(width: 10),
              _summaryChip('Attempted',    '$attempted',   passCol),
              pw.SizedBox(width: 10),
              _summaryChip('Absent',       '$absentCount', absentCol),
              pw.SizedBox(width: 10),
              _summaryChip('Average',
                  '${avgPct.toStringAsFixed(1)}%',
                  avgPct >= 60 ? passCol : failCol),
            ],
          ),
          pw.SizedBox(height: 16),

          // Table
          pw.Table(
            border: pw.TableBorder.all(
                color: PdfColor.fromHex('#E8EEF4'), width: 0.5),
            columnWidths: const {
              0: pw.FlexColumnWidth(2.5),
              1: pw.FlexColumnWidth(1.5),
              2: pw.FlexColumnWidth(1.2),
              3: pw.FlexColumnWidth(1.2),
              4: pw.FlexColumnWidth(1.0),
            },
            children: [
              pw.TableRow(
                decoration: pw.BoxDecoration(color: headerColor),
                children: [
                  _hCell('Test / Subject'),
                  _hCell('Test Date'),
                  _hCell('Marks'),
                  _hCell('Percentage'),
                  _hCell('Status'),
                ],
              ),
              ...tests.asMap().entries.map((e) {
                final idx    = e.key;
                final test   = e.value;
                final result = resultMap[test.id];
                final bg     = idx.isOdd ? altRow : PdfColors.white;

                String marksStr = '—';
                String pctStr   = '—';
                String status   = 'Not Submitted';
                PdfColor statusColor = PdfColor.fromHex('#8896AA');

                if (result != null) {
                  if (result.wasAbsent) {
                    status      = 'Absent';
                    statusColor = absentCol;
                  } else {
                    marksStr    = '${result.marksObtained}/${result.marksTotal}';
                    pctStr      = '${result.percentage.toStringAsFixed(1)}%';
                    status      = result.percentage >= 50 ? 'Pass' : 'Fail';
                    statusColor = result.percentage >= 80
                        ? passCol
                        : result.percentage >= 50
                            ? midCol
                            : failCol;
                  }
                }

                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: bg),
                  children: [
                    _dCell('${test.topic} (${test.subject})'),
                    _dCell(fmt(test.testDate)),
                    _dCell(marksStr),
                    _dCell(pctStr),
                    pw.Padding(
                      padding: const pw.EdgeInsets.symmetric(
                          horizontal: 8, vertical: 6),
                      child: pw.Container(
                        padding: const pw.EdgeInsets.symmetric(
                            horizontal: 5, vertical: 2),
                        decoration: pw.BoxDecoration(
                          color: PdfColor(statusColor.red,
                              statusColor.green, statusColor.blue, 0.12),
                          borderRadius: pw.BorderRadius.circular(4),
                        ),
                        child: pw.Text(status,
                            style: pw.TextStyle(
                                color:      statusColor,
                                fontSize:   8,
                                fontWeight: pw.FontWeight.bold)),
                      ),
                    ),
                  ],
                );
              }),
            ],
          ),
          pw.SizedBox(height: 14),
          pw.Text('Generated by App_Name School Management System',
              style: pw.TextStyle(
                  color: PdfColor.fromHex('#8896AA'), fontSize: 9)),
        ],
      ),
    );
    return doc.save();
  }

  // ── Test Results PDF — entire class (all students) ─────────
  static Future<Uint8List> generateClassTestReport({
    required String                          schoolName,
    required String                          sectionId,
    required String                          className,
    required List<SchoolTest>                tests,
    required List<Student>                   students,
    required Map<String, Map<String, TestResult?>> studentResultMap,
    // outer key = studentId, inner key = testId
  }) async {
    final doc         = pw.Document();
    final headerColor = PdfColor.fromHex('#001858');
    final altRow      = PdfColor.fromHex('#F8F9FB');
    final passCol     = PdfColor.fromHex('#16A34A');
    final failCol     = PdfColor.fromHex('#E53E6B');
    final midCol      = PdfColor.fromHex('#F59E0B');

    String fmt(DateTime d) =>
        '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

    doc.addPage(
      pw.MultiPage(
        pageFormat:   PdfPageFormat.a4.landscape,
        margin:       const pw.EdgeInsets.all(28),
        build: (ctx) => [
          // Header
          pw.Container(
            padding: const pw.EdgeInsets.all(14),
            decoration: pw.BoxDecoration(
                color: headerColor,
                borderRadius: pw.BorderRadius.circular(8)),
            child: pw.Row(
              children: [
                pw.Expanded(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(schoolName,
                          style: pw.TextStyle(
                              color: PdfColors.white,
                              fontSize: 16,
                              fontWeight: pw.FontWeight.bold)),
                      pw.SizedBox(height: 3),
                      pw.Text('Class Test Results — $className',
                          style: pw.TextStyle(
                              color: PdfColors.white, fontSize: 11)),
                    ],
                  ),
                ),
                pw.Text('Section: $sectionId',
                    style: pw.TextStyle(
                        color: PdfColor(1, 1, 1, 0.7), fontSize: 10)),
              ],
            ),
          ),
          pw.SizedBox(height: 14),

          // Table: rows = students, columns = tests
          pw.Table(
            border: pw.TableBorder.all(
                color: PdfColor.fromHex('#E8EEF4'), width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(2.2),
              for (int i = 0; i < tests.length; i++)
                i + 1: const pw.FlexColumnWidth(1.1),
            },
            children: [
              // Header row
              pw.TableRow(
                decoration: pw.BoxDecoration(color: headerColor),
                children: [
                  _hCell('Student'),
                  ...tests.map((t) => _hCell(
                      '${t.subject}\n${fmt(t.testDate)}')),
                ],
              ),
              // Student rows
              ...students.asMap().entries.map((e) {
                final idx     = e.key;
                final student = e.value;
                final results = studentResultMap[student.id] ?? {};
                final bg      = idx.isOdd ? altRow : PdfColors.white;

                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: bg),
                  children: [
                    _dCell('${student.name}\n(${student.rollNo})'),
                    ...tests.map((t) {
                      final r = results[t.id];
                      if (r == null) {
                        return pw.Padding(
                          padding: const pw.EdgeInsets.all(6),
                          child: pw.Text('—',
                              style: pw.TextStyle(
                                  color: PdfColor.fromHex('#8896AA'),
                                  fontSize: 8.5)),
                        );
                      }
                      if (r.wasAbsent) {
                        return pw.Padding(
                          padding: const pw.EdgeInsets.all(6),
                          child: pw.Text('Absent',
                              style: pw.TextStyle(
                                  color:      midCol,
                                  fontSize:   8,
                                  fontWeight: pw.FontWeight.bold)),
                        );
                      }
                      final pct   = r.percentage;
                      final color = pct >= 80
                          ? passCol
                          : pct >= 50 ? midCol : failCol;
                      return pw.Padding(
                        padding: const pw.EdgeInsets.all(6),
                        child: pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Text(
                                '${r.marksObtained}/${r.marksTotal}',
                                style: pw.TextStyle(
                                    color:      color,
                                    fontSize:   9,
                                    fontWeight: pw.FontWeight.bold)),
                            pw.Text(
                                '${pct.toStringAsFixed(0)}%',
                                style: pw.TextStyle(
                                    color:    color,
                                    fontSize: 7.5)),
                          ],
                        ),
                      );
                    }),
                  ],
                );
              }),
            ],
          ),
          pw.SizedBox(height: 12),
          pw.Text('Generated by App_Name School Management System',
              style: pw.TextStyle(
                  color: PdfColor.fromHex('#8896AA'), fontSize: 9)),
        ],
      ),
    );
    return doc.save();
  }
}
