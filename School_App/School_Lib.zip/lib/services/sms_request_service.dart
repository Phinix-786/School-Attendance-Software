import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/models.dart';

class SmsRequestService {
  static final _db = FirebaseFirestore.instance;

  static CollectionReference<Map<String, dynamic>> _col(String schoolId) =>
      _db.collection('schools/$schoolId/sms_requests');

  static String _todayKey() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  static Future<Set<String>> _alreadySentToday(String schoolId) async {
    final todayKey = _todayKey();
    final snap = await _db
        .collection('schools/$schoolId/sms_daily_records')
        .doc(todayKey)
        .get();
    if (!snap.exists || snap.data() == null) return {};
    final sentList = List<String>.from(snap.data()?['sentStudentIds'] ?? []);
    return sentList.toSet();
  }

  static Future<void> _markSentToday(
      String schoolId, List<String> studentIds) async {
    if (studentIds.isEmpty) return;
    final todayKey = _todayKey();
    final ref = _db
        .collection('schools/$schoolId/sms_daily_records')
        .doc(todayKey);

    final snap = await ref.get();
    final existing = snap.exists
        ? Set<String>.from(snap.data()?['sentStudentIds'] ?? [])
        : <String>{};
    existing.addAll(studentIds);

    await ref.set({
      'date': todayKey,
      'sentStudentIds': existing.toList(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // ── Main entry point ─────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> queueSmsRequests({
    required String schoolId,
    required String schoolName,
    required List<AttendanceRecord> absentRecords,
    required List<Student> students,
    List<SchoolClass> classes = const [],
  }) async {
    debugPrint('[SmsService] queueSmsRequests START — absentRecords=${absentRecords.length} students=${students.length} classes=${classes.length}');
    if (absentRecords.isEmpty) {
      debugPrint('[SmsService] absentRecords empty — returning early');
      return {'queued': 0, 'skipped': 0};
    }

    debugPrint('[SmsService] calling _alreadySentToday...');
    final alreadySent = await _alreadySentToday(schoolId);
    debugPrint('[SmsService] _alreadySentToday returned ${alreadySent.length} already-sent IDs');

    final Map<String, Student>     studentMap = {for (final s in students) s.id: s};
    final Map<String, SchoolClass> classMap   = {for (final c in classes)  c.id: c};

    final batch        = _db.batch();
    int    queued      = 0;
    int    skipped     = 0;
    final  dateStr     = _formattedDate();
    final  newlySentIds = <String>[];

    for (final record in absentRecords) {
      if (alreadySent.contains(record.studentId)) {
        debugPrint('[SmsService] skipping ${record.studentId} — already sent today');
        skipped++;
        continue;
      }

      final student = studentMap[record.studentId];
      if (student == null) {
        debugPrint('[SmsService] WARNING: no student found for id=${record.studentId}');
        continue;
      }

      final cleanPhone = _cleanPhone(student.parentPhone);
      if (cleanPhone.isEmpty) {
        debugPrint('[SmsService] WARNING: empty phone for student=${student.name}');
        continue;
      }

      final schoolClass = classMap[student.classId];
      final className   = schoolClass?.name    ?? '';
      final section     = schoolClass?.section ?? '';

      debugPrint('[SmsService] queuing SMS for student=${student.name} phone=$cleanPhone status=${record.status.name} lateMinutes=${record.lateMinutes}');

      final docRef = _col(schoolId).doc();
      batch.set(docRef, {
        'schoolId':         schoolId,
        'schoolName':       schoolName,
        'studentName':      student.name,
        'rollNo':           student.rollNo,
        'parentPhone':      cleanPhone,
        'attendanceStatus': record.status.name, // 'absent' | 'late'
        'className':        className,
        'section':          section,
        'date':             dateStr,
        'smsStatus':        'pending',
        'processed':        false,
        'createdAt':        FieldValue.serverTimestamp(),
        // Only written for late students — field is absent for absent records
        // so the SMS app knows to skip the {lateMinutes} placeholder.
        if (record.status == AttendanceStatus.late && record.lateMinutes != null)
          'lateMinutes': record.lateMinutes,
      });
      newlySentIds.add(record.studentId);
      queued++;
    }

    debugPrint('[SmsService] queued=$queued skipped=$skipped — about to commit batch...');
    if (queued > 0) {
      await batch.commit();
      debugPrint('[SmsService] batch.commit() done — calling _markSentToday...');
      await _markSentToday(schoolId, newlySentIds);
      debugPrint('[SmsService] _markSentToday done');
    }

    debugPrint('[SmsService] queueSmsRequests DONE — returning queued=$queued skipped=$skipped');
    return {'queued': queued, 'skipped': skipped};
  }

  static String _cleanPhone(String raw) =>
      raw.replaceAll(RegExp(r'[^\d]'), '');

  static String _formattedDate() {
    final now = DateTime.now();
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    return '${now.day} ${months[now.month - 1]} ${now.year}';
  }
}