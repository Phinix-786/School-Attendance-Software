// lib/backend_config.dart
// Image backend settings.  Keep this file out of version control
// (add to .gitignore) because it contains the API key.

/// Base URL of your Ubuntu backend.  No trailing slash.
const String kBackendBaseUrl = 'your-backend-url.com';

/// Must match App_Name_API_KEY in /etc/App_Name.env on the server.
const String kBackendApiKey  = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
