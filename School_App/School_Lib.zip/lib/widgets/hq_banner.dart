// lib/widgets/hq_banner.dart  (School app)
// Toast widget removed — notifications now go to Windows natively.
import 'package:flutter/material.dart';
import '../services/hq_message_service.dart';
import '../app_theme.dart';

class HqBanner extends StatelessWidget {
  const HqBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<HqMessage?>(
      valueListenable: HqMessageService.instance.activeBanner,
      builder: (context, msg, _) {
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          transitionBuilder: (child, anim) => SizeTransition(
            sizeFactor: anim,
            child:      FadeTransition(opacity: anim, child: child),
          ),
          child: msg == null
              ? const SizedBox.shrink(key: ValueKey('none'))
              : _BannerBar(key: ValueKey(msg.id), msg: msg),
        );
      },
    );
  }
}

class _BannerBar extends StatelessWidget {
  final HqMessage msg;
  const _BannerBar({super.key, required this.msg});

  @override
  Widget build(BuildContext context) {
    final isUpdate  = msg.type == 'update';
    final dark      = isDark(context);

    final bgColor = isUpdate
        ? (dark ? const Color(0xFF78350F).withValues(alpha: 0.85) : const Color(0xFFFEF3C7))
        : (dark ? const Color(0xFF0C2A4A) : const Color(0xFFE0F2FE));

    final textColor = isUpdate
        ? (dark ? const Color(0xFFFCD34D) : const Color(0xFF92400E))
        : (dark ? const Color(0xFF7DD3FC) : const Color(0xFF0369A1));

    final iconColor = isUpdate
        ? (dark ? const Color(0xFFFCD34D) : const Color(0xFFD97706))
        : (dark ? const Color(0xFF38BDF8) : const Color(0xFF0EA5E9));

    return Container(
      width:  double.infinity,
      decoration: BoxDecoration(
        color:  bgColor,
        border: Border(bottom: BorderSide(
            color: iconColor.withValues(alpha: 0.3))),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
      child: Row(
        children: [
          Icon(
            isUpdate ? Icons.system_update_rounded : Icons.campaign_rounded,
            color: iconColor, size: 16,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg.message,
              style: TextStyle(
                color:      textColor,
                fontSize:   12.5,
                fontWeight: FontWeight.w600,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: HqMessageService.instance.dismissBanner,
            child: Container(
              width:  22, height: 22,
              decoration: BoxDecoration(
                color:        iconColor.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Icon(Icons.close_rounded, color: iconColor, size: 13),
            ),
          ),
        ],
      ),
    );
  }
}