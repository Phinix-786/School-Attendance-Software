// lib/widgets/update_banner.dart
//
// A slim, non-intrusive banner that sits at the top of the sidebar
// and shows update progress. It disappears completely when idle.

import 'package:flutter/material.dart';
import '../services/auto_updater_service.dart';
import '../app_theme.dart';

class UpdateBanner extends StatelessWidget {
  const UpdateBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<UpdaterState>(
      valueListenable: AutoUpdaterService.instance.state,
      builder: (context, state, _) {
        if (state == UpdaterState.idle || state == UpdaterState.upToDate) return const SizedBox.shrink();

        return ValueListenableBuilder<double?>(
          valueListenable: AutoUpdaterService.instance.downloadProgress,
          builder: (context, progress, _) {
            return _BannerContent(state: state, progress: progress);
          },
        );
      },
    );
  }
}

class _BannerContent extends StatelessWidget {
  final UpdaterState state;
  final double?      progress;
  const _BannerContent({required this.state, required this.progress});

  @override
  Widget build(BuildContext context) {
    IconData icon;
    String   label;
    bool     showBar;

    switch (state) {
      case UpdaterState.checking:
        icon    = Icons.sync_rounded;
        label   = 'Checking for updates...';
        showBar = false;
        break;
      case UpdaterState.downloading:
        icon    = Icons.download_rounded;
        label   = 'Downloading update...';
        showBar = true;
        break;
      case UpdaterState.installing:
        icon    = Icons.system_update_rounded;
        label   = 'Installing update, app will restart...';
        showBar = false;
        break;
      default:
        icon    = Icons.check_circle_rounded;
        label   = '';
        showBar = false;
    }

    return Container(
      width:   double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color:  kNavy.withValues(alpha: 0.07),
        border: Border(bottom: BorderSide(color: cBorder(context))),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              (state == UpdaterState.checking ||
                      state == UpdaterState.downloading)
                  ? _SpinningIcon(icon: icon)
                  : Icon(icon, size: 13, color: kNavy),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color:      cNavy(context),
                    fontSize:   11.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              if (showBar && progress != null)
                Text(
                  '${(progress! * 100).toStringAsFixed(0)}%',
                  style: TextStyle(
                    color:      cMuted(context),
                    fontSize:   10.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 7),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: showBar && progress != null
                ? LinearProgressIndicator(
                    value:           progress,
                    minHeight:       4,
                    backgroundColor: cBorder(context),
                    valueColor:
                        const AlwaysStoppedAnimation<Color>(kNavy),
                  )
                : LinearProgressIndicator(
                    minHeight:       4,
                    backgroundColor: cBorder(context),
                    valueColor:
                        const AlwaysStoppedAnimation<Color>(kNavy),
                  ),
          ),
        ],
      ),
    );
  }
}

class _SpinningIcon extends StatefulWidget {
  final IconData icon;
  const _SpinningIcon({required this.icon});
  @override
  State<_SpinningIcon> createState() => _SpinningIconState();
}

class _SpinningIconState extends State<_SpinningIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync:    this,
      duration: const Duration(seconds: 1),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RotationTransition(
      turns: _ctrl,
      child: Icon(widget.icon, size: 13, color: kNavy),
    );
  }
}