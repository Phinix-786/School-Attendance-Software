// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:local_notifier/local_notifier.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_theme.dart';
import 'screens/login_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/main_shell.dart';
import 'screens/app_lock_screen.dart';
import 'services/auto_updater_service.dart';
import 'services/local_settings_service.dart';
import 'models/local_models.dart';

const firebaseOptions = FirebaseOptions(
  apiKey:            'AIzaSyBHoNsCHbBhYYeEenJyjLEbKk0EP22kbV0',
  authDomain:        'school-saas-pk.firebaseapp.com',
  projectId:         'school-saas-pk',
  storageBucket:     'school-saas-pk.firebasestorage.app',
  messagingSenderId: '620118270209',
  appId:             '1:620118270209:web:5532c261aa539f3e5dbb00',
);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: firebaseOptions);

  await localNotifier.setup(
    appName:        'App_Name Attendance',
    shortcutPolicy: ShortcutPolicy.requireCreate,
  );

  AutoUpdaterService.instance.init();

  final prefs           = await SharedPreferences.getInstance();
  final savedSchoolId   = prefs.getString('schoolId');
  final savedSchoolName = prefs.getString('schoolName');
  final savedSectionId  = prefs.getString('sectionId');
  final savedSectionName = prefs.getString('sectionName');
  final savedIsAdmin    = prefs.getBool('isAdmin') ?? false;
  final hasSeenWelcome  = prefs.getBool('hasSeenWelcome') ?? false;

  Widget home;

  if (savedSchoolId == null) {
    home = const LoginScreen();
  } else if (savedIsAdmin) {
    // Admin login — no section required
    final isValid = await _validateSchool(savedSchoolId);
    if (!isValid) {
      await _clearPrefs(prefs);
      home = const LoginScreen();
    } else if (!hasSeenWelcome) {
      home = WelcomeScreen(
        schoolId:    savedSchoolId,
        schoolName:  savedSchoolName ?? '',
        sectionId:   '',
        sectionName: 'Admin',
        isAdmin:     true,
      );
    } else {
      home = await _gatedShell(MainShell(
        schoolId:    savedSchoolId,
        schoolName:  savedSchoolName ?? '',
        sectionId:   '',
        sectionName: 'Admin',
        isAdmin:     true,
      ));
    }
  } else {
    // Section login
    if (savedSectionId == null) {
      home = const LoginScreen();
    } else {
      final isValid = await _validateSession(savedSchoolId, savedSectionId);
      if (!isValid) {
        await _clearPrefs(prefs);
        home = const LoginScreen();
      } else if (!hasSeenWelcome) {
        home = WelcomeScreen(
          schoolId:    savedSchoolId,
          schoolName:  savedSchoolName ?? '',
          sectionId:   savedSectionId,
          sectionName: savedSectionName ?? '',
          isAdmin:     false,
        );
      } else {
        home = await _gatedShell(MainShell(
          schoolId:    savedSchoolId,
          schoolName:  savedSchoolName ?? '',
          sectionId:   savedSectionId,
          sectionName: savedSectionName ?? '',
          isAdmin:     false,
        ));
      }
    }
  }

  runApp(SchoolDesktopApp(home: home));
}

/// Wraps a MainShell with lock screen and/or privacy consent if needed.
/// Called instead of using MainShell directly when restoring a session.
Future<Widget> _gatedShell(Widget shell) async {
  final lockConfig = await LocalSettingsService.instance.loadLockConfig();
  // Privacy consent is not required for the school desktop app.
  Widget dest = shell;

  if (lockConfig.enabled && lockConfig.hashValue.isNotEmpty) {
    // Wrap in a navigator-less lock screen that calls onUnlocked
    return _LockGate(lockConfig: lockConfig, child: dest);
  }
  return dest;
}

/// StatefulWidget that shows AppLockScreen and replaces itself with [child]
/// once the user unlocks. No Navigator needed — just swaps widgets.
class _LockGate extends StatefulWidget {
  final LockConfig lockConfig;
  final Widget     child;
  const _LockGate({required this.lockConfig, required this.child});
  @override
  State<_LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<_LockGate> {
  bool _unlocked = false;
  @override
  Widget build(BuildContext context) {
    if (_unlocked) return widget.child;
    return AppLockScreen(
      lockConfig: widget.lockConfig,
      onUnlocked: () => setState(() => _unlocked = true),
    );
  }
}

Future<void> _clearPrefs(SharedPreferences prefs) async {
  await prefs.remove('schoolId');
  await prefs.remove('schoolName');
  await prefs.remove('sectionId');
  await prefs.remove('sectionName');
  await prefs.remove('isAdmin');
  await prefs.remove('hasSeenWelcome');
}

Future<bool> _validateSchool(String schoolId) async {
  try {
    final doc = await FirebaseFirestore.instance
        .collection('schools')
        .doc(schoolId)
        .get();
    if (!doc.exists) return false;
    return doc.data()?['isActive'] == true;
  } catch (_) {
    return true;
  }
}

Future<bool> _validateSession(String schoolId, String sectionId) async {
  try {
    final schoolDoc = await FirebaseFirestore.instance
        .collection('schools')
        .doc(schoolId)
        .get();

    if (!schoolDoc.exists) return false;
    final data = schoolDoc.data()!;
    if (data['isActive'] != true) return false;

    final sectionDoc = await FirebaseFirestore.instance
        .collection('schools/$schoolId/sections')
        .doc(sectionId)
        .get();

    return sectionDoc.exists;
  } catch (_) {
    return true;
  }
}

class SchoolDesktopApp extends StatefulWidget {
  final Widget home;
  const SchoolDesktopApp({super.key, required this.home});

  @override
  State<SchoolDesktopApp> createState() => _SchoolDesktopAppState();
}

class _SchoolDesktopAppState extends State<SchoolDesktopApp> {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        title:                      'App_Name Attendance',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme:     lightThemeData,
        darkTheme: darkThemeData,
        home:      widget.home,
      ),
    );
  }
}
